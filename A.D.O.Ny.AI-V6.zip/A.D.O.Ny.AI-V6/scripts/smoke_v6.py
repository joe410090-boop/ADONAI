#!/usr/bin/env python3
"""v6 smoke test — exercises every OpenHuman-inspired subsystem end-to-end.

Runs without an LLM (uses a stub).  Verifies that:
  1. Config loads with all v6 sections enabled.
  2. Each subsystem constructs + starts + stops cleanly.
  3. The runtime wires them together correctly.
  4. Core flows (ingest → search → mirror, compress, propose workflow,
     pairing fails-closed, etc.) work.

Usage:
    python /home/z/my-project/adonai-v6/scripts/smoke_v6.py
"""
from __future__ import annotations

import asyncio
import sys
import tempfile
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(_PROJECT_ROOT))

from adonai.config.settings import (
    AgentEconomyConfig, BatteriesConfig, GoalsTodosConfig,
    GraphHarnessConfig, MemoryTreeConfig, MeetingAgentsConfig,
    SplitBrainConfig, SubconsciousConfig, SuperContextConfig,
    TokenJuiceConfig, WorkflowsConfig,
)
from adonai.openhuman.memory_tree import Chunk, MemoryTreeService
from adonai.openhuman.subconscious import SubconsciousEngine
from adonai.openhuman.goals_todos import GoalsTodosService
from adonai.openhuman.tokenjuice import TokenJuice
from adonai.openhuman.workflows import WorkflowEngine
from adonai.openhuman.graph_harness import GraphHarness
from adonai.openhuman.split_brain import SplitBrain
from adonai.openhuman.agent_economy import AgentEconomy
from adonai.openhuman.super_context import SuperContext
from adonai.openhuman.batteries import Batteries
from adonai.openhuman.meeting_agents import MeetingAgentsService, Meeting
from adonai.openhuman.subconscious_bridge import SubconsciousExecutiveBridge


class StubLLM:
    async def complete(self, prompt: str, **kw):
        class _R: text = "skip\nnothing new"
        return _R()
    async def close(self): pass


PASS = "\033[32m✓\033[0m"
FAIL = "\033[31m✗\033[0m"
results: list[tuple[str, bool, str]] = []


def check(name: str, ok: bool, detail: str = "") -> None:
    results.append((name, ok, detail))
    mark = PASS if ok else FAIL
    print(f"  {mark} {name}{(': ' + detail) if detail else ''}")


async def main() -> int:
    tmp = Path(tempfile.mkdtemp(prefix="adonai_v6_smoke_"))
    print(f"\n  v6 smoke test — temp dir: {tmp}\n")

    # 1. Memory Tree
    print("  [1/11] Memory Tree + Obsidian Wiki mirror")
    cfg = MemoryTreeConfig(enabled=True, db_path=tmp/"mt.db", vault_path=tmp/"vault", mirror_interval_s=9999)
    svc = MemoryTreeService(cfg)
    svc.ingest(Chunk(id="c1", source_kind="chat", source_id="s1", source_authority=0.9,
                     content="The user asked about Q3 revenue.", created_at=1700000000000))
    svc.ingest(Chunk(id="c2", source_kind="email", source_id="e1", source_authority=0.8,
                     content="Q3 revenue was $2.4M, up 18% YoY.", created_at=1700000001000))
    n = svc.build_tree()
    check("build_tree creates nodes", n == 2, f"{n} nodes")
    hits = svc.search("revenue", k=5)
    check("search finds hits", len(hits) >= 1, f"{len(hits)} hits")
    n_mirror = svc.mirror_now()
    check("mirror_to_vault writes .md files", n_mirror >= 1, f"{n_mirror} files")
    svc.store.close()

    # 2. Subconscious
    print("\n  [2/11] Subconscious loop")
    cfg = SubconsciousConfig(enabled=True, tick_interval_s=9999)
    engine = SubconsciousEngine(cfg, llm=StubLLM())
    await engine.start()
    check("engine starts", engine._running)
    await engine.stop()
    check("engine stops", not engine._running)

    # 3. Goals & Todos
    print("\n  [3/11] Goals & Todos")
    cfg = GoalsTodosConfig(enabled=True, db_path=tmp/"gt.db", promote_to_long_term_after_turns=2)
    gsvc = GoalsTodosService(cfg)
    g = gsvc.add_long_term("Ship v6 release")
    check("add long-term goal", g.scope == "long_term")
    gsvc.add_kanban_card("sess-1", "Task A", status="backlog")
    gsvc.add_kanban_card("sess-1", "Task B", status="doing")
    board = gsvc.kanban_board("sess-1")
    check("kanban board has 2 columns with cards",
          len(board["backlog"]) == 1 and len(board["doing"]) == 1)
    gsvc.close()

    # 4. TokenJuice
    print("\n  [4/11] TokenJuice")
    cfg = TokenJuiceConfig(enabled=True, strategy="extractive",
                           min_tokens_to_compress=10, target_ratio=0.3, cache_enabled=False)
    tj = TokenJuice(cfg)
    long_text = "The quick brown fox. Lazy dog. " * 50
    out = tj.compress(long_text)
    ratio = len(out) / len(long_text)
    check("compress reduces size", ratio < 0.7, f"{ratio:.0%} of original")
    stats = tj.stats_snapshot()
    check("stats recorded", stats["total_inputs"] >= 1)

    # 5. Workflows
    print("\n  [5/11] Workflows")
    cfg = WorkflowsConfig(enabled=True, db_path=tmp/"wf.db")
    we = WorkflowEngine(cfg)
    proposal = we.propose_workflow("test", "desc", {"nodes": {
        "t": {"id": "t", "kind": "trigger", "next": ["n1"]},
        "n1": {"id": "n1", "kind": "agent", "next": []},
    }})
    check("propose_workflow validates", proposal["valid"])
    wf = we.save_workflow("My Flow", "desc", proposal["graph"], enabled=True)
    check("save_workflow persists", wf.id is not None)
    flows = we.store.list_workflows()
    check("list_workflows returns 1", len(flows) == 1)
    we.store.close()

    # 6. Graph Harness
    print("\n  [6/11] Graph Harness")
    cfg = GraphHarnessConfig(enabled=True, cost_db_path=tmp/"costs.db")
    gh = GraphHarness(cfg, runtime=None)
    graph = gh.build_default_graph("test goal")
    check("build_default_graph has 4 nodes", len(graph) == 4)
    run = await gh.run("test goal", max_steps=2)
    check("run produces a result", run.status in ("completed", "failed", "incomplete"))
    replay = gh.replay(run.id)
    check("replay returns the run", replay is not None)
    gh.close()

    # 7. Split Brain
    print("\n  [7/11] Split Brain")
    cfg = SplitBrainConfig(enabled=True)
    sb = SplitBrain(cfg, reflex_llm=None, deep_llm=None, deep_runtime=None)
    result = await sb.triage("complex question")
    check("triage hands to deep when no reflex LLM", result.verdict == "hand_to_deep")
    sb.set_directive("Focus on security")
    check("steering directive set", sb._directive is not None)

    # 8. Agent Economy
    print("\n  [8/11] Agent Economy")
    cfg = AgentEconomyConfig(enabled=True, handle="adonai@tiny.place", require_pairing_consent=True)
    ae = AgentEconomy(cfg)
    await ae.start()
    check("handle registered", ae.handle is not None and ae.handle.handle == "adonai@tiny.place")
    pairing = await ae.request_pairing("peer@tiny.place")
    check("pairing fails closed without approval callback", pairing.state == "unpaired")
    await ae.stop()

    # 9. SuperContext
    print("\n  [9/11] SuperContext")
    cfg = SuperContextConfig(enabled=True, max_sweep_s=1.0)
    sc = SuperContext(cfg, memory_tree=None, workspace_root=None)
    pack = await sc.sweep("hello world")
    check("sweep returns within budget", pack.elapsed_ms < 2000)
    injected = sc.inject("user msg", pack)
    check("inject prepends context", "user msg" in injected)

    # 10. Batteries
    print("\n  [10/11] Batteries")
    cfg = BatteriesConfig()
    b = Batteries(cfg)
    check("privacy mode default off", not b.privacy_mode.enabled)
    b.privacy_mode.enable()
    check("privacy mode allows ollama", b.privacy_mode.check_backend("ollama"))
    check("privacy mode refuses openai", not b.privacy_mode.check_backend("openai"))
    check("router routes chat→small", b.router_ext.route("chat") == "small")

    # 11. Meeting Agents
    print("\n  [11/11] Meeting Agents")
    cfg = MeetingAgentsConfig(enabled=True)
    mas = MeetingAgentsService(cfg, llm=None)
    m = Meeting(id="m1", platform="meet", url="https://meet.google.com/abc",
                title="Standup", start_at=1700000000000)
    mas.schedule_meeting(m)
    meetings = mas.list_meetings()
    check("schedule + list meeting", len(meetings) == 1)

    # 12. Subconscious → Executive Bridge
    print("\n  [Bonus] Subconscious → Executive Bridge")
    cfg = SubconsciousConfig(enabled=True, bridge_to_executive=True)
    bridge = SubconsciousExecutiveBridge(cfg, runtime=None)
    bridge.journal.close()
    from adonai.openhuman.subconscious_bridge import BridgeJournal
    bridge.journal = BridgeJournal(str(tmp / "bridge.db"))
    result = await bridge("test goal", {"tainted": False})
    check("bridge records failure when no runtime", bool(result))
    recent = bridge.recent()
    check("journal has 1 failed entry", len(recent) == 1 and recent[0]["status"] == "failed")
    bridge.close()

    # Summary
    print("\n  " + "=" * 60)
    passed = sum(1 for _, ok, _ in results if ok)
    failed = sum(1 for _, ok, _ in results if not ok)
    total = len(results)
    print(f"  {PASS} {passed}/{total} checks passed")
    if failed:
        print(f"  {FAIL} {failed}/{total} checks failed:")
        for name, ok, detail in results:
            if not ok:
                print(f"      {FAIL} {name}: {detail}")
        return 1
    print(f"\n  All v6 subsystems verified. Smoke test passed.\n")
    return 0


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
