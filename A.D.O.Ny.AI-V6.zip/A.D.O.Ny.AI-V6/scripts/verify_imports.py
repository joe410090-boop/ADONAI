#!/usr/bin/env python3
"""Verify all advanced parallelism imports work correctly."""
import sys
import traceback
from pathlib import Path

# Same sys.path setup as main.py
_PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

def try_import(name, import_stmt):
    try:
        exec(import_stmt)
        print(f"  ✓ {name}")
        return True
    except Exception as e:
        print(f"  ✗ {name}: {e}")
        traceback.print_exc()
        return False

checks = [
    ("DynamicBatchController", "from adonai.executors.dynamic_batch_controller import DynamicBatchController"),
    ("ParallelSynthesisEngine", "from adonai.executors.parallel_synthesis import ParallelSynthesisEngine"),
    ("SpeculativeExecutionEngine", "from adonai.executors.speculative_executor import SpeculativeExecutionEngine"),
    ("StepPredictor", "from adonai.executors.speculative_executor import StepPredictor"),
    ("SpeculativeCache", "from adonai.executors.speculative_executor import SpeculativeCache"),
    ("AdvancedParallelExecutor", "from adonai.executors.advanced_parallel_executor import AdvancedParallelExecutor"),
    ("EnhancedExecutor", "from adonai.executors import EnhancedExecutor"),
    ("All executor __init__ exports", "from adonai.executors import *"),
]

all_ok = True
for name, stmt in checks:
    if not try_import(name, stmt):
        all_ok = False

print(f"\n{'='*50}")
if all_ok:
    print("RESULT: ALL IMPORTS PASSED ✓")
    sys.exit(0)
else:
    print("RESULT: SOME IMPORTS FAILED ✗")
    sys.exit(1)

