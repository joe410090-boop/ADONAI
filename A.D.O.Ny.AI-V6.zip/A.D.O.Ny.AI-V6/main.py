#!/usr/bin/env python3
"""A.D.O.N.AI v4 — CLI entry point.

Commands:
    chat       Interactive REPL chat with the agent.
    serve      Start the FastAPI HTTP server (via uvicorn).
    run        Execute a single goal to completion.
    init-db    Initialise the SQLite database (idempotent).
    recover    Resume interrupted tasks.
    report     Print a performance report.
    pentest    Run a pentest scan against a target (absorbed Strix).
"""
from __future__ import annotations

import argparse
import asyncio
import logging
import sys
from pathlib import Path

_PROJECT_ROOT = Path(__file__).resolve().parent
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from adonai import __version__


def _setup_logging(level: str = "INFO") -> None:
    numeric = getattr(logging, level.upper(), logging.INFO)
    logging.basicConfig(
        level=numeric,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        stream=sys.stderr,
    )


async def _cmd_chat(args):
    from adonai.config.settings import load_config
    from adonai.runtime import ADONAI
    config = load_config(path=args.config, debug=args.debug, log_level=args.log_level.upper())
    _setup_logging(config.log_level)
    ai = ADONAI(config=config)
    print(f"\n  A.D.O.N.AI v{__version__} — Interactive Chat\n  Type /quit to exit.\n")
    try:
        await ai.start()
        session_id = "cli-default"
        while True:
            try:
                user_input = input("\033[1mYou\033[0m> ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\nGoodbye!")
                break
            if not user_input:
                continue
            if user_input.lower() in ("/quit", "/exit", "/q"):
                break
            if user_input.lower() == "/clear":
                ai.clear_conversation(session_id)
                print("  [conversation cleared]")
                continue
            try:
                print("\033[1mADONAI\033[0m> ", end="", flush=True)
                reply = await ai.chat(user_input, session_id=session_id)
                print(reply)
            except KeyboardInterrupt:
                print("\n[interrupted]")
            except Exception as exc:
                print(f"\n[error] {exc}", file=sys.stderr)
    finally:
        await ai.shutdown()


async def _cmd_serve(args):
    import uvicorn
    from adonai.config.settings import load_config
    from adonai.api.server import create_app
    config = load_config(path=args.config, debug=args.debug, log_level=args.log_level.upper())
    _setup_logging(config.log_level)
    app = create_app(config=config)
    host = config.api.host
    port = args.port if args.port is not None else config.api.port
    print(f"Starting A.D.O.N.AI v4 API server on {host}:{port}  (docs: http://{host}:{port}/docs)\n")
    uv_config = uvicorn.Config(app, host=host, port=port, log_level="info")
    server = uvicorn.Server(uv_config)
    await server.serve()


async def _cmd_run(args):
    from adonai.config.settings import load_config
    from adonai.runtime import ADONAI
    from adonai.core.events import EventTypes
    goal = " ".join(args.goal)
    if not goal:
        print("[ERROR] No goal specified.", file=sys.stderr)
        sys.exit(1)
    config = load_config(path=args.config, debug=args.debug, log_level=args.log_level.upper())
    _setup_logging(config.log_level)
    ai = ADONAI(config=config)
    exit_code = 0
    print(f"Running goal: {goal[:120]}")
    try:
        await ai.start()

        # Subscribe to step events so we can print a live checklist.
        # The executor publishes PLAN_CREATED + STEP_STARTED/COMPLETED/FAILED
        # on the EventBus; we render them as a todo list with status marks.
        step_states: dict[str, str] = {}  # step_id -> "✓" | "✗" | "▶" | " "
        step_order: list[str] = []
        step_labels: dict[str, str] = {}

        def _render():
            # Walk steps in declaration order and print their current status.
            print("\r\033[A" * (len(step_order) + 1) if step_order else "", end="")
            for sid in step_order:
                mark = step_states.get(sid, " ")
                label = step_labels.get(sid, sid)[:70]
                print(f"  [{mark}] {label}")

        async def _on_plan(event):
            steps = event.payload.get("steps", [])
            step_order.clear(); step_labels.clear(); step_states.clear()
            for s in steps:
                step_order.append(s["id"])
                step_labels[s["id"]] = s["description"]
                step_states[s["id"]] = " "
            print()
            for sid in step_order:
                print(f"  [ ] {step_labels[sid][:70]}")

        async def _on_step(event):
            step = event.payload.get("step") or {}
            sid = step.get("id")
            if not sid or sid not in step_states:
                return
            status = step.get("status")
            if status == "running":
                step_states[sid] = "▶"
            elif status == "completed":
                step_states[sid] = "✓"
            elif status in ("failed", "blocked"):
                step_states[sid] = "✗"
            # Re-render the checklist in place.
            _render()

        ai.events.subscribe(EventTypes.PLAN_CREATED, _on_plan)
        ai.events.subscribe(EventTypes.STEP_STARTED, _on_step)
        ai.events.subscribe(EventTypes.STEP_COMPLETED, _on_step)
        ai.events.subscribe(EventTypes.STEP_FAILED, _on_step)

        kwargs = {}
        if args.max_steps is not None:
            kwargs["max_steps"] = args.max_steps
        if args.max_duration is not None:
            kwargs["max_duration_s"] = args.max_duration
        result = await ai.run(goal, **kwargs)
        print(f"\n{'─'*48}")
        print(f"  Status     : {result.status.value}")
        print(f"  Steps      : {result.steps_executed}")
        print(f"  Duration   : {result.duration_s:.1f}s")
        print(f"  Confidence : {result.confidence:.2f}")
        print(f"{'─'*48}")
        if result.output is not None:
            output = str(result.output)
            print(f"\nOutput:\n{output[:3000]}" if len(output) <= 3000 else f"\nOutput (truncated):\n{output[:3000]}…")
        if result.error:
            print(f"\nError: {result.error}", file=sys.stderr)
        if result.status.value != "completed":
            exit_code = 1
    except Exception as exc:
        print(f"[ERROR] Task failed: {exc}", file=sys.stderr)
        exit_code = 1
    finally:
        await ai.shutdown()
    if exit_code:
        sys.exit(exit_code)


async def _cmd_init_db(args):
    from adonai.config.settings import load_config
    from adonai.database import init_db
    _setup_logging(args.log_level)
    config = load_config(path=args.config)
    db_path = await init_db(config=config)
    print(f"Database initialised at: {db_path}")


async def _cmd_recover(args):
    from adonai.config.settings import load_config
    from adonai.runtime import ADONAI
    config = load_config(path=args.config, debug=args.debug, log_level=args.log_level.upper())
    _setup_logging(config.log_level)
    ai = ADONAI(config=config)
    try:
        await ai.start()
        if ai.recovery is not None:
            recovered = await ai.recovery.recover_all()
            if not recovered:
                print("No resumable tasks found.")
            else:
                print(f"Recovered {len(recovered)} task(s):")
                for tid in recovered:
                    print(f"  • {tid}")
    except Exception as exc:
        print(f"[ERROR] Recovery failed: {exc}", file=sys.stderr)
        sys.exit(1)
    finally:
        await ai.shutdown()


async def _cmd_report(args):
    from adonai.config.settings import load_config
    from adonai.analytics.reporter import ReportGenerator
    from adonai.learning.experience import ExperienceStore
    from adonai.learning.patterns import PatternExtractor
    from adonai.learning.analytics import AnalyticsTracker
    config = load_config(path=args.config, log_level=args.log_level.upper())
    _setup_logging(config.log_level)
    gen = ReportGenerator(
        AnalyticsTracker(config), ExperienceStore(config), PatternExtractor(config),
    )
    print(await gen.generate_text())


async def _cmd_pentest(args):
    """Run a pentest scan against one or more targets.

    Mirrors Strix's CLI ergonomics: ``--target`` (repeatable),
    ``--target-list`` (file), ``--scan-mode``, ``--instruction``,
    ``--instruction-file``, ``--non-interactive``, ``--max-turns``.

    The scan is executed by the PentesterAgent, which uses the
    absorbed Strix pentest tools (adonai/pentest/, adonai/tools/builtin/pentest_*).
    """
    from adonai.config.settings import load_config
    from adonai.runtime import ADONAI
    from adonai.core.models import Task, TaskPriority, TaskComplexity
    from adonai.pentest.sandbox import ScanMode

    # Build target list.
    targets: list[dict[str, str]] = []
    for t in (args.target or []):
        targets.append(_classify_target(t))
    if args.target_list:
        from pathlib import Path
        for line in Path(args.target_list).read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            targets.append(_classify_target(line))
    if not targets:
        print("[ERROR] No targets specified. Use --target or --target-list.", file=sys.stderr)
        sys.exit(2)

    # Validate scan mode.
    try:
        scan_mode = ScanMode(args.scan_mode.lower())
    except ValueError:
        print(f"[ERROR] Invalid scan mode: {args.scan_mode!r}. "
              f"Choose from: quick, standard, deep.", file=sys.stderr)
        sys.exit(2)

    # Load instruction file (if any).
    instruction_file = None
    if args.instruction_file:
        from pathlib import Path
        instruction_file = Path(args.instruction_file)
        if not instruction_file.exists():
            print(f"[ERROR] Instruction file not found: {instruction_file}", file=sys.stderr)
            sys.exit(2)

    # Load ADONAI config + start the runtime.
    config = load_config(path=args.config, debug=args.debug, log_level=args.log_level.upper())
    _setup_logging(config.log_level)
    ai = ADONAI(config=config)
    exit_code = 0

    # Build a goal string for the run record + logging.
    goal = (
        f"Pentest scan ({scan_mode.value} mode) against: "
        + ", ".join(t["value"] for t in targets)
    )
    if args.instruction:
        goal += f" — instruction: {args.instruction}"

    print(f"\n  A.D.O.N.AI Pentest — scan mode: {scan_mode.value}")
    print(f"  Targets ({len(targets)}):")
    for i, t in enumerate(targets, 1):
        print(f"    {i}. [{t['type']}] {t['value']}")
    print()

    try:
        await ai.start()
        # Build the Task with the pentest context.
        task = Task(
            goal=goal,
            description=goal,
            priority=TaskPriority.HIGH,
            complexity=TaskComplexity.COMPLEX,
            assigned_agent="pentester",
            context={
                "pentest": {
                    "targets": targets,
                    "scan_mode": scan_mode.value,
                    "instruction": args.instruction or "",
                    "instruction_file": str(instruction_file) if instruction_file else None,
                    "interactive": not args.non_interactive,
                    "max_turns": args.max_turns or 50,
                },
            },
        )
        result = await ai.agents.get("pentester").run(task)

        print(f"\n{'─' * 60}")
        print(f"  Scan status   : {result.status.value}")
        if isinstance(result.output, dict):
            print(f"  Scan ID       : {result.output.get('scan_id', '?')}")
            print(f"  Run dir       : {result.output.get('run_dir', '?')}")
            print(f"  SARIF report  : {result.output.get('sarif_path', '?')}")
            print(f"  Exec report   : {result.output.get('executive_report_path', '?')}")
            print(f"  Duration      : {result.output.get('duration_s', 0):.1f}s")
            summary = result.output.get("final_summary", "")
            if summary:
                print(f"\n  Summary:\n{summary[:1500]}")
        if result.error:
            print(f"\n  Error: {result.error}", file=sys.stderr)
        if result.status.value != "completed":
            exit_code = 1
    except Exception as exc:
        print(f"[ERROR] Pentest scan failed: {exc}", file=sys.stderr)
        import traceback
        if args.debug:
            traceback.print_exc()
        exit_code = 1
    finally:
        await ai.shutdown()
    if exit_code:
        sys.exit(exit_code)


def _classify_target(value: str) -> dict[str, str]:
    """Classify a target string as local_code / url / github."""
    v = value.strip()
    if v.startswith(("http://", "https://")):
        if "github.com/" in v:
            return {"type": "github", "value": v}
        return {"type": "url", "value": v}
    # Local path check
    from pathlib import Path
    if Path(v).exists():
        return {"type": "local_code", "value": v}
    # Bare domain — treat as URL.
    if "." in v and "/" not in v:
        return {"type": "url", "value": f"https://{v}"}
    # Default: treat as URL.
    return {"type": "url", "value": v}


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="adonai",
        description=f"A.D.O.N.AI v{__version__} — Autonomous AI Operating System",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument("--config", type=str, default=None, metavar="PATH")
    parser.add_argument("--debug", action="store_true", default=False)
    parser.add_argument("--log-level", type=str, default="INFO",
                        choices=["DEBUG", "INFO", "WARNING", "ERROR"])
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("chat", help="Interactive chat REPL")
    serve_p = sub.add_parser("serve", help="Start the FastAPI HTTP server")
    serve_p.add_argument("--port", type=int, default=None)
    run_p = sub.add_parser("run", help="Execute a single goal")
    run_p.add_argument("goal", nargs="+")
    run_p.add_argument("--max-steps", type=int, default=None)
    run_p.add_argument("--max-duration", type=int, default=None)
    sub.add_parser("init-db", help="Initialise the SQLite database")
    sub.add_parser("recover", help="Recover interrupted tasks")
    sub.add_parser("report", help="Print performance report")
    # Pentest subcommand — mirrors Strix CLI ergonomics.
    pentest_p = sub.add_parser(
        "pentest",
        help="Run a pentest scan against a target (absorbed Strix)",
        description=(
            "Run an autonomous pentest scan against one or more targets. "
            "Targets may be local code paths, URLs, or GitHub repos. "
            "Outputs SARIF + Markdown reports to workspace/pentest_runs/."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python main.py pentest -t ./app-directory\n"
            "  python main.py pentest -t https://github.com/org/repo\n"
            "  python main.py pentest -t https://your-app.com --scan-mode deep\n"
            "  python main.py pentest -t ./ --scan-mode quick --non-interactive\n"
            "  python main.py pentest --target-list ./targets.txt\n"
        ),
    )
    pentest_p.add_argument(
        "-t", "--target", action="append", default=[],
        help="Target (repeatable). Local path, URL, or GitHub repo.",
    )
    pentest_p.add_argument(
        "--target-list", default=None,
        help="File of targets (one per non-empty, non-comment line).",
    )
    pentest_p.add_argument(
        "--scan-mode", default="deep",
        choices=["quick", "standard", "deep"],
        help="Scan depth (default: deep).",
    )
    pentest_p.add_argument(
        "--instruction", default="",
        help="Additional instruction for the agent (e.g. focus areas, rules of engagement).",
    )
    pentest_p.add_argument(
        "--instruction-file", default=None,
        help="File with detailed instructions (rules of engagement, scope, exclusions).",
    )
    pentest_p.add_argument(
        "-n", "--non-interactive", action="store_true", default=False,
        help="Run headless — no interactive prompts. Exits non-zero if findings are found.",
    )
    pentest_p.add_argument(
        "--max-turns", type=int, default=None,
        help="Max LLM round-trips for the scan (default: 50).",
    )
    return parser


def main(argv=None):
    parser = build_parser()
    args = parser.parse_args(argv)
    if not args.command:
        parser.print_help()
        sys.exit(0)
    if args.command == "init-db":
        asyncio.run(_cmd_init_db(args))
        return
    if args.command == "report":
        asyncio.run(_cmd_report(args))
        return
    if args.command == "pentest":
        asyncio.run(_cmd_pentest(args))
        return
    async def _dispatch():
        handlers = {"chat": _cmd_chat, "serve": _cmd_serve, "run": _cmd_run, "recover": _cmd_recover}
        h = handlers.get(args.command)
        if h:
            await h(args)
        else:
            parser.print_help()
            sys.exit(1)
    try:
        asyncio.run(_dispatch())
    except KeyboardInterrupt:
        print("\nInterrupted.")
        sys.exit(0)


if __name__ == "__main__":
    main()
