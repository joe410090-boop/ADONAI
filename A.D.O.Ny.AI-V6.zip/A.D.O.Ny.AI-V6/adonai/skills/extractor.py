"""Skill extractor — turns a successful (Task, Plan, TaskResult) into a Skill via LLM."""
from __future__ import annotations
import logging
from typing import Any
from adonai.core.interfaces import LLMClient
from adonai.core.json_utils import extract_json
from adonai.core.models import Plan, PlanStep, Skill, Task, TaskResult, TaskStatus
log = logging.getLogger(__name__)
_EXTRACTOR_PROMPT = """You are a skill extractor. Given a successful task execution, extract a reusable skill. Output STRICT JSON: {"name":"...","description":"...","category":"coding|research|web|custom","trigger_patterns":[...],"procedure":[...],"required_tools":[...]}"""


def _coerce_plan_step(p: Any) -> PlanStep | None:
    """Coerce one LLM-provided procedure item into a PlanStep.

    Handles three shapes the LLM is known to emit:
      * dict  -> {"description": "...", "tool": "...", "parameters": {...}}
      * str   -> a bare description (tool/parameters default)
      * None  -> skip
    Returns None for anything we cannot interpret so the caller can drop it.
    """
    if p is None:
        return None
    if isinstance(p, str):
        desc = p.strip()
        if not desc:
            return None
        return PlanStep(description=desc)
    if isinstance(p, dict):
        desc = str(p.get("description", "") or "").strip()
        if not desc:
            # Fall back to a 'tool' hint or skip.
            tool = p.get("tool")
            if not tool:
                return None
            desc = str(tool)
        tool = p.get("tool")
        params = p.get("parameters", {}) or {}
        if not isinstance(params, dict):
            # Some models return a list of strings or a JSON string here.
            if isinstance(params, str):
                try:
                    import json as _json
                    parsed = _json.loads(params)
                    params = parsed if isinstance(parsed, dict) else {}
                except Exception:
                    params = {}
            else:
                params = {}
        return PlanStep(description=desc, tool=tool, parameters=params)
    # Any other type (int, list, …) — skip silently.
    return None


class SkillExtractor:
    def __init__(self, llm: LLMClient) -> None: self.llm = llm
    async def extract(self, task: Task, plan: Plan, result: TaskResult) -> Skill | None:
        steps_repr = "\n".join(f"- {s.description} [tool={s.tool}]" for s in plan.steps if s.status == TaskStatus.COMPLETED)
        if not steps_repr: return None
        try:
            resp = await self.llm.complete(messages=[{"role":"system","content":_EXTRACTOR_PROMPT},{"role":"user","content":f"Task: {task.goal}\nSteps:\n{steps_repr}\nOutput JSON:"}],temperature=0.2,max_tokens=1024)
            data = extract_json(resp.text or "")
        except Exception as e:
            log.warning("Skill extractor failed: %s", e); return None
        # If the LLM returned a bare list (some models do), take the first
        # dict element as the skill payload.
        if isinstance(data, list):
            data = data[0] if data and isinstance(data[0], dict) else {}
        if not isinstance(data, dict):
            log.warning("Skill build failed: expected JSON object, got %s", type(data).__name__)
            return None
        try:
            from adonai.core.models import SkillCategory
            procedure: list[PlanStep] = []
            for p in (data.get("procedure") or []):
                step = _coerce_plan_step(p)
                if step is not None:
                    procedure.append(step)
            return Skill(
                name=str(data.get("name", "unnamed") or "unnamed"),
                description=str(data.get("description", "") or ""),
                category=SkillCategory(data.get("category", "custom") or "custom"),
                trigger_patterns=list(data.get("trigger_patterns") or []),
                procedure=procedure,
                required_tools=list(data.get("required_tools") or []),
                created_from=task.id,
                success_rate=1.0,
                usage_count=1,
            )
        except Exception as e:
            log.warning("Skill build failed: %s", e); return None
