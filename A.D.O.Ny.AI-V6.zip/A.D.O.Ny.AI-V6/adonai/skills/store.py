"""SQLite-backed skill store."""
from __future__ import annotations
import json, logging, sqlite3, time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from adonai.core.interfaces import SkillStore
from adonai.core.models import PlanStep, Skill, SkillCategory
log = logging.getLogger(__name__)

class SQLiteSkillStore(SkillStore):
    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()
    def _conn(self):
        c = sqlite3.connect(str(self.db_path)); c.row_factory = sqlite3.Row; return c
    def _ensure_schema(self):
        with self._conn() as c:
            c.execute("""CREATE TABLE IF NOT EXISTS skills (
                id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT NOT NULL,
                category TEXT NOT NULL, version TEXT NOT NULL DEFAULT '1.0.0',
                examples TEXT NOT NULL DEFAULT '[]', trigger_patterns TEXT NOT NULL DEFAULT '[]',
                procedure TEXT NOT NULL DEFAULT '[]', required_tools TEXT NOT NULL DEFAULT '[]',
                success_rate REAL NOT NULL DEFAULT 0.0, usage_count INTEGER NOT NULL DEFAULT 0,
                failure_count INTEGER NOT NULL DEFAULT 0, last_used REAL, created_at REAL NOT NULL,
                created_from TEXT, author TEXT NOT NULL DEFAULT 'adonai', tags TEXT NOT NULL DEFAULT '[]',
                active INTEGER NOT NULL DEFAULT 1)""")
            c.execute("CREATE INDEX IF NOT EXISTS idx_skills_cat ON skills(category)")
            c.execute("CREATE INDEX IF NOT EXISTS idx_skills_act ON skills(active)")
            c.commit()
    async def save(self, skill: Skill) -> str:
        with self._conn() as c:
            c.execute("""INSERT OR REPLACE INTO skills (id,name,description,category,version,examples,trigger_patterns,procedure,required_tools,success_rate,usage_count,failure_count,last_used,created_at,created_from,author,tags,active) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (skill.id,skill.name,skill.description,skill.category,skill.version,json.dumps(skill.examples),json.dumps(skill.trigger_patterns),json.dumps([s.model_dump(mode="json") for s in skill.procedure]),json.dumps(skill.required_tools),skill.success_rate,skill.usage_count,skill.failure_count,skill.last_used.timestamp() if skill.last_used else None,skill.created_at.timestamp() if skill.created_at else time.time(),skill.created_from,skill.author,json.dumps(skill.tags),int(skill.active)))
            c.commit()
        return skill.id
    async def load(self, skill_id: str) -> Skill | None:
        with self._conn() as c:
            r = c.execute("SELECT * FROM skills WHERE id = ?",(skill_id,)).fetchone()
        return _row(r) if r else None
    async def find_by_trigger(self, query: str) -> list[Skill]:
        q = query.lower()
        with self._conn() as c:
            rows = c.execute("SELECT * FROM skills WHERE active=1 ORDER BY success_rate DESC, usage_count DESC").fetchall()
        out = []
        for r in rows:
            triggers = json.loads(r["trigger_patterns"] or "[]")
            if triggers and any(t.lower() in q for t in triggers):
                out.append(_row(r))
        return out
    async def list_all(self, category: str | None = None) -> list[Skill]:
        with self._conn() as c:
            if category:
                rows = c.execute("SELECT * FROM skills WHERE category=? ORDER BY usage_count DESC",(category,)).fetchall()
            else:
                rows = c.execute("SELECT * FROM skills ORDER BY usage_count DESC").fetchall()
        return [_row(r) for r in rows]
    async def delete(self, skill_id: str) -> bool:
        with self._conn() as c:
            cur = c.execute("DELETE FROM skills WHERE id = ?",(skill_id,)); c.commit(); return cur.rowcount > 0
    async def update_stats(self, skill_id: str, success: bool) -> None:
        with self._conn() as c:
            r = c.execute("SELECT usage_count,failure_count,success_rate FROM skills WHERE id=?",(skill_id,)).fetchone()
            if not r: return
            n = int(r["usage_count"])+1
            old = float(r["success_rate"])
            new = old + ((1.0 if success else 0.0)-old)/n
            c.execute("UPDATE skills SET usage_count=?,failure_count=?,success_rate=?,last_used=? WHERE id=?",(n,int(r["failure_count"])+(0 if success else 1),new,time.time(),skill_id))
            c.commit()
    async def retire_low_performers(self, min_success_rate: float) -> int:
        with self._conn() as c:
            cur = c.execute("UPDATE skills SET active=0 WHERE success_rate < ? AND usage_count >= 3",(min_success_rate,)); c.commit(); return cur.rowcount

def _row(r):
    def _ts(t): return datetime.fromtimestamp(t,tz=timezone.utc) if t else None
    proc = []
    for p in json.loads(r["procedure"] or "[]"):
        try: proc.append(PlanStep(**p))
        except: pass
    return Skill(id=r["id"],name=r["name"],description=r["description"],category=SkillCategory(r["category"]),version=r["version"],examples=json.loads(r["examples"] or "[]"),trigger_patterns=json.loads(r["trigger_patterns"] or "[]"),procedure=proc,required_tools=json.loads(r["required_tools"] or "[]"),success_rate=float(r["success_rate"]),usage_count=int(r["usage_count"]),failure_count=int(r["failure_count"]),last_used=_ts(r["last_used"]),created_at=_ts(r["created_at"]),created_from=r["created_from"],author=r["author"],tags=json.loads(r["tags"] or "[]"),active=bool(r["active"]))
