"""Skill ranker — order skills by effectiveness + relevance."""
from __future__ import annotations
from adonai.core.models import Skill
class SkillRanker:
    def __init__(self, store) -> None: self.store = store
    async def rank_for_goal(self, goal: str, top_k: int = 5) -> list[Skill]:
        skills = await self.store.find_by_trigger(goal)
        import time; now = time.time()
        max_usage = max((s.usage_count for s in skills), default=1) or 1
        for s in skills:
            recency = 1.0 if (s.last_used and (now - s.last_used.timestamp()) < 86400) else 0.5
            s._rank_score = (s.success_rate*0.5)+(s.usage_count/max_usage*0.3)+(recency*0.2)
        skills.sort(key=lambda s: getattr(s,"_rank_score",0), reverse=True)
        return skills[:top_k]
    async def retire_low_performers(self, min_success_rate: float = 0.4) -> int:
        return await self.store.retire_low_performers(min_success_rate)
