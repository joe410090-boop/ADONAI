"""Upgrade 5 — Skill Evolution System.

Converts repeated successful behavior into reusable skills that become
callable tools.

Pipeline::

    Experience → Pattern Analysis → Skill Extraction → Skill Registry
              → Skill-as-Tool adapter → ToolRegistry

Generated skills are exposed as native tools (e.g.
``run_openfoam_simulation()``, ``research_company()``,
``code_refactor_project()``) so the planner can pick them up like any
other tool.

Behavioral verification: every newly-extracted skill must pass N
held-out examples before promotion to active status.  Failures trigger
either re-extraction or retirement.

The evolver composes the existing
:class:`~adonai.skills.manager.SkillManager` (which already does
LLM-based extraction) with pattern mining and a skill-to-tool adapter.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
from collections import Counter, defaultdict
from typing import Any

from adonai.core.exceptions import SkillError
from adonai.core.interfaces import LLMClient, SkillEvolver, Tool
from adonai.core.models import (
    Experience, Plan, PlanStep, Skill, SkillCategory, Task, TaskResult,
    TaskStatus, ToolCall, ToolResult, VerificationType,
)

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Pattern miner
# ──────────────────────────────────────────────────────────────────────────────


class PatternMiner:
    """Mines the experience store for repeated successful patterns.

    A "pattern" is a sequence of (tool, parameters_hash) tuples that
    appears in 3+ successful experiences with similar goals.
    """

    def __init__(
        self,
        experience_store: Any = None,
        *,
        min_observations: int = 3,
    ) -> None:
        self.experiences = experience_store
        self.min_observations = min_observations

    async def mine(self) -> list[dict[str, Any]]:
        """Return a list of pattern dicts.

        Each pattern: ``{signature, count, success_rate, example_goal,
        tool_sequence, parameter_template}``.
        """
        if self.experiences is None:
            return []
        # Pull recent experiences (the ExperienceStore exposes .recent).
        try:
            recent = await self.experiences.recent(limit=200)
        except Exception as e:
            log.warning("PatternMiner: experience.recent failed: %s", e)
            return []
        # Group by tool signature.
        by_sig: dict[str, list[Experience]] = defaultdict(list)
        for exp in recent:
            sig = self._signature(exp)
            if sig:
                by_sig[sig].append(exp)
        patterns: list[dict[str, Any]] = []
        for sig, exps in by_sig.items():
            if len(exps) < self.min_observations:
                continue
            successes = sum(1 for e in exps if e.success)
            success_rate = successes / len(exps)
            if success_rate < 0.5:
                continue
            # Pick a representative example.
            example = exps[0]
            patterns.append({
                "signature": sig,
                "count": len(exps),
                "success_rate": success_rate,
                "example_goal": example.task_goal,
                "tool_sequence": self._extract_tool_sequence(example),
                "parameter_template": self._extract_parameter_template(exps),
                "complexity": example.task_complexity,
                "agent_used": example.agent_used,
                # v9 fix: include the full experience group so the
                # skill evolver's run_cycle() can hold out the LAST
                # experience and replay it as a real task through the
                # runtime (instead of faking a pass with a trivial
                # Task(goal=example_goal)). Holding out a real example
                # and replaying it exercises the skill against an
                # actual goal+context the system has seen before.
                "experiences": list(exps),
            })
        # Sort by count × success_rate.
        patterns.sort(key=lambda p: p["count"] * p["success_rate"], reverse=True)
        return patterns

    @staticmethod
    def _signature(exp: Experience) -> str | None:
        """Build a signature from the plan's tool sequence.

        Two experiences with the same tool sequence in the same order
        share a signature.
        """
        plan = exp.plan_snapshot or {}
        steps = plan.get("steps") or []
        tools = [s.get("tool") for s in steps if s.get("tool")]
        if not tools:
            return None
        return " → ".join(tools)

    @staticmethod
    def _extract_tool_sequence(exp: Experience) -> list[str]:
        plan = exp.plan_snapshot or {}
        return [s.get("tool") for s in (plan.get("steps") or []) if s.get("tool")]

    @staticmethod
    def _extract_parameter_template(exps: list[Experience]) -> dict[str, Any]:
        """Build a parameter template by intersecting keys across experiences.

        For each tool in the sequence, find the parameter keys that
        appear in ALL experiences — those become the template's required
        parameters.  Values are placeholders.
        """
        # Collect per-step parameter dicts across all experiences.
        per_step_params: list[list[dict[str, Any]]] = []
        for exp in exps:
            plan = exp.plan_snapshot or {}
            steps = plan.get("steps") or []
            per_step_params.append([s.get("parameters") or {} for s in steps])
        if not per_step_params:
            return {}
        # Use the first experience's step count as the canonical length.
        n_steps = len(per_step_params[0])
        template: dict[str, Any] = {}
        for i in range(n_steps):
            # Collect all parameter keys at step i.
            keys_per_exp = [
                set(step_params[i].keys())
                for step_params in per_step_params
                if i < len(step_params)
            ]
            if not keys_per_exp:
                continue
            common = set.intersection(*keys_per_exp) if keys_per_exp else set()
            for k in common:
                template[f"step_{i}.{k}"] = "<fill_in>"
        return template


# ──────────────────────────────────────────────────────────────────────────────
# SkillExtractor (LLM-backed)
# ──────────────────────────────────────────────────────────────────────────────


_SKILL_EXTRACTION_PROMPT = (
    "You are the SKILL EXTRACTOR for an autonomous research platform.\n"
    "Given a repeated successful pattern, extract a reusable skill.\n\n"
    "Output JSON:\n"
    "{\n"
    '  "name": str,                        // snake_case tool name (e.g. "research_company")\n'
    '  "description": str,                 // one-sentence description\n'
    '  "category": "coding"|"research"|"web"|"project_management"|"analysis"|"writing"|"custom",\n'
    '  "trigger_patterns": [str],          // when should this skill be used?\n'
    '  "procedure": [                      // ordered steps\n'
    '    {"description": str, "tool": str|null, "parameters": {}, "expected_outcome": str?}\n'
    "  ],\n"
    '  "required_tools": [str]\n'
    "}\n\n"
    "Return ONLY the JSON.  No prose, no markdown fences."
)


class LLMSkillExtractor:
    """LLM-backed skill extractor.

    Wraps the pattern in a prompt and asks the LLM to produce a
    structured :class:`Skill` definition.
    """

    def __init__(self, llm: LLMClient | None = None) -> None:
        self.llm = llm

    async def extract(
        self, pattern: dict[str, Any],
    ) -> Skill | None:
        if self.llm is None:
            return self._heuristic_extract(pattern)
        user_prompt = (
            f"PATTERN SIGNATURE: {pattern.get('signature', '')}\n"
            f"OCCURRENCES: {pattern.get('count', 0)}\n"
            f"SUCCESS RATE: {pattern.get('success_rate', 0):.2f}\n"
            f"EXAMPLE GOAL: {pattern.get('example_goal', '')}\n"
            f"TOOL SEQUENCE: {pattern.get('tool_sequence', [])}\n"
            f"PARAMETER TEMPLATE: {json.dumps(pattern.get('parameter_template', {}))}\n\n"
            f"Extract a reusable skill as JSON."
        )
        from adonai.core.json_utils import extract_json, JSONExtractionError
        try:
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": _SKILL_EXTRACTION_PROMPT},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.2,
                max_tokens=1024,
            )
            data = extract_json(resp.text or "")
        except (JSONExtractionError, Exception) as e:
            log.warning("Skill extraction LLM failed: %s — using heuristic", e)
            return self._heuristic_extract(pattern)
        if not isinstance(data, dict):
            return None
        return self._dict_to_skill(data, pattern)

    def _heuristic_extract(self, pattern: dict[str, Any]) -> Skill | None:
        """Build a skill directly from the pattern, without LLM help."""
        sig = pattern.get("signature", "")
        if not sig:
            return None
        # snake_case name from first tool + "_sequence"
        first_tool = (pattern.get("tool_sequence") or ["unknown"])[0]
        name = f"{first_tool}_sequence"
        # Trigger patterns = words from the example goal.
        goal = pattern.get("example_goal", "")
        triggers = [
            w.lower() for w in re.findall(r"\b[A-Za-z]{4,}\b", goal)
        ][:5]
        # Procedure = the tool sequence.
        procedure = [
            PlanStep(
                description=f"Run {tool}",
                tool=tool,
                verification_type=VerificationType.UNVERIFIED,
            )
            for tool in (pattern.get("tool_sequence") or [])
        ]
        return Skill(
            name=name,
            description=f"Repeated pattern: {sig[:200]}",
            category=SkillCategory.CUSTOM,
            trigger_patterns=triggers,
            procedure=procedure,
            required_tools=list(pattern.get("tool_sequence") or []),
            success_rate=pattern.get("success_rate", 0.5),
            usage_count=pattern.get("count", 0),
            created_from="pattern_miner:heuristic",
        )

    @staticmethod
    def _dict_to_skill(data: dict[str, Any], pattern: dict[str, Any]) -> Skill:
        procedure = []
        for step_data in (data.get("procedure") or []):
            if not isinstance(step_data, dict):
                continue
            procedure.append(PlanStep(
                description=step_data.get("description", "(no description)"),
                tool=step_data.get("tool"),
                parameters=step_data.get("parameters") or {},
                expected_outcome=step_data.get("expected_outcome"),
                verification_type=VerificationType.UNVERIFIED,
            ))
        try:
            category = SkillCategory(data.get("category", "custom"))
        except ValueError:
            category = SkillCategory.CUSTOM
        return Skill(
            name=str(data.get("name", "extracted_skill")),
            description=str(data.get("description", "")),
            category=category,
            trigger_patterns=list(data.get("trigger_patterns") or []),
            procedure=procedure,
            required_tools=list(data.get("required_tools") or []),
            success_rate=pattern.get("success_rate", 0.5),
            usage_count=pattern.get("count", 0),
            created_from="pattern_miner:llm",
        )


# ──────────────────────────────────────────────────────────────────────────────
# SkillTool — adapter that exposes a Skill as a callable Tool
# ──────────────────────────────────────────────────────────────────────────────


class SkillTool(Tool):
    """Adapts a :class:`Skill` into a callable :class:`Tool`.

    When invoked, the tool replays the skill's procedure: each step
    either invokes its named tool via the parent registry, or asks the
    LLM to synthesize output (when ``tool=None``).
    """

    def __init__(
        self,
        skill: Skill,
        tool_registry: Any = None,
        llm: LLMClient | None = None,
        skill_manager: Any = None,
    ) -> None:
        self.skill = skill
        self.tools = tool_registry
        self.llm = llm
        # v5: wire the SkillManager so record_skill_use() is called after
        # each execution, updating usage_count/success_rate/last_used.
        # Previously these stats never evolved after creation, so
        # retire_low_performers (which checks usage_count >= 3) always
        # returned 0 and SkillRanker.rank_for_goal was useless.
        self.skill_manager = skill_manager
        self.name = f"skill.{skill.name}"
        self.description = skill.description
        self.parameters = self._build_parameters_schema()
        self.risk_level = "low"
        self.requires_approval = False
        self.tags = ["skill", skill.category.value]
        self.category = "skill"

    def _build_parameters_schema(self) -> dict:
        """Build a minimal JSON-schema for the skill's parameters."""
        props: dict[str, dict] = {}
        for step_idx, step in enumerate(self.skill.procedure):
            for key in step.parameters:
                props[f"step{step_idx}_{key}"] = {"type": "string"}
        return {
            "type": "object",
            "properties": props,
            "additionalProperties": True,
        }

    async def execute(self, **params: Any) -> ToolResult:
        """Replay the skill's procedure.

        Each step either invokes its tool via the registry, or asks the
        LLM to synthesize text when ``tool=None``.  Step outputs are
        threaded into the next step's ``parameters`` under the key
        ``"previous_output"``.

        v5: now calls ``record_skill_use()`` on the SkillManager after
        each execution so usage_count/success_rate/last_used evolve.
        """
        from adonai.core.models import ToolCall
        start_ts = __import__("time").time()
        outputs: list[Any] = []
        last_output: Any = None
        success = True
        error_msg: str | None = None
        for i, step in enumerate(self.skill.procedure):
            # Allow caller-provided per-step params to override.
            step_params = dict(step.parameters)
            step_params["previous_output"] = last_output
            for k, v in params.items():
                if k.startswith(f"step{i}_"):
                    step_params[k[len(f"step{i}_"):]] = v
            if step.tool and self.tools is not None:
                try:
                    res = await self.tools.execute(step.tool, **step_params)
                    if not res.success:
                        success = False
                        error_msg = f"step {i} ({step.tool}) failed: {res.error}"
                        break
                    last_output = res.output
                except Exception as e:
                    success = False
                    error_msg = f"step {i} ({step.tool}) exception: {e}"
                    break
            elif self.llm is not None:
                # LLM synthesis step.
                try:
                    user_msg = (
                        f"Goal: {self.skill.description}\n"
                        f"Step {i+1}: {step.description}\n"
                        f"Previous output: {last_output}\n"
                        f"Additional params: {step_params}"
                    )
                    resp = await self.llm.complete(
                        messages=[{"role": "user", "content": user_msg}],
                        temperature=0.3,
                        max_tokens=512,
                    )
                    last_output = resp.text
                except Exception as e:
                    success = False
                    error_msg = f"step {i} LLM failed: {e}"
                    break
            else:
                last_output = step.description
            outputs.append(last_output)

        duration = __import__("time").time() - start_ts
        call_id = ToolCall(tool=self.name, parameters=params).id

        # v5: record skill usage so stats evolve.
        if self.skill_manager is not None:
            try:
                await self.skill_manager.record_skill_use(
                    self.skill.id, success=success,
                )
            except Exception:
                pass  # non-fatal

        if not success:
            return ToolResult(
                call_id=call_id, tool=self.name, success=False,
                error=error_msg, duration_s=duration,
            )
        return ToolResult(
            call_id=call_id, tool=self.name, success=True,
            output=last_output,
            metadata={"steps_executed": len(outputs), "all_outputs": outputs},
            duration_s=duration,
        )


# ──────────────────────────────────────────────────────────────────────────────
# DefaultSkillEvolver
# ──────────────────────────────────────────────────────────────────────────────


class DefaultSkillEvolver(SkillEvolver):
    """Default skill-evolution pipeline.

    Wires together :class:`PatternMiner` + :class:`LLMSkillExtractor`
    + the existing :class:`~adonai.skills.manager.SkillManager`, and
    exposes the evolved skills as :class:`SkillTool` instances on a
    tool registry.
    """

    def __init__(
        self,
        llm: LLMClient | None = None,
        experience_store: Any = None,
        skill_manager: Any = None,
        tool_registry: Any = None,
        *,
        config: Any = None,
        memory_manager: Any = None,
        runtime: Any = None,
    ) -> None:
        self.llm = llm
        self.config = config
        self.experiences = experience_store
        self.skills = skill_manager
        self.tools = tool_registry
        # v4.1 — when a skill is promoted to a tool, we ALSO write a
        # PROCEDURAL memory entry describing the procedure so the
        # planner can recall "how to do X" without re-learning from
        # scratch.  Without this, learned procedures are only stored
        # in the SkillManager (which the planner doesn't query).
        self.memory_manager = memory_manager
        # v9 fix: hold a runtime reference so verify_skill can replay
        # held-out experiences as real tasks through the runtime
        # (runtime.run(goal)) instead of faking a pass with a trivial
        # Task(goal=example_goal). When None, verification is skipped
        # with a warning (see run_cycle).
        self.runtime = runtime
        min_obs = (
            getattr(getattr(config, "skill_evolution", None),
                    "min_observations_to_extract", 3)
            if config else 3
        )
        self.miner = PatternMiner(experience_store, min_observations=min_obs)
        self.extractor = LLMSkillExtractor(llm)

    # ── SkillEvolver interface ───────────────────────────────────────────

    async def mine_patterns(self) -> list[dict[str, Any]]:
        return await self.miner.mine()

    async def extract_skill(
        self, pattern: dict[str, Any],
    ) -> Skill | None:
        skill = await self.extractor.extract(pattern)
        if skill is None:
            return None
        # Persist via SkillManager if available.
        if self.skills is not None:
            try:
                # SkillManager has a store attribute.
                store = getattr(self.skills, "store", None)
                if store is not None:
                    await store.save(skill)
            except Exception as e:
                log.warning("Skill persist failed: %s", e)
        return skill

    async def promote_to_tool(self, skill: Skill) -> str:
        """Register a skill as a callable :class:`SkillTool`.

        Returns the tool name (e.g. ``"skill.research_company"``).

        Also writes a PROCEDURAL memory entry describing the procedure
        so the planner can recall "how to do X" without re-learning.
        """
        if self.tools is None:
            raise SkillError(
                "SkillEvolver has no tool_registry — cannot promote skill"
            )
        tool = SkillTool(
            skill=skill,
            tool_registry=self.tools,
            llm=self.llm,
            # v5: wire the SkillManager so record_skill_use() is called.
            skill_manager=self.skills,
        )
        await self.tools.register(tool, namespace="skill")
        log.info("Promoted skill '%s' to tool '%s'", skill.name, tool.name)
        # ── Write a PROCEDURAL memory so the planner can recall how ──
        # to do this task without re-learning from scratch.
        if self.memory_manager is not None:
            try:
                from adonai.core.models import Memory, MemoryType
                # Build a compact description of the procedure.
                proc_steps = []
                for i, step in enumerate(skill.procedure, 1):
                    tool_name = getattr(step, "tool", "?") or "llm.synthesize"
                    desc = getattr(step, "description", "") or ""
                    proc_steps.append(f"  {i}. {tool_name}: {desc}")
                content = (
                    f"Procedure: {skill.name}\n"
                    f"Description: {skill.description}\n\n"
                    f"Steps:\n" + "\n".join(proc_steps)
                )
                await self.memory_manager.add(Memory(
                    type=MemoryType.PROCEDURAL,
                    content=content,
                    importance=0.9,  # procedures are high-value
                    source="skill_evolver",
                    tags=["procedure", "skill", skill.name],
                    metadata={
                        "skill_id": skill.id,
                        "skill_name": skill.name,
                        "step_count": len(skill.procedure),
                        "trigger_patterns": skill.trigger_patterns,
                    },
                ))
            except Exception as e:
                log.debug(
                    "Procedural memory write for skill '%s' failed: %s",
                    skill.name, e,
                )
        return tool.name

    async def verify_skill(
        self, skill: Skill, held_out_examples: list[Task],
    ) -> dict[str, Any]:
        """Behaviorally verify a skill against held-out examples.

        For each example, the evolver builds a Task with the example
        goal, runs the skill as a tool, and checks the result.  The
        skill passes if ``success_rate >=
        config.skill_evolution.min_success_rate_to_promote``.

        v9 fix: when a runtime reference is available, replay each
        held-out example's goal through the runtime (runtime.run(goal))
        instead of directly invoking the skill tool with empty kwargs.
        The runtime-based replay exercises the full
        planner→executor→skill pipeline, so it actually tests whether
        the skill is invokable from a realistic task flow. The direct
        tools.execute() path is kept as a fallback for when no runtime
        is wired (e.g. unit tests).
        """
        if not held_out_examples:
            return {"pass": False, "reason": "no held-out examples provided"}
        if self.tools is None:
            return {"pass": False, "reason": "no tool_registry available"}
        # Ensure the skill is registered.
        try:
            await self.promote_to_tool(skill)
        except SkillError as e:
            return {"pass": False, "reason": str(e)}
        tool_name = f"skill.{skill.name}"
        results: list[bool] = []
        for example in held_out_examples:
            try:
                # v9 fix: prefer runtime-based replay when available.
                if self.runtime is not None and hasattr(self.runtime, "run"):
                    # Replay the held-out goal through the full runtime
                    # pipeline. The skill is registered as a tool, so
                    # the planner/executor can pick it up. We treat a
                    # COMPLETED task as success, anything else as fail.
                    task_result = await self.runtime.run(example.goal)
                    results.append(
                        bool(task_result)
                        and getattr(task_result, "status", None) == TaskStatus.COMPLETED
                    )
                    continue
                # Fallback: direct tool invocation.
                tr = await self.tools.execute(tool_name, **example.context)
                results.append(bool(tr.success))
            except Exception as e:
                log.debug(
                    "verify_skill: example '%s' raised: %s",
                    getattr(example, "goal", "")[:80], e,
                )
                results.append(False)
        success_rate = sum(1 for r in results if r) / len(results)
        min_rate = (
            getattr(getattr(self.config, "skill_evolution", None),
                    "min_success_rate_to_promote", 0.7)
            if self.config else 0.7
        )
        return {
            "pass": success_rate >= min_rate,
            "success_rate": success_rate,
            "samples": len(results),
            "results": results,
        }

    # ── Full pipeline ────────────────────────────────────────────────────

    async def run_cycle(self) -> dict[str, Any]:
        """Run the full mine → extract → promote → verify cycle.

        Returns a summary dict with counts.

        v9 fix: previously verification was faked by building a trivial
        Task(goal=pattern.get("example_goal", "test")) and running it
        as a tool — any skill that didn't crash would pass. We now:
          1. Hold out the LAST experience from each pattern's
             experience group (pattern["experiences"]).
          2. If a runtime reference is available, replay that held-out
             experience's goal through the runtime (runtime.run(goal))
             with the skill registered as a tool, and check the result.
          3. If no runtime is available OR the pattern has no
             experiences, skip verification with a warning instead of
             faking a pass. The skill is still promoted (since we
             can't verify it) but a warning is logged so operators
             know the verification gate didn't fire.
        """
        patterns = await self.mine_patterns()
        promoted = 0
        rejected = 0
        skipped_verification = 0
        for pattern in patterns:
            try:
                skill = await self.extract_skill(pattern)
                if skill is None:
                    rejected += 1
                    continue
                # v9 fix: build held-out examples from the pattern's
                # real experience group (last experience held out).
                # Fall back to skipping verification if no experiences
                # or no runtime.
                experiences = pattern.get("experiences") or []
                held_out: list[Task] = []
                if experiences and self.runtime is not None:
                    # Hold out the LAST experience — replay its goal as
                    # a real task through the runtime during verify_skill.
                    held_out_exp = experiences[-1]
                    held_out.append(Task(
                        goal=held_out_exp.task_goal,
                        complexity=held_out_exp.task_complexity,
                    ))
                # Optionally verify before promoting.
                if self.tools is not None and held_out:
                    verification = await self.verify_skill(skill, held_out)
                    if not verification.get("pass"):
                        log.info(
                            "Skill '%s' failed verification (%s)",
                            skill.name, verification,
                        )
                        rejected += 1
                        continue
                elif self.tools is None:
                    # No tool registry — can't register the skill as a
                    # tool, so verification is impossible. Promote only
                    # if we have a SkillManager to persist it.
                    log.warning(
                        "Skill '%s' verification skipped — no tool_registry "
                        "available (promoting without verification gate)",
                        skill.name,
                    )
                    skipped_verification += 1
                elif not held_out:
                    # No held-out examples available (no experiences in
                    # pattern, or no runtime to replay them through).
                    # Skip verification with a warning rather than
                    # faking a pass.
                    reason = "no experiences in pattern" if not experiences else "no runtime reference"
                    log.warning(
                        "Skill '%s' verification skipped — %s "
                        "(promoting without verification gate)",
                        skill.name, reason,
                    )
                    skipped_verification += 1
                promoted += 1
            except Exception as e:
                log.warning("Skill evolution cycle error: %s", e)
                rejected += 1
        log.info(
            "SkillEvolver cycle: %d patterns → %d promoted, %d rejected, "
            "%d skipped verification",
            len(patterns), promoted, rejected, skipped_verification,
        )
        return {
            "patterns_found": len(patterns),
            "promoted": promoted,
            "rejected": rejected,
            "skipped_verification": skipped_verification,
        }


__all__ = [
    "PatternMiner",
    "LLMSkillExtractor",
    "SkillTool",
    "DefaultSkillEvolver",
]
