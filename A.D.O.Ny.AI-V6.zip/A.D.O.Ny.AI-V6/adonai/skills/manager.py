"""SkillManager — orchestrates SkillStore + Extractor + Ranker."""
from __future__ import annotations
import logging
import re
from typing import Any
from adonai.config.settings import Config
from adonai.core.events import EventPublisher, EventTypes
from adonai.core.models import ComposedSkill, Plan, Skill, Task, TaskResult, TaskStatus
from adonai.skills.extractor import SkillExtractor
from adonai.skills.ranker import SkillRanker
from adonai.skills.store import SQLiteSkillStore
log = logging.getLogger(__name__)

class SkillManager(EventPublisher):
    def __init__(self, config: Config, llm: Any | None = None) -> None:
        self.config = config
        self.store = SQLiteSkillStore(config.memory.sqlite_path)
        self.extractor = SkillExtractor(llm) if llm is not None else None
        self.ranker = SkillRanker(self.store)

    async def compose_skills(
        self,
        component_skill_ids: list[str],
        *,
        name: str,
        description: str,
        composition_strategy: str = "sequential",
        condition: str | None = None,
    ) -> ComposedSkill | None:
        """Compose two or more existing skills into a new ComposedSkill.

        Args:
            component_skill_ids: IDs of the skills to compose (≥ 2).
            name: Name for the new composed skill.
            description: What the composed skill does.
            composition_strategy: ``sequential`` (run in order, output
                chains), ``parallel`` (run all, merge outputs), or
                ``conditional`` (run next only if ``condition`` evals
                True against the prior output).
            condition: Python expression for conditional composition
                (e.g. ``"output.get('success') is True"``).

        Returns:
            The newly created + persisted ComposedSkill, or None on
            failure (e.g. component skills not found).
        """
        if len(component_skill_ids) < 2:
            raise ValueError("compose_skills requires at least 2 component skills")

        # Load all components.
        components: list[Skill] = []
        for sid in component_skill_ids:
            skill = await self.store.load(sid)
            if skill is None:
                log.warning("ComposedSkill: component %s not found — aborting", sid)
                return None
            components.append(skill)

        # Merge the procedures in order.
        merged_procedure: list = []
        merged_tools: list[str] = []
        merged_triggers: list[str] = []
        for comp in components:
            merged_procedure.extend(comp.procedure)
            merged_tools.extend(comp.required_tools)
            merged_triggers.extend(comp.trigger_patterns[:3])

        composed = ComposedSkill(
            name=name,
            description=description,
            component_skill_ids=component_skill_ids,
            composition_strategy=composition_strategy,
            condition=condition,
            procedure=merged_procedure,
            required_tools=list(dict.fromkeys(merged_tools)),  # dedup preserve order
            trigger_patterns=merged_triggers[:7],
            tags=["composed"] + [f"composed_of:{sid}" for sid in component_skill_ids],
            success_rate=min(c.success_rate for c in components),
        )
        await self.store.save(composed)
        log.info(
            "Composed skill '%s' from %d components (strategy=%s)",
            name, len(components), composition_strategy,
        )

        # Emit skill.composed event.
        await self._emit(EventTypes.SKILL_COMPOSED, {
            "skill_id": composed.id,
            "name": name,
            "component_count": len(components),
            "component_ids": component_skill_ids,
            "strategy": composition_strategy,
        })

        return composed

    async def extract_from_task(self, task: Task, plan: Plan | None, result: TaskResult) -> Skill | None:
        if result.status != TaskStatus.COMPLETED: return None
        if not plan or len(plan.steps) < 2: return None
        if self.extractor is not None:
            try:
                skill = await self.extractor.extract(task, plan, result)
                if skill is not None:
                    await self.store.save(skill)
                    log.info("Extracted skill '%s' from task %s", skill.name, task.id)
                    return skill
            except Exception as e:
                log.warning("LLM skill extraction failed: %s — using heuristic", e)
        try:
            from adonai.core.models import SkillCategory
            g = task.goal.lower()
            if any(w in g for w in ["code","write","implement","build","script"]):
                cat = SkillCategory.CODING
            elif any(w in g for w in ["search","research","find","news"]):
                cat = SkillCategory.RESEARCH
            elif any(w in g for w in ["web","fetch","url"]):
                cat = SkillCategory.WEB
            elif any(w in g for w in ["analyze","data","csv","json"]):
                cat = SkillCategory.ANALYSIS
            elif any(w in g for w in ["design","optimize","engineer","nozzle","turbine"]):
                cat = SkillCategory.PROJECT_MANAGEMENT
            else:
                cat = SkillCategory.CUSTOM

            # IMPROVED naming algorithm
            skill_name = self._generate_skill_name(task.goal, cat)

            # Generate trigger patterns
            triggers = self._generate_triggers(task.goal)

            # Collect tools used
            tools_used = list(set(s.tool for s in plan.steps if s.tool))

            skill = Skill(
                name=skill_name,
                description=f"Skill from: {task.goal[:200]}",
                category=cat,
                trigger_patterns=triggers,
                procedure=[s for s in plan.steps if s.status == TaskStatus.COMPLETED],
                required_tools=tools_used,
                created_from=task.id,
                success_rate=1.0,
                usage_count=1,
            )
            await self.store.save(skill)
            log.info("Extracted heuristic skill '%s' from task %s", skill_name, task.id)
            return skill
        except Exception as e:
            log.warning("Heuristic skill extraction failed: %s", e)
            return None

    def _generate_skill_name(self, goal: str, category: str) -> str:
        """Generate a clean, descriptive skill name from the goal text.

        IMPROVED: Strips punctuation, skips question words, uses action verbs.
        """
        g = goal.lower().strip()

        # Remove common question prefixes
        question_prefixes = [
            "how do you ", "how does it ", "how do i ", "how to ",
            "what is ", "what are ", "what's ", "whats ",
            "why do ", "why does ", "why is ",
            "can you ", "could you ", "do you ",
            "tell me about ", "explain ",
        ]
        for prefix in question_prefixes:
            if g.startswith(prefix):
                g = g[len(prefix):]
                break

        # Remove punctuation
        g = re.sub(r'[^\w\s]', '', g)

        # Split into words
        words = g.split()

        # Skip stop words
        stop_words = {
            "the", "a", "an", "is", "are", "was", "were", "be", "been",
            "to", "of", "in", "on", "at", "for", "with", "by",
            "and", "or", "but", "not", "so", "if", "then",
            "this", "that", "these", "those", "it", "its",
            "i", "you", "he", "she", "we", "they", "me", "him", "her",
            "my", "your", "his", "our", "their",
            "do", "does", "did", "have", "has", "had",
            "will", "would", "can", "could", "should", "shall",
            "about", "into", "from", "than", "then", "just",
            "please", "also", "very", "much", "some", "any",
        }
        content_words = [w for w in words if w not in stop_words and len(w) > 2]

        if not content_words:
            # Fallback: use category + timestamp
            return f"{category}_skill"

        # Take first 3 content words
        name_parts = content_words[:3]
        return "_".join(name_parts)

    def _generate_triggers(self, goal: str) -> list[str]:
        """Generate trigger patterns for skill matching."""
        g = goal.lower().strip()
        triggers = [goal[:80]]  # Original goal as first trigger

        # Add key content words as triggers
        words = re.findall(r'\b\w{4,}\b', g)
        stop_words = {"about", "would", "could", "please", "should", "these", "those", "their"}
        for w in words:
            if w not in stop_words:
                triggers.append(w)

        # Add action-based triggers
        if "write" in g or "create" in g or "generate" in g:
            triggers.append("write code")
            triggers.append("create script")
        if "search" in g or "find" in g or "research" in g:
            triggers.append("search for")
            triggers.append("research")
        if "analyze" in g or "examine" in g or "inspect" in g:
            triggers.append("analyze")
            triggers.append("examine")

        return triggers[:7]  # Max 7 triggers

    async def find_skills_for_goal(self, goal: str, top_k: int = 3) -> list[Skill]:
        return await self.ranker.rank_for_goal(goal, top_k=top_k)

    async def list_all(self) -> list[Skill]:
        return await self.store.list_all()

    async def record_skill_use(self, skill_id: str, success: bool) -> None:
        await self.store.update_stats(skill_id, success)

    async def retire_low_performers(self) -> int:
        return await self.ranker.retire_low_performers(self.config.skills.min_success_rate)
