"""Upgrade 11 — Simulation Abstraction Layer.

Universal simulation interface that supports future integrations:

* OpenFOAM (CFD)
* PyBullet (rigid-body physics)
* CARLA (autonomous driving)
* Isaac Sim (robotics)
* Custom simulators

Common API::

    run_simulation(spec)   → SimulationResult
    collect_metrics(result, names) → dict[str, float]
    evaluate_results(result, criteria) → dict[str, Any]
    health_check() → bool

Concrete adapters live in this module.  The package exports
:class:`MockSimulator` (zero-dependency reference implementation),
CLI-based adapters (:class:`OpenFOAMSimulator`), Python-based adapters
(:class:`PyBulletSimulator`, :class:`CarlASimulator`,
:class:`IsaacSimSimulator`), and a :class:`SimulatorRegistry` for
runtime lookup.
"""
from __future__ import annotations

import asyncio
import logging
import math
import random
import re
import time
from datetime import datetime, timezone
from typing import Any

from adonai.core.exceptions import SimulationError
from adonai.core.interfaces import Simulator
from adonai.core.models import (
    SimulationResult, SimulationSpec, SimulationStatus,
)

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# MockSimulator — reference implementation
# ──────────────────────────────────────────────────────────────────────────────


class MockSimulator(Simulator):
    """Zero-dependency simulator that returns deterministic-ish metrics.

    Useful for unit tests, demos, and as a fallback when a real simulator
    backend is unavailable.  Each metric is computed as::

        metric_value = base + amplitude * sin(param1) + noise(seed)

    where ``base`` and ``amplitude`` come from ``spec.config``.
    """

    name: str = "mock"

    async def run_simulation(self, spec: SimulationSpec) -> SimulationResult:
        start = datetime.now(timezone.utc)
        start_ts = time.time()
        # Simulate work proportional to the number of parameters.
        work_units = max(1, len(spec.parameters))
        work_s = min(spec.timeout_s, 0.05 * work_units)
        await asyncio.sleep(work_s)

        result = SimulationResult(
            spec=spec,
            status=SimulationStatus.COMPLETED,
            started_at=start,
            completed_at=datetime.now(timezone.utc),
            duration_s=time.time() - start_ts,
            metrics={},
            log=f"mock simulation ran for {work_s:.3f}s",
        )
        # Collect any requested metrics.
        try:
            result.metrics = await self.collect_metrics(result, spec.metrics)
        except Exception as e:
            log.warning("Mock metric collection failed: %s", e)
        return result

    async def collect_metrics(
        self, result: SimulationResult, metric_names: list[str],
    ) -> dict[str, float]:
        out: dict[str, float] = {}
        params = result.spec.parameters
        config = result.spec.config or {}
        # Deterministic seed from the parameters for reproducibility.
        seed_str = repr(sorted(params.items()))
        seed = abs(hash(seed_str)) % (2**32)
        rng = random.Random(seed)
        for name in metric_names:
            base = float(config.get(f"{name}_base", 0.5))
            amp = float(config.get(f"{name}_amplitude", 0.3))
            # Use the first parameter's value as the "input" if available.
            input_val = next(iter(params.values()), 1.0)
            try:
                x = float(input_val)
            except (TypeError, ValueError):
                x = 1.0
            value = base + amp * math.sin(x) + rng.uniform(-0.02, 0.02)
            out[name] = round(value, 6)
        return out

    async def evaluate_results(
        self, result: SimulationResult, criteria: dict[str, Any],
    ) -> dict[str, Any]:
        """Evaluate a result against threshold criteria.

        ``criteria`` is a dict like ``{"efficiency": {"min": 0.4,
        "max": 0.95}}``.  Each metric in ``result.metrics`` is checked
        against its criteria; the returned dict has a ``pass`` boolean
        and a per-metric breakdown.
        """
        out: dict[str, Any] = {"pass": True, "metrics": {}}
        for metric_name, conds in criteria.items():
            if metric_name not in result.metrics:
                out["metrics"][metric_name] = {
                    "value": None, "pass": False,
                    "reason": "metric not in result",
                }
                out["pass"] = False
                continue
            value = result.metrics[metric_name]
            metric_pass = True
            reasons: list[str] = []
            if "min" in conds and value < conds["min"]:
                metric_pass = False
                reasons.append(f"value {value} < min {conds['min']}")
            if "max" in conds and value > conds["max"]:
                metric_pass = False
                reasons.append(f"value {value} > max {conds['max']}")
            if "equals" in conds and value != conds["equals"]:
                metric_pass = False
                reasons.append(f"value {value} != target {conds['equals']}")
            out["metrics"][metric_name] = {
                "value": value, "pass": metric_pass,
                "reasons": reasons,
            }
            if not metric_pass:
                out["pass"] = False
        return out

    async def health_check(self) -> bool:
        return True  # always healthy


# ──────────────────────────────────────────────────────────────────────────────
# CLI-based simulator (for OpenFOAM-style backends)
# ──────────────────────────────────────────────────────────────────────────────


class CLISimulator(Simulator):
    """Base class for CLI-driven simulators (OpenFOAM, SU2, etc.).

    Subclasses override :meth:`_build_command` to produce the shell
    command that runs the simulation.  The base class handles subprocess
    execution, timeout, and stdout/stderr capture.
    """

    name: str = "cli"

    def __init__(
        self,
        binary: str = "",
        *,
        default_timeout_s: float = 600.0,
        env: dict[str, str] | None = None,
    ) -> None:
        self.binary = binary
        self.default_timeout_s = default_timeout_s
        self.env = env

    async def run_simulation(self, spec: SimulationSpec) -> SimulationResult:
        if not self.binary:
            raise SimulationError(
                f"{self.name}: no binary configured (set binary=...)"
            )
        start = datetime.now(timezone.utc)
        start_ts = time.time()
        cmd = self._build_command(spec)
        timeout = min(spec.timeout_s or self.default_timeout_s,
                      self.default_timeout_s)
        try:
            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=self.env,
            )
            try:
                stdout, stderr = await asyncio.wait_for(
                    proc.communicate(), timeout=timeout,
                )
            except asyncio.TimeoutError:
                proc.kill()
                await proc.wait()
                raise SimulationError(
                    f"{self.name}: timeout after {timeout}s"
                )
            status = (
                SimulationStatus.COMPLETED if proc.returncode == 0
                else SimulationStatus.FAILED
            )
            result = SimulationResult(
                spec=spec,
                status=status,
                started_at=start,
                completed_at=datetime.now(timezone.utc),
                duration_s=time.time() - start_ts,
                log=(stdout or b"").decode("utf-8", errors="replace"),
                error=(stderr or b"").decode("utf-8", errors="replace") or None,
            )
            if status == SimulationStatus.COMPLETED:
                try:
                    result.metrics = await self.collect_metrics(
                        result, spec.metrics,
                    )
                except Exception as e:
                    log.warning("%s metric collection failed: %s", self.name, e)
            return result
        except FileNotFoundError as e:
            raise SimulationError(
                f"{self.name}: binary not found ({self.binary})"
            ) from e

    def _build_command(self, spec: SimulationSpec) -> list[str]:
        """Override in subclasses to produce the shell command."""
        raise NotImplementedError

    async def collect_metrics(
        self, result: SimulationResult, metric_names: list[str],
    ) -> dict[str, float]:
        """Parse metrics from the simulation log.

        Default implementation looks for ``metric_name=value`` lines in
        the log.  Subclasses can override for custom parsers.
        """
        out: dict[str, float] = {}
        log_text = result.log or ""
        for name in metric_names:
            m = re.search(
                rf"\b{re.escape(name)}\s*[:=]\s*(-?\d+\.?\d*)",
                log_text,
            )
            if m:
                try:
                    out[name] = float(m.group(1))
                except ValueError:
                    pass
        return out

    async def evaluate_results(
        self, result: SimulationResult, criteria: dict[str, Any],
    ) -> dict[str, Any]:
        return await MockSimulator().evaluate_results(result, criteria)

    async def health_check(self) -> bool:
        """Check if the binary exists by running `--version` (best effort)."""
        if not self.binary:
            return False
        try:
            proc = await asyncio.create_subprocess_exec(
                self.binary, "--version",
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await asyncio.wait_for(proc.wait(), timeout=5.0)
            return True
        except Exception:
            return False


# ──────────────────────────────────────────────────────────────────────────────
# Concrete adapter stubs
# ──────────────────────────────────────────────────────────────────────────────


class OpenFOAMSimulator(CLISimulator):
    """OpenFOAM CFD solver adapter.

    Expects a configured OpenFOAM case directory in
    ``spec.config["case_dir"]``.  Runs ``simpleFoam`` (or the solver
    specified in ``spec.config["solver"]``) and parses convergence
    metrics from the log.
    """

    name: str = "openfoam"

    def __init__(
        self, binary: str = "simpleFoam", *,
        default_timeout_s: float = 3600.0,
        env: dict[str, str] | None = None,
    ) -> None:
        super().__init__(binary, default_timeout_s=default_timeout_s, env=env)

    def _build_command(self, spec: SimulationSpec) -> list[str]:
        case_dir = spec.config.get("case_dir", ".")
        solver = spec.config.get("solver", self.binary)
        return [solver, "-case", str(case_dir)]


class PyBulletSimulator(Simulator):
    """PyBullet rigid-body physics adapter.

    Requires the ``pybullet`` Python package.  Expects
    ``spec.config["script"]`` to point to a Python file that uses
    pybullet and prints metrics as ``name = value`` lines.
    """

    name: str = "pybullet"

    async def run_simulation(self, spec: SimulationSpec) -> SimulationResult:
        script = spec.config.get("script")
        if not script:
            raise SimulationError("pybullet: spec.config['script'] required")
        # v9 fix: graceful degradation when the pybullet package isn't
        # installed. Previously the simulator would proceed to spawn a
        # subprocess running `python <script>`, which would then fail
        # inside the script with an ImportError on `import pybullet`
        # — producing a SimulationStatus.FAILED result whose error
        # message was opaque ("No module named 'pybullet'" buried in
        # stderr). Callers had no way to know the failure was due to
        # missing optional deps vs. an actual simulation bug. We now
        # detect the missing dep up-front, log a clear warning, and
        # delegate to MockSimulator so the experiment loop can
        # continue with mocked metrics. Callers don't need to change
        # their code — same SimulationResult shape, just COMPLETED
        # instead of FAILED with a warning in the log.
        try:
            import pybullet  # noqa: F401
        except ImportError:
            log.warning(
                "pybullet package not installed — falling back to "
                "MockSimulator for spec=%r (install with `pip install "
                "pybullet` for real physics)",
                getattr(spec, "name", None) or spec.simulator,
            )
            mock = MockSimulator()
            mock_result = await mock.run_simulation(spec)
            # Annotate the result so downstream consumers can tell
            # this was a mocked run, not a real one.
            mock_result.log = (
                f"[mocked: pybullet not installed] {mock_result.log or ''}"
            )
            return mock_result
        start = datetime.now(timezone.utc)
        start_ts = time.time()
        try:
            proc = await asyncio.create_subprocess_exec(
                "python", str(script),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=spec.timeout_s,
            )
            status = (
                SimulationStatus.COMPLETED if proc.returncode == 0
                else SimulationStatus.FAILED
            )
            result = SimulationResult(
                spec=spec,
                status=status,
                started_at=start,
                completed_at=datetime.now(timezone.utc),
                duration_s=time.time() - start_ts,
                log=(stdout or b"").decode("utf-8", errors="replace"),
                error=(stderr or b"").decode("utf-8", errors="replace") or None,
            )
            if status == SimulationStatus.COMPLETED:
                result.metrics = await self.collect_metrics(
                    result, spec.metrics,
                )
            return result
        except Exception as e:
            raise SimulationError(f"pybullet: {e}") from e

    async def collect_metrics(
        self, result: SimulationResult, metric_names: list[str],
    ) -> dict[str, float]:
        return await CLISimulator(binary="").collect_metrics(result, metric_names)

    async def evaluate_results(
        self, result: SimulationResult, criteria: dict[str, Any],
    ) -> dict[str, Any]:
        return await MockSimulator().evaluate_results(result, criteria)

    async def health_check(self) -> bool:
        try:
            import pybullet  # noqa: F401
            return True
        except ImportError:
            return False


class CarlASimulator(Simulator):
    """CARLA autonomous-driving simulator adapter.

    Requires the ``carla`` Python package and a running CARLA server.
    When the package is available and ``spec.config["script"]`` points to
    a Python file that uses the carla API and prints metrics as
    ``name = value`` lines, this adapter runs the script in a subprocess
    (matching the PyBullet pattern). When the package is not available,
    returns a FAILED result with a clear error message.
    """

    name: str = "carla"

    async def run_simulation(self, spec: SimulationSpec) -> SimulationResult:
        start = datetime.now(timezone.utc)
        start_ts = time.time()
        # Check if carla package is available.
        try:
            import carla  # noqa: F401
        except ImportError:
            # v9 fix: graceful degradation — fall back to MockSimulator
            # instead of returning FAILED with "package not installed".
            # This keeps the experiment loop running when optional deps
            # are missing, with a clear log warning so operators know
            # the simulation is being mocked. Callers don't need to
            # change their code.
            log.warning(
                "CARLA Python package not installed — falling back to "
                "MockSimulator for spec=%r (install with `pip install "
                "carla` and run a CARLA server on localhost:2000 for "
                "real autonomous-driving simulation)",
                getattr(spec, "name", None) or spec.simulator,
            )
            mock = MockSimulator()
            mock_result = await mock.run_simulation(spec)
            mock_result.log = (
                f"[mocked: carla not installed] {mock_result.log or ''}"
            )
            return mock_result
        script = spec.config.get("script")
        if not script:
            return SimulationResult(
                spec=spec,
                status=SimulationStatus.FAILED,
                error="carla: spec.config['script'] required (Python file "
                      "that uses the carla API)",
                started_at=start,
                completed_at=datetime.now(timezone.utc),
                duration_s=0.0,
            )
        try:
            proc = await asyncio.create_subprocess_exec(
                "python", str(script),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=spec.timeout_s,
            )
            status = (
                SimulationStatus.COMPLETED if proc.returncode == 0
                else SimulationStatus.FAILED
            )
            result = SimulationResult(
                spec=spec,
                status=status,
                started_at=start,
                completed_at=datetime.now(timezone.utc),
                duration_s=time.time() - start_ts,
                log=(stdout or b"").decode("utf-8", errors="replace"),
                error=(stderr or b"").decode("utf-8", errors="replace") or None,
            )
            if status == SimulationStatus.COMPLETED:
                result.metrics = await self.collect_metrics(
                    result, spec.metrics,
                )
            return result
        except asyncio.TimeoutError:
            return SimulationResult(
                spec=spec, status=SimulationStatus.FAILED,
                error=f"carla: script timed out after {spec.timeout_s}s",
                started_at=start, completed_at=datetime.now(timezone.utc),
                duration_s=time.time() - start_ts,
            )
        except Exception as e:
            raise SimulationError(f"carla: {e}") from e

    async def collect_metrics(
        self, result: SimulationResult, metric_names: list[str],
    ) -> dict[str, float]:
        return await CLISimulator(binary="").collect_metrics(result, metric_names)

    async def evaluate_results(
        self, result: SimulationResult, criteria: dict[str, Any],
    ) -> dict[str, Any]:
        return await MockSimulator().evaluate_results(result, criteria)

    async def health_check(self) -> bool:
        try:
            import carla  # noqa: F401
            return True
        except ImportError:
            return False


class IsaacSimSimulator(Simulator):
    """NVIDIA Isaac Sim robotics adapter.

    Requires the ``isaacsim`` Python package. When the package is
    available and ``spec.config["script"]`` points to a Python file that
    uses the isaacsim API, this adapter runs the script in a subprocess.
    When the package is not available, returns a FAILED result with a
    clear error message.
    """

    name: str = "isaac_sim"

    async def run_simulation(self, spec: SimulationSpec) -> SimulationResult:
        start = datetime.now(timezone.utc)
        start_ts = time.time()
        try:
            import isaacsim  # noqa: F401
        except ImportError:
            # v9 fix: graceful degradation — fall back to MockSimulator
            # instead of returning FAILED with "package not installed".
            # Keeps the experiment loop running when NVIDIA Isaac Sim
            # isn't installed, with a clear log warning. Operators who
            # need real robotics simulation can install isaacsim from
            # NVIDIA's Omniverse launcher.
            log.warning(
                "Isaac Sim Python package not installed — falling back "
                "to MockSimulator for spec=%r (install from NVIDIA's "
                "Omniverse launcher or `pip install isaacsim` for real "
                "robotics simulation)",
                getattr(spec, "name", None) or spec.simulator,
            )
            mock = MockSimulator()
            mock_result = await mock.run_simulation(spec)
            mock_result.log = (
                f"[mocked: isaacsim not installed] {mock_result.log or ''}"
            )
            return mock_result
        script = spec.config.get("script")
        if not script:
            return SimulationResult(
                spec=spec,
                status=SimulationStatus.FAILED,
                error="isaac_sim: spec.config['script'] required",
                started_at=start,
                completed_at=datetime.now(timezone.utc),
                duration_s=0.0,
            )
        try:
            proc = await asyncio.create_subprocess_exec(
                "python", str(script),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=spec.timeout_s,
            )
            status = (
                SimulationStatus.COMPLETED if proc.returncode == 0
                else SimulationStatus.FAILED
            )
            result = SimulationResult(
                spec=spec,
                status=status,
                started_at=start,
                completed_at=datetime.now(timezone.utc),
                duration_s=time.time() - start_ts,
                log=(stdout or b"").decode("utf-8", errors="replace"),
                error=(stderr or b"").decode("utf-8", errors="replace") or None,
            )
            if status == SimulationStatus.COMPLETED:
                result.metrics = await self.collect_metrics(
                    result, spec.metrics,
                )
            return result
        except asyncio.TimeoutError:
            return SimulationResult(
                spec=spec, status=SimulationStatus.FAILED,
                error=f"isaac_sim: script timed out after {spec.timeout_s}s",
                started_at=start, completed_at=datetime.now(timezone.utc),
                duration_s=time.time() - start_ts,
            )
        except Exception as e:
            raise SimulationError(f"isaac_sim: {e}") from e

    async def collect_metrics(
        self, result: SimulationResult, metric_names: list[str],
    ) -> dict[str, float]:
        return await CLISimulator(binary="").collect_metrics(result, metric_names)

    async def evaluate_results(
        self, result: SimulationResult, criteria: dict[str, Any],
    ) -> dict[str, Any]:
        return await MockSimulator().evaluate_results(result, criteria)

    async def health_check(self) -> bool:
        try:
            import isaacsim  # noqa: F401
            return True
        except ImportError:
            return False


# ──────────────────────────────────────────────────────────────────────────────
# SimulatorRegistry
# ──────────────────────────────────────────────────────────────────────────────


class SimulatorRegistry:
    """Registry + factory for simulators.

    Simulators are registered by name; callers request a simulator by
    name (e.g. ``"openfoam"``) or by inspecting the
    :class:`SimulationSpec.simulator` field.
    """

    def __init__(self) -> None:
        self._simulators: dict[str, Simulator] = {}
        self._factories: dict[str, Any] = {}

    def register(self, simulator: Simulator) -> None:
        self._simulators[simulator.name] = simulator
        log.info("Registered simulator '%s'", simulator.name)

    def register_factory(
        self, name: str, factory: Any,
    ) -> None:
        """Register a lazy factory ``(config) -> Simulator``."""
        self._factories[name] = factory
        log.info("Registered simulator factory '%s'", name)

    def get(self, name: str) -> Simulator:
        # Lazy-instantiate from factory if needed.
        if name not in self._simulators and name in self._factories:
            sim = self._factories[name]()
            self._simulators[name] = sim
        sim = self._simulators.get(name)
        if sim is None:
            raise SimulationError(f"unknown simulator: {name!r}")
        return sim

    def list_simulators(self) -> list[str]:
        return sorted(set(self._simulators) | set(self._factories))

    async def run(self, spec: SimulationSpec) -> SimulationResult:
        sim = self.get(spec.simulator)
        return await sim.run_simulation(spec)


# ──────────────────────────────────────────────────────────────────────────────
# Factory
# ──────────────────────────────────────────────────────────────────────────────


def build_default_registry(config: Any = None) -> SimulatorRegistry:
    """Build a registry with all bundled simulators.

    Real-backend simulators (OpenFOAM, PyBullet, CARLA, Isaac Sim) are
    registered as lazy factories so they don't fail at import time when
    their dependencies are missing.
    """
    registry = SimulatorRegistry()
    # Mock is always available.
    registry.register(MockSimulator())
    # Real backends — lazy factories.
    cfg = getattr(config, "simulation", None) if config else None
    sim_configs = getattr(cfg, "simulators", {}) if cfg else {}
    of_cfg = sim_configs.get("openfoam", {})
    if of_cfg.get("backend") == "cli":
        registry.register_factory(
            "openfoam",
            lambda c=of_cfg: OpenFOAMSimulator(
                binary=c.get("binary", "simpleFoam"),
            ),
        )
    else:
        registry.register_factory(
            "openfoam", lambda: OpenFOAMSimulator(),
        )
    registry.register_factory("pybullet", lambda: PyBulletSimulator())
    registry.register_factory("carla", lambda: CarlASimulator())
    registry.register_factory("isaac_sim", lambda: IsaacSimSimulator())
    return registry


__all__ = [
    "MockSimulator",
    "CLISimulator",
    "OpenFOAMSimulator",
    "PyBulletSimulator",
    "CarlASimulator",
    "IsaacSimSimulator",
    "SimulatorRegistry",
    "build_default_registry",
]
