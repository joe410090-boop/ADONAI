"""Upgrade 12 — Long-Term Strategic Reasoning.

Implements a goals hierarchy::

    Mission → Strategic Goals → Tactical Goals → Tasks

The agent maintains:

* priorities (per-goal priority + dependencies)
* dependencies (which goals block which)
* progress tracking (0..1 per goal)
* success probability (Bayesian-ish estimate that updates as sub-goals
  complete or fail)

The :class:`DefaultStrategicReasoner` decomposes a mission into
sub-goals (LLM-driven when available, heuristic fallback), maintains
them in a SQLite-backed :class:`StrategicGoalStore`, and propagates
progress / probability updates up the hierarchy.
"""
from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from adonai.core.exceptions import StrategicReasoningError
from adonai.core.interfaces import LLMClient, StrategicReasoner
from adonai.core.json_utils import JSONExtractionError, extract_json
from adonai.core.models import (
    GoalLevel, StrategicGoal, TaskPriority,
)

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# SQLite-backed goal store
# ──────────────────────────────────────────────────────────────────────────────


class StrategicGoalStore:
    """SQLite persistence for :class:`StrategicGoal` objects."""

    def __init__(
        self, db_path: str | Path, table: str = "strategic_goals",
    ) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.table = table
        self._ensure_schema()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_schema(self) -> None:
        with self._conn() as conn:
            conn.execute(f"""CREATE TABLE IF NOT EXISTS {self.table} (
                id TEXT PRIMARY KEY,
                level TEXT NOT NULL,
                title TEXT NOT NULL,
                description TEXT,
                parent_goal_id TEXT,
                child_goal_ids TEXT NOT NULL DEFAULT '[]',
                task_ids TEXT NOT NULL DEFAULT '[]',
                priority TEXT NOT NULL DEFAULT 'medium',
                dependencies TEXT NOT NULL DEFAULT '[]',
                progress REAL NOT NULL DEFAULT 0.0,
                success_probability REAL NOT NULL DEFAULT 0.5,
                status TEXT NOT NULL DEFAULT 'proposed',
                target_completion_at REAL,
                created_at REAL NOT NULL,
                updated_at REAL,
                metadata TEXT NOT NULL DEFAULT '{{}}'
            )""")
            conn.execute(
                f"CREATE INDEX IF NOT EXISTS idx_{self.table}_level "
                f"ON {self.table}(level)"
            )
            conn.execute(
                f"CREATE INDEX IF NOT EXISTS idx_{self.table}_parent "
                f"ON {self.table}(parent_goal_id)"
            )
            conn.commit()

    async def save(self, goal: StrategicGoal) -> str:
        now = goal.created_at.timestamp() if goal.created_at else time.time()
        with self._conn() as conn:
            conn.execute(
                f"""INSERT OR REPLACE INTO {self.table}
                    (id, level, title, description, parent_goal_id,
                     child_goal_ids, task_ids, priority, dependencies,
                     progress, success_probability, status,
                     target_completion_at, created_at, updated_at, metadata)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (goal.id, goal.level.value, goal.title, goal.description,
                 goal.parent_goal_id,
                 json.dumps(goal.child_goal_ids),
                 json.dumps(goal.task_ids),
                 goal.priority.value,
                 json.dumps(goal.dependencies),
                 goal.progress, goal.success_probability, goal.status,
                 goal.target_completion_at.timestamp()
                    if goal.target_completion_at else None,
                 now,
                 goal.updated_at.timestamp() if goal.updated_at else None,
                 json.dumps(goal.metadata, default=str)),
            )
            conn.commit()
        return goal.id

    async def load(self, goal_id: str) -> StrategicGoal | None:
        with self._conn() as conn:
            row = conn.execute(
                f"SELECT * FROM {self.table} WHERE id = ?", (goal_id,)
            ).fetchone()
        return _row_to_goal(row) if row else None

    async def list_goals(
        self,
        *,
        level: GoalLevel | None = None,
        parent_id: str | None = None,
        status: str | None = None,
        limit: int = 100,
    ) -> list[StrategicGoal]:
        sql = f"SELECT * FROM {self.table} WHERE 1=1"
        params: list[Any] = []
        if level is not None:
            sql += " AND level = ?"
            params.append(level.value)
        if parent_id is not None:
            sql += " AND parent_goal_id = ?"
            params.append(parent_id)
        if status is not None:
            sql += " AND status = ?"
            params.append(status)
        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        with self._conn() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [_row_to_goal(r) for r in rows]

    async def delete(self, goal_id: str) -> bool:
        with self._conn() as conn:
            cur = conn.execute(
                f"DELETE FROM {self.table} WHERE id = ?", (goal_id,)
            )
            conn.commit()
            return cur.rowcount > 0

    async def get_pending(self, limit: int = 10) -> list[StrategicGoal]:
        """Return goals whose status is 'proposed' or 'in_progress',
        ordered by priority (critical > high > medium > low) then recency.

        v9 fix: Previously StrategicGoalStore had save/load/list_goals/delete
        but no `get_pending` helper. The planner's strategic-goal injection
        (added in v9) needs this method to query active goals at planning
        time. Without it, the strategic_reasoner output was write-only.
        """
        _priority_order = {"critical": 0, "high": 1, "medium": 2, "low": 3}
        sql = (
            f"SELECT * FROM {self.table} "
            f"WHERE status IN ('proposed', 'in_progress', 'pending') "
            f"ORDER BY created_at DESC LIMIT ?"
        )
        with self._conn() as conn:
            rows = conn.execute(sql, (limit,)).fetchall()
        goals = [_row_to_goal(r) for r in rows]
        # Sort by priority (critical first), preserving recency order within a tier.
        goals.sort(key=lambda g: _priority_order.get(
            getattr(g, "priority", None) and g.priority.value or "medium", 2))
        return goals


# ──────────────────────────────────────────────────────────────────────────────
# DefaultStrategicReasoner
# ──────────────────────────────────────────────────────────────────────────────


_DECOMPOSITION_PROMPT = (
    "You are the STRATEGIC REASONER of an autonomous research platform.\n"
    "Given a mission, decompose it into a goal hierarchy.\n\n"
    "Output JSON array of goals (max 10):\n"
    "[\n"
    "  {\n"
    '    "level": "strategic"|"tactical"|"task",\n'
    '    "title": str,\n'
    '    "description": str?,\n'
    '    "priority": "low"|"medium"|"high"|"critical",\n'
    '    "parent_index": int?,          // index of parent goal in this array\n'
    '    "dependencies": [int],         // indices of goals this one depends on\n'
    '    "success_probability": 0.0-1.0\n'
    "  }\n"
    "]\n\n"
    "Rules:\n"
    "1. The first goal MUST be the strategic-level summary.\n"
    "2. Tactical goals decompose strategic goals.\n"
    "3. Task-level goals are concrete actionable items.\n"
    "4. Keep the hierarchy shallow (max 3 levels).\n"
    "Return ONLY the JSON array.  No prose, no markdown fences."
)


class DefaultStrategicReasoner(StrategicReasoner):
    """LLM-backed strategic reasoner with SQLite persistence.

    Falls back to a heuristic decomposer when no LLM is configured.
    """

    def __init__(
        self,
        llm: LLMClient | None = None,
        store: StrategicGoalStore | None = None,
        *,
        config: Any = None,
    ) -> None:
        self.llm = llm
        self.config = config
        if store is None:
            db_path = (
                getattr(getattr(config, "memory", None), "sqlite_path", None)
                or Path("data/adonai.db")
            )
            table = (
                getattr(getattr(config, "strategy", None), "sqlite_table",
                        "strategic_goals")
            )
            store = StrategicGoalStore(db_path, table=table)
        self.store = store

    # ── StrategicReasoner interface ──────────────────────────────────────

    async def decompose(
        self, mission: str, *, depth: int = 3,
    ) -> list[StrategicGoal]:
        """Decompose a mission into a goal hierarchy.

        Returns the full list of goals (strategic + tactical + task).
        Each goal's ``parent_goal_id`` is resolved to its actual id.
        """
        if self.llm is None:
            goals = self._heuristic_decompose(mission, depth)
            # Persist heuristic-generated goals (the LLM path persists
            # inside its own block; we duplicate here for consistency).
            for g in goals:
                try:
                    await self.store.save(g)
                except Exception as e:
                    log.warning("Heuristic goal save failed: %s", e)
            return goals
        # Cap depth to the configured maximum.
        max_depth = (
            getattr(getattr(self.config, "strategy", None), "default_depth", 3)
            if self.config else 3
        )
        depth = min(depth, max_depth)
        user_prompt = (
            f"MISSION: {mission}\n"
            f"DEPTH: {depth} levels\n\n"
            f"Decompose into a goal hierarchy as JSON."
        )
        try:
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": _DECOMPOSITION_PROMPT},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.3,
                max_tokens=2048,
            )
            data = extract_json(resp.text or "")
        except (JSONExtractionError, Exception) as e:
            log.warning(
                "Strategic decomposition LLM failed: %s — using heuristic", e,
            )
            return self._heuristic_decompose(mission, depth)
        if not isinstance(data, list):
            data = [data] if isinstance(data, dict) else []
        # First pass: create goals without parent links.
        goals: list[StrategicGoal] = []
        for item in data[:10]:
            if not isinstance(item, dict):
                continue
            try:
                level = GoalLevel(item.get("level", "tactical"))
            except ValueError:
                level = GoalLevel.TACTICAL
            try:
                priority = TaskPriority(item.get("priority", "medium"))
            except ValueError:
                priority = TaskPriority.MEDIUM
            goal = StrategicGoal(
                level=level,
                title=str(item.get("title", "untitled")),
                description=item.get("description"),
                priority=priority,
                success_probability=float(item.get("success_probability", 0.5)),
                status="active",
            )
            goals.append(goal)
        # Second pass: resolve parent_index → parent_goal_id.
        for i, item in enumerate(data[:len(goals)]):
            if not isinstance(item, dict):
                continue
            parent_idx = item.get("parent_index")
            if isinstance(parent_idx, int) and 0 <= parent_idx < len(goals):
                goals[i].parent_goal_id = goals[parent_idx].id
                if goals[i].id not in goals[parent_idx].child_goal_ids:
                    goals[parent_idx].child_goal_ids.append(goals[i].id)
            # Resolve dependencies.
            dep_indices = item.get("dependencies") or []
            if isinstance(dep_indices, list):
                for dep_idx in dep_indices:
                    if (
                        isinstance(dep_idx, int)
                        and 0 <= dep_idx < len(goals)
                        and dep_idx != i
                    ):
                        if goals[dep_idx].id not in goals[i].dependencies:
                            goals[i].dependencies.append(goals[dep_idx].id)
        # Persist all goals.
        for g in goals:
            try:
                await self.store.save(g)
            except Exception as e:
                log.warning("StrategicGoal save failed: %s", e)
        return goals

    async def prioritize(
        self, goals: list[StrategicGoal],
    ) -> list[StrategicGoal]:
        """Re-order goals by priority × success_probability × dependencies.

        Goals with no outstanding dependencies come first.  Within that,
        higher-priority + higher-probability goals come first.
        """
        priority_rank = {
            TaskPriority.CRITICAL: 4,
            TaskPriority.HIGH: 3,
            TaskPriority.MEDIUM: 2,
            TaskPriority.LOW: 1,
        }
        all_ids = {g.id for g in goals}
        def score(g: StrategicGoal) -> tuple[int, float, float]:
            # 1 if all dependencies are in `goals` AND completed.
            deps_complete = all(
                dep not in all_ids
                or any(d.id == dep and d.status == "completed" for d in goals)
                for dep in g.dependencies
            )
            unblocked = 1 if deps_complete else 0
            return (
                unblocked,
                priority_rank.get(g.priority, 2) * 0.4 + g.success_probability * 0.6,
                g.progress,
            )
        return sorted(goals, key=score, reverse=True)

    async def update_progress(
        self, goal_id: str, progress_delta: float,
    ) -> StrategicGoal:
        """Update a goal's progress and propagate to ancestors."""
        goal = await self.store.load(goal_id)
        if goal is None:
            raise StrategicReasoningError(f"goal not found: {goal_id}")
        goal.progress = max(0.0, min(1.0, goal.progress + progress_delta))
        if goal.progress >= 1.0:
            goal.status = "completed"
        elif goal.progress > 0.0 and goal.status == "proposed":
            goal.status = "active"
        # Success probability nudges: completing lifts probability,
        # failing lowers it.
        decay = (
            getattr(getattr(self.config, "strategy", None),
                    "success_probability_decay", 0.05)
            if self.config else 0.05
        )
        if progress_delta > 0:
            goal.success_probability = min(
                0.99, goal.success_probability + abs(progress_delta) * 0.1,
            )
        elif progress_delta < 0:
            goal.success_probability = max(
                0.01, goal.success_probability - decay,
            )
        goal.updated_at = datetime.now(timezone.utc)
        await self.store.save(goal)
        # Propagate to parent.
        if goal.parent_goal_id:
            try:
                await self._propagate_to_parent(goal.parent_goal_id)
            except Exception as e:
                log.debug("Progress propagation failed: %s", e)
        return goal

    async def replan_strategy(
        self, blocked_goal: StrategicGoal,
    ) -> list[StrategicGoal]:
        """Re-decompose a blocked goal into alternative sub-goals.

        Marks the blocked goal as ``"blocked"`` and creates one or more
        alternative tactical goals that route around the blockage.
        """
        if blocked_goal.status != "blocked":
            blocked_goal.status = "blocked"
            blocked_goal.updated_at = datetime.now(timezone.utc)
            await self.store.save(blocked_goal)
        # Generate alternatives.
        if self.llm is None:
            return self._heuristic_alternatives(blocked_goal)
        user_prompt = (
            f"BLOCKED GOAL: {blocked_goal.title}\n"
            f"DESCRIPTION: {blocked_goal.description or '(none)'}\n"
            f"PARENT: {blocked_goal.parent_goal_id or '(top-level)'}\n\n"
            f"Propose 1-3 alternative tactical goals that route around "
            f"this blockage.  Output the same JSON array schema."
        )
        try:
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": _DECOMPOSITION_PROMPT},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.4,
                max_tokens=1024,
            )
            data = extract_json(resp.text or "")
        except (JSONExtractionError, Exception) as e:
            log.warning("Strategic replan LLM failed: %s — using heuristic", e)
            return self._heuristic_alternatives(blocked_goal)
        if not isinstance(data, list):
            data = [data] if isinstance(data, dict) else []
        alternatives: list[StrategicGoal] = []
        for item in data[:3]:
            if not isinstance(item, dict):
                continue
            try:
                level = GoalLevel(item.get("level", "tactical"))
            except ValueError:
                level = GoalLevel.TACTICAL
            try:
                priority = TaskPriority(item.get("priority", "medium"))
            except ValueError:
                priority = TaskPriority.MEDIUM
            alt = StrategicGoal(
                level=level,
                title=str(item.get("title", "alternative")),
                description=item.get("description"),
                priority=priority,
                parent_goal_id=blocked_goal.parent_goal_id,
                success_probability=float(item.get("success_probability", 0.4)),
                status="proposed",
                metadata={"replan_of": blocked_goal.id},
            )
            try:
                await self.store.save(alt)
            except Exception as e:
                log.warning("Alternative goal save failed: %s", e)
            alternatives.append(alt)
        return alternatives

    # ── Helpers ──────────────────────────────────────────────────────────

    async def _propagate_to_parent(self, parent_id: str) -> None:
        """Recompute parent's progress as the mean of its children's."""
        parent = await self.store.load(parent_id)
        if parent is None:
            return
        children = await self.store.list_goals(parent_id=parent_id, limit=100)
        if not children:
            return
        avg_progress = sum(c.progress for c in children) / len(children)
        avg_prob = sum(c.success_probability for c in children) / len(children)
        parent.progress = avg_progress
        parent.success_probability = avg_prob
        if all(c.status == "completed" for c in children):
            parent.status = "completed"
        parent.updated_at = datetime.now(timezone.utc)
        await self.store.save(parent)
        # Recurse upward.
        if parent.parent_goal_id:
            try:
                await self._propagate_to_parent(parent.parent_goal_id)
            except Exception:
                pass

    def _heuristic_decompose(
        self, mission: str, depth: int,
    ) -> list[StrategicGoal]:
        """Cheap decomposer: 1 strategic + 2 tactical + 2 task-level goals."""
        strategic = StrategicGoal(
            level=GoalLevel.STRATEGIC,
            title=f"Strategic: {mission[:80]}",
            description=mission,
            priority=TaskPriority.HIGH,
            success_probability=0.6,
            status="active",
        )
        goals = [strategic]
        if depth >= 2:
            tactical_a = StrategicGoal(
                level=GoalLevel.TACTICAL,
                title="Tactical A: research phase",
                description="Gather context and prior art for the mission.",
                parent_goal_id=strategic.id,
                priority=TaskPriority.MEDIUM,
                success_probability=0.7,
                status="proposed",
            )
            tactical_b = StrategicGoal(
                level=GoalLevel.TACTICAL,
                title="Tactical B: execution phase",
                description="Execute the core work of the mission.",
                parent_goal_id=strategic.id,
                priority=TaskPriority.HIGH,
                success_probability=0.5,
                status="proposed",
                dependencies=[tactical_a.id],
            )
            strategic.child_goal_ids.extend([tactical_a.id, tactical_b.id])
            goals.extend([tactical_a, tactical_b])
        if depth >= 3:
            task1 = StrategicGoal(
                level=GoalLevel.TASK,
                title="Task: initial prototype",
                description="Build a minimal prototype.",
                parent_goal_id=goals[1].id if len(goals) > 1 else None,
                priority=TaskPriority.MEDIUM,
                success_probability=0.7,
                status="proposed",
            )
            task2 = StrategicGoal(
                level=GoalLevel.TASK,
                title="Task: validation",
                description="Validate the prototype against criteria.",
                parent_goal_id=goals[2].id if len(goals) > 2 else None,
                priority=TaskPriority.MEDIUM,
                success_probability=0.6,
                status="proposed",
            )
            goals.extend([task1, task2])
        return goals

    def _heuristic_alternatives(
        self, blocked: StrategicGoal,
    ) -> list[StrategicGoal]:
        """Produce a single fallback alternative goal."""
        alt = StrategicGoal(
            level=GoalLevel.TACTICAL,
            title=f"Alternative: re-approach '{blocked.title[:60]}'",
            description=(
                f"Heuristic alternative to blocked goal '{blocked.title}'. "
                f"Decompose into smaller, independently-testable sub-tasks."
            ),
            parent_goal_id=blocked.parent_goal_id,
            priority=blocked.priority,
            success_probability=max(0.2, blocked.success_probability - 0.1),
            status="proposed",
            metadata={"replan_of": blocked.id, "heuristic": True},
        )
        return [alt]


# ──────────────────────────────────────────────────────────────────────────────
# Row converter
# ──────────────────────────────────────────────────────────────────────────────


def _row_to_goal(row: sqlite3.Row) -> StrategicGoal:
    target_completion_at = None
    if row["target_completion_at"]:
        target_completion_at = datetime.fromtimestamp(
            row["target_completion_at"], tz=timezone.utc,
        )
    updated_at = None
    if row["updated_at"]:
        updated_at = datetime.fromtimestamp(row["updated_at"], tz=timezone.utc)
    return StrategicGoal(
        id=row["id"],
        level=GoalLevel(row["level"]),
        title=row["title"],
        description=row["description"],
        parent_goal_id=row["parent_goal_id"],
        child_goal_ids=json.loads(row["child_goal_ids"] or "[]"),
        task_ids=json.loads(row["task_ids"] or "[]"),
        priority=TaskPriority(row["priority"]),
        dependencies=json.loads(row["dependencies"] or "[]"),
        progress=float(row["progress"]),
        success_probability=float(row["success_probability"]),
        status=row["status"],
        target_completion_at=target_completion_at,
        created_at=datetime.fromtimestamp(row["created_at"], tz=timezone.utc),
        updated_at=updated_at,
        metadata=json.loads(row["metadata"] or "{}"),
    )


__all__ = ["StrategicGoalStore", "DefaultStrategicReasoner"]
