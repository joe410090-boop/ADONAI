"""VerificationGate — fable-mode proactive step verification.

Fable-mode principle: every stage must define a pass condition that an
*external artifact* satisfies.  "I reviewed it and it looks right" is not
a check.  This module runs *after* a step succeeds (the tool returned
success=True) to catch the silent-wrong-output case that the tool's own
boolean cannot detect.

Gate types:
  TEST_RUN        — run an assertion derived from expected_outcome
  FILE_EXISTS     — stat() the file path from step parameters
  OUTPUT_CONTAINS — check output string contains keywords
  SOURCE_FETCHED  — verify non-empty content was returned
  EXIT_CODE       — already implied by tool success (cheap pass)
  UNVERIFIED      — explicit gap; always passes but logs a warning
  LLM_CHECK       — ask the LLM to confirm output matches expectation
"""
from __future__ import annotations

import json
import logging
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from adonai.core.models import PlanStep, VerificationType

log = logging.getLogger(__name__)


@dataclass
class GateResult:
    """Outcome of a verification gate check."""
    passed: bool
    message: str
    verification_type: VerificationType
    warning: bool = False  # True when the gate passes but something is off


class VerificationGate:
    """Runs a failable verification check on a completed step's output.

    Design goals:
    - Cheap: most gates are pure Python, no LLM call.
    - Failable: every gate can return passed=False.
    - Informative: the message says *what* failed, not just that it did.
    - Small-model friendly: when the planner omits verification_type,
      the planner's _resolve_verification_type infers one from the tool.
    """

    # ── Public API ────────────────────────────────────────────────────────

    async def verify(
        self,
        step: PlanStep,
        step_output: Any,
        workspace: str = ".",
    ) -> GateResult:
        """Run the verification gate for *step* against *step_output*.

        Returns a GateResult.  Callers decide what to do on failure
        (self-heal, replan, mark unverified, etc.).
        """
        vtype = step.verification_type

        # UNVERIFIED: the planner explicitly said no check exists.
        # Pass, but flag so the gap is visible.
        if vtype == VerificationType.UNVERIFIED:
            msg = step.verification_detail or "no failable check defined"
            return GateResult(
                passed=True,
                message=f"[UNVERIFIED] {msg}",
                verification_type=vtype,
                warning=True,
            )

        try:
            if vtype == VerificationType.FILE_EXISTS:
                return self._check_file_exists(step, workspace)
            elif vtype == VerificationType.OUTPUT_CONTAINS:
                return self._check_output_contains(step, step_output)
            elif vtype == VerificationType.SOURCE_FETCHED:
                return self._check_source_fetched(step_output)
            elif vtype == VerificationType.EXIT_CODE:
                # Already implied by tool returning success=True.
                # Still run a lightweight sanity check.
                return self._check_exit_code(step_output)
            elif vtype == VerificationType.TEST_RUN:
                return self._check_test_run(step, step_output, workspace)
            elif vtype == VerificationType.LLM_CHECK:
                return await self._check_llm(step, step_output)
            else:
                # Unknown type — fall back to unverified with warning.
                return GateResult(
                    passed=True,
                    message=f"unknown verification_type '{vtype}', treated as unverified",
                    verification_type=vtype,
                    warning=True,
                )
        except Exception as e:
            log.warning("VerificationGate error for step '%s': %s", step.description, e)
            return GateResult(
                passed=False,
                message=f"verification gate crashed: {e}",
                verification_type=vtype,
            )

    # ── Gate implementations ──────────────────────────────────────────────

    def _check_file_exists(self, step: PlanStep, workspace: str) -> GateResult:
        """Verify a file was actually written to disk."""
        file_path = step.parameters.get("path", "")
        if not file_path:
            # Try to extract from expected_outcome or verification_detail.
            detail = step.verification_detail or step.expected_outcome or ""
            path_match = re.search(r'[\w/\\\-\.]+\.\w+', detail)
            if path_match:
                file_path = path_match.group(0)

        if not file_path:
            return GateResult(
                passed=False,
                message="file_exists check: no file path in parameters or verification_detail",
                verification_type=VerificationType.FILE_EXISTS,
            )

        full_path = Path(workspace) / file_path if not Path(file_path).is_absolute() else Path(file_path)
        if full_path.exists() and full_path.stat().st_size > 0:
            return GateResult(
                passed=True,
                message=f"file exists: {file_path} ({full_path.stat().st_size} bytes)",
                verification_type=VerificationType.FILE_EXISTS,
            )
        return GateResult(
            passed=False,
            message=f"file does not exist or is empty: {file_path}",
            verification_type=VerificationType.FILE_EXISTS,
        )

    def _check_output_contains(self, step: PlanStep, step_output: Any) -> GateResult:
        """Verify output contains expected keywords.

        Pass if ANY keyword is found (output is on-topic).
        Warn (but still pass) if some are missing.
        Fail only if NO keywords are found at all.
        """
        detail = step.verification_detail or step.expected_outcome or ""
        # Extract quoted strings as keywords.
        keywords = re.findall(r"'([^']{2,})'", detail)
        if not keywords:
            stopwords = {"the", "and", "for", "that", "this", "with", "from",
                        "are", "was", "were", "been", "have", "has", "had",
                        "not", "but", "all", "can", "will", "just", "should"}
            keywords = [
                w for w in re.findall(r'\b\w{3,}\b', detail.lower())
                if w not in stopwords
            ][:5]

        if not keywords:
            return GateResult(
                passed=True,
                message="output_contains: no keywords to check (passing by default)",
                verification_type=VerificationType.OUTPUT_CONTAINS,
                warning=True,
            )

        output_str = ""
        if isinstance(step_output, str):
            output_str = step_output
        elif isinstance(step_output, dict):
            output_str = json.dumps(step_output, default=str)
        elif isinstance(step_output, list):
            output_str = json.dumps(step_output, default=str)
        else:
            output_str = str(step_output)

        output_lower = output_str.lower()
        matched = [kw for kw in keywords if kw.lower() in output_lower]
        missing = [kw for kw in keywords if kw.lower() not in output_lower]

        # Pass if at least one keyword matched — the output is on-topic.
        # Only fail when ZERO keywords match (output is clearly off-target).
        if matched:
            return GateResult(
                passed=True,
                message=f"output_contains: {len(matched)}/{len(keywords)} keywords found"
                        + (f" (missing: {missing})" if missing else ""),
                verification_type=VerificationType.OUTPUT_CONTAINS,
                warning=bool(missing),  # warn if some missing, but still pass
            )
        return GateResult(
            passed=False,
            message=f"output_contains: 0/{len(keywords)} keywords found "
                    f"(expected any of: {keywords})",
            verification_type=VerificationType.OUTPUT_CONTAINS,
        )

    def _check_source_fetched(self, step_output: Any) -> GateResult:
        """Verify that web_fetch or web_search returned actual content."""
        if step_output is None:
            return GateResult(
                passed=False,
                message="source_fetched: output is None — no content was fetched",
                verification_type=VerificationType.SOURCE_FETCHED,
            )

        # Check for non-empty content.
        if isinstance(step_output, dict):
            # web_search returns {"results": [...]}
            results = step_output.get("results", [])
            if results and len(results) > 0:
                has_snippets = any(r.get("snippet") for r in results)
                if has_snippets:
                    return GateResult(
                        passed=True,
                        message=f"source_fetched: {len(results)} results with snippets",
                        verification_type=VerificationType.SOURCE_FETCHED,
                    )
            # web_fetch returns {"content": "..."}
            content = step_output.get("content", "")
            if content and len(content.strip()) > 50:
                return GateResult(
                    passed=True,
                    message=f"source_fetched: {len(content)} chars of content",
                    verification_type=VerificationType.SOURCE_FETCHED,
                )
        elif isinstance(step_output, str) and len(step_output.strip()) > 50:
            return GateResult(
                passed=True,
                message=f"source_fetched: {len(step_output)} chars of content",
                verification_type=VerificationType.SOURCE_FETCHED,
            )

        return GateResult(
            passed=False,
            message="source_fetched: no meaningful content in output",
            verification_type=VerificationType.SOURCE_FETCHED,
        )

    def _check_exit_code(self, step_output: Any) -> GateResult:
        """Lightweight sanity check for terminal/python_exec steps.

        The tool already returned success=True, which implies exit code 0.
        But we check for common silent-failure patterns in the output.
        """
        output_str = ""
        if isinstance(step_output, dict):
            # Combine stdout + stderr for checking.
            output_str = " ".join(
                step_output.get(k, "") for k in ("stdout", "stderr", "output", "")
                if isinstance(step_output.get(k), str)
            )
        elif isinstance(step_output, str):
            output_str = step_output
        else:
            output_str = str(step_output)

        # Red flags that indicate silent failure despite success=True.
        red_flags = [
            "error:", "exception:", "traceback", "segmentation fault",
            "killed", "permission denied", "command not found",
        ]
        output_lower = output_str.lower()
        found_flags = [f for f in red_flags if f in output_lower]

        if not found_flags:
            return GateResult(
                passed=True,
                message="exit_code: success=True, no red flags in output",
                verification_type=VerificationType.EXIT_CODE,
            )
        return GateResult(
            passed=False,
            message=f"exit_code: success=True but output contains: {found_flags}",
            verification_type=VerificationType.EXIT_CODE,
        )

    def _check_test_run(
        self, step: PlanStep, step_output: Any, workspace: str,
    ) -> GateResult:
        """Check that a python_exec/terminal step's output indicates tests passed.

        This is a heuristic check — we look for common success/failure
        patterns in the output rather than re-running tests (which would
        be expensive and the tests may not be idempotent).
        """
        output_str = ""
        if isinstance(step_output, dict):
            output_str = " ".join(
                step_output.get(k, "") for k in ("stdout", "stderr", "output", "")
                if isinstance(step_output.get(k), str)
            )
        elif isinstance(step_output, str):
            output_str = step_output
        else:
            output_str = str(step_output)

        output_lower = output_str.lower()

        # Check for explicit failure indicators.
        failure_patterns = [
            "assertionerror", "failed", "error", "traceback",
            "FAIL", "ERROR",
        ]
        success_patterns = [
            "passed", "ok", "success", "pass",
            "PASS", "OK",
        ]

        has_failure = any(p in output_lower for p in failure_patterns)
        has_success = any(p in output_lower for p in success_patterns)

        if has_failure and not has_success:
            return GateResult(
                passed=False,
                message=f"test_run: output contains failure indicators: "
                        f"{[p for p in failure_patterns if p in output_lower]}",
                verification_type=VerificationType.TEST_RUN,
            )
        if has_success:
            return GateResult(
                passed=True,
                message="test_run: output contains success indicators",
                verification_type=VerificationType.TEST_RUN,
            )

        # No clear signal — pass with warning.
        return GateResult(
            passed=True,
            message="test_run: no clear pass/fail signal in output",
            verification_type=VerificationType.TEST_RUN,
            warning=True,
        )

    async def _check_llm(self, step: PlanStep, step_output: Any) -> GateResult:
        """LLM-based verification: ask the model if output matches expectation.

        This is the most expensive gate (one LLM call) and should be used
        only when no cheaper gate applies.

        v9 SECURITY FIX: Previously failed OPEN when the LLM was unavailable
        or its call raised an exception (`passed=True, warning=True`). This
        meant the strongest verification gate was silently a no-op under
        failure — exactly the failure mode it's supposed to catch. Now
        fails CLOSED: returns `passed=False` so the executor can trigger
        self-heal/replan instead of proceeding on unverified output.
        """
        # v9: fail CLOSED when no LLM is available. Previously this returned
        # passed=True, making the gate a silent no-op.
        if self._llm is None:
            return GateResult(
                passed=False,
                message="llm_check: no LLM available — verification denied (fail-closed)",
                verification_type=VerificationType.LLM_CHECK,
                warning=True,
            )

        output_str = (
            json.dumps(step_output, default=str)[:2000]
            if isinstance(step_output, (dict, list))
            else str(step_output)[:2000]
        )
        expectation = step.expected_outcome or step.verification_detail or "produce useful output"

        try:
            resp = await self._llm.complete(
                messages=[
                    {"role": "system", "content": (
                        "You are a verification checker.  Given the expected outcome "
                        "and the actual output, determine if the output satisfies the "
                        'expectation.  Respond JSON: {"passed": true/false, "reason": "..."}'
                    )},
                    {"role": "user", "content": (
                        f"Expected outcome: {expectation}\n\n"
                        f"Actual output:\n{output_str}\n\n"
                        "Does the output satisfy the expected outcome?"
                    )},
                ],
                temperature=0.1,
                max_tokens=128,
            )
            from adonai.core.json_utils import extract_json
            data = extract_json(resp.text or "")
            # v9: default to False (fail-closed) if the LLM didn't include
            # the `passed` key, instead of defaulting to True.
            passed = bool(data.get("passed", False))
            reason = data.get("reason", "")
            return GateResult(
                passed=passed,
                message=f"llm_check: {'passed' if passed else 'FAILED'} — {reason}",
                verification_type=VerificationType.LLM_CHECK,
                warning=not passed,
            )
        except Exception as e:
            log.warning("LLM verification failed (fail-closed): %s", e)
            # v9: fail CLOSED instead of passing by default.
            return GateResult(
                passed=False,
                message=f"llm_check: LLM call failed ({e}) — verification denied (fail-closed)",
                verification_type=VerificationType.LLM_CHECK,
                warning=True,
            )

    # ── LLM injection ─────────────────────────────────────────────────────

    def __init__(self, llm=None, workspace: str = ".") -> None:
        self._llm = llm
        self.workspace = workspace

    def set_llm(self, llm: Any) -> None:
        """Inject an LLM client for LLM_CHECK gates."""
        self._llm = llm