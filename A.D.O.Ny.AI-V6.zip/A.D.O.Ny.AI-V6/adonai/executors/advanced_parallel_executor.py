"""Advanced Parallel Executor — combines adaptive batching + parallel synthesis + speculative execution.

This is the next-generation executor that extends ``EnhancedExecutor`` with
three advanced parallelism engines:

1. **DynamicBatchController** — adaptively sizes parallel batches based on
   real-time metrics (tool latency, error rate, step risk level, graph depth)
   instead of a hardcoded ``[:4]`` limit.  Slow tools get larger batches to
   overlap latency; high error rates shrink batches.

2. **ParallelSynthesisEngine** — runs multiple ``tool=None`` LLM synthesis
   steps **concurrently** rather than sequentially, with dependency-scoped
   context (each step sees only its relevant outputs).  Steps with identical
   dependency sets can share a single LLM call.

3. **SpeculativeExecutionEngine** — predicts likely next steps and
   pre-executes read-only tools (web_search, file.read) in the background
   before the executor loop explicitly picks them.  Results are cached;
   subsequent step executions are near-instant.

Usage
-----
The executor is wired automatically by the runtime when
``config.executor.advanced_parallelism.enabled`` is True::

    executor = AdvancedParallelExecutor(
        llm=llm, tool_registry=tools,
        memory_manager=memory, checkpoint_manager=checkpoints,
        config=config, planner=planner,
        enable_dynamic_batching=True,
        enable_parallel_synthesis=True,
        enable_speculative_execution=True,
    )

Speedup Estimates
-----------------
For a typical plan with 4 parallel web searches + 2 synthesis steps:

  * Sequential (TaskExecutor):               6 × 5s = **30s**
  * EnhancedExecutor (basic parallel):        2 generations × 5s = **10s**
  * AdvancedParallelExecutor (all features):  1 gen × 5s + 0s cache = **~5s**

  → **6× faster** over the base executor.
  → **2× faster** over the EnhancedExecutor.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import Any

from adonai.core.models import (
    Memory, MemoryType, Plan, PlanStep, Task, TaskResult, TaskStatus, ToolResult,
)
from adonai.executors.executor import TaskExecutor
from adonai.executors.parallel_executor import EnhancedExecutor
from adonai.executors.dynamic_batch_controller import DynamicBatchController
from adonai.executors.parallel_synthesis import ParallelSynthesisEngine
from adonai.executors.speculative_executor import SpeculativeExecutionEngine
from adonai.planning.graph import DependencyGraph

log = logging.getLogger(__name__)


class AdvancedParallelExecutor(EnhancedExecutor):
    """Enhanced executor with adaptive batching, parallel synthesis,
    and speculative execution.

    Extends :class:`EnhancedExecutor` — all existing functionality (memory
    recall, checkpointing, verification gates, replan, final synthesis) is
    preserved.  The parallelism improvements are purely in the step
    execution loop (the ``while True`` block in ``execute()``).
    """

    def __init__(
        self,
        *args,
        enable_parallel: bool = True,
        enable_dynamic_batching: bool = True,
        enable_parallel_synthesis: bool = True,
        enable_speculative_execution: bool = True,
        **kwargs,
    ) -> None:
        super().__init__(*args, enable_parallel=enable_parallel, **kwargs)

        self._enable_dynamic_batching = enable_dynamic_batching
        self._enable_parallel_synthesis = enable_parallel_synthesis
        self._enable_speculative_execution = enable_speculative_execution

        # ── Advanced parallelism engines ────────────────────────────────
        self._batch_controller = DynamicBatchController(
            tool_registry=self.tools,
            min_batch=1,
            max_batch=self._resolve_max_batch(),
        )
        self._synthesis_engine: ParallelSynthesisEngine | None = None
        self._speculative_engine: SpeculativeExecutionEngine | None = None
        self._dependency_map: dict[str, list[str]] = {}
        self._reverse_dependency_map: dict[str, list[str]] = {}

    def _resolve_max_batch(self) -> int:
        """Resolve the maximum batch size from config.

        Defaults to 16 for the advanced executor (higher than the
        EnhancedExecutor's hardcoded 4).
        """
        try:
            if self.config and hasattr(self.config, "executor"):
                cfg = getattr(self.config, "executor", None)
                if cfg and hasattr(cfg, "advanced_parallelism"):
                    ap = getattr(cfg, "advanced_parallelism", None)
                    if ap and getattr(ap, "max_batch_size", None):
                        return int(ap.max_batch_size)
        except Exception:
            pass
        return 16

    async def execute(self, task: Task, plan: Plan) -> TaskResult:
        """Execute plan with advanced parallelism.

        Overrides ``EnhancedExecutor.execute()`` with an improved step
        execution loop that uses all three parallelism engines.
        """
        # ── Pre-flight: build dependency maps ─────────────────────────────
        self._dependency_map = {}
        self._reverse_dependency_map = {}
        for step in plan.steps:
            deps = list(getattr(step, "dependencies", []) or [])
            self._reverse_dependency_map[step.id] = deps
            for dep_id in deps:
                self._dependency_map.setdefault(dep_id, []).append(step.id)

        # ── Fast path: single step, no tool ───────────────────────────────
        if len(plan.steps) == 1 and not plan.steps[0].tool:
            return await TaskExecutor.execute(self, task, plan)

        # ── Meta-question interception ────────────────────────────────────
        # Reuse EnhancedExecutor's meta-question handler.
        meta_response = await self._handle_meta_question(task)
        if meta_response is not None:
            return TaskResult(
                task_id=task.id, status=TaskStatus.COMPLETED,
                output=meta_response, steps_executed=0,
                duration_s=0.0, confidence=1.0,
            )

        if not self.enable_parallel:
            # Fall back to sequential execution (base executor).
            return await TaskExecutor.execute(self, task, plan)

        # ── Initialise engines ────────────────────────────────────────────
        start = time.time()
        self._current_task_id = task.id
        session_id = task.session_id or self._task_sessions.get(task.id, "default")
        self._task_sessions[task.id] = session_id
        self._dynamic_system_prompt = await self._build_system_prompt()

        # Persist goal to working memory.
        if self.memory is not None:
            try:
                await self.memory.add(Memory(
                    type=MemoryType.WORKING,
                    content=f"user goal: {task.goal}",
                    importance=0.8, source="user",
                    session_id=session_id,
                ))
            except Exception:
                pass

        # Recall long-term memory.
        recalled_memories: list = []
        if self.memory is not None:
            try:
                recalled_memories = await self.memory.recall(
                    task.goal, top_k=5,
                    types=[MemoryType.EPISODIC, MemoryType.SEMANTIC],
                )
            except Exception as e:
                log.debug(
                    "AdvancedParallelExecutor memory.recall failed (non-fatal): %s", e,
                )
        if recalled_memories and self._dynamic_system_prompt:
            mem_block = "\n\nRelevant long-term memories:\n" + "\n".join(
                f"- [{m.type.value if hasattr(m.type, 'value') else m.type}] "
                f"{m.content[:300]}"
                for m in recalled_memories[:5]
            )
            self._dynamic_system_prompt += mem_block

        # Build synthesis engine (needs the system prompt).
        self._synthesis_engine = ParallelSynthesisEngine(
            llm=self.llm,
            system_prompt=self._dynamic_system_prompt,
            max_concurrent_synthesis=8,
            merge_identical_contexts=True,
            max_tokens_per_synthesis=self._resolve_max_synthesis_tokens(),
            temperature=self._resolve_temperature(),
        )

        # Build speculative engine.
        self._speculative_engine = SpeculativeExecutionEngine(
            tool_registry=self.tools,
            enabled=self._enable_speculative_execution,
            max_concurrent_speculations=4,
            confidence_threshold=0.7,
            cache_max_entries=100,
        )

        # ── Step execution loop ──────────────────────────────────────────
        graph = DependencyGraph(plan)
        executed = 0
        last_output: Any = None
        last_error: str | None = None
        history = self._get_history(session_id)
        self._step_outputs = {}

        max_retries_per_step = 3

        while True:
            # Get all ready steps.
            ready_steps = graph.ready_steps()
            if not ready_steps:
                break

            pending_ready = [s for s in ready_steps if s.status == TaskStatus.PENDING]
            if not pending_ready:
                break

            if executed >= task.max_steps:
                break

            # ── 1. Speculative execution: predict and pre-execute ────────
            if self._speculative_engine and self._enable_speculative_execution:
                # Check cache for any ready steps that were speculated.
                for step in pending_ready[:4]:
                    cached = self._speculative_engine.check_cache(step, consume=False)
                    if cached:
                        log.info(
                            "Speculative cache HIT for step '%s' (%s) — instant result",
                            step.description, step.tool,
                        )

                # Predict and launch new speculations.
                # Find the last completed step to feed the predictor.
                completed_steps = [s for s in plan.steps
                                   if s.status == TaskStatus.COMPLETED]
                last_completed = completed_steps[-1] if completed_steps else None
                await self._speculative_engine.predict_and_execute(
                    completed_step_id=last_completed.id if last_completed else None,
                    completed_step_tool=last_completed.tool if last_completed else None,
                    pending_steps=pending_ready,
                    dependency_map=self._dependency_map,
                    reverse_dependency_map=self._reverse_dependency_map,
                )

            # ── 2. Compute batch size ────────────────────────────────────
            if self._enable_dynamic_batching and self._batch_controller:
                # Estimate remaining graph depth.
                remaining_depth = self._estimate_remaining_depth(graph, pending_ready)
                batch_size = self._batch_controller.compute_batch_size(
                    pending_ready,
                    graph_remaining_depth=remaining_depth,
                )
            else:
                batch_size = min(len(pending_ready), 4)  # fallback to default

            batch = pending_ready[:batch_size]

            # ── 3. Execute batch ─────────────────────────────────────────
            log.info(
                "AdvancedParallelExecutor: batch of %d step(s) (dynamic=%s, "
                "remaining_depth=%s, pending=%d)",
                len(batch), self._enable_dynamic_batching,
                getattr(self, '_last_depth', '?'), len(pending_ready),
            )

            if len(batch) == 1:
                step = batch[0]
                result, step_output = await self._execute_step_with_retry(
                    step, task, last_output, history, max_retries_per_step,
                )
                step.status = TaskStatus.COMPLETED if result.success else TaskStatus.FAILED
                if result.success:
                    executed += 1
                    last_output = step_output
                    self._step_outputs[step.id] = step_output
                else:
                    last_error = result.error or "tool returned failure"
                # Record for speculative engine.
                if self._speculative_engine:
                    self._speculative_engine.record_step_completed(step, step_output)
            else:
                # ── Parallel batch execution ─────────────────────────────
                log.info(
                    "AdvancedParallelExecutor: running %d steps concurrently",
                    len(batch),
                )

                # Separate tool steps from synthesis steps.
                tool_steps = [s for s in batch if getattr(s, "tool", None)]
                synthesis_steps = [s for s in batch if not getattr(s, "tool", None)]

                # Execute tool steps in parallel (existing EnhancedExecutor path).
                tool_results: list[tuple[PlanStep, ToolResult, Any]] = []
                if tool_steps:
                    tasks = [
                        self._execute_step_with_retry(
                            step, task, None, history, max_retries_per_step,
                        )
                        for step in tool_steps
                    ]
                    raw_tool_results = await asyncio.gather(*tasks, return_exceptions=True)

                    for step, result_tuple in zip(tool_steps, raw_tool_results):
                        if isinstance(result_tuple, Exception):
                            tool_results.append((
                                step,
                                ToolResult(
                                    call_id=f"err_{step.id}", tool=step.tool or "?",
                                    success=False, error=str(result_tuple),
                                ),
                                None,
                            ))
                            continue
                        result, step_output = result_tuple
                        tool_results.append((step, result, step_output))

                # Execute synthesis steps in parallel (ParallelSynthesisEngine).
                synthesis_results: list[tuple[PlanStep, ToolResult]] = []
                if synthesis_steps and self._synthesis_engine:
                    synthesis_results = await self._synthesis_engine.execute_parallel(
                        synthesis_steps=synthesis_steps,
                        step_outputs=self._step_outputs,
                        task_goal=task.goal,
                        history=history,
                    )

                # ── Process all results ──────────────────────────────────
                batch_latencies: list[float] = []
                batch_succeeded = 0
                batch_failed = 0
                batch_failed_step: PlanStep | None = None
                batch_failed_error: str | None = None
                completed_in_batch: list[PlanStep] = []

                # Process tool results.
                for step, result, step_output in tool_results:
                    duration = getattr(result, "duration_s", 0.0)
                    batch_latencies.append(duration)
                    if result.success:
                        step.status = TaskStatus.COMPLETED
                        executed += 1
                        self._step_outputs[step.id] = step_output
                        completed_in_batch.append(step)
                        last_output = step_output
                        batch_succeeded += 1
                        # Record for speculative engine.
                        if self._speculative_engine:
                            self._speculative_engine.record_step_completed(
                                step, step_output,
                            )
                    else:
                        step.status = TaskStatus.FAILED
                        batch_failed += 1
                        last_error = result.error or "tool returned failure"
                        if batch_failed_step is None:
                            batch_failed_step = step
                            batch_failed_error = last_error

                # Process synthesis results.
                for step, result in synthesis_results:
                    duration = getattr(result, "duration_s", 0.0)
                    batch_latencies.append(duration)
                    if result.success:
                        step.status = TaskStatus.COMPLETED
                        executed += 1
                        self._step_outputs[step.id] = result.output
                        completed_in_batch.append(step)
                        last_output = result.output
                        batch_succeeded += 1
                    else:
                        step.status = TaskStatus.FAILED
                        batch_failed += 1
                        last_error = result.error or "synthesis failed"
                        if batch_failed_step is None:
                            batch_failed_step = step
                            batch_failed_error = last_error

                # Record batch outcome for dynamic controller.
                if self._batch_controller:
                    self._batch_controller.record_batch_outcome(
                        n_requested=len(batch),
                        n_succeeded=batch_succeeded,
                        n_failed=batch_failed,
                        step_latencies_s=batch_latencies if batch_latencies else None,
                    )

                # ── Handle partial batch failure (replan) ────────────────
                if batch_failed_step is not None:
                    blocked = graph.blocked_steps()
                    if blocked:
                        log.warning(
                            "AdvancedParallelExecutor: %d step(s) failed in batch, "
                            "%d downstream blocked — triggering replan",
                            batch_failed, len(blocked),
                        )
                        for s in completed_in_batch:
                            self._step_outputs.pop(s.id, None)
                            s.status = TaskStatus.PENDING
                            s.verification_passed = None
                            s.verification_message = None
                        last_output = None

                        if self.planner is not None:
                            try:
                                new_plan = await self.planner.replan(
                                    task, plan, batch_failed_step,
                                    batch_failed_error or "parallel batch failed",
                                )
                                if new_plan and new_plan.steps:
                                    plan = new_plan
                                    graph = DependencyGraph(plan)
                                    self._active_plans[task.id] = plan
                                    self._rebuild_dependency_maps(plan)
                                    log.info(
                                        "AdvancedParallelExecutor: replan succeeded — "
                                        "new plan has %d steps",
                                        len(plan.steps),
                                    )
                                    if self.checkpoints is not None:
                                        try:
                                            await self.checkpoints.checkpoint(task, plan)
                                        except Exception:
                                            pass
                                    continue
                            except Exception as e:
                                log.warning(
                                    "AdvancedParallelExecutor: replan failed: %s", e,
                                )

            # Checkpoint after each generation.
            if self.checkpoints is not None:
                try:
                    await self.checkpoints.checkpoint(task, plan)
                except Exception:
                    pass

        # ── Final synthesis (same as EnhancedExecutor) ────────────────────
        # Merge parallel outputs.
        if len(self._step_outputs) > 1 and last_output is not None:
            all_outputs = list(self._step_outputs.values())
            if len(all_outputs) > 1:
                last_output = self._merge_outputs(all_outputs, task)

        # Dict-to-text synthesis.
        if isinstance(last_output, (dict, list)):
            try:
                pretty = json.dumps(last_output, indent=2, default=str)[:4000]
                user_turn = (
                    f"{task.goal}\n\n"
                    f"--- Tool output (use this to answer) ---\n{pretty}\n--- end ---\n\n"
                    f"Write a clear, well-formatted natural-language response."
                )
                messages = (
                    [{"role": "system", "content": self._dynamic_system_prompt}]
                    + list(history)
                    + [{"role": "user", "content": user_turn}]
                )
                resp = await self.llm.complete(
                    messages=messages,
                    temperature=self._resolve_temperature(),
                    max_tokens=self._resolve_max_synthesis_tokens(),
                )
                if resp.text and resp.text.strip():
                    last_output = resp.text
            except Exception as e:
                log.warning("Final synthesis failed: %s", e)

        # Defensive fallback.
        if last_output is None and last_error is None:
            try:
                messages = (
                    [{"role": "system", "content": self._dynamic_system_prompt}]
                    + list(history)
                    + [{"role": "user", "content": task.goal}]
                )
                resp = await self.llm.complete(
                    messages=messages,
                    temperature=self._resolve_temperature(),
                    max_tokens=self._resolve_max_synthesis_tokens(),
                )
                last_output = resp.text
                executed = max(executed, 1)
            except Exception as e:
                last_error = f"final synthesis failed: {type(e).__name__}: {e}"

        # ── Build result ─────────────────────────────────────────────────
        task_result = TaskResult(
            task_id=task.id, status=TaskStatus.COMPLETED,
            output=last_output, error=last_error,
            steps_executed=executed, duration_s=time.time() - start,
            confidence=plan.confidence,
        )

        reply = task_result.output if task_result.output is not None else (
            f"[error] {task_result.error}" if task_result.error else "[no response]"
        )
        self._record_turn(session_id, task.goal, str(reply))

        # Persist episodic memory (same as EnhancedExecutor fix).
        if self.memory is not None:
            try:
                await self.memory.add(Memory(
                    type=MemoryType.EPISODIC,
                    content=f"Task: {task.goal}\nResult: {str(reply)[:500]}",
                    importance=0.7 if task_result.status == TaskStatus.COMPLETED else 0.5,
                    source="executor",
                    session_id=getattr(task, 'session_id', None),
                ))
            except Exception as e:
                log.debug(
                    "AdvancedParallelExecutor episodic memory write failed: %s", e,
                )

        # Log speculative engine stats.
        if self._speculative_engine and self._enable_speculative_execution:
            stats = self._speculative_engine.stats()
            if stats.get("attempts", 0) > 0:
                log.info(
                    "AdvancedParallelExecutor speculative stats: "
                    "attempts=%d hits=%d misses=%d errors=%d hit_rate=%.1f%%",
                    stats["attempts"], stats["hits"],
                    stats["misses"], stats["errors"],
                    stats["hit_rate"] * 100,
                )

        # Log batch controller stats.
        if self._batch_controller and self._enable_dynamic_batching:
            summary = self._batch_controller.summary()
            log.info(
                "AdvancedParallelExecutor batch controller stats: %s",
                summary,
            )

        return task_result

    # ── Helpers ───────────────────────────────────────────────────────────

    def _rebuild_dependency_maps(self, plan: Plan) -> None:
        """Rebuild dependency maps for a new/replanned plan."""
        self._dependency_map.clear()
        self._reverse_dependency_map.clear()
        for step in plan.steps:
            deps = list(getattr(step, "dependencies", []) or [])
            self._reverse_dependency_map[step.id] = deps
            for dep_id in deps:
                self._dependency_map.setdefault(dep_id, []).append(step.id)

    def _estimate_remaining_depth(
        self,
        graph: DependencyGraph,
        pending_steps: list[PlanStep],
    ) -> int:
        """Estimate how many generation layers remain in the dependency graph.

        Uses a simple BFS from the current pending steps to find the
        longest remaining chain.
        """
        if not pending_steps:
            return 0

        # Build a set of step IDs for O(1) lookup.
        pending_ids = {s.id for s in pending_steps}

        # For each pending step, compute its longest chain length.
        memo: dict[str, int] = {}

        def _longest_chain(step_id: str, visited: set[str]) -> int:
            """DFS to find longest dependency chain from *step_id*."""
            if step_id in memo:
                return memo[step_id]
            if step_id not in pending_ids:
                return 0
            if step_id in visited:
                return 0  # cycle guard (shouldn't happen in valid plans)

            children = self._dependency_map.get(step_id, [])
            if not children:
                memo[step_id] = 0
                return 0

            visited.add(step_id)
            max_depth = 0
            for child_id in children:
                if child_id in pending_ids:
                    depth = 1 + _longest_chain(child_id, visited)
                    max_depth = max(max_depth, depth)
            visited.remove(step_id)

            memo[step_id] = max_depth
            return max_depth

        max_depth = 0
        for step in pending_steps:
            depth = _longest_chain(step.id, set())
            max_depth = max(max_depth, depth)

        self._last_depth = max_depth
        return max_depth

    def _resolve_max_synthesis_tokens(self) -> int:
        """Resolve max tokens for synthesis from config."""
        try:
            if self.config and hasattr(self.config, "llm"):
                return int(self.config.llm.max_tokens) or 1536
        except Exception:
            pass
        return 1536

    def _resolve_temperature(self) -> float:
        """Resolve temperature from config."""
        try:
            if self.config and hasattr(self.config, "agent"):
                return float(self.config.agent.default_temperature) or 0.3
        except Exception:
            pass
        return 0.3

