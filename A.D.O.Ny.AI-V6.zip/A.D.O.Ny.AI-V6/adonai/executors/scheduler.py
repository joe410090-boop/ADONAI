"""Task scheduler — priority queue + background execution with concurrency limit."""
from __future__ import annotations

import asyncio
import logging
import time
import uuid
from typing import Any

from adonai.config.settings import Config
from adonai.core.models import Task, TaskResult, TaskStatus

log = logging.getLogger(__name__)


class TaskScheduler:
    """In-process priority scheduler for background Task execution.

    v9 fix: submit() now writes a checkpoint at submission time so a crash
    between submit and the executor's first per-step checkpoint doesn't
    lose the task permanently. recover_all() now delegates to the
    RecoveryManager instead of returning an empty list.
    """

    def __init__(
        self,
        config: Config,
        *,
        agent: Any,
        checkpoint_manager: Any = None,
        recovery_manager: Any = None,
    ) -> None:
        self.config = config
        self.agent = agent
        self._semaphore = asyncio.Semaphore(max(1, config.tasks.max_concurrent_tasks))
        self._tasks: dict[str, asyncio.Task] = {}
        self._results: dict[str, TaskResult] = {}
        self._errors: dict[str, str] = {}
        self._goals: dict[str, str] = {}
        self._started_at: dict[str, float] = {}
        # v9: optional checkpoint/recovery managers for crash-resilience.
        self._checkpoint_manager = checkpoint_manager
        self._recovery_manager = recovery_manager

    async def submit(self, task: Task) -> str:
        """Schedule *task* for background execution.  Returns the task id."""
        task_id = task.id or str(uuid.uuid4())
        self._goals[task_id] = task.goal
        self._started_at[task_id] = time.time()

        # v9: write a checkpoint at submission so a crash between submit
        # and the executor's first per-step checkpoint doesn't lose the
        # task permanently.
        if self._checkpoint_manager is not None:
            try:
                task.id = task_id
                task.status = TaskStatus.RUNNING
                await self._checkpoint_manager.checkpoint(task)
            except Exception as e:
                log.warning(
                    "Scheduler submit checkpoint failed for %s (non-fatal): %s",
                    task_id, e,
                )

        async def _runner():
            async with self._semaphore:
                try:
                    # `agent` is a callable (ADONAI._scheduler_agent), not
                    # an object with .run() — see recovery.py for the same
                    # convention.  Using .run() here would raise
                    # AttributeError: 'function' object has no attribute 'run'.
                    result = await self.agent(task)
                    self._results[task_id] = result
                    return result
                except Exception as exc:
                    self._errors[task_id] = f"{type(exc).__name__}: {exc}"
                    log.exception("Background task %s failed", task_id)
                    raise

        self._tasks[task_id] = asyncio.create_task(_runner())
        log.info("Scheduled background task %s: %s", task_id, task.goal[:100])
        return task_id

    async def status(self, task_id: str) -> dict[str, Any] | None:
        t = self._tasks.get(task_id)
        if t is None:
            return None
        info: dict[str, Any] = {
            "task_id": task_id,
            "goal": self._goals.get(task_id),
            "running": not t.done(),
            "started_at": self._started_at.get(task_id),
        }
        if t.done():
            if t.cancelled():
                info["status"] = "cancelled"
            elif t.exception():
                info["status"] = "failed"
                info["error"] = str(t.exception())
            else:
                info["status"] = "completed"
                r = self._results.get(task_id)
                if r is not None:
                    info["result"] = r.output
                    info["steps_executed"] = r.steps_executed
                    info["duration_s"] = r.duration_s
        else:
            info["status"] = "running"
        return info

    async def cancel(self, task_id: str) -> bool:
        t = self._tasks.get(task_id)
        if t is None or t.done():
            return False
        t.cancel()
        try:
            await t
        except asyncio.CancelledError:
            pass
        return True

    async def list_all(self) -> list[dict[str, Any]]:
        out = []
        for tid in list(self._tasks.keys()):
            s = await self.status(tid)
            if s is not None:
                out.append(s)
        return out

    async def shutdown(self) -> None:
        for tid, t in list(self._tasks.items()):
            if not t.done():
                t.cancel()
        for t in self._tasks.values():
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass
        self._tasks.clear()

    async def recover_all(self) -> list[str]:
        """Recover all interrupted tasks.

        v9 fix: Previously a stub returning []. Now delegates to the
        RecoveryManager (if wired) so the scheduler actually participates
        in crash recovery. The RecoveryManager reads from the
        CheckpointManager's SQLite store and resumes any task with
        status IN ('running', 'paused').
        """
        if self._recovery_manager is not None:
            try:
                return await self._recovery_manager.recover_all()
            except Exception as e:
                log.warning("Scheduler recover_all delegation failed: %s", e)
                return []
        # No recovery manager wired — return empty list (legacy behavior).
        log.debug("Scheduler recover_all: no recovery_manager wired")
        return []
