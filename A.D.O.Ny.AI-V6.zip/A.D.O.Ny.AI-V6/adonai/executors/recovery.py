"""Recovery manager — resumes interrupted tasks on startup.

v4 hardening:
  * Recovery tasks are stored in a set with a done-callback that discards
    them, preventing CPython from garbage-collecting the asyncio.Task
    mid-execution (which would silently cancel recovery).
  * A concurrency semaphore bounds the number of simultaneously-recovered
    tasks to avoid thundering-herd on startup.
  * Tasks are awaited via a tracked group so that shutdown() can cancel
    in-flight recoveries cleanly.
  * Checkpoint resume: if a valid checkpoint with a Plan exists, the
    recovery restores the plan (with step statuses intact) and passes it
    directly to the executor, so the DependencyGraph automatically skips
    COMPLETED steps and continues from PENDING ones.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any, Awaitable, Callable

from adonai.executors.checkpoint import CheckpointManager
from adonai.core.models import Plan, PlanStep, Task, TaskStatus

log = logging.getLogger(__name__)


class RecoveryManager:
    """Resumes tasks that were running when the process last exited."""

    def __init__(
        self,
        checkpoint_manager: CheckpointManager,
        agent: Callable[[Task], Awaitable[Any]] | Any,
        *,
        max_concurrent: int = 4,
        executor: Any | None = None,
    ) -> None:
        self.checkpoints = checkpoint_manager
        self.agent = agent
        self._max_concurrent = max_concurrent
        self._executor = executor  # optional TaskExecutor for direct plan resume
        # Holds strong refs to in-flight recovery tasks so CPython doesn't
        # GC them mid-execution (Python asyncio docs explicitly warn against
        # losing the only reference to a create_task result).
        self._recovery_tasks: set[asyncio.Task] = set()
        self._semaphore: asyncio.Semaphore | None = None  # lazily created

    async def recover_all(self) -> list[str]:
        """Re-enqueue all resumable tasks.  Returns list of recovered task IDs."""
        try:
            resumable = await self.checkpoints.list_resumable_tasks()
        except Exception as e:
            log.warning("Recovery: failed to list resumable tasks: %s", e)
            return []

        if self._semaphore is None:
            self._semaphore = asyncio.Semaphore(self._max_concurrent)

        recovered: list[str] = []
        for task_info in resumable:
            tid = task_info["id"]
            try:
                task = Task(
                    id=tid, goal=task_info["goal"],
                    status=TaskStatus.PENDING,
                    session_id=task_info.get("session_id"),
                )
                if self.agent is not None:
                    # Wrap in a semaphore-bounded runner so we don't thundering-
                    # herd the LLM with N simultaneous recoveries.
                    async def _runner(t: Task = task) -> None:
                        async with self._semaphore:  # type: ignore[arg-type]
                            try:
                                await self._recover_task(t)
                            except asyncio.CancelledError:
                                raise
                            except Exception as e:
                                log.warning("Recovery of task %s failed: %s", t.id, e)

                    t = asyncio.create_task(_runner())
                    # CRITICAL: keep a strong ref + install a done-callback
                    # that discards it. Without this, CPython may GC the
                    # task mid-execution and silently cancel recovery.
                    self._recovery_tasks.add(t)
                    t.add_done_callback(self._recovery_tasks.discard)
                recovered.append(tid)
                log.info("Recovered task %s: %s", tid, task_info["goal"][:80])
            except Exception as e:
                log.warning("Failed to recover task %s: %s", tid, e)
        return recovered

    async def _recover_task(self, task: Task) -> Any:
        """Recover a single task, attempting checkpoint-based plan restoration.

        If a valid checkpoint with a Plan is found and an executor is
        available, the restored Plan (with step statuses preserved) is
        passed directly to the executor.  The DependencyGraph will
        automatically skip COMPLETED steps and continue from PENDING ones.

        Falls back to re-planning (via self.agent) if no valid checkpoint
        or plan exists.

        CRITICAL: task.status MUST be set to RUNNING before invoking the
        executor. The executor takes per-step checkpoints that persist
        task.status.value; if status is left as PENDING, the next crash's
        list_resumable_tasks() (which filters for status IN ('running','paused'))
        will silently drop this task. Two consecutive crashes used to kill
        the task — this fix breaks that failure mode.
        """
        restored_plan = await self._load_restored_plan(task.id)
        if restored_plan is not None and self._executor is not None:
            log.info(
                "Recovery: resuming task %s from checkpoint with %d steps "
                "(%d completed, %d pending)",
                task.id,
                len(restored_plan.steps),
                sum(1 for s in restored_plan.steps if s.status == TaskStatus.COMPLETED),
                sum(1 for s in restored_plan.steps if s.status == TaskStatus.PENDING),
            )
            # Mark RUNNING so per-step checkpoints persist the correct state.
            # Without this, the next crash's list_resumable_tasks() filter
            # (status IN ('running','paused')) silently drops the task.
            task.status = TaskStatus.RUNNING
            try:
                await self.checkpoints.update_task_status(task.id, TaskStatus.RUNNING.value)
            except Exception as e:
                log.debug("Recovery: could not pre-update task status to RUNNING: %s", e)
            return await self._executor.execute(task, restored_plan)

        # No valid checkpoint or no executor — fall back to re-planning.
        if restored_plan is not None:
            log.info(
                "Recovery: checkpoint found for task %s but no executor available, "
                "falling back to re-planning",
                task.id,
            )
        else:
            log.info(
                "Recovery: no valid checkpoint with plan for task %s, "
                "falling back to re-planning",
                task.id,
            )
        # Re-planning path also needs RUNNING state for the same reason.
        task.status = TaskStatus.RUNNING
        try:
            await self.checkpoints.update_task_status(task.id, TaskStatus.RUNNING.value)
        except Exception as e:
            log.debug("Recovery: could not pre-update task status to RUNNING: %s", e)
        return await self.agent(task)

    async def _load_restored_plan(self, task_id: str) -> Plan | None:
        """Try to load the latest checkpoint for a task and restore its Plan.

        Returns a Plan with step statuses intact, or None if no valid
        checkpoint/plan is found.
        """
        try:
            checkpoints = await self.checkpoints.list_checkpoints(task_id)
            if not checkpoints:
                return None
            # Load the most recent checkpoint.
            latest_cp_id = checkpoints[0]["id"]
            snapshot = await self.checkpoints.load_checkpoint(latest_cp_id)
            if snapshot is None:
                return None

            plan_data = snapshot.get("plan")
            if not plan_data:
                return None

            # Reconstruct Plan with step statuses preserved.
            # The plan_data comes from plan.model_dump(mode="json"), so
            # Plan.model_validate() can reconstruct it faithfully including
            # each PlanStep's status field.
            restored_plan = Plan.model_validate(plan_data)

            # Validate: at least one step must exist and not all should be
            # in terminal states (otherwise there's nothing to resume).
            if not restored_plan.steps:
                return None
            if all(
                s.status in (TaskStatus.COMPLETED, TaskStatus.FAILED)
                for s in restored_plan.steps
            ):
                log.info(
                    "Recovery: all steps in checkpoint for task %s are in "
                    "terminal state, nothing to resume",
                    task_id,
                )
                return None

            return restored_plan
        except Exception as e:
            log.warning("Recovery: failed to load checkpoint for task %s: %s", task_id, e)
            return None

    async def wait_for_recovery(self, timeout: float | None = None) -> None:
        """Wait for all in-flight recovery tasks to finish."""
        if not self._recovery_tasks:
            return
        tasks = list(self._recovery_tasks)
        try:
            await asyncio.wait_for(asyncio.gather(*tasks, return_exceptions=True),
                                    timeout=timeout)
        except asyncio.TimeoutError:
            log.warning("Recovery: %d tasks still running after %ss — cancelling",
                        len(self._recovery_tasks), timeout)
            for t in list(self._recovery_tasks):
                t.cancel()

    async def shutdown(self) -> None:
        """Cancel all in-flight recovery tasks."""
        for t in list(self._recovery_tasks):
            t.cancel()
        # Drain.
        if self._recovery_tasks:
            await asyncio.gather(*self._recovery_tasks, return_exceptions=True)
        self._recovery_tasks.clear()