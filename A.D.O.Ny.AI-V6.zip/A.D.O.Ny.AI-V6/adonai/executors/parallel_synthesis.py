"""Parallel synthesis engine — runs independent LLM synthesis steps concurrently.

In the standard executor pipeline, each ``tool=None`` step (LLM synthesis)
runs sequentially: step 1 synthesises, step 2 waits, step 3 waits.
When multiple synthesis steps have no tool call and no dependencies
between them, they can run **concurrently**, each getting only the
subset of prior outputs they actually need.

This is valuable for plans like::

    Step 1: web_search("AI news")         [tool=web_search]
    Step 2: web_search("stock prices")    [tool=web_search]
    Step 3: llm.synthesise AI news         [tool=None, depends on 1]
    Step 4: llm.synthesise stock analysis  [tool=None, depends on 2]

Steps 3 and 4 are independent synthesis steps that can run in parallel.

Usage::

    engine = ParallelSynthesisEngine(llm, system_prompt)
    results = await engine.execute_parallel(
        synthesis_steps=[step3, step4],
        step_outputs={"step_1": "AI news results...", "step_2": "Stock data..."},
        task_goal="Get AI news and stock prices",
        history=[],
    )
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import Any

from adonai.core.models import PlanStep, ToolResult

log = logging.getLogger(__name__)


class ParallelSynthesisEngine:
    """Executes multiple independent LLM synthesis steps concurrently.

    Each synthesis step is framed with only its relevant context (the
    outputs of its dependency steps), not every output in the plan.
    This prevents the LLM from being confused by unrelated data and
    reduces token waste.

    The engine groups synthesis steps by their dependency set so that
    steps with *identical* dependency sets can share a single LLM call
    (when ``merge_identical_contexts=True``), reducing total LLM calls.
    """

    def __init__(
        self,
        llm: Any,
        system_prompt: str,
        *,
        max_concurrent_synthesis: int = 8,
        merge_identical_contexts: bool = True,
        max_tokens_per_synthesis: int = 1536,
        temperature: float = 0.3,
    ) -> None:
        self._llm = llm
        self._system_prompt = system_prompt
        self._max_concurrent = max_concurrent_synthesis
        self._merge_identical = merge_identical_contexts
        self._max_tokens = max_tokens_per_synthesis
        self._temperature = temperature

    async def execute_parallel(
        self,
        synthesis_steps: list[PlanStep],
        step_outputs: dict[str, Any],
        task_goal: str,
        history: list[dict[str, str]],
    ) -> list[tuple[PlanStep, ToolResult]]:
        """Execute multiple synthesis steps concurrently.

        Parameters
        ----------
        synthesis_steps : list[PlanStep]
            Steps with ``tool=None`` that need LLM synthesis.
        step_outputs : dict[str, Any]
            Map of step_id → output for all completed steps in the plan.
        task_goal : str
            The original user goal / task description.
        history : list[dict[str, str]]
            Conversation history for context.

        Returns
        -------
        list[tuple[PlanStep, ToolResult]]
            List of (step, result) pairs in the **same order** as
            ``synthesis_steps``.
        """
        if not synthesis_steps:
            return []

        # Group steps by their dependency signature so we can merge
        # steps with identical contexts.
        if self._merge_identical:
            groups = self._group_by_dependency_signature(synthesis_steps)
        else:
            groups = [(s,) for s in synthesis_steps]  # one per group

        semaphore = asyncio.Semaphore(self._max_concurrent)

        async def _execute_group(group: tuple[PlanStep, ...]) -> list[tuple[PlanStep, ToolResult]]:
            """Execute a group of synthesis steps.

            If the group has >1 step with identical dependencies, we
            make a single LLM call and duplicate the result to all
            steps (saves LLM calls at the cost of slightly redundant
            output).
            """
            async with semaphore:
                if len(group) == 1:
                    result = await self._execute_one(
                        group[0], step_outputs, task_goal, history,
                    )
                    return [(group[0], result)]
                else:
                    # All steps in the group share the same dependency
                    # signature → same context. Make ONE LLM call and
                    # use the output for all.
                    first_step = group[0]
                    result = await self._execute_one(
                        first_step, step_outputs, task_goal, history,
                    )
                    return [(s, result) for s in group]

        # Execute all groups concurrently.
        coros = [_execute_group(g) for g in groups]
        group_results: list[list[tuple[PlanStep, ToolResult]]]
        group_results = await asyncio.gather(*coros, return_exceptions=True)

        # Flatten results back to original order.
        result_map: dict[str, tuple[PlanStep, ToolResult]] = {}
        for grp_res in group_results:
            if isinstance(grp_res, Exception):
                log.warning("Parallel synthesis group raised: %s", grp_res)
                continue
            for step, tr in grp_res:
                result_map[step.id] = (step, tr)

        return [
            result_map.get(s.id, (s, ToolResult(
                call_id=f"synth_{s.id}", tool="llm.synthesize",
                success=False, error="synthesis group failed",
            )))
            for s in synthesis_steps
        ]

    async def _execute_one(
        self,
        step: PlanStep,
        step_outputs: dict[str, Any],
        task_goal: str,
        history: list[dict[str, str]],
    ) -> ToolResult:
        """Execute a single synthesis step.

        Frames the prompt with only the outputs of the step's
        dependencies — not every output in the plan.
        """
        start = time.time()
        try:
            # Collect context: only outputs from steps this step depends on.
            relevant_outputs = self._collect_relevant_outputs(step, step_outputs)

            # Build the user turn.
            if relevant_outputs:
                pretty = self._format_output(relevant_outputs)
                user_turn = (
                    f"{task_goal}\n\n"
                    f"--- Tool output (use this to answer) ---\n"
                    f"{pretty}\n--- end ---\n\n"
                    f"Write a clear, well-formatted natural-language response "
                    f"that answers my question using the tool output above. "
                    f"Cite sources by name when relevant. Do NOT include raw JSON."
                )
            else:
                user_turn = task_goal

            messages = (
                [{"role": "system", "content": self._system_prompt}]
                + list(history)
                + [{"role": "user", "content": user_turn}]
            )

            resp = await self._llm.complete(
                messages=messages,
                temperature=self._temperature,
                max_tokens=self._max_tokens,
            )

            text = resp.text.strip() if resp.text else ""
            if not text:
                log.warning(
                    "Parallel synthesis step '%s' produced empty output",
                    step.description,
                )
                return ToolResult(
                    call_id=f"synth_{step.id}", tool="llm.synthesize",
                    success=True,
                    output="(synthesis produced no text — check the tool output above)",
                    duration_s=time.time() - start,
                )

            return ToolResult(
                call_id=f"synth_{step.id}", tool="llm.synthesize",
                success=True, output=text,
                duration_s=time.time() - start,
            )

        except Exception as e:
            log.warning(
                "Parallel synthesis step '%s' raised: %s",
                step.description, e,
            )
            return ToolResult(
                call_id=f"synth_{step.id}", tool="llm.synthesize",
                success=False,
                error=f"{type(e).__name__}: {e}",
                duration_s=time.time() - start,
            )

    def _collect_relevant_outputs(
        self,
        step: PlanStep,
        all_outputs: dict[str, Any],
    ) -> dict[str, Any]:
        """Collect only the outputs this step's dependencies need.

        For each dependency ID, look up the output in all_outputs.
        If the dependency chain is empty, return ALL outputs (the
        step needs everything).
        """
        deps = list(getattr(step, "dependencies", []) or [])
        if not deps:
            # No explicit dependencies → use all available outputs.
            return dict(all_outputs)

        relevant: dict[str, Any] = {}
        for dep_id in deps:
            if dep_id in all_outputs:
                relevant[dep_id] = all_outputs[dep_id]

        return relevant

    def _format_output(self, outputs: dict[str, Any]) -> str:
        """Format a dict of step outputs into a compact string.

        Handles nested dicts, lists, and primitive types.
        Cap at 4000 chars to keep the prompt bounded.
        """
        # If there's only one output, use it directly.
        if len(outputs) == 1:
            val = next(iter(outputs.values()))
            if isinstance(val, (dict, list)):
                return json.dumps(val, indent=2, default=str)[:4000]
            return str(val)[:4000]

        # Multiple outputs — label them by step ID.
        parts: list[str] = []
        for step_id, val in outputs.items():
            label = step_id
            if isinstance(val, (dict, list)):
                formatted = json.dumps(val, indent=2, default=str)
            else:
                formatted = str(val)
            parts.append(f"[{label}]\n{formatted[:2000]}")

        combined = "\n\n---\n\n".join(parts)
        return combined[:4000]

    @staticmethod
    def _group_by_dependency_signature(
        steps: list[PlanStep],
    ) -> list[tuple[PlanStep, ...]]:
        """Group steps that share the same dependency set.

        Two steps with identical dependency IDs will receive the same
        context, so they can share a single LLM call.

        Returns a list of groups (tuples), preserving the original order
        of the *first* step in each signature class.
        """
        signature_map: dict[str, list[PlanStep]] = {}
        for step in steps:
            deps = sorted(getattr(step, "dependencies", []) or [])
            # Include the tool name and description for finer grouping.
            sig = json.dumps({
                "deps": deps,
                "description_prefix": (step.description or "")[:60],
            }, sort_keys=True)
            signature_map.setdefault(sig, []).append(step)

        # Return groups in the order of the first occurrence.
        seen: set[str] = set()
        groups: list[tuple[PlanStep, ...]] = []
        for step in steps:
            deps = sorted(getattr(step, "dependencies", []) or [])
            sig = json.dumps({
                "deps": deps,
                "description_prefix": (step.description or "")[:60],
            }, sort_keys=True)
            if sig not in seen:
                seen.add(sig)
                groups.append(tuple(signature_map[sig]))
        return groups

