"""Conversation store — persists chat history to SQLite so it survives restarts.

The in-memory dict in TaskExecutor is fast but volatile.  This store mirrors
every conversation turn to SQLite, so when the server restarts, the agent
can reload all prior conversations and continue where it left off.
"""
from __future__ import annotations

import json
import logging
import sqlite3
import time
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)


class ConversationStore:
    """SQLite-backed conversation history store."""

    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_schema(self) -> None:
        with self._conn() as conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS conversations (
                session_id  TEXT NOT NULL,
                turn_index  INTEGER NOT NULL,
                role        TEXT NOT NULL,
                content     TEXT NOT NULL,
                timestamp   REAL NOT NULL,
                PRIMARY KEY (session_id, turn_index)
            )""")
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_conv_session ON conversations(session_id)"
            )
            conn.commit()

    def save_turn(
        self, session_id: str, turn_index: int,
        role: str, content: str,
    ) -> None:
        """Persist a single message (user or assistant) to SQLite."""
        with self._conn() as conn:
            conn.execute(
                """INSERT OR REPLACE INTO conversations
                   (session_id, turn_index, role, content, timestamp)
                   VALUES (?, ?, ?, ?, ?)""",
                (session_id, turn_index, role, content, time.time()),
            )
            conn.commit()

    def load_session(self, session_id: str) -> list[dict[str, str]]:
        """Load all messages for a session, ordered by turn_index."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT role, content FROM conversations WHERE session_id = ? "
                "ORDER BY turn_index ASC",
                (session_id,),
            ).fetchall()
        return [{"role": r["role"], "content": r["content"]} for r in rows]

    def load_all(self) -> dict[str, list[dict[str, str]]]:
        """Load ALL conversations from SQLite.  Used on startup."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT session_id, role, content FROM conversations "
                "ORDER BY session_id, turn_index ASC"
            ).fetchall()
        out: dict[str, list[dict[str, str]]] = {}
        for r in rows:
            out.setdefault(r["session_id"], []).append({
                "role": r["role"], "content": r["content"],
            })
        return out

    def clear_session(self, session_id: str) -> None:
        """Delete all messages for a session."""
        with self._conn() as conn:
            conn.execute(
                "DELETE FROM conversations WHERE session_id = ?",
                (session_id,),
            )
            conn.commit()

    def clear_all(self) -> None:
        """Delete ALL conversations."""
        with self._conn() as conn:
            conn.execute("DELETE FROM conversations")
            conn.commit()

    def list_sessions(self) -> list[dict[str, Any]]:
        """Return summary of all sessions."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT session_id, COUNT(*) AS msg_count, "
                "MIN(timestamp) AS first_ts, MAX(timestamp) AS last_ts "
                "FROM conversations GROUP BY session_id ORDER BY last_ts DESC"
            ).fetchall()
        return [{
            "session_id": r["session_id"],
            "message_count": r["msg_count"],
            "turn_count": r["msg_count"] // 2,
            "first_ts": r["first_ts"],
            "last_ts": r["last_ts"],
        } for r in rows]
