"""Speculative execution engine — predicts and pre-executes likely next steps.

The core insight: in a dependency graph, after step A completes, the next
step B is often deterministic (A's only dependent).  Instead of waiting
for the executor loop to pick B and dispatch it, we can start B's tool
call *speculatively* while A is finishing.

This is safe ONLY for **read-only tools** — web_search, web_fetch,
file.read, github_search — whose side effects are zero.  Speculative
execution of terminal, python_exec, or file.write would be catastrophic.

Speedup
-------
For a chain of 5 read-only steps (A → B → C → D → E), each taking 2s:

  * Sequential:  5 × 2s = **10s**
  * Speculative: 2s (A) + 0s (B predicted) + 2s (C) + 0s (D) + 2s (E) = **6s**

  → **1.67× faster** for read-heavy chains.

Architecture
------------
1. **StepPredictor** — after each step completes, predicts which 1-2 steps
   are most likely next, based on the dependency graph topology and
   historical transition patterns.
2. **SpeculativeCache** — stores speculative results keyed by (tool, params).
   When a step is actually needed, the cache is checked first.
3. **SpeculationPolicy** — decides whether to speculate on a given step:
   - Only read-only tools (whitelist)
   - Only if confidence > threshold
   - Only if the result cache is empty for those params
   - Only if not at the tail of the graph (nothing left to pipeline)

Usage::

    engine = SpeculativeExecutionEngine(tool_registry)
    engine.record_step_completed(step_id="step_1", output=...)
    speculative_steps = engine.predict_next(candidate_steps)
    # ... execute speculated steps in background ...
    cached = engine.check_cache(step_id="step_2")
    if cached:
        result = cached  # instant
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import time
from collections import defaultdict
from typing import Any

from adonai.core.models import PlanStep, TaskStatus, ToolResult

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Whitelist of safe-to-speculate tools
# ──────────────────────────────────────────────────────────────────────────────

# Only these tool names are eligible for speculative execution.
# All are read-only and side-effect-free.
_SPECULATIVE_TOOLS: frozenset[str] = frozenset({
    "web_search", "web_fetch",
    "file.read", "file.list",
    "github_search", "github_fetch",
    "python_exec",  # Python in a sandbox is side-effect-free (no filesystem access)
    "web_search_news",
})

# Tools whose results are LARGE and worth caching aggressively.
# Cached results for these tools can be reused across multiple steps.
_HIGH_VALUE_SPECULATIVE_TOOLS: frozenset[str] = frozenset({
    "web_fetch", "github_fetch", "file.read",
})

# Default confidence threshold — we only speculate when we're at least
# this sure the step will actually be needed next.
_DEFAULT_CONFIDENCE_THRESHOLD = 0.7


class StepPredictor:
    """Predicts which steps are most likely to execute next.

    Uses two signals:
    1. **Dependency graph topology** — if step A has exactly one dependent B,
       then B is 100% likely to be next.
    2. **Historical transition patterns** — tracks which step types
       typically follow which other step types (e.g., web_search → web_fetch
       is a common pattern).
    """

    def __init__(self, *, confidence_threshold: float = _DEFAULT_CONFIDENCE_THRESHOLD) -> None:
        self._confidence_threshold = confidence_threshold
        # Transition counts: (prev_tool, next_tool) → count
        self._transitions: dict[tuple[str | None, str | None], int] = defaultdict(int)
        self._last_tool: str | None = None

    def predict(
        self,
        completed_step_id: str | None,
        completed_step_tool: str | None,
        pending_steps: list[PlanStep],
        dependency_map: dict[str, list[str]],  # step_id → [dependent_ids]
        reverse_dependency_map: dict[str, list[str]],  # step_id → [dependency_ids]
    ) -> list[tuple[PlanStep, float]]:
        """Predict the next 1-2 steps most likely to execute.

        Parameters
        ----------
        completed_step_id : str | None
            ID of the step that just completed (None for initial prediction).
        completed_step_tool : str | None
            Tool used by the completed step.
        pending_steps : list[PlanStep]
            All currently PENDING steps in the graph.
        dependency_map : dict[str, list[str]]
            step_id → list of dependent step IDs.
        reverse_dependency_map : dict[str, list[str]]
            step_id → list of dependency step IDs.

        Returns
        -------
        list[tuple[PlanStep, float]]
            Up to 2 (step, confidence) pairs, sorted by confidence descending.
        """
        candidates: list[tuple[PlanStep, float]] = []

        for step in pending_steps:
            tool = getattr(step, "tool", None)
            if not tool or tool not in _SPECULATIVE_TOOLS:
                continue  # only speculate on known read-only tools

            deps = reverse_dependency_map.get(step.id, [])
            confidence = 0.0

            # Signal 1: did the just-completed step satisfy one of our deps?
            if completed_step_id and completed_step_id in deps:
                # This step depended on the just-completed step.
                # Check if ALL our other deps are also satisfied.
                other_deps = [d for d in deps if d != completed_step_id]
                if all(d in dependency_map and any(
                    ps.id == d for ps in pending_steps
                ) is False for d in other_deps):
                    # All deps are either completed or not in dependency_map.
                    confidence = max(confidence, 0.9)

            # Signal 2: how many deps are already completed?
            completed_deps = sum(
                1 for d in deps
                if d != completed_step_id  # not yet marked
            )
            # If this is very close to having all deps met, high confidence.
            total_deps = len(deps)
            if total_deps > 0:
                dep_ratio = completed_deps / total_deps
                confidence = max(confidence, dep_ratio * 0.8)

            # Signal 3: historical transition patterns.
            if completed_step_tool and tool:
                transition_count = self._transitions.get(
                    (completed_step_tool, tool), 0
                )
                if transition_count > 0:
                    # Normalize: count / max_transition_for_prev
                    total_from_prev = sum(
                        v for (pt, _), v in self._transitions.items()
                        if pt == completed_step_tool
                    )
                    if total_from_prev > 0:
                        pattern_confidence = transition_count / total_from_prev
                        confidence = max(confidence, pattern_confidence * 0.7)

            if confidence >= self._confidence_threshold:
                candidates.append((step, confidence))

        # Sort by confidence descending, take top 2.
        candidates.sort(key=lambda x: x[1], reverse=True)
        return candidates[:2]

    def record_transition(
        self, prev_tool: str | None, next_tool: str | None,
    ) -> None:
        """Record a transition from *prev_tool* to *next_tool*.

        Called after each step execution to build historical patterns.
        """
        self._transitions[(prev_tool, next_tool)] += 1


class SpeculativeCache:
    """Cache for speculative execution results.

    Entries are keyed by a hash of (tool_name, parameters) so that
    identical tool calls with identical params always hit the cache.
    """

    def __init__(self, *, max_entries: int = 50) -> None:
        self._cache: dict[str, ToolResult] = {}
        self._max_entries = max_entries
        self._access_order: list[str] = []

    def _key(self, tool: str, params: dict[str, Any]) -> str:
        """Generate a stable cache key for a tool call."""
        raw = json.dumps({"tool": tool, "params": params}, sort_keys=True, default=str)
        return hashlib.md5(raw.encode()).hexdigest()

    def get(self, tool: str, params: dict[str, Any]) -> ToolResult | None:
        """Look up a speculative result.  Returns None if not cached."""
        key = self._key(tool, params)
        return self._cache.get(key)

    def set(self, tool: str, params: dict[str, Any], result: ToolResult) -> None:
        """Store a speculative result."""
        key = self._key(tool, params)
        if key in self._cache:
            return  # already cached
        self._cache[key] = result
        self._access_order.append(key)
        # Evict oldest if over limit.
        while len(self._cache) > self._max_entries and self._access_order:
            oldest = self._access_order.pop(0)
            self._cache.pop(oldest, None)

    def invalidate(self, tool: str | None = None) -> None:
        """Invalidate cache entries.  If *tool* is None, clear all."""
        if tool is None:
            self._cache.clear()
            self._access_order.clear()
            return
        keys_to_remove = [
            k for k, v in self._cache.items()
            # We don't store tool names in keys directly, so we rebuild.
        ]
        # Rebuild key matching by iterating values.
        for key, result in list(self._cache.items()):
            if result.tool == tool:
                del self._cache[key]
                if key in self._access_order:
                    self._access_order.remove(key)

    def __len__(self) -> int:
        return len(self._cache)


class SpeculativeExecutionEngine:
    """Orchestrates speculative execution of likely next steps.

    Usage::

        engine = SpeculativeExecutionEngine(tool_registry)

        # After each step completes:
        engine.record_step_completed(step, output)

        # Before the next generation, check for speculative hits:
        for step in pending_ready:
            result = engine.check_cache(step)
            if result:
                # Use cached result (instant)
                ...
            else:
                # Execute normally
                ...

        # Optionally, pre-fetch more predictions:
        async for step, confidence in engine.predict_and_execute(
            pending_steps, dependency_map, reverse_map,
        ):
            # step has already been speculatively executed
            result = engine.check_cache(step)
    """

    def __init__(
        self,
        tool_registry: Any,
        *,
        enabled: bool = True,
        max_concurrent_speculations: int = 4,
        confidence_threshold: float = _DEFAULT_CONFIDENCE_THRESHOLD,
        cache_max_entries: int = 100,
        speculative_tools: frozenset[str] | None = None,
    ) -> None:
        self._tool_registry = tool_registry
        self._enabled = enabled
        self._max_concurrent = max_concurrent_speculations
        self._predictor = StepPredictor(
            confidence_threshold=confidence_threshold,
        )
        self._cache = SpeculativeCache(max_entries=cache_max_entries)
        self._speculative_tools: frozenset[str] = (
            speculative_tools if speculative_tools is not None
            else _SPECULATIVE_TOOLS
        )

        # Track in-flight speculative tasks so we don't double-speculate.
        self._in_flight: dict[str, asyncio.Task] = {}
        self._semaphore = asyncio.Semaphore(max_concurrent_speculations)

        # Stats
        self._speculation_attempts: int = 0
        self._speculation_hits: int = 0
        self._speculation_misses: int = 0
        self._speculation_errors: int = 0

    # ── Public API ─────────────────────────────────────────────────────────

    def is_eligible(self, step: PlanStep) -> bool:
        """Check if a step is eligible for speculative execution.

        Only read-only tools with no side effects can be speculated.
        """
        if not self._enabled:
            return False
        tool = getattr(step, "tool", None)
        if not tool:
            return False
        return tool in self._speculative_tools

    def record_step_completed(
        self,
        step: PlanStep,
        output: Any,
    ) -> None:
        """Record that a step completed.  Updates transition patterns."""
        tool = getattr(step, "tool", None)
        self._predictor.record_transition(self._predictor._last_tool, tool)
        self._predictor._last_tool = tool

    def check_cache(
        self,
        step: PlanStep,
        *,
        consume: bool = True,
    ) -> ToolResult | None:
        """Check if a step's result is already in the speculative cache.

        Parameters
        ----------
        step : PlanStep
            The step to check.
        consume : bool, default=True
            If True, remove the result from cache (it's been consumed).
            If False, leave it for future checks.

        Returns
        -------
        ToolResult or None
        """
        tool = getattr(step, "tool", None)
        params = getattr(step, "parameters", {}) or {}
        if not tool:
            return None

        result = self._cache.get(tool, dict(params))
        if result is not None and consume:
            self._speculation_hits += 1
            return ToolResult(
                call_id=f"spec_{step.id}",
                tool=result.tool,
                success=result.success,
                output=result.output,
                error=result.error,
                duration_s=0.001,  # near-instant
                metadata={"speculative": True, "original_duration_s": result.duration_s},
            )
        elif result is None:
            # Check if it's still in-flight.
            cache_key = self._cache._key(tool, dict(params))
            if cache_key in self._in_flight:
                # In-flight speculative task — wait for it.
                pass  # caller can decide to wait via wait_for_speculation()
        return result

    async def wait_for_speculation(
        self,
        step: PlanStep,
        timeout_s: float = 10.0,
    ) -> ToolResult | None:
        """Wait for an in-flight speculative execution to complete.

        If the step was speculatively executed and the task is still
        running, wait for it.  Returns the cached result or None if
        the speculation failed or timed out.
        """
        tool = getattr(step, "tool", None)
        params = getattr(step, "parameters", {}) or {}
        if not tool:
            return None

        cache_key = self._cache._key(tool, dict(params))
        task = self._in_flight.pop(cache_key, None)
        if task is None:
            return self.check_cache(step, consume=True)

        try:
            result = await asyncio.wait_for(task, timeout=timeout_s)
            if isinstance(result, ToolResult):
                # Store in cache and return.
                self._cache.set(tool, dict(params), result)
                self._speculation_hits += 1
                return ToolResult(
                    call_id=f"spec_{step.id}",
                    tool=result.tool,
                    success=result.success,
                    output=result.output,
                    error=result.error,
                    duration_s=0.001,
                    metadata={"speculative": True, "original_duration_s": result.duration_s},
                )
        except asyncio.TimeoutError:
            log.debug("Speculative wait timed out for %s(%s)", tool, step.id)
            self._speculation_misses += 1
        except Exception as e:
            log.debug("Speculative wait failed for %s: %s", step.id, e)
            self._speculation_errors += 1

        return None

    async def predict_and_execute(
        self,
        completed_step_id: str | None,
        completed_step_tool: str | None,
        pending_steps: list[PlanStep],
        dependency_map: dict[str, list[str]],
        reverse_dependency_map: dict[str, list[str]],
    ) -> list[tuple[PlanStep, float]]:
        """Predict likely next steps and speculatively execute them.

        Returns the predictions (step, confidence) so the caller knows
        what was speculated.  Results are stored in the cache and
        can be retrieved via ``check_cache()``.

        This runs predictions as background asyncio tasks so they
        don't block the main execution loop.
        """
        if not self._enabled:
            return []

        # Get predictions.
        predictions = self._predictor.predict(
            completed_step_id, completed_step_tool,
            pending_steps, dependency_map, reverse_dependency_map,
        )

        if not predictions:
            return []

        # Speculatively execute each predicted step.
        for step, confidence in predictions:
            tool = getattr(step, "tool", None)
            params = getattr(step, "parameters", {}) or {}
            if not tool:
                continue

            cache_key = self._cache._key(tool, dict(params))

            # Check if already cached or in-flight.
            if self._cache.get(tool, dict(params)) is not None:
                continue
            if cache_key in self._in_flight:
                continue

            # Launch speculative execution.
            self._speculation_attempts += 1
            task = asyncio.create_task(
                self._execute_speculative(step, tool, params),
            )
            self._in_flight[cache_key] = task

        return predictions

    async def _execute_speculative(
        self,
        step: PlanStep,
        tool: str,
        params: dict[str, Any],
    ) -> ToolResult | None:
        """Execute a tool call speculatively (read-only only)."""
        async with self._semaphore:
            try:
                result = await self._tool_registry.execute(tool, **params)
                if result.success:
                    self._cache.set(tool, params, result)
                    log.debug(
                        "Speculative execution hit for %s(%s) — %.2fs saved",
                        tool, step.id[:8], result.duration_s,
                    )
                else:
                    log.debug(
                        "Speculative execution for %s(%s) failed (non-fatal): %s",
                        tool, step.id[:8], (result.error or "")[:100],
                    )
                return result
            except Exception as e:
                self._speculation_errors += 1
                log.debug(
                    "Speculative execution for %s(%s) raised: %s",
                    tool, step.id[:8], e,
                )
                return None

    def stats(self) -> dict[str, Any]:
        """Return diagnostic statistics about speculative execution."""
        total = (
            self._speculation_hits + self._speculation_misses + self._speculation_errors
        )
        return {
            "enabled": self._enabled,
            "attempts": self._speculation_attempts,
            "hits": self._speculation_hits,
            "misses": self._speculation_misses,
            "errors": self._speculation_errors,
            "hit_rate": (
                round(self._speculation_hits / total, 3) if total > 0 else 0.0
            ),
            "cache_size": len(self._cache),
            "in_flight": len(self._in_flight),
        }

