"""Parallel Execution Engine — runs independent plan steps concurrently.

Improvements over the base executor:
  1. Dependency-aware parallelism: Steps with no dependencies run in parallel
  2. Async tool execution: All tools already async, but now steps can overlap
  3. Result merging: Combines outputs from parallel steps intelligently
  4. Fallback: If parallel execution fails, falls back to sequential

Usage:
    The EnhancedExecutor replaces TaskExecutor when parallel mode is enabled.
    It automatically detects which steps can run in parallel (no dependencies)
    and executes them concurrently using asyncio.gather().
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from typing import Any

from adonai.core.models import (
    Memory, MemoryType, Plan, PlanStep, Task, TaskResult, TaskStatus, ToolResult,
)
from adonai.executors.executor import TaskExecutor
from adonai.llm.prompt import SystemPrompts
from adonai.planning.graph import DependencyGraph

log = logging.getLogger(__name__)


class EnhancedExecutor(TaskExecutor):
    """Executor with parallel step execution for independent steps.

    Steps that have no dependencies (or whose dependencies are all complete)
    are executed concurrently. Steps with dependencies wait for their
    predecessors to finish.

    Example:
        Plan:
          Step 1: web_search("AI news")        [no deps]
          Step 2: web_search("quantum news")    [no deps]
          Step 3: file.write(results)           [depends on 1, 2]
          Step 4: synthesize                    [depends on 3]

        Execution:
          Generation 1: Step 1 + Step 2 run in PARALLEL
          Generation 2: Step 3 runs (after 1+2 complete)
          Generation 3: Step 4 runs (after 3 complete)
    """

    def __init__(self, *args, enable_parallel: bool = True, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.enable_parallel = enable_parallel
        self._step_outputs: dict[str, Any] = {}  # step_id → output

    async def execute(self, task: Task, plan: Plan) -> TaskResult:
        """Execute plan with parallel step support."""
        # Check for fast mode (1-step plan, no tool).
        if len(plan.steps) == 1 and not plan.steps[0].tool:
            return await super().execute(task, plan)

        # Check for meta-questions.
        meta_response = await self._handle_meta_question(task)
        if meta_response is not None:
            return TaskResult(
                task_id=task.id, status=TaskStatus.COMPLETED,
                output=meta_response, steps_executed=0,
                duration_s=0.0, confidence=1.0,
            )

        if not self.enable_parallel:
            # Fall back to sequential execution.
            return await super().execute(task, plan)

        # ── Parallel execution ──────────────────────────────────────────
        start = time.time()
        self._current_task_id = task.id
        session_id = task.session_id or self._task_sessions.get(task.id, "default")
        self._task_sessions[task.id] = session_id
        self._dynamic_system_prompt = await self._build_system_prompt()

        # Persist goal to working memory.
        if self.memory is not None:
            try:
                await self.memory.add(Memory(
                    type=MemoryType.WORKING,
                    content=f"user goal: {task.goal}",
                    importance=0.8, source="user",
                    session_id=session_id,
                ))
            except Exception:
                pass

        # v5: Recall long-term memory — same as the serial executor
        # (executor.py:143-163). Previously the parallel executor wrote
        # WORKING memory but never called memory.recall(), so when
        # max_concurrent_tasks > 1, long-term memory was not injected
        # into the system prompt at all. This was an asymmetry/bug.
        recalled_memories: list = []
        if self.memory is not None:
            try:
                recalled_memories = await self.memory.recall(
                    task.goal, top_k=5,
                    types=[MemoryType.EPISODIC, MemoryType.SEMANTIC],
                )
            except Exception as e:
                import logging as _log
                _log.getLogger(__name__).debug(
                    "ParallelExecutor memory.recall failed (non-fatal): %s", e,
                )
        # Inject recalled memories into the system prompt so the LLM sees them.
        if recalled_memories and self._dynamic_system_prompt:
            mem_block = "\n\nRelevant long-term memories:\n" + "\n".join(
                f"- [{m.type.value if hasattr(m.type, 'value') else m.type}] "
                f"{m.content[:300]}"
                for m in recalled_memories[:5]
            )
            self._dynamic_system_prompt += mem_block

        graph = DependencyGraph(plan)
        executed = 0
        last_output: Any = None
        last_error: str | None = None
        history = self._get_history(session_id)
        self._step_outputs = {}

        max_retries_per_step = 3

        while True:
            # Get all ready steps (deps satisfied, still pending).
            ready_steps = graph.ready_steps()
            if not ready_steps:
                break

            # Filter to only PENDING steps.
            pending_ready = [s for s in ready_steps if s.status == TaskStatus.PENDING]
            if not pending_ready:
                break

            # Check if we've hit max_steps.
            if executed >= task.max_steps:
                break

            # v9 fix: sort pending_ready by risk_level BEFORE slicing so
            # the highest-priority (lowest-risk) steps are guaranteed to
            # run first. Previously `pending_ready[:4]` discarded the
            # risk-ordering that DependencyGraph.ready_steps() had already
            # established — but only if the slice happened to take the
            # first 4. The graph already sorts by risk, but if a caller
            # ever passes a differently-ordered list (or if we later add
            # priority-based filtering), this re-sort keeps the invariant
            # explicit and defensive. Map: low=0, medium=1, high=2,
            # critical=3 (PlanStep.risk_level only allows low/medium/high
            # today, but critical is included for forward-compat).
            _risk_order = {"low": 0, "medium": 1, "high": 2, "critical": 3}
            pending_ready.sort(
                key=lambda s: (_risk_order.get(getattr(s, "risk_level", "low"), 0), s.id)
            )

            # Determine how many we can run in parallel.
            # Limit to max 4 concurrent steps to avoid overwhelming the LLM.
            batch = pending_ready[:4]

            if len(batch) == 1:
                # Single step — run sequentially (with self-healing).
                step = batch[0]
                result, step_output = await self._execute_step_with_retry(
                    step, task, last_output, history, max_retries_per_step,
                )
                step.status = TaskStatus.COMPLETED if result.success else TaskStatus.FAILED
                if result.success:
                    executed += 1
                    last_output = step_output
                    self._step_outputs[step.id] = step_output
                else:
                    last_error = result.error or "tool returned failure"
            else:
                # Multiple independent steps — run in PARALLEL.
                log.info(
                    "Parallel execution: running %d steps concurrently (generation %d)",
                    len(batch), executed // len(batch) + 1,
                )

                # Execute all steps in the batch concurrently.
                tasks = [
                    self._execute_step_with_retry(
                        step, task, None, history, max_retries_per_step,
                    )
                    for step in batch
                ]
                results = await asyncio.gather(*tasks, return_exceptions=True)

                # Process results.
                batch_failed_step: PlanStep | None = None
                batch_failed_error: str | None = None
                completed_in_batch: list[PlanStep] = []
                for i, (step, result_tuple) in enumerate(zip(batch, results)):
                    if isinstance(result_tuple, Exception):
                        step.status = TaskStatus.FAILED
                        last_error = str(result_tuple)
                        if batch_failed_step is None:
                            batch_failed_step = step
                            batch_failed_error = last_error
                        log.warning("Parallel step '%s' raised: %s", step.description, result_tuple)
                        continue

                    result, step_output = result_tuple
                    if result.success:
                        step.status = TaskStatus.COMPLETED
                        executed += 1
                        self._step_outputs[step.id] = step_output
                        completed_in_batch.append(step)
                        # Use the last successful output as the "current" output.
                        last_output = step_output
                    else:
                        step.status = TaskStatus.FAILED
                        last_error = result.error or "tool returned failure"
                        if batch_failed_step is None:
                            batch_failed_step = step
                            batch_failed_error = last_error

                # v9 fix: rollback on partial parallel-batch failure.
                # If any step in the batch failed AND there are downstream
                # steps that depend on it (graph.blocked_steps() non-empty),
                # discard the sibling outputs and trigger replan immediately
                # rather than merging. Previously the surviving siblings'
                # outputs were merged into the final synthesis even though
                # the downstream steps they feed into could no longer run
                # (because their co-dependency failed) — producing a
                # misleading "partial success" answer.
                if batch_failed_step is not None:
                    blocked = graph.blocked_steps()
                    if blocked:
                        log.warning(
                            "ParallelExecutor: %d step(s) in batch failed and "
                            "%d downstream step(s) are now blocked — discarding "
                            "%d sibling output(s) and triggering replan",
                            sum(1 for s in batch if s.status == TaskStatus.FAILED),
                            len(blocked),
                            len(completed_in_batch),
                        )
                        # Discard sibling outputs from this batch.
                        for s in completed_in_batch:
                            self._step_outputs.pop(s.id, None)
                            # Roll back the step status so the replanned plan
                            # can re-execute it cleanly.
                            s.status = TaskStatus.PENDING
                            s.verification_passed = None
                            s.verification_message = None
                        # Use the failed step's error as the replan reason.
                        last_output = None
                        # Trigger replan if we have a planner and haven't
                        # exhausted our replan budget. We reuse the same
                        # _max_replans heuristic as the serial executor.
                        if self.planner is not None and not getattr(self, "_parallel_replan_exhausted", False):
                            try:
                                new_plan = await self.planner.replan(
                                    task, plan, batch_failed_step,
                                    batch_failed_error or "parallel batch failed",
                                )
                                if new_plan and new_plan.steps:
                                    plan = new_plan
                                    graph = DependencyGraph(plan)
                                    self._active_plans[task.id] = plan
                                    # Publish the replan event if possible.
                                    try:
                                        from adonai.core.events import EventTypes
                                        await self._publish_event(task, EventTypes.PLAN_CREATED, {
                                            "plan_id": plan.id, "task_id": task.id,
                                            "goal": task.goal, "replan": True,
                                            "steps": [self._step_summary(s) for s in plan.steps],
                                        })
                                    except Exception:
                                        pass
                                    log.info(
                                        "ParallelExecutor: replan succeeded — new plan has %d steps",
                                        len(plan.steps),
                                    )
                                    # Checkpoint the replanned state.
                                    if self.checkpoints is not None:
                                        try:
                                            await self.checkpoints.checkpoint(task, plan)
                                        except Exception:
                                            pass
                                    continue  # resume outer loop with new plan
                            except Exception as e:
                                log.warning("ParallelExecutor: replan after batch failure failed: %s", e)
                                self._parallel_replan_exhausted = True

            # Checkpoint after each generation.
            if self.checkpoints is not None:
                try:
                    await self.checkpoints.checkpoint(task, plan)
                except Exception:
                    pass

        # ── Final synthesis ──────────────────────────────────────────────
        # If we have multiple parallel outputs, merge them.
        if len(self._step_outputs) > 1 and last_output is not None:
            # Collect all outputs from completed steps.
            all_outputs = list(self._step_outputs.values())
            if len(all_outputs) > 1:
                last_output = self._merge_outputs(all_outputs, task)

        # Dict-to-text synthesis.
        if isinstance(last_output, (dict, list)):
            try:
                pretty = json.dumps(last_output, indent=2, default=str)[:4000]
                user_turn = (
                    f"{task.goal}\n\n"
                    f"--- Tool output (use this to answer) ---\n{pretty}\n--- end ---\n\n"
                    f"Write a clear, well-formatted natural-language response."
                )
                messages = (
                    [{"role": "system", "content": self._dynamic_system_prompt}]
                    + list(history)
                    + [{"role": "user", "content": user_turn}]
                )
                resp = await self.llm.complete(
                    messages=messages,
                    temperature=self.config.agent.default_temperature if self.config else 0.3,
                    max_tokens=self.config.llm.max_tokens if self.config else 1536,
                )
                if resp.text and resp.text.strip():
                    last_output = resp.text
            except Exception as e:
                log.warning("Final synthesis failed: %s", e)

        # Defensive fallback.
        if last_output is None and last_error is None:
            try:
                messages = (
                    [{"role": "system", "content": self._dynamic_system_prompt}]
                    + list(history)
                    + [{"role": "user", "content": task.goal}]
                )
                resp = await self.llm.complete(
                    messages=messages,
                    temperature=self.config.agent.default_temperature if self.config else 0.3,
                    max_tokens=self.config.llm.max_tokens if self.config else 1536,
                )
                last_output = resp.text
                executed = max(executed, 1)
            except Exception as e:
                last_error = f"final synthesis failed: {type(e).__name__}: {e}"

        task_result = TaskResult(
            task_id=task.id, status=TaskStatus.COMPLETED,
            output=last_output, error=last_error,
            steps_executed=executed, duration_s=time.time() - start,
            confidence=plan.confidence,
        )

        # Record to conversation history.
        reply = task_result.output if task_result.output is not None else (
            f"[error] {task_result.error}" if task_result.error else "[no response]"
        )
        self._record_turn(session_id, task.goal, str(reply))

        # v9 fix: persist an EPISODIC memory after task completion (same
        # fix as the serial TaskExecutor — see executor.py:580-598).
        # The parallel executor was missing this write entirely.
        if self.memory is not None:
            try:
                await self.memory.add(Memory(
                    type=MemoryType.EPISODIC,
                    content=f"Task: {task.goal}\nResult: {str(reply)[:500]}",
                    importance=0.7 if task_result.status == TaskStatus.COMPLETED else 0.5,
                    source="executor",
                    session_id=getattr(task, 'session_id', None),
                ))
            except Exception as e:
                log.debug("ParallelExecutor episodic memory write failed (non-fatal): %s", e)

        return task_result

    async def _execute_step_with_retry(
        self, step: PlanStep, task: Task, prev_output: Any,
        history: list[dict[str, str]], max_retries: int,
    ) -> tuple[ToolResult, Any]:
        """Execute a single step with self-healing retry.

        Returns (ToolResult, output_value).
        """
        retry_count = 0
        while retry_count <= max_retries:
            result = await self._execute_step(step, task, prev_output, history)
            if result.success:
                return result, result.output

            # Self-healing for code execution steps.
            if step.tool in ("python_exec", "terminal") and retry_count < max_retries:
                error_msg = result.error or "tool returned failure"
                log.warning(
                    "Step '%s' failed (attempt %d/%d): %s — self-healing",
                    step.description, retry_count + 1, max_retries, error_msg[:200],
                )
                fix_result = await self._self_heal_step(step, task, error_msg, result.output)
                if fix_result:
                    step.parameters = fix_result
                    retry_count += 1
                    continue

            return result, result.output

        return result, result.output

    def _merge_outputs(self, outputs: list[Any], task: Task) -> Any:
        """Merge outputs from parallel steps.

        If all outputs are dicts, merge them into one dict.
        If all are strings, concatenate them.
        Otherwise, return the last one.
        """
        if not outputs:
            return None

        # If all are dicts, merge.
        if all(isinstance(o, dict) for o in outputs):
            merged = {}
            for o in outputs:
                merged.update(o)
            return merged

        # If all are strings, concatenate.
        if all(isinstance(o, str) for o in outputs):
            return "\n\n---\n\n".join(outputs)

        # If all are lists, concatenate.
        if all(isinstance(o, list) for o in outputs):
            return [item for o in outputs for item in o]

        # Mixed types — return the last non-None output.
        for o in reversed(outputs):
            if o is not None:
                return o

        return outputs[-1]
