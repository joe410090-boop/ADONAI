"""Checkpoint manager — snapshots task + plan state to SQLite for crash recovery."""
from __future__ import annotations

import json
import logging
import sqlite3
import time
from pathlib import Path
from typing import Any

from adonai.config.settings import Config
from adonai.core.models import Plan, Task, TaskStatus

log = logging.getLogger(__name__)


class CheckpointManager:
    """Persist snapshots of in-flight Tasks + Plans to SQLite."""

    def __init__(self, config: Config) -> None:
        self.db_path = Path(config.memory.sqlite_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_schema(self) -> None:
        with self._conn() as conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS task_checkpoints (
                id         TEXT PRIMARY KEY,
                task_id    TEXT NOT NULL,
                snapshot   TEXT NOT NULL,
                created_at REAL NOT NULL
            )""")
            conn.execute("""CREATE TABLE IF NOT EXISTS tasks (
                id          TEXT PRIMARY KEY,
                goal        TEXT NOT NULL,
                status      TEXT NOT NULL,
                plan        TEXT NOT NULL DEFAULT '{}',
                steps_log   TEXT NOT NULL DEFAULT '[]',
                result      TEXT,
                created_at  REAL NOT NULL,
                updated_at  REAL NOT NULL,
                parent_task_id TEXT,
                owner_agent TEXT,
                session_id  TEXT
            )""")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_tasks_updated ON tasks(updated_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_checkpoints_task ON task_checkpoints(task_id)")
            conn.commit()

    async def checkpoint(
        self, task: Task, plan: Plan | None = None,
        steps_log: list[dict[str, Any]] | None = None,
        result: Any = None,
    ) -> str:
        """Save a snapshot of *task*; returns checkpoint id."""
        import uuid
        cp_id = str(uuid.uuid4())
        snapshot = {
            "task": task.model_dump(mode="json"),
            "plan": plan.model_dump(mode="json") if plan else None,
            "steps_log": steps_log or [],
            "result": _stringify(result),
            "timestamp": time.time(),
        }
        now = time.time()
        with self._conn() as conn:
            conn.execute(
                "INSERT INTO task_checkpoints (id, task_id, snapshot, created_at) VALUES (?, ?, ?, ?)",
                (cp_id, task.id, json.dumps(snapshot, default=str), now),
            )
            conn.execute(
                """INSERT INTO tasks
                     (id, goal, status, plan, steps_log, result, created_at, updated_at,
                      parent_task_id, owner_agent, session_id)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(id) DO UPDATE SET
                     status=excluded.status, plan=excluded.plan,
                     steps_log=excluded.steps_log, result=excluded.result,
                     updated_at=excluded.updated_at""",
                (
                    task.id, task.goal, task.status.value,
                    plan.model_dump_json() if plan else "{}",
                    json.dumps(steps_log or [], default=str),
                    _stringify(result),
                    task.created_at.timestamp() if task.created_at else now,
                    now, task.parent_id, task.assigned_agent, task.session_id,
                ),
            )
            conn.commit()
        return cp_id

    async def list_resumable_tasks(self) -> list[dict]:
        """Return tasks whose status was running/paused when last checkpointed."""
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT id, goal, status, created_at, updated_at, session_id FROM tasks "
                "WHERE status IN (?, ?) ORDER BY updated_at DESC",
                (TaskStatus.RUNNING.value, TaskStatus.PAUSED.value),
            ).fetchall()
        return [dict(r) for r in rows]

    async def load_task(self, task_id: str) -> dict | None:
        with self._conn() as conn:
            row = conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
        return dict(row) if row else None

    async def list_checkpoints(self, task_id: str) -> list[dict]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT id, task_id, created_at FROM task_checkpoints "
                "WHERE task_id = ? ORDER BY created_at DESC",
                (task_id,),
            ).fetchall()
        return [dict(r) for r in rows]

    async def load_checkpoint(self, checkpoint_id: str) -> dict | None:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT snapshot FROM task_checkpoints WHERE id = ?",
                (checkpoint_id,),
            ).fetchone()
        return json.loads(row["snapshot"]) if row else None

    async def update_task_status(
        self, task_id: str, status: TaskStatus, result: Any = None,
    ) -> None:
        with self._conn() as conn:
            conn.execute(
                "UPDATE tasks SET status = ?, result = ?, updated_at = ? WHERE id = ?",
                (status.value, _stringify(result), time.time(), task_id),
            )
            conn.commit()

    async def list_all_tasks(self, limit: int = 100) -> list[dict]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM tasks ORDER BY updated_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [dict(r) for r in rows]


def _stringify(value: Any) -> str | None:
    if value is None:
        return None
    if isinstance(value, str):
        return value
    try:
        return json.dumps(value, default=str)
    except Exception:
        return str(value)[:2000]
