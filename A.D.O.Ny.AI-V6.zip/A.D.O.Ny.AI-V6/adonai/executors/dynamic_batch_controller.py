"""Dynamic batch controller — adaptively sizes parallel step batches.

Instead of a hardcoded batch limit (``pending_ready[:4]``), this controller
uses real-time metrics to determine the optimal number of concurrent steps:

1. **Historical tool latency** — from ``ToolRegistry.all_stats()``, we know
   how long each tool typically takes. Slow tools (web_fetch 6-10s) justify
   larger batches to overlap latency. Fast tools (file.read 0.01s) don't.
2. **Step complexity** — steps with ``risk_level=low`` (read-only) can be
   more aggressively batched than ``risk_level=high`` (destructive) steps.
3. **Error-rate feedback** — if a batch has a high failure rate, reduce the
   batch size for subsequent generations (back-pressure).
4. **Dependency graph depth** — when the graph has many pending layers,
   aggressive batching clears them faster.  Near the end, smaller batches
   reduce wasted speculative work.

Usage::

    controller = DynamicBatchController(tool_registry)
    controller.record_batch_outcome(n_requested=4, n_succeeded=3, n_failed=1)
    batch_size = controller.compute_batch_size(ready_steps)
"""
from __future__ import annotations

import logging
import time
from collections import defaultdict, deque
from typing import Any

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Default configuration
# ──────────────────────────────────────────────────────────────────────────────

# Minimum and maximum batch sizes (hard limits).
_MIN_BATCH = 1
_MAX_BATCH = 16

# If the mean tool latency in the current batch is above this threshold (s),
# we can justify larger batches (overlap more slow tools).
_LATENCY_THRESHOLD_FAST = 0.5   # <0.5s → fast tools, small batches
_LATENCY_THRESHOLD_SLOW = 2.0   # >2.0s → slow tools, large batches

# Error-rate back-pressure: if failure rate exceeds this, shrink batches.
_MAX_ERROR_RATE = 0.33  # 33% failure → shrink

# Decay factor for exponential moving average (EMA) of latency + error rate.
_EMA_ALPHA = 0.3

# How many recent generations to remember for back-pressure.
_WINDOW_SIZE = 20


class DynamicBatchController:
    """Adaptively sizes parallel step batches based on runtime metrics.

    Thread-safe for concurrent read/write (all operations are atomic on
    built-in types + deque).
    """

    def __init__(
        self,
        tool_registry: Any | None = None,
        *,
        min_batch: int = _MIN_BATCH,
        max_batch: int = _MAX_BATCH,
        latency_fast_threshold: float = _LATENCY_THRESHOLD_FAST,
        latency_slow_threshold: float = _LATENCY_THRESHOLD_SLOW,
        max_error_rate: float = _MAX_ERROR_RATE,
        ema_alpha: float = _EMA_ALPHA,
        window_size: int = _WINDOW_SIZE,
    ) -> None:
        self._tool_registry = tool_registry
        self._min_batch = min_batch
        self._max_batch = max_batch
        self._latency_fast = latency_fast_threshold
        self._latency_slow = latency_slow_threshold
        self._max_error_rate = max_error_rate
        self._ema_alpha = ema_alpha
        self._window_size = window_size

        # Recent batch outcomes (deque of (n_requested, n_succeeded, n_failed)).
        self._outcomes: deque[tuple[int, int, int]] = deque(maxlen=window_size)

        # EMA of mean tool latency across all tools (updated on each batch).
        self._ema_latency: float | None = None

        # EMA of error rate.
        self._ema_error_rate: float | None = None

        # Last computed batch size (for logging).
        self._last_batch_size: int = _MAX_BATCH

    # ── Public API ──────────────────────────────────────────────────────────

    def compute_batch_size(
        self,
        ready_steps: list[Any],
        *,
        graph_remaining_depth: int | None = None,
    ) -> int:
        """Compute the optimal batch size for the current set of ready steps.

        Parameters
        ----------
        ready_steps : list[PlanStep]
            Steps that are ready to execute (dependencies satisfied).
        graph_remaining_depth : int, optional
            Number of remaining generation layers in the dependency graph.
            If None, assumes moderate depth.

        Returns
        -------
        int
            Number of steps to include in the current parallel batch.
        """
        if not ready_steps:
            return 0

        n_ready = len(ready_steps)

        # Start with the max batch size, then apply constraints.
        batch = self._max_batch

        # 1. Constraint: not more than available steps.
        batch = min(batch, n_ready)

        # 2. Constraint: step risk levels.
        #    High-risk steps → smaller batches (safety + faster failure).
        high_risk_count = sum(
            1 for s in ready_steps[:batch]
            if getattr(s, "risk_level", "low") in ("high", "critical")
        )
        if high_risk_count >= batch // 2:
            # More than half the batch is high-risk — shrink.
            batch = max(self._min_batch, batch // 2)

        # 3. Constraint: historical tool latency.
        latency_score = self._compute_latency_factor(ready_steps[:batch])
        if latency_score < self._latency_fast:
            # Fast tools — small batches (no latency to overlap).
            batch = min(batch, 4)
        elif latency_score > self._latency_slow:
            # Slow tools — larger batches (overlap high latency).
            batch = min(batch, self._max_batch)
        else:
            # Medium tools — moderate batches.
            batch = min(batch, 8)

        # 4. Constraint: error-rate back-pressure.
        if self._ema_error_rate is not None and self._ema_error_rate > self._max_error_rate:
            # High error rate — conservative batches.
            batch = max(self._min_batch, batch // 2)
            log.info(
                "DynamicBatchController: high error rate (EMA=%.2f) — "
                "shrinking batch to %d",
                self._ema_error_rate, batch,
            )

        # 5. Constraint: graph depth.
        if graph_remaining_depth is not None:
            if graph_remaining_depth <= 1:
                # Last layer — small batch (nothing left to pipeline).
                batch = min(batch, 2)
            elif graph_remaining_depth >= 5:
                # Many layers ahead — aggressive batching clears faster.
                pass  # keep current batch size

        # Clamp to bounds.
        batch = max(self._min_batch, min(batch, self._max_batch))
        self._last_batch_size = batch
        return batch

    def record_batch_outcome(
        self,
        n_requested: int,
        n_succeeded: int,
        n_failed: int,
        *,
        step_latencies_s: list[float] | None = None,
    ) -> None:
        """Record the outcome of a parallel batch execution.

        Updates EMA latency and error rate.  Call this after each
        generation completes.

        Parameters
        ----------
        n_requested : int
            Number of steps in the batch.
        n_succeeded : int
            Steps that completed successfully.
        n_failed : int
            Steps that failed.
        step_latencies_s : list[float], optional
            Per-step execution latencies for EMA update.
        """
        self._outcomes.append((n_requested, n_succeeded, n_failed))

        # Update EMA error rate.
        total = n_succeeded + n_failed
        error_rate = n_failed / total if total > 0 else 0.0
        if self._ema_error_rate is None:
            self._ema_error_rate = error_rate
        else:
            self._ema_error_rate = (
                self._ema_alpha * error_rate
                + (1 - self._ema_alpha) * self._ema_error_rate
            )

        # Update EMA latency from per-step latencies.
        if step_latencies_s:
            mean_lat = sum(step_latencies_s) / len(step_latencies_s)
            if self._ema_latency is None:
                self._ema_latency = mean_lat
            else:
                self._ema_latency = (
                    self._ema_alpha * mean_lat
                    + (1 - self._ema_alpha) * self._ema_latency
                )

        # Also update from ToolRegistry stats if available (broader signal).
        self._update_from_registry_stats()

    # ── Stats helpers ──────────────────────────────────────────────────────

    def _compute_latency_factor(self, steps: list[Any]) -> float:
        """Compute a representative latency score for a set of steps.

        Uses per-step tool names to look up historical latencies from
        ToolRegistry stats.  Falls back to EMA latency if registry stats
        are unavailable.
        """
        if not self._tool_registry:
            # Fall back to stored EMA.
            return self._ema_latency or 1.0

        try:
            stats = self._tool_registry.all_stats()
        except Exception:
            return self._ema_latency or 1.0

        if not stats:
            return self._ema_latency or 1.0

        latencies: list[float] = []
        for step in steps:
            tool_name = getattr(step, "tool", None)
            if not tool_name:
                continue
            s = stats.get(tool_name)
            if s and s.get("calls", 0) > 0:
                # Mean latency per call.
                mean_tool_lat = s["total_s"] / s["calls"]
                latencies.append(mean_tool_lat)

        if not latencies:
            return self._ema_latency or 1.0

        # Use the MAX latency (the slowest tool in the batch determines
        # how much time we save by parallelising).
        return max(latencies)

    def _update_from_registry_stats(self) -> None:
        """Update EMA latency from the broader ToolRegistry stats.

        This gives us a more stable signal than per-generation latencies
        alone.
        """
        if not self._tool_registry:
            return
        try:
            stats = self._tool_registry.all_stats()
        except Exception:
            return
        if not stats:
            return

        # Compute a weighted mean latency across all tools.
        total_calls = 0
        total_time = 0.0
        for tool_name, s in stats.items():
            calls = s.get("calls", 0)
            if calls > 0:
                total_calls += calls
                total_time += s.get("total_s", 0.0)

        if total_calls > 0:
            overall_mean = total_time / total_calls
            if self._ema_latency is None:
                self._ema_latency = overall_mean
            else:
                # Lower alpha for the broader signal (more stable).
                self._ema_latency = (
                    0.1 * overall_mean + 0.9 * self._ema_latency
                )

    # ── Properties ─────────────────────────────────────────────────────────

    @property
    def last_batch_size(self) -> int:
        """Most recently computed batch size."""
        return self._last_batch_size

    @property
    def ema_latency(self) -> float | None:
        """Exponential moving average of tool latency in seconds."""
        return self._ema_latency

    @property
    def ema_error_rate(self) -> float | None:
        """Exponential moving average of step error rate (0..1)."""
        return self._ema_error_rate

    def summary(self) -> dict[str, Any]:
        """Return a diagnostic summary of the controller state."""
        return {
            "last_batch_size": self._last_batch_size,
            "ema_latency_s": round(self._ema_latency, 3) if self._ema_latency else None,
            "ema_error_rate": round(self._ema_error_rate, 3) if self._ema_error_rate else None,
            "outcomes_in_window": len(self._outcomes),
            "min_batch": self._min_batch,
            "max_batch": self._max_batch,
        }

