"""Report generator — produces summary reports from analytics + experiences."""
from __future__ import annotations

import json
import time
from typing import Any

from adonai.learning.experience import ExperienceStore
from adonai.learning.patterns import PatternExtractor
from adonai.learning.analytics import AnalyticsTracker


class ReportGenerator:
    """Generate performance + learning reports."""

    def __init__(
        self,
        analytics: AnalyticsTracker,
        experiences: ExperienceStore | None = None,
        patterns: PatternExtractor | None = None,
    ) -> None:
        self.analytics = analytics
        self.experiences = experiences
        self.patterns = patterns

    async def generate(self) -> dict[str, Any]:
        """Generate a full report."""
        report: dict[str, Any] = {
            "generated_at": time.time(),
            "metrics": self.analytics.summary(),
        }
        if self.experiences is not None:
            report["experiences"] = await self.experiences.stats()
        if self.patterns is not None:
            report["patterns"] = self.patterns.analyze()
        return report

    async def generate_text(self) -> str:
        """Generate a human-readable text report."""
        report = await self.generate()
        lines = ["=" * 60, "A.D.O.N.AI Performance Report", "=" * 60, ""]

        # Metrics.
        lines.append("Metrics:")
        for name, stats in report.get("metrics", {}).items():
            lines.append(
                f"  {name}: count={stats['count']} avg={stats['avg']:.3f} "
                f"min={stats['min']} max={stats['max']}"
            )
        lines.append("")

        # Experiences.
        exp = report.get("experiences", {})
        if exp:
            lines.append("Experiences:")
            lines.append(f"  Total: {exp.get('total', 0)}")
            lines.append(f"  Successes: {exp.get('successes', 0)}")
            lines.append(f"  Failures: {exp.get('failures', 0)}")
            lines.append(f"  Success rate: {exp.get('success_rate', 0):.1%}")
            lines.append(f"  Avg duration: {exp.get('avg_duration_s', 0):.1f}s")
            lines.append("")

        # Patterns.
        # PatternExtractor.analyze() returns a nested dict:
        #   {experiences: {status_counts, ...}, goal_patterns: {top_keywords, ...},
        #    failure_patterns: {top_lessons, ...}, ...}
        # The previous code read flat keys (status_counts, top_goal_words,
        # top_failure_lessons) which never existed — the Patterns section was
        # always empty.  Fixed below to read the nested keys.
        pat = report.get("patterns", {})
        if pat:
            lines.append("Patterns:")
            exp_pat = pat.get("experiences", {}) or {}
            goal_pat = pat.get("goal_patterns", {}) or {}
            fail_pat = pat.get("failure_patterns", {}) or {}
            lines.append(f"  Status counts: {exp_pat.get('status_counts', {})}")
            lines.append(
                f"  Top goal words: "
                f"{[k['keyword'] for k in goal_pat.get('top_keywords', [])[:5]]}"
            )
            lines.append(
                f"  Top failure lessons: "
                f"{[l[0] for l in fail_pat.get('top_lessons', [])[:3]]}"
            )
            lines.append("")

        lines.append("=" * 60)
        return "\n".join(lines)
