"""Analytics tracker — re-exported from learning.analytics."""
from adonai.learning.analytics import AnalyticsTracker

__all__ = ["AnalyticsTracker"]
