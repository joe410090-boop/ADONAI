"""Observability — structured logging + metrics + health monitoring (Phase 18).

Provides:
  * StructuredLogger — JSON-formatted log lines for machine consumption.
  * MetricsRegistry — in-memory counter/histogram/gauge registry with
    periodic flush to SQLite.
  * HealthMonitor — tracks subsystem health (LLM, tools, memory, executors).
  * ExecutionTracer — records distributed traces of task → step → tool calls.

The metrics registry is intentionally simple (no Prometheus dependency).
For production deployments, export via the /metrics endpoint (already
exposed in v4_routes.py) and scrape with Prometheus/Grafana.
"""
from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Structured Logger
# ──────────────────────────────────────────────────────────────────────────────

class StructuredLogger:
    """JSON-line logger for machine-readable logs.

    Usage:
        slog = StructuredLogger("adonai.runtime")
        slog.info("task_completed", task_id="...", duration_s=1.23, agent="executive")
        # → {"ts":"2026-07-09T...","level":"INFO","logger":"adonai.runtime",
        #    "event":"task_completed","task_id":"...","duration_s":1.23,"agent":"executive"}
    """

    def __init__(self, name: str) -> None:
        self._logger = logging.getLogger(name)

    def _emit(self, level: int, event: str, **fields: Any) -> None:
        record = {
            "ts": time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime()),
            "level": logging.getLevelName(level),
            "logger": self._logger.name,
            "event": event,
            **fields,
        }
        self._logger.log(level, json.dumps(record, default=str))

    def debug(self, event: str, **fields: Any) -> None:
        self._emit(logging.DEBUG, event, **fields)

    def info(self, event: str, **fields: Any) -> None:
        self._emit(logging.INFO, event, **fields)

    def warning(self, event: str, **fields: Any) -> None:
        self._emit(logging.WARNING, event, **fields)

    def error(self, event: str, **fields: Any) -> None:
        self._emit(logging.ERROR, event, **fields)


# ──────────────────────────────────────────────────────────────────────────────
# Metrics Registry
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class _Counter:
    name: str
    value: float = 0.0
    labels: dict[str, str] = field(default_factory=dict)

    def inc(self, amount: float = 1.0) -> None:
        self.value += amount


@dataclass
class _Gauge:
    name: str
    value: float = 0.0
    labels: dict[str, str] = field(default_factory=dict)

    def set(self, value: float) -> None:
        self.value = value

    def inc(self, amount: float = 1.0) -> None:
        self.value += amount

    def dec(self, amount: float = 1.0) -> None:
        self.value -= amount


@dataclass
class _Histogram:
    name: str
    buckets: list[float] = field(default_factory=lambda: [
        0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0, 2.5, 5.0, 10.0, 30.0, 60.0
    ])
    counts: list[int] = field(default_factory=list)
    sum: float = 0.0
    count: int = 0
    labels: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.counts:
            self.counts = [0] * len(self.buckets)

    def observe(self, value: float) -> None:
        self.sum += value
        self.count += 1
        for i, bound in enumerate(self.buckets):
            if value <= bound:
                self.counts[i] += 1


class MetricsRegistry:
    """In-memory metrics registry with periodic SQLite flush.

    Supports counters, gauges, and histograms. Thread-safe via a single
    RLock (metrics are write-heavy, read-infrequent).
    """

    def __init__(self, db_path: Path | None = None, flush_interval_s: float = 60.0) -> None:
        self._counters: dict[str, _Counter] = {}
        self._gauges: dict[str, _Gauge] = {}
        self._histograms: dict[str, _Histogram] = {}
        self._lock = threading.RLock()
        self._db_path = db_path
        self._flush_interval = flush_interval_s
        self._flush_task: asyncio.Task | None = None
        if db_path:
            self._init_db()

    def _init_db(self) -> None:
        if not self._db_path:
            return
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(str(self._db_path)) as conn:
            # Create the table if it doesn't exist.
            conn.execute("""
                CREATE TABLE IF NOT EXISTS metrics (
                    name TEXT, type TEXT, value REAL, labels TEXT, ts REAL
                )
            """)
            # ── Migration: add missing columns to pre-existing tables ──
            # The original schema (shipped before v4) had only (name, value, ts)
            # and didn't include `type` or `labels`.  Without this migration,
            # _flush() raises "table metrics has no column named type" on
            # every flush attempt against an old DB file.  We introspect the
            # columns and ALTER TABLE ADD COLUMN for any that are missing.
            existing_cols = {
                row[1]
                for row in conn.execute("PRAGMA table_info(metrics)").fetchall()
            }
            for col_name, col_type in (
                ("type", "TEXT"),
                ("value", "REAL"),
                ("labels", "TEXT"),
                ("ts", "REAL"),
                ("name", "TEXT"),
            ):
                if col_name not in existing_cols:
                    try:
                        conn.execute(
                            f"ALTER TABLE metrics ADD COLUMN {col_name} {col_type}"
                        )
                    except sqlite3.OperationalError:
                        # Column may have been added by a concurrent writer.
                        pass
            conn.execute("CREATE INDEX IF NOT EXISTS idx_metrics_name ON metrics(name)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_metrics_ts ON metrics(ts)")
            conn.commit()

    def counter(self, name: str, labels: dict[str, str] | None = None) -> _Counter:
        key = f"{name}:{json.dumps(labels or {}, sort_keys=True)}"
        with self._lock:
            if key not in self._counters:
                self._counters[key] = _Counter(name=name, labels=labels or {})
            return self._counters[key]

    def gauge(self, name: str, labels: dict[str, str] | None = None) -> _Gauge:
        key = f"{name}:{json.dumps(labels or {}, sort_keys=True)}"
        with self._lock:
            if key not in self._gauges:
                self._gauges[key] = _Gauge(name=name, labels=labels or {})
            return self._gauges[key]

    def histogram(self, name: str, labels: dict[str, str] | None = None) -> _Histogram:
        key = f"{name}:{json.dumps(labels or {}, sort_keys=True)}"
        with self._lock:
            if key not in self._histograms:
                self._histograms[key] = _Histogram(name=name, labels=labels or {})
            return self._histograms[key]

    def snapshot(self) -> dict[str, Any]:
        """Return a JSON-serializable snapshot of all metrics."""
        with self._lock:
            return {
                "counters": [
                    {"name": c.name, "value": c.value, "labels": c.labels}
                    for c in self._counters.values()
                ],
                "gauges": [
                    {"name": g.name, "value": g.value, "labels": g.labels}
                    for g in self._gauges.values()
                ],
                "histograms": [
                    {"name": h.name, "sum": h.sum, "count": h.count,
                     "buckets": list(zip(h.buckets, h.counts)), "labels": h.labels}
                    for h in self._histograms.values()
                ],
                "ts": time.time(),
            }

    def start_flush_loop(self) -> None:
        """Start the periodic flush-to-SQLite loop (async)."""
        if self._flush_task is not None or not self._db_path:
            return
        self._flush_task = asyncio.create_task(self._flush_loop())

    async def stop_flush_loop(self) -> None:
        if self._flush_task is not None:
            self._flush_task.cancel()
            try:
                await self._flush_task
            except asyncio.CancelledError:
                pass
            self._flush_task = None

    async def _flush_loop(self) -> None:
        while True:
            try:
                await asyncio.sleep(self._flush_interval)
                self._flush()
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.warning("MetricsRegistry flush failed: %s", e)

    def _flush(self) -> None:
        if not self._db_path:
            return
        snap = self.snapshot()
        ts = snap["ts"]
        with sqlite3.connect(str(self._db_path)) as conn:
            for c in snap["counters"]:
                conn.execute(
                    "INSERT INTO metrics (name, type, value, labels, ts) VALUES (?,?,?,?,?)",
                    (c["name"], "counter", c["value"], json.dumps(c["labels"]), ts),
                )
            for g in snap["gauges"]:
                conn.execute(
                    "INSERT INTO metrics (name, type, value, labels, ts) VALUES (?,?,?,?,?)",
                    (g["name"], "gauge", g["value"], json.dumps(g["labels"]), ts),
                )
            for h in snap["histograms"]:
                conn.execute(
                    "INSERT INTO metrics (name, type, value, labels, ts) VALUES (?,?,?,?,?)",
                    (h["name"], "histogram_count", h["count"], json.dumps(h["labels"]), ts),
                )
            conn.commit()


# ──────────────────────────────────────────────────────────────────────────────
# Health Monitor
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class HealthStatus:
    healthy: bool
    last_check: float
    error: str | None = None
    details: dict[str, Any] = field(default_factory=dict)


class HealthMonitor:
    """Tracks the health of subsystems (LLM, tools, memory, executors).

    Each subsystem is registered with a async health-check callable. The
    monitor polls them periodically and caches the result.
    """

    def __init__(self, check_interval_s: float = 30.0) -> None:
        self._checks: dict[str, tuple[callable, float]] = {}  # name → (check_fn, interval)
        self._status: dict[str, HealthStatus] = {}
        self._check_interval = check_interval_s
        self._task: asyncio.Task | None = None

    def register(self, name: str, check_fn: callable, interval_s: float = 30.0) -> None:
        """Register a subsystem health check. check_fn is async, returns (healthy, error, details)."""
        self._checks[name] = (check_fn, interval_s)
        self._status[name] = HealthStatus(healthy=True, last_check=0.0)

    async def check(self, name: str) -> HealthStatus:
        check_fn, _ = self._checks.get(name, (None, 0))
        if check_fn is None:
            return self._status.get(name, HealthStatus(healthy=False, last_check=0.0, error="unregistered"))
        try:
            result = await check_fn()
            if isinstance(result, tuple):
                healthy, error, details = result + (None, {})[:3 - len(result)]
            else:
                healthy, error, details = bool(result), None, {}
            self._status[name] = HealthStatus(
                healthy=healthy, last_check=time.time(), error=error, details=details or {}
            )
        except Exception as e:
            self._status[name] = HealthStatus(
                healthy=False, last_check=time.time(),
                error=f"{type(e).__name__}: {e}", details={},
            )
        return self._status[name]

    async def check_all(self) -> dict[str, HealthStatus]:
        for name in list(self._checks):
            await self.check(name)
        return dict(self._status)

    def snapshot(self) -> dict[str, Any]:
        return {
            name: {
                "healthy": s.healthy, "last_check": s.last_check,
                "error": s.error, "details": s.details,
                "age_s": time.time() - s.last_check if s.last_check else None,
            }
            for name, s in self._status.items()
        }

    # v6: background poll loop so /health returns fresh data instead of
    # the initial healthy=True forever. Previously check_all() had zero
    # production callers — the monitor was constructed but never polled.
    def start(self) -> None:
        """Start the background health-check poll loop."""
        if self._task is not None:
            return
        self._task = asyncio.create_task(self._poll_loop())

    async def stop(self) -> None:
        """Stop the background poll loop."""
        if self._task is None:
            return
        self._task.cancel()
        try:
            await self._task
        except asyncio.CancelledError:
            pass
        self._task = None

    async def _poll_loop(self) -> None:
        """Periodically run check_all() so snapshot() returns fresh data."""
        while True:
            try:
                await asyncio.sleep(self._check_interval)
                await self.check_all()
            except asyncio.CancelledError:
                break
            except Exception as e:
                # Don't let the poll loop die on a single check failure.
                import logging as _log
                _log.getLogger(__name__).debug("HealthMonitor poll error: %s", e)


# ──────────────────────────────────────────────────────────────────────────────
# Execution Tracer
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class TraceSpan:
    span_id: str
    parent_id: str | None
    name: str
    start_ts: float
    end_ts: float | None = None
    attributes: dict[str, Any] = field(default_factory=dict)
    events: list[dict[str, Any]] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "span_id": self.span_id, "parent_id": self.parent_id,
            "name": self.name, "start_ts": self.start_ts, "end_ts": self.end_ts,
            "duration_s": (self.end_ts - self.start_ts) if self.end_ts else None,
            "attributes": self.attributes, "events": self.events,
        }


class ExecutionTracer:
    """Records distributed traces of task → step → tool calls (Phase 18).

    Traces are kept in-memory (ring buffer of last N) and optionally
    persisted to SQLite. Use /trace/{task_id} to retrieve.
    """

    def __init__(self, max_traces: int = 1000, db_path: Path | None = None) -> None:
        self._spans: dict[str, list[TraceSpan]] = defaultdict(list)  # root_id → spans
        self._open: dict[str, TraceSpan] = {}  # span_id → span (open only)
        self._max_traces = max_traces
        self._root_ids: deque[str] = deque(maxlen=max_traces)
        self._db_path = db_path
        if db_path:
            self._init_db()

    def _init_db(self) -> None:
        if not self._db_path:
            return
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(str(self._db_path)) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS traces (
                    root_id TEXT, span_id TEXT, parent_id TEXT, name TEXT,
                    start_ts REAL, end_ts REAL, attributes TEXT, events TEXT
                )
            """)
            conn.execute("CREATE INDEX IF NOT EXISTS idx_traces_root ON traces(root_id)")
            conn.commit()

    def start_span(
        self, name: str, *, parent_id: str | None = None, root_id: str | None = None,
        **attributes: Any,
    ) -> str:
        import uuid
        span_id = f"span_{uuid.uuid4().hex[:12]}"
        span = TraceSpan(
            span_id=span_id, parent_id=parent_id, name=name,
            start_ts=time.time(), attributes=attributes,
        )
        self._open[span_id] = span
        root = root_id or parent_id or span_id
        if root not in self._spans:
            self._root_ids.append(root)
        self._spans[root].append(span)
        return span_id

    def end_span(self, span_id: str, **attributes: Any) -> None:
        span = self._open.pop(span_id, None)
        if span is None:
            return
        span.end_ts = time.time()
        span.attributes.update(attributes)

    def add_event(self, span_id: str, event: str, **attributes: Any) -> None:
        span = self._open.get(span_id)
        if span is None:
            return
        span.events.append({"name": event, "ts": time.time(), **attributes})

    def get_trace(self, root_id: str) -> list[dict[str, Any]]:
        return [s.to_dict() for s in self._spans.get(root_id, [])]

    def recent_traces(self, limit: int = 20) -> list[dict[str, Any]]:
        ids = list(self._root_ids)[-limit:]
        return [{"root_id": rid, "spans": len(self._spans.get(rid, []))} for rid in reversed(ids)]


# Module-level singletons (lazily initialized by the runtime).
_metrics: MetricsRegistry | None = None
_health: HealthMonitor | None = None
_tracer: ExecutionTracer | None = None


def get_metrics() -> MetricsRegistry:
    global _metrics
    if _metrics is None:
        _metrics = MetricsRegistry()
    return _metrics


def get_health_monitor() -> HealthMonitor:
    global _health
    if _health is None:
        _health = HealthMonitor()
    return _health


def get_tracer() -> ExecutionTracer:
    global _tracer
    if _tracer is None:
        _tracer = ExecutionTracer()
    return _tracer


# ──────────────────────────────────────────────────────────────────────────────
# v7: StructuredLogger singleton — previously dead code.
# ──────────────────────────────────────────────────────────────────────────────

_structured_loggers: dict[str, StructuredLogger] = {}


def get_structured_logger(name: str = "adonai") -> StructuredLogger:
    """Return a StructuredLogger instance for the given name.

    v7: StructuredLogger was fully implemented (35 LOC) but never
    instantiated by any production module. It's now exposed via this
    getter so subsystems can emit JSON-line logs for machine-readable
    consumption (e.g. by the analytics pipeline or external log
    aggregators like Loki / Elasticsearch).
    """
    global _structured_loggers
    if name not in _structured_loggers:
        _structured_loggers[name] = StructuredLogger(name)
    return _structured_loggers[name]
