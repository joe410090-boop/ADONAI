"""Tree-of-Thoughts reasoner — BFS tree with branching, scoring, and backtracking.

Implements a genuine Tree of Thought (Yao et al. 2023) with:
- Multi-generational BFS expansion (branching factor = candidates)
- Per-thought scoring via LLM evaluation
- Pruning of low-scoring branches (prune_threshold)
- Best-path backtracking from leaf to root
- Configurable depth (max_depth)

Unlike a flat generate-score-pick approach, this builds an actual thought
tree, explores multiple generations, and backtracks from dead-ends.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Any
from uuid import uuid4

from adonai.core.interfaces import LLMClient, Reasoner
from adonai.core.json_utils import extract_json, JSONExtractionError
from adonai.core.models import Task

log = logging.getLogger(__name__)


@dataclass
class _Thought:
    """A single node in the thought tree."""
    id: str
    content: str
    parent_id: str | None = None
    children: list[str] = field(default_factory=list)
    score: float = 0.0
    generation: int = 0
    status: str = "pending"  # pending | explored | pruned


class TreeOfThoughts(Reasoner):
    """BFS Tree-of-Thought with branching, pruning, and backtracking."""

    name = "tot"

    def __init__(
        self,
        llm: LLMClient,
        candidates: int = 3,
        max_depth: int = 2,
        prune_threshold: float = 0.3,
        top_k: int = 2,
    ) -> None:
        self.llm = llm
        self.candidates = candidates
        self.max_depth = max_depth
        self.prune_threshold = prune_threshold
        self.top_k = top_k  # how many top thoughts to expand per generation

    # ── Thought generation ─────────────────────────────────────────────

    async def _generate_thoughts(
        self, goal: str, parent_content: str, count: int,
    ) -> list[str]:
        """Generate *count* child thoughts from a parent thought."""
        try:
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": (
                        "You are a creative problem-solver.  Given a parent "
                        "thought, propose the next step.  Be specific, concise, "
                        "and actionable.  Do NOT solve the goal — just describe "
                        "the next reasoning step."
                    )},
                    {"role": "user", "content": (
                        f"Goal: {goal}\n\n"
                        f"Parent thought: {parent_content}\n\n"
                        f"Propose the next reasoning step:"
                    )},
                ],
                temperature=0.7,
                max_tokens=256,
            )
            # Split into separate thoughts if the LLM returns multiple.
            lines = [l.strip() for l in resp.text.strip().split("\n") if l.strip()]
            if not lines:
                return [resp.text.strip()]
            return lines[:count]
        except Exception as e:
            log.warning("ToT thought generation failed: %s", e)
            return []

    async def _score_thought(self, goal: str, thought_content: str) -> float:
        """Score a thought 0..1 for likelihood of leading to a solution."""
        try:
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": (
                        "You are a critical evaluator.  Score this reasoning "
                        "step 0..1 for how likely it is to lead to solving "
                        "the goal.  Output ONLY a single float, e.g. 0.75"
                    )},
                    {"role": "user", "content": (
                        f"Goal: {goal}\n\nReasoning step: {thought_content}\n\nScore:"
                    )},
                ],
                temperature=0.1,
                max_tokens=16,
            )
            score = float(resp.text.strip().split()[0])
            return max(0.0, min(1.0, score))
        except Exception as e:
            log.debug("ToT scoring failed: %s", e)
            return 0.5

    # ── Tree search ────────────────────────────────────────────────────

    async def reason(
        self, task: Task, context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        nodes: dict[str, _Thought] = {}

        # Generation 0: generate root thoughts directly from the goal.
        root_children = await self._generate_thoughts(
            task.goal, "(root — no parent)", self.candidates,
        )
        if not root_children:
            return {
                "conclusion": "(no thoughts generated)",
                "confidence": 0.0, "trace": "", "alternatives": [], "strategy": "tot",
            }

        gen0_ids: list[str] = []
        for content in root_children:
            t = _Thought(id=f"tot_{uuid4().hex[:8]}", content=content, generation=0)
            nodes[t.id] = t
            gen0_ids.append(t.id)

        # BFS expansion for max_depth generations.
        best_leaf_id: str | None = None
        best_leaf_score: float = -1.0

        for gen in range(self.max_depth):
            # Find pending nodes in the current generation.
            pending = [
                nid for nid, n in nodes.items()
                if n.generation == gen and n.status == "pending"
            ]
            if not pending:
                break

            # Score all pending nodes.
            scored: list[tuple[str, float]] = []
            for nid in pending:
                s = await self._score_thought(task.goal, nodes[nid].content)
                nodes[nid].score = s
                if s >= self.prune_threshold:
                    nodes[nid].status = "explored"
                    scored.append((nid, s))
                else:
                    nodes[nid].status = "pruned"
                    log.debug("ToT: pruned %s (score=%.2f < %.2f)", nid, s, self.prune_threshold)

            if not scored:
                log.debug("ToT: all nodes pruned at generation %d", gen)
                break

            # Track best leaf across all generations.
            for nid, s in scored:
                if s > best_leaf_score or best_leaf_id is None:
                    best_leaf_score = s
                    best_leaf_id = nid

            # If this is the last generation, don't expand further.
            if gen >= self.max_depth - 1:
                break

            # Expand top-k explored nodes into the next generation.
            scored.sort(key=lambda x: x[1], reverse=True)
            expand_ids = [nid for nid, _ in scored[:self.top_k]]

            for parent_id in expand_ids:
                children = await self._generate_thoughts(
                    task.goal, nodes[parent_id].content, self.candidates,
                )
                for child_content in children:
                    child = _Thought(
                        id=f"tot_{uuid4().hex[:8]}",
                        content=child_content,
                        parent_id=parent_id,
                        generation=gen + 1,
                    )
                    nodes[child.id] = child
                    nodes[parent_id].children.append(child.id)

        # ── Backtrack from best leaf to root ────────────────────────────
        if best_leaf_id is None:
            # Fallback: pick the highest-scoring gen-0 node.
            gen0_scored = [(nid, nodes[nid].score) for nid in gen0_ids if nodes[nid].status == "explored"]
            if gen0_scored:
                gen0_scored.sort(key=lambda x: x[1], reverse=True)
                best_leaf_id = gen0_scored[0][0]
            else:
                best_leaf_id = gen0_ids[0]

        path: list[_Thought] = []
        current_id = best_leaf_id
        while current_id is not None:
            node = nodes.get(current_id)
            if node is None:
                break
            path.append(node)
            current_id = node.parent_id
        path.reverse()

        # ── Execute along the best path ────────────────────────────────
        chain = " -> ".join(f"[g{t.generation} s={t.score:.2f}] {t.content[:80]}" for t in path)
        try:
            exec_resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": (
                        "You are an executor.  Follow the reasoning chain "
                        "step by step to solve the goal.  Be concise and "
                        "concrete in your final answer."
                    )},
                    {"role": "user", "content": (
                        f"Goal: {task.goal}\n\n"
                        f"Reasoning chain:\n"
                        + "\n".join(f"{i+1}. {t.content}" for i, t in enumerate(path))
                        + "\n\nNow solve the goal following this chain:"
                    )},
                ],
                temperature=0.3,
                max_tokens=1024,
            )
            conclusion = exec_resp.text.strip()
        except Exception as e:
            conclusion = f"(execution failed: {e})"

        total_thoughts = len(nodes)
        explored = sum(1 for n in nodes.values() if n.status == "explored")
        pruned = sum(1 for n in nodes.values() if n.status == "pruned")

        return {
            "conclusion": conclusion,
            "confidence": best_leaf_score,
            "trace": (
                f"Tree-of-Thought: {total_thoughts} thoughts, "
                f"{explored} explored, {pruned} pruned, "
                f"depth={self.max_depth}, path_length={len(path)}\n"
                f"Best path: {chain}"
            ),
            "alternatives": [n.content for n in nodes.values() if n.status == "explored"][:5],
            "strategy": "tot",
        }
