"""Self-consistency reasoner — sample N answers, pick the majority/consensus."""
from __future__ import annotations

import collections
import logging
from typing import Any

from adonai.core.interfaces import LLMClient, Reasoner
from adonai.core.models import Task

log = logging.getLogger(__name__)


class SelfConsistency(Reasoner):
    """Sample N answers at high temperature; return the most common one."""

    name = "self_consistency"

    def __init__(self, llm: LLMClient, samples: int = 3) -> None:
        self.llm = llm
        self.samples = samples

    async def reason(
        self, task: Task, context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        answers: list[str] = []
        for i in range(self.samples):
            try:
                resp = await self.llm.complete(
                    messages=[
                        {"role": "system", "content": "You are a careful reasoner. Answer concisely."},
                        {"role": "user", "content": task.goal},
                    ],
                    temperature=0.7, max_tokens=512,
                )
                answers.append(resp.text.strip())
            except Exception as e:
                log.warning("SelfConsistency sample %d failed: %s", i, e)

        if not answers:
            return {
                "conclusion": "(no samples generated)", "confidence": 0.0,
                "trace": "", "alternatives": [], "strategy": "self_consistency",
            }

        # Find consensus — for short answers, exact match; for long, first 200 chars.
        normalized = [a[:200].lower().strip() for a in answers]
        counter = collections.Counter(normalized)
        most_common, count = counter.most_common(1)[0]
        # Pick the first answer matching the most-common prefix.
        conclusion = next((a for a, n in zip(answers, normalized) if n == most_common), answers[0])
        confidence = count / len(answers)
        return {
            "conclusion": conclusion,
            "confidence": confidence,
            "trace": f"Sampled {len(answers)} answers; consensus rate {confidence:.0%}",
            "alternatives": answers,
            "strategy": "self_consistency",
        }
