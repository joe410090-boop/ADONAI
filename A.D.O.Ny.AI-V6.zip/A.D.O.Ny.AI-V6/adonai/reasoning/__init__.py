"""Reasoning engine — composes 6 strategies: CoT, ToT, self-consistency, reflection, debate, verification."""
from adonai.reasoning.engine import ReasoningEngine
from adonai.reasoning.cot import ChainOfThought
from adonai.reasoning.tot import TreeOfThoughts
from adonai.reasoning.self_consistency import SelfConsistency
from adonai.reasoning.reflection import ReflectionReasoner
from adonai.reasoning.debate import DebateReasoner
from adonai.reasoning.verification import VerificationReasoner

__all__ = [
    "ReasoningEngine", "ChainOfThought", "TreeOfThoughts",
    "SelfConsistency", "ReflectionReasoner", "DebateReasoner", "VerificationReasoner",
]
