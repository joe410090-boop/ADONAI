"""Upgrade 4 — Reflection Engine.

Runs *after every task execution* and produces structured
:class:`~adonai.core.models.Lesson` objects that the planner, critic,
and skill-evolver can consult.

Reflection questions (configurable via ``config.reflection.questions``,
defaults to the four canonical questions)::

    What worked?
    What failed?
    What surprised us?
    What should change?

Lessons are persisted to SQLite (``lessons`` table) with:

* ``lesson`` — the takeaway, in plain language
* ``confidence`` — 0..1
* ``applicable_domains`` — list of tags (e.g. ``["coding", "research"]``)
* ``evidence`` — concrete observations supporting the lesson
* ``counter_evidence`` — observations that contradict it (keeps us honest)
* ``times_reinforced`` / ``times_contradicted`` — reinforcement tracking

The engine supports ``recall_lessons(domain=...)`` so the planner can
consult past lessons before generating a new plan, and ``reinforce()``
which strengthens or weakens an existing lesson based on new evidence.
"""
from __future__ import annotations

import json
import logging
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Literal

from adonai.core.exceptions import ReflectionError
from adonai.core.events import EventPublisher, EventTypes
from adonai.core.interfaces import LLMClient, ReflectionEngine
from adonai.core.json_utils import JSONExtractionError, extract_json
from adonai.core.models import Lesson, Plan, Task, TaskResult, TaskStatus

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Reflection prompt
# ──────────────────────────────────────────────────────────────────────────────


_REFLECTION_SYSTEM_PROMPT = (
    "You are the REFLECTION engine of an autonomous research platform.\n"
    "Given a completed task (goal, plan, outcome), extract LESSONS that\n"
    "will help future tasks succeed and avoid past mistakes.\n\n"
    "For each lesson, output JSON:\n"
    "{\n"
    '  "lesson": str,                       // the takeaway (one sentence)\n'
    '  "confidence": 0.0-1.0,               // how confident is this lesson?\n'
    '  "applicable_domains": [str],         // e.g. ["coding","research"]\n'
    '  "evidence": [str],                   // observations supporting it\n'
    '  "counter_evidence": [str]            // observations contradicting it\n'
    "}\n\n"
    "Output a JSON array of lesson objects.  Max 5 lessons.\n"
    "Only return lessons with confidence >= 0.4.\n"
    "Return ONLY the JSON array — no prose, no markdown fences."
)


# ──────────────────────────────────────────────────────────────────────────────
# SQLiteLessonStore — pure persistence layer
# ──────────────────────────────────────────────────────────────────────────────


class SQLiteLessonStore:
    """SQLite-backed persistence for :class:`Lesson` objects."""

    def __init__(self, db_path: str | Path, table: str = "lessons") -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.table = table
        self._ensure_schema()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_schema(self) -> None:
        with self._conn() as conn:
            conn.execute(f"""CREATE TABLE IF NOT EXISTS {self.table} (
                id TEXT PRIMARY KEY,
                lesson TEXT NOT NULL,
                confidence REAL NOT NULL,
                applicable_domains TEXT NOT NULL DEFAULT '[]',
                source_task_id TEXT,
                source_session_id TEXT,
                evidence TEXT NOT NULL DEFAULT '[]',
                counter_evidence TEXT NOT NULL DEFAULT '[]',
                times_reinforced INTEGER NOT NULL DEFAULT 0,
                times_contradicted INTEGER NOT NULL DEFAULT 0,
                created_at REAL NOT NULL,
                last_reinforced_at REAL,
                tags TEXT NOT NULL DEFAULT '[]'
            )""")
            conn.execute(
                f"CREATE INDEX IF NOT EXISTS idx_{self.table}_conf "
                f"ON {self.table}(confidence DESC)"
            )
            conn.commit()

    async def save(self, lesson: Lesson) -> str:
        now = lesson.created_at.timestamp() if lesson.created_at else time.time()
        with self._conn() as conn:
            conn.execute(
                f"""INSERT OR REPLACE INTO {self.table}
                    (id, lesson, confidence, applicable_domains, source_task_id,
                     source_session_id, evidence, counter_evidence,
                     times_reinforced, times_contradicted, created_at,
                     last_reinforced_at, tags)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (lesson.id, lesson.lesson, lesson.confidence,
                 json.dumps(lesson.applicable_domains),
                 lesson.source_task_id, lesson.source_session_id,
                 json.dumps(lesson.evidence),
                 json.dumps(lesson.counter_evidence),
                 lesson.times_reinforced, lesson.times_contradicted,
                 now,
                 lesson.last_reinforced_at.timestamp()
                    if lesson.last_reinforced_at else None,
                 json.dumps(lesson.tags)),
            )
            conn.commit()
        return lesson.id

    async def load(self, lesson_id: str) -> Lesson | None:
        with self._conn() as conn:
            row = conn.execute(
                f"SELECT * FROM {self.table} WHERE id = ?", (lesson_id,)
            ).fetchone()
        return _row_to_lesson(row) if row else None

    async def list_lessons(
        self,
        *,
        domain: str | None = None,
        top_k: int = 10,
        min_confidence: float = 0.0,
    ) -> list[Lesson]:
        sql = f"SELECT * FROM {self.table} WHERE confidence >= ?"
        params: list[Any] = [min_confidence]
        if domain:
            # JSON-array containment check (SQLite json_each).
            sql += f" AND EXISTS (SELECT 1 FROM json_each({self.table}.applicable_domains) WHERE value = ?)"
            params.append(domain)
        sql += f" ORDER BY confidence DESC, times_reinforced DESC LIMIT ?"
        params.append(top_k)
        with self._conn() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [_row_to_lesson(r) for r in rows]

    async def increment_field(
        self, lesson_id: str, field: Literal["reinforced", "contradicted"],
    ) -> Lesson | None:
        """Atomically increment times_reinforced or times_contradicted."""
        if field not in ("reinforced", "contradicted"):
            raise ReflectionError(f"invalid field: {field}")
        col = f"times_{field}"
        now = time.time()
        with self._conn() as conn:
            row = conn.execute(
                f"SELECT * FROM {self.table} WHERE id = ?", (lesson_id,)
            ).fetchone()
            if not row:
                return None
            conn.execute(
                f"UPDATE {self.table} SET {col} = {col} + 1, "
                f"last_reinforced_at = ? WHERE id = ?",
                (now, lesson_id),
            )
            conn.commit()
            row = conn.execute(
                f"SELECT * FROM {self.table} WHERE id = ?", (lesson_id,)
            ).fetchone()
        return _row_to_lesson(row) if row else None


# ──────────────────────────────────────────────────────────────────────────────
# DefaultReflectionEngine
# ──────────────────────────────────────────────────────────────────────────────


class DefaultReflectionEngine(ReflectionEngine, EventPublisher):
    """LLM-backed reflection engine with SQLite persistence.

    Falls back to a heuristic extractor when no LLM is configured — this
    keeps the engine usable in tests and CI environments.
    """

    def __init__(
        self,
        llm: LLMClient | None = None,
        store: SQLiteLessonStore | None = None,
        *,
        config: Any = None,
    ) -> None:
        self.llm = llm
        self.config = config
        if store is None:
            db_path = (
                getattr(getattr(config, "memory", None), "sqlite_path", None)
                or Path("data/adonai.db")
            )
            table = (
                getattr(getattr(config, "reflection", None), "sqlite_table", "lessons")
            )
            store = SQLiteLessonStore(db_path, table=table)
        self.store = store

    # ── ReflectionEngine interface ───────────────────────────────────────

    async def reflect(
        self,
        task: Task,
        plan: Plan | None,
        result: TaskResult,
        *,
        context: dict[str, Any] | None = None,
    ) -> list[Lesson]:
        """Reflect on a completed task; persist + return the lessons."""
        context = context or {}
        # 1. Try LLM extraction.
        if self.llm is not None:
            try:
                lessons = await self._llm_reflect(task, plan, result, context)
            except Exception as e:
                log.warning("LLM reflection failed (%s) — falling back to heuristic", e)
                lessons = self._heuristic_reflect(task, plan, result, context)
        else:
            lessons = self._heuristic_reflect(task, plan, result, context)

        # 2. Filter by min confidence.
        min_conf = (
            getattr(getattr(self.config, "reflection", None),
                    "min_lesson_confidence", 0.4)
            if self.config else 0.4
        )
        max_lessons = (
            getattr(getattr(self.config, "reflection", None),
                    "max_lessons_per_task", 5)
            if self.config else 5
        )
        lessons = [l for l in lessons if l.confidence >= min_conf][:max_lessons]

        # 3. Persist.
        for lesson in lessons:
            try:
                await self.store.save(lesson)
                # Emit lesson.learned event for subscribers.
                # NOTE: ``Lesson`` has ``applicable_domains`` (list), not
                # ``domain``.  We expose the first one as ``domain`` for
                # backward-compatible event subscribers and the full list
                # as ``domains`` for new subscribers.
                domains = list(lesson.applicable_domains or [])
                await self._emit(EventTypes.LESSON_LEARNED, {
                    "lesson_id": lesson.id,
                    "lesson": lesson.lesson[:200],
                    "confidence": lesson.confidence,
                    "domain": domains[0] if domains else None,
                    "domains": domains,
                    "task_id": task.id,
                })
            except Exception as e:
                log.warning("Lesson persist failed: %s", e)

        log.info("ReflectionEngine: extracted %d lesson(s) for task %s",
                 len(lessons), task.id)
        return lessons

    async def recall_lessons(
        self,
        *,
        domain: str | None = None,
        top_k: int = 10,
    ) -> list[Lesson]:
        return await self.store.list_lessons(domain=domain, top_k=top_k)

    async def reinforce(self, lesson_id: str, supports: bool) -> Lesson:
        """Reinforce (supports=True) or contradict (supports=False) a lesson.

        Adjusts the lesson's confidence using a Bayesian update with
        Beta(2, 2) prior.  Reinforcement pushes confidence up by ~0.1;
        contradiction pushes it down by ~0.15.  Repeated contradictions
        eventually flip the lesson.
        """
        lesson = await self.store.load(lesson_id)
        if lesson is None:
            raise ReflectionError(f"lesson not found: {lesson_id}")
        # Bayesian-ish update.
        prior = max(0.01, min(0.99, lesson.confidence))
        # Treat as Beta-Binomial: alpha = 1 + n * prior, beta = 1 + n * (1-prior).
        n = lesson.times_reinforced + lesson.times_contradicted
        alpha = 1.0 + n * prior
        beta = 1.0 + n * (1.0 - prior)
        if supports:
            alpha += 1.0
        else:
            beta += 1.0
        new_conf = alpha / (alpha + beta)
        # Apply asymmetry: contradictions weigh slightly more.
        if not supports:
            new_conf = max(0.01, new_conf - 0.05)
        lesson.confidence = round(max(0.01, min(0.99, new_conf)), 3)
        # Persist counter.
        field = "reinforced" if supports else "contradicted"
        updated = await self.store.increment_field(lesson_id, field)  # type: ignore[arg-type]
        if updated is not None:
            updated.confidence = lesson.confidence
            await self.store.save(updated)
            return updated
        return lesson

    # ── LLM reflection ───────────────────────────────────────────────────

    async def _llm_reflect(
        self,
        task: Task,
        plan: Plan | None,
        result: TaskResult,
        context: dict[str, Any],
    ) -> list[Lesson]:
        user_prompt = self._build_user_prompt(task, plan, result, context)
        resp = await self.llm.complete(
            messages=[
                {"role": "system", "content": _REFLECTION_SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.2,
            max_tokens=1024,
        )
        text = resp.text or ""
        try:
            data = extract_json(text)
        except JSONExtractionError as e:
            log.warning("Reflection LLM returned unparseable JSON: %s", e)
            return []
        if not isinstance(data, list):
            data = [data] if isinstance(data, dict) else []
        lessons: list[Lesson] = []
        for item in data:
            if not isinstance(item, dict):
                continue
            try:
                lesson_text = str(item.get("lesson", "")).strip()
                if not lesson_text:
                    continue
                lesson = Lesson(
                    lesson=lesson_text,
                    confidence=float(item.get("confidence", 0.5)),
                    applicable_domains=list(item.get("applicable_domains") or []),
                    source_task_id=task.id,
                    source_session_id=task.session_id,
                    evidence=list(item.get("evidence") or []),
                    counter_evidence=list(item.get("counter_evidence") or []),
                    tags=self._infer_tags(task, plan),
                )
                lessons.append(lesson)
            except Exception as e:
                log.debug("Lesson parse failed: %s", e)
        return lessons

    def _build_user_prompt(
        self,
        task: Task,
        plan: Plan | None,
        result: TaskResult,
        context: dict[str, Any],
    ) -> str:
        questions = (
            getattr(getattr(self.config, "reflection", None), "questions", None)
            or ["What worked?", "What failed?", "What surprised us?",
                "What should change?"]
        )
        questions_block = "\n".join(f"- {q}" for q in questions)
        steps_summary = ""
        if plan and plan.steps:
            steps_summary = "\n".join(
                f"  {i+1}. {s.description} [tool={s.tool}, status={s.status.value}]"
                for i, s in enumerate(plan.steps[:10])
            )
        output_str = str(result.output)[:1500] if result.output else "(empty)"
        return (
            f"TASK GOAL: {task.goal}\n"
            f"COMPLEXITY: {task.complexity.value}\n"
            f"OUTCOME: {result.status.value} (confidence={result.confidence:.2f})\n"
            f"STEPS EXECUTED: {result.steps_executed}\n"
            f"DURATION: {result.duration_s:.1f}s\n\n"
            f"PLAN:\n{steps_summary or '(no plan)'}\n\n"
            f"OUTPUT:\n{output_str}\n"
            + (f"\nERROR: {result.error[:500]}\n" if result.error else "")
            + f"\n\nAnswer these questions:\n{questions_block}\n\n"
            f"Extract lessons as a JSON array."
        )

    # ── Heuristic reflection ─────────────────────────────────────────────

    def _heuristic_reflect(
        self,
        task: Task,
        plan: Plan | None,
        result: TaskResult,
        context: dict[str, Any],
    ) -> list[Lesson]:
        """Cheap rule-based reflection when no LLM is available."""
        lessons: list[Lesson] = []
        tags = self._infer_tags(task, plan)
        # Lesson 1: outcome-based.
        if result.status == TaskStatus.COMPLETED:
            lessons.append(Lesson(
                lesson=(
                    f"Goal similar to '{task.goal[:80]}' was achievable "
                    f"in {result.steps_executed} steps using "
                    f"{task.assigned_agent or 'default'} agent."
                ),
                confidence=0.6,
                applicable_domains=tags,
                source_task_id=task.id,
                source_session_id=task.session_id,
                evidence=[f"task.completed: {task.id}"],
                tags=tags,
            ))
        elif result.status == TaskStatus.FAILED:
            lessons.append(Lesson(
                lesson=(
                    f"Goal similar to '{task.goal[:80]}' failed with: "
                    f"{(result.error or 'unknown error')[:120]}"
                ),
                confidence=0.7,
                applicable_domains=tags,
                source_task_id=task.id,
                source_session_id=task.session_id,
                evidence=[f"task.failed: {task.id}"],
                counter_evidence=[],
                tags=tags,
            ))
        # Lesson 2: efficiency.
        if plan and plan.steps and result.status == TaskStatus.COMPLETED:
            n_steps = len(plan.steps)
            if n_steps > 8:
                lessons.append(Lesson(
                    lesson=(
                        f"Plans with >8 steps ({n_steps} observed) tend to "
                        f"be inefficient — consider decomposition."
                    ),
                    confidence=0.55,
                    applicable_domains=tags,
                    source_task_id=task.id,
                    evidence=[f"step_count={n_steps}"],
                    tags=tags,
                ))
            unverified = sum(
                1 for s in plan.steps
                if s.verification_type.value == "unverified"
            )
            if unverified > n_steps / 2:
                lessons.append(Lesson(
                    lesson=(
                        f"{unverified}/{n_steps} steps lacked verification — "
                        f"insist on verification_type for future plans."
                    ),
                    confidence=0.65,
                    applicable_domains=tags,
                    source_task_id=task.id,
                    evidence=[f"unverified_steps={unverified}"],
                    tags=tags,
                ))
        return lessons

    # ── Helpers ──────────────────────────────────────────────────────────

    @staticmethod
    def _infer_tags(task: Task, plan: Plan | None) -> list[str]:
        goal_l = task.goal.lower()
        tags: list[str] = []
        if any(w in goal_l for w in ["code", "implement", "debug", "function"]):
            tags.append("coding")
        if any(w in goal_l for w in ["search", "find", "research", "investigate"]):
            tags.append("research")
        if any(w in goal_l for w in ["analyze", "summarize", "report"]):
            tags.append("analysis")
        if any(w in goal_l for w in ["design", "optimize", "simulate"]):
            tags.append("engineering")
        if any(w in goal_l for w in ["write", "draft", "compose"]):
            tags.append("writing")
        if not tags:
            tags.append("general")
        return tags


# ──────────────────────────────────────────────────────────────────────────────
# Row converter
# ──────────────────────────────────────────────────────────────────────────────


def _row_to_lesson(row: sqlite3.Row) -> Lesson:
    return Lesson(
        id=row["id"],
        lesson=row["lesson"],
        confidence=float(row["confidence"]),
        applicable_domains=json.loads(row["applicable_domains"] or "[]"),
        source_task_id=row["source_task_id"],
        source_session_id=row["source_session_id"],
        evidence=json.loads(row["evidence"] or "[]"),
        counter_evidence=json.loads(row["counter_evidence"] or "[]"),
        times_reinforced=int(row["times_reinforced"]),
        times_contradicted=int(row["times_contradicted"]),
        created_at=datetime.fromtimestamp(row["created_at"], tz=timezone.utc),
        last_reinforced_at=(
            datetime.fromtimestamp(row["last_reinforced_at"], tz=timezone.utc)
            if row["last_reinforced_at"] else None
        ),
        tags=json.loads(row["tags"] or "[]"),
    )


__all__ = ["DefaultReflectionEngine", "SQLiteLessonStore"]
