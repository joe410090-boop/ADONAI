"""Debate reasoner — multiple agents argue different positions, then synthesize.

v8: Added programmatic argument-quality scoring that measures evidence
density (numbers, citations, specific claims), argument length balance,
and rebuttal specificity.  The final confidence is derived from these
signals rather than a hardcoded 0.6.
"""
from __future__ import annotations

import logging
import re
from typing import Any

from adonai.core.interfaces import LLMClient, Reasoner
from adonai.core.models import Task

log = logging.getLogger(__name__)


class DebateReasoner(Reasoner):
    """Run a multi-turn debate between two positions, then synthesize."""

    name = "debate"

    def __init__(self, llm: LLMClient, rounds: int = 2) -> None:
        self.llm = llm
        self.rounds = rounds

    @staticmethod
    def _argument_quality(text: str) -> float:
        """Programmatic scoring of argument quality (0..1).

        Measures:
        - Evidence density: presence of numbers, percentages, citations
        - Specificity: sentence count and average sentence length
        - Structure: presence of list markers, transition words
        """
        if not text or text.startswith("("):
            return 0.2

        score = 0.3  # baseline for any non-empty argument

        # Evidence density: count numbers and data-like patterns.
        numbers = len(re.findall(r"\d+(?:\.\d+)?[%]?", text))
        score += min(0.2, numbers * 0.04)

        # Citation-like patterns (e.g., "according to", "studies show", "source:").
        citations = len(re.findall(
            r"(?:according to|studies? show|research|source|evidence|data shows?|\[\d+\])",
            text, re.IGNORECASE,
        ))
        score += min(0.15, citations * 0.05)

        # Length: longer arguments (within reason) tend to be more substantive.
        word_count = len(text.split())
        if 20 <= word_count <= 300:
            score += min(0.15, word_count / 600.0)

        # Structure: list markers and transitions indicate organized thinking.
        markers = len(re.findall(r"(?:first|second|third|finally|moreover|however|therefore|because|consequently)", text, re.IGNORECASE))
        score += min(0.1, markers * 0.025)

        # Specific claims: sentences with "is", "are", "was" (assertions).
        assertions = len(re.findall(r"\b(?:is|are|was|were|has|have)\b", text, re.IGNORECASE))
        score += min(0.1, assertions * 0.01)

        return min(1.0, score)

    async def reason(
        self, task: Task, context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        # 1. Generate two opposing positions.
        positions: list[str] = []
        for stance, label in [("for", "proponent"), ("against", "skeptic")]:
            try:
                resp = await self.llm.complete(
                    messages=[
                        {"role": "system", "content": (
                            f"You are the {label} in a debate.  Argue your position "
                            f"forcefully but fairly.  Be concise."
                        )},
                        {"role": "user", "content": f"Topic: {task.goal}"},
                    ],
                    temperature=0.6, max_tokens=400,
                )
                positions.append(resp.text.strip())
            except Exception as e:
                log.warning("Debate %s failed: %s", label, e)
                positions.append(f"({label} unavailable)")

        # 2. Run N rounds of rebuttal.
        for r in range(self.rounds):
            for i, label in enumerate(["proponent", "skeptic"]):
                opponent = positions[1 - i]
                try:
                    resp = await self.llm.complete(
                        messages=[
                            {"role": "system", "content": f"You are the {label}.  Rebut the opponent's argument."},
                            {"role": "user", "content": f"Opponent:\n{opponent}\n\nYour rebuttal:"},
                        ],
                        temperature=0.5, max_tokens=400,
                    )
                    positions[i] = resp.text.strip()
                except Exception as e:
                    log.warning("Debate round %d %s failed: %s", r, label, e)

        # 3. Programmatic scoring of both arguments.
        pro_score = self._argument_quality(positions[0])
        skept_score = self._argument_quality(positions[1])

        # Balance: penalize if one side is much longer (dominance != quality).
        pro_len = len(positions[0].split())
        skept_len = len(positions[1].split())
        if pro_len > 0 and skept_len > 0:
            ratio = min(pro_len, skept_len) / max(pro_len, skept_len)
            balance_bonus = (ratio - 0.3) * 0.1  # 0..0.07
        else:
            balance_bonus = 0.0

        # Confidence = weighted average of both sides + balance.
        confidence = 0.5 * (pro_score + skept_score) + balance_bonus
        confidence = max(0.3, min(0.9, confidence))

        # 4. Synthesize.
        try:
            synth = await self.llm.complete(
                messages=[
                    {"role": "system", "content": (
                        "You are a neutral judge.  Synthesize the debate into a "
                        "balanced conclusion.  Be concise."
                    )},
                    {"role": "user", "content": (
                        f"Topic: {task.goal}\n\n"
                        f"Proponent:\n{positions[0]}\n\n"
                        f"Skeptic:\n{positions[1]}\n\n"
                        f"Synthesized conclusion:"
                    )},
                ],
                temperature=0.3, max_tokens=512,
            )
            conclusion = synth.text.strip()
        except Exception as e:
            conclusion = f"(synthesis failed: {e})"

        return {
            "conclusion": conclusion,
            "confidence": round(confidence, 3),
            "trace": (
                f"Debate with {self.rounds} rounds. "
                f"Pro quality={pro_score:.2f}, Skeptic quality={skept_score:.2f}, "
                f"balance={balance_bonus:.2f}. "
                f"Pro: {positions[0][:200]}... Skeptic: {positions[1][:200]}..."
            ),
            "alternatives": positions,
            "strategy": "debate",
        }
