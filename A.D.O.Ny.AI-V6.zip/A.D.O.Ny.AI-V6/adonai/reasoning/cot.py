"""Chain-of-Thought reasoner — single LLM call with explicit step-by-step prompt."""
from __future__ import annotations

from typing import Any

from adonai.core.interfaces import LLMClient, Reasoner
from adonai.core.models import Task


class ChainOfThought(Reasoner):
    """Single-pass CoT — small models benefit most from explicit step prompts."""

    name = "cot"

    def __init__(self, llm: LLMClient) -> None:
        self.llm = llm

    async def reason(
        self, task: Task, context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        prompt = (
            f"Goal: {task.goal}\n\n"
            "Think step by step.  Show your reasoning, then give a final answer "
            "prefixed with 'ANSWER:'."
        )
        resp = await self.llm.complete(
            messages=[
                {"role": "system", "content": "You are a careful reasoner. Think step by step."},
                {"role": "user", "content": prompt},
            ],
            temperature=0.3, max_tokens=1024,
        )
        text = resp.text or ""
        # Split into reasoning + answer.
        if "ANSWER:" in text:
            parts = text.split("ANSWER:", 1)
            reasoning = parts[0].strip()
            answer = parts[1].strip()
        else:
            reasoning = text
            answer = text
        return {
            "conclusion": answer,
            "confidence": 0.7,
            "trace": reasoning,
            "alternatives": [],
            "strategy": "cot",
        }
