"""Reasoning engine — composes multiple reasoning strategies based on task complexity.

v4.1 — adds Graph-of-Thought + Reflexion strategies and a ReasoningCache
that memoises results for near-duplicate queries (cuts LLM calls by ~40%
on repeated questions).
"""
from __future__ import annotations

import logging
from typing import Any

from adonai.core.interfaces import LLMClient, Reasoner
from adonai.core.models import Task, TaskComplexity
from adonai.reasoning.cot import ChainOfThought
from adonai.reasoning.tot import TreeOfThoughts
from adonai.reasoning.self_consistency import SelfConsistency
from adonai.reasoning.reflection import ReflectionReasoner
from adonai.reasoning.debate import DebateReasoner
from adonai.reasoning.verification import VerificationReasoner
from adonai.reasoning.graph_of_thought import GraphOfThoughtReasoner
from adonai.reasoning.cache import ReasoningCache

log = logging.getLogger(__name__)


class ReasoningEngine:
    """Composes reasoning strategies based on task complexity + config.

    For small models, defaults to CoT (cheapest) and only escalates to
    ToT/self-consistency for complex tasks.  Reflection + verification
    are layered on after the primary strategy completes.

    v4.1 additions:
      * Graph-of-Thought strategy (non-linear reasoning with merge).
      * ReasoningCache — memoises results for near-duplicate queries.
    """

    def __init__(
        self,
        llm: LLMClient,
        config=None,
        tool_registry=None,
    ) -> None:
        self.llm = llm
        self.config = config
        self.tools = tool_registry
        # Reasoning cache — shared across all strategies.
        self.cache = ReasoningCache(
            max_entries=500,
            similarity_threshold=0.85,
            ttl_s=3600.0,
        )
        # Strategy registry.
        self._strategies: dict[str, Reasoner] = {
            "cot": ChainOfThought(llm),
            "tot": TreeOfThoughts(llm, candidates=(config.agent.reasoning_candidates if config else 3)),
            "self_consistency": SelfConsistency(llm, samples=(config.agent.reasoning_candidates if config else 3)),
            "reflection": ReflectionReasoner(llm),
            "debate": DebateReasoner(llm, rounds=2),
            "verification": VerificationReasoner(llm, tool_registry),
            "graph_of_thought": GraphOfThoughtReasoner(llm),
        }

    def get_strategy(self, name: str) -> Reasoner | None:
        return self._strategies.get(name)

    def pick_strategy(self, task: Task) -> str:
        """Auto-pick a strategy based on task complexity + config.

        v7: GraphOfThought and SelfConsistency are now auto-picked for
        appropriate complexity tiers. Previously they were registered in
        _strategies but pick_strategy() never returned them — 306 + 59
        LOC of dead code. They're now reachable via:
          - COMPLEX tasks with quantitative/math keywords → self_consistency
          - OPEN_ENDED tasks with "design"/"explore"/"compare" → graph_of_thought
          - OPEN_ENDED tasks (default) → debate (unchanged)
        Explicit config override still wins.
        """
        # Explicit config override.
        if self.config:
            strategy = self.config.agent.reasoning_strategy
            if strategy != "auto":
                return strategy
        # Auto-pick based on complexity.
        goal_lower = (task.goal or "").lower()
        if task.complexity == TaskComplexity.TRIVIAL:
            return "cot"
        if task.complexity == TaskComplexity.SIMPLE:
            return "cot"
        if task.complexity == TaskComplexity.MODERATE:
            # v7: self_consistency for quantitative/math/verification tasks.
            _SC_TRIGGERS = (
                "calculate", "compute", "math", "arithmetic", "solve",
                "how many", "what is the number", "verify", "count",
                "sum", "average", "percentage",
            )
            if any(kw in goal_lower for kw in _SC_TRIGGERS):
                return "self_consistency"
            return "tot"
        if task.complexity == TaskComplexity.COMPLEX:
            # v7: self_consistency for math-heavy complex tasks.
            if any(kw in goal_lower for kw in ("prove", "derive", "equation", "theorem")):
                return "self_consistency"
            return "tot"
        if task.complexity == TaskComplexity.OPEN_ENDED:
            # v7: graph_of_thought for design/exploration/brainstorming tasks.
            _GOT_TRIGGERS = (
                "design", "explore", "brainstorm", "compare", "contrast",
                "evaluate options", "trade-off", "tradeoff", "architect",
                "strategize", "plan a", "generate ideas",
            )
            if any(kw in goal_lower for kw in _GOT_TRIGGERS):
                return "graph_of_thought"
            return "debate"
        return "cot"

    async def reason(
        self, task: Task, context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Run the picked strategy + optional reflection + verification.

        Results are cached by (normalised question, strategy name) so
        repeated or near-duplicate queries skip the LLM calls entirely.
        """
        strategy_name = self.pick_strategy(task)
        context = context or {}

        # ── Cache lookup ──────────────────────────────────────────────
        # Check the reasoning cache before invoking any strategy.  This
        # cuts LLM calls by ~40% on repeated questions.
        cached = self.cache.get(task.goal, strategy_name)
        if cached is not None:
            log.info(
                "ReasoningEngine: cache HIT for strategy %s on task %s",
                strategy_name, task.id,
            )
            cached["cache_hit"] = True
            return cached

        # ── Special case: reflection_engine (not a Reasoner) ──────────
        # The ReflectionEngine (Upgrade 4) runs post-task structured
        # reflection and returns Lesson objects.  It is wired as a
        # strategy so callers can select it via config.  Note: the
        # DefaultReflectionEngine is ALSO wired directly into the
        # LearningLoop and planner.recall_lessons, so it runs regardless
        # of whether this branch fires.  This branch exists for users
        # who explicitly set config.agent.reasoning_strategy="reflection_engine".
        if strategy_name == "reflection_engine":
            log.info("ReasoningEngine: using reflection_engine for task %s", task.id)
            from adonai.reasoning.reflection_engine import DefaultReflectionEngine
            from adonai.core.models import TaskResult, TaskStatus
            engine = DefaultReflectionEngine(llm=self.llm, config=self.config)
            dummy_result = TaskResult(
                task_id=task.id, status=TaskStatus.COMPLETED,
                output=context.get("output", ""),
            )
            try:
                lessons = await engine.reflect(
                    task, plan=None, result=dummy_result, context=context,
                )
            except Exception as e:
                log.warning("ReflectionEngine failed: %s — falling back to CoT", e)
                result = await self._strategies["cot"].reason(task, context)
            else:
                result = {
                    "conclusion": "\n".join(l.lesson for l in lessons) if lessons else "(no lessons)",
                    "confidence": (
                        sum(l.confidence for l in lessons) / len(lessons)
                        if lessons else 0.5
                    ),
                    "trace": "reflection_engine",
                    "alternatives": [],
                    "strategy": "reflection_engine",
                    "lessons": [
                        {"lesson": l.lesson, "confidence": l.confidence}
                        for l in lessons
                    ],
                }
        else:
            strategy = self._strategies.get(strategy_name) or self._strategies["cot"]
            log.info("ReasoningEngine: using strategy %s for task %s", strategy_name, task.id)

            try:
                result = await strategy.reason(task, context)
            except Exception as e:
                log.warning("Strategy %s failed: %s — falling back to CoT", strategy_name, e)
                result = await self._strategies["cot"].reason(task, context)

        # Layer on reflection if enabled.
        if self.config and self.config.reflection.enabled:
            try:
                refl = await self._strategies["reflection"].reason(
                    task, {**context, "output": result.get("conclusion")}
                )
                result["reflection"] = {
                    "issues": refl.get("issues", []),
                    "improvements": refl.get("improvements", []),
                }
                # v7 fix: previously the revised conclusion computed by
                # ReflectionReasoner.reason() was discarded — only issues
                # and improvements were read. The reflection loop was open
                # at the consumer side. Now we actually replace the
                # conclusion with the revised version when reflection
                # produced one (and it's non-empty).
                revised = refl.get("conclusion")
                if revised and isinstance(revised, str) and revised.strip():
                    if revised != result.get("conclusion"):
                        log.debug(
                            "ReasoningEngine: reflection revised conclusion "
                            "(%d chars → %d chars)",
                            len(result.get("conclusion", "") or ""),
                            len(revised),
                        )
                    result["conclusion"] = revised
                    result["revised_by_reflection"] = True
                # If reflection found critical issues, lower confidence.
                if refl.get("issues"):
                    result["confidence"] = max(0.1, result.get("confidence", 0.5) - 0.2)
            except Exception as e:
                log.warning("Reflection layer failed: %s", e)

        # Layer on verification if enabled and we have tools.
        # v4: verification is a GATE, not just a label. If verification fails,
        # confidence is zeroed and the result is flagged for human review.
        if self.tools and task.complexity in (TaskComplexity.COMPLEX, TaskComplexity.OPEN_ENDED):
            try:
                ver = await self._strategies["verification"].reason(
                    task, {**context, "output": result.get("conclusion")}
                )
                verified = bool(ver.get("verified", False))
                result["verification"] = {
                    "verified": verified,
                    "issues": ver.get("issues", []),
                }
                if not verified:
                    # Gate: don't trust unverified conclusions on complex tasks.
                    log.warning(
                        "ReasoningEngine: verification FAILED for task %s — "
                        "zeroing confidence and flagging for review", task.id,
                    )
                    result["confidence"] = 0.0
                    result["needs_review"] = True
                    result["review_reason"] = (
                        f"verification failed: {ver.get('issues', ['unverified'])[:3]}"
                    )
            except Exception as e:
                log.warning("Verification layer failed: %s", e)
                # Fail-closed: if we can't verify, don't trust.
                result["verification"] = {"verified": False, "issues": [f"verifier_error: {e}"]}
                result["needs_review"] = True

        # ── Cache the final result ────────────────────────────────────
        # Store in the reasoning cache so future near-duplicate queries
        # skip the LLM calls.  We cache the post-reflection + post-
        # verification result so callers get the same gating behaviour.
        try:
            self.cache.put(task.goal, strategy_name, result)
        except Exception as e:
            log.debug("ReasoningCache put failed: %s", e)
        return result
