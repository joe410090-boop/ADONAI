"""Verification reasoner — checks factual claims against external sources."""
from __future__ import annotations

import logging
from typing import Any

from adonai.core.interfaces import LLMClient, Reasoner
from adonai.core.models import Task

log = logging.getLogger(__name__)


class VerificationReasoner(Reasoner):
    """Verify the agent's output by cross-checking claims with web_search."""

    name = "verification"

    def __init__(self, llm: LLMClient, tool_registry=None) -> None:
        self.llm = llm
        self.tools = tool_registry

    async def reason(
        self, task: Task, context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        context = context or {}
        output = context.get("output") or ""
        if not output or not self.tools:
            return {
                "conclusion": output, "confidence": 0.5,
                "trace": "no output to verify or no tools available",
                "alternatives": [], "strategy": "verification",
                "verified": False, "issues": [],
            }
        # 1. Extract claims from the output.
        try:
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": (
                        "Extract the key factual claims from the text. "
                        'Output JSON: {"claims": ["claim 1", "claim 2"]}'
                    )},
                    {"role": "user", "content": output[:2000]},
                ],
                temperature=0.2, max_tokens=256,
            )
            from adonai.core.json_utils import extract_json
            data = extract_json(resp.text or "")
            claims = data.get("claims", [])[:3]  # verify up to 3 claims
        except Exception as e:
            log.warning("Verification claim extraction failed: %s", e)
            claims = []

        # 2. Verify each claim via web_search.
        # v9 SECURITY FIX: Previously called `await self.tools.get_tool(...)`
        # then `await tool.execute(...)` directly, SKIPPING the permission
        # gate that lives in ToolRegistry.execute(). This bypassed the
        # human-approval callback for high-risk tools and the per-tool
        # stats recording. While only `web_search` (low-risk) was invoked,
        # the pattern worked for ANY tool — a future change swapping in
        # `terminal` or `python_exec` would have executed shell/code with
        # no permission check. Now we route through `self.tools.execute()`
        # which is the single secured entry point.
        issues: list[str] = []
        verified_count = 0
        for claim in claims:
            try:
                # v9: use the secured registry.execute() path.
                result = await self.tools.execute("web_search", query=claim, max_results=3)
                if result.success and result.output:
                    snippets = " ".join(
                        r.get("snippet", "") for r in result.output.get("results", [])
                    )
                    # Ask the LLM if the snippets support the claim.
                    check = await self.llm.complete(
                        messages=[
                            {"role": "system", "content": (
                                "Does the evidence support the claim? "
                                'Respond JSON: {"supports": true/false, "reason": "..."}'
                            )},
                            {"role": "user", "content": (
                                f"Claim: {claim}\n\nEvidence:\n{snippets[:1000]}"
                            )},
                        ],
                        temperature=0.2, max_tokens=128,
                    )
                    from adonai.core.json_utils import extract_json
                    verdict = extract_json(check.text or "")
                    if verdict.get("supports"):
                        verified_count += 1
                    else:
                        issues.append(f"Claim not supported: {claim[:100]} — {verdict.get('reason','')}")
            except Exception as e:
                log.warning("Verification of claim '%s' failed: %s", claim[:50], e)

        # v9 fix: use a threshold (>=70% of claims verified) instead of
        # requiring ALL claims to be verified. The previous all-or-nothing
        # rule was too brittle — a single unverified claim out of 3 would
        # zero the verdict, and with LLM-judge noise this happened often.
        confidence = verified_count / max(1, len(claims)) if claims else 0.5
        verification_rate = verified_count / max(1, len(claims)) if claims else 0.0
        verified = verification_rate >= 0.7 if claims else False
        return {
            "conclusion": output,
            "confidence": confidence,
            "trace": f"Verified {verified_count}/{len(claims)} claims",
            "alternatives": [],
            "strategy": "verification",
            "verified": verified,
            "verification_rate": round(verification_rate, 3),
            "issues": issues,
        }
