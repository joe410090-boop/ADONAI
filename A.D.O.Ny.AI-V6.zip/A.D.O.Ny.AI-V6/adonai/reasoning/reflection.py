"""Reflection reasoner — critique the agent's own output and revise it.

v6 fix: ReflectionReasoner now makes a SECOND LLM call to revise the
conclusion based on the identified issues. Previously it generated a
critique (issues + improvements) but returned the original output
verbatim as the conclusion — the critique was computed and discarded.
The engine only lowered confidence by 0.2. Now the conclusion is
actually revised, closing the reflection loop.

v8: Added a reflection buffer that accumulates past critiques across
invocations, enabling the reasoner to recognize RECURRING issues and
avoid repeating past mistakes.  The buffer is bounded (max 50 entries)
and evicts oldest entries when full.
"""
from __future__ import annotations

import logging
from collections import deque
from typing import Any

from adonai.core.interfaces import LLMClient, Reasoner
from adonai.core.json_utils import extract_json, JSONExtractionError
from adonai.core.models import Task
from adonai.llm.prompt import SystemPrompts

log = logging.getLogger(__name__)


class ReflectionReasoner(Reasoner):
    """Critique a prior output, suggest improvements, and revise the output.

    Maintains a bounded history of past reflections so that RECURRING
    issues are surfaced in future critiques.  Each invocation adds to the
    buffer; the buffer is consulted before critique to warn about known
    failure patterns.
    """

    name = "reflection"

    def __init__(self, llm: LLMClient, *, buffer_size: int = 50) -> None:
        self.llm = llm
        self._buffer: deque[dict[str, Any]] = deque(maxlen=buffer_size)

    async def reason(
        self, task: Task, context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        context = context or {}
        output_to_critique = context.get("output") or context.get("prior_output") or ""
        if not output_to_critique:
            return {
                "conclusion": "(nothing to critique)",
                "confidence": 1.0, "trace": "", "alternatives": [],
                "strategy": "reflection",
                "issues": [], "improvements": [],
            }
        try:
            # Build execution context to give the LLM more signal.
            context_info = ""
            if hasattr(task, 'steps_executed') and task.steps_executed:
                context_info += f"\n\nSteps executed: {task.steps_executed}"
            if hasattr(task, 'error') and task.error:
                context_info += f"\n\nLast error: {task.error}"

            # ── v8: Inject past reflection history to detect recurring issues ──
            history_block = ""
            if self._buffer:
                # Summarize the most common past issues (up to 5).
                issue_counts: dict[str, int] = {}
                for entry in self._buffer:
                    entry_issues = entry.get("issues", []) if isinstance(entry, dict) else []
                    if not isinstance(entry_issues, list):
                        continue
                    for iss in entry_issues:
                        # v9 fix: 'unhashable type: slice' was raised here when
                        # the LLM returned issues as a list of dicts (e.g.
                        # [{"issue": "..."}, ...]) instead of a list of strings.
                        # iss was a dict, iss[:60] called dict.__getitem__(slice)
                        # which tries to hash the slice -> TypeError.
                        # Now we coerce iss to a string before slicing.
                        if isinstance(iss, dict):
                            # Common LLM shapes: {"issue": "..."}, {"text": "..."},
                            # {"description": "..."}, {"message": "..."}.
                            key_text = (
                                iss.get("issue")
                                or iss.get("text")
                                or iss.get("description")
                                or iss.get("message")
                                or iss.get("problem")
                                or str(iss)
                            )
                        elif isinstance(iss, (list, tuple)):
                            key_text = " ".join(str(x) for x in iss)
                        else:
                            key_text = str(iss)
                        # Normalize to first 60 chars for grouping.
                        key = key_text[:60] if isinstance(key_text, str) else str(key_text)[:60]
                        issue_counts[key] = issue_counts.get(key, 0) + 1
                recurring = sorted(issue_counts.items(), key=lambda x: x[1], reverse=True)[:5]
                if recurring:
                    history_block = (
                        "\n\nRECURRING ISSUES from past reflections (frequency in parentheses):\n"
                        + "\n".join(f"- {issue} ({count}x)" for issue, count in recurring)
                        + "\nPay special attention to avoiding these."
                    )

            # ── Call 1: Extract issues + improvements ───────────────────
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": SystemPrompts.REFLECTION},
                    {"role": "user", "content": (
                        f"Original goal: {task.goal}\n\n"
                        f"Output to critique:\n{str(output_to_critique)[:2000]}"
                        f"{context_info}"
                        f"{history_block}\n\n"
                        f"Output JSON with issues + improvements + confidence."
                    )},
                ],
                temperature=0.3, max_tokens=512,
            )
            data = extract_json(resp.text or "")
            # v9 fix: extract_json may return a list, dict, or scalar.
            # Normalize to a dict so .get() always works.
            if isinstance(data, list):
                # If the LLM returned a list, take the first dict element
                # or treat the whole list as having no issues.
                data = data[0] if (data and isinstance(data[0], dict)) else {}
            if not isinstance(data, dict):
                data = {}
            raw_issues = data.get("issues", [])
            raw_improvements = data.get("improvements", [])
            # v9 fix: issues/improvements may be a list of dicts (LLM shape:
            # [{"issue": "..."}, ...]). Coerce each to a string so downstream
            # slicing and dict-key usage doesn't raise 'unhashable type: slice'.
            def _coerce_str_list(items: Any) -> list[str]:
                if not isinstance(items, list):
                    if isinstance(items, str):
                        return [items]
                    return []
                out: list[str] = []
                for it in items:
                    if isinstance(it, dict):
                        s = (
                            it.get("issue") or it.get("text") or it.get("description")
                            or it.get("improvement") or it.get("message") or str(it)
                        )
                        out.append(str(s))
                    elif isinstance(it, (list, tuple)):
                        out.append(" ".join(str(x) for x in it))
                    else:
                        out.append(str(it))
                return out
            issues = _coerce_str_list(raw_issues)
            improvements = _coerce_str_list(raw_improvements)
            confidence = float(data.get("confidence", 0.5))

            # v8: Append to reflection buffer for future recurring-issue detection.
            self._buffer.append({
                "goal_prefix": task.goal[:80],
                "issues": issues[:10],
                "improvements": improvements[:10],
                "confidence": confidence,
            })

            # ── Call 2 (v6): Revise the conclusion to address issues ────
            # Previously the original output was returned verbatim and the
            # critique was discarded. Now we revise.
            revised_conclusion = output_to_critique
            if issues or improvements:
                try:
                    revision_prompt = (
                        f"Original goal: {task.goal}\n\n"
                        f"Original output:\n{str(output_to_critique)[:2000]}\n\n"
                        f"Identified issues:\n"
                        + "\n".join(f"- {i}" for i in issues[:10])
                        + f"\n\nSuggested improvements:\n"
                        + "\n".join(f"- {imp}" for imp in improvements[:10])
                        + "\n\nRewrite the output to address the issues and "
                        f"incorporate the improvements. Keep it concise. "
                        f"Output ONLY the revised text, no meta-commentary."
                    )
                    rev_resp = await self.llm.complete(
                        messages=[
                            {"role": "system", "content": (
                                "You are a revision agent. Rewrite the output "
                                "to address the identified issues. Be concise "
                                "and concrete. Output only the revised text."
                            )},
                            {"role": "user", "content": revision_prompt},
                        ],
                        temperature=0.2, max_tokens=1024,
                    )
                    revised = (rev_resp.text or "").strip()
                    if revised and not revised.lower().startswith("i cannot"):
                        revised_conclusion = revised
                        log.debug(
                            "ReflectionReasoner: revised conclusion "
                            "(%d issues, %d improvements applied)",
                            len(issues), len(improvements),
                        )
                except Exception as e:
                    log.debug("Reflection revision step failed (non-fatal): %s", e)

            return {
                "conclusion": revised_conclusion,  # v6: now the REVISED output
                "confidence": confidence,
                "trace": resp.text,
                "alternatives": [],
                "strategy": "reflection",
                "issues": issues,
                "improvements": improvements,
                "original_output": output_to_critique,  # preserved for reference
            }
        except (JSONExtractionError, Exception) as e:
            log.warning("Reflection failed: %s", e)
            return {
                "conclusion": output_to_critique, "confidence": 0.3,
                "trace": "", "alternatives": [], "strategy": "reflection",
                "issues": [f"reflection_failed: {e}"], "improvements": [],
            }
