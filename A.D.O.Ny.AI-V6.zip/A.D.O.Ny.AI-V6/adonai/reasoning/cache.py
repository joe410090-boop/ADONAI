"""Reasoning cache — memoise reasoning results for similar queries.

Reasoning is expensive (multiple LLM calls per strategy).  When the same
question (or a near-duplicate) is asked again, the cache returns the
previous result instead of re-deriving it.

The cache key is a SHA-256 of the normalised question + strategy name +
reasoning parameters.  "Normalised" means lowercased, whitespace-collapsed,
and stripped of trailing punctuation — so "What is 2+2?" and "what is 2+2"
hit the same cache entry.

Near-duplicate detection is done via Jaccard similarity over word sets.
If a new query has Jaccard similarity >= 0.85 with any cached query, the
cached result is returned.  This catches paraphrases like "latest AI
news" vs "recent AI news" without requiring an embedding model.

The cache is bounded (default 500 entries, LRU eviction) and can be
flushed manually via :meth:`clear`.
"""
from __future__ import annotations

import hashlib
import json
import logging
import time
from collections import OrderedDict
from typing import Any

log = logging.getLogger(__name__)


def _normalise(text: str) -> str:
    """Normalise a query for cache keying."""
    return " ".join(text.lower().split()).rstrip(".?!")


def _word_set(text: str) -> set[str]:
    return set(_normalise(text).split())


def _jaccard(a: set[str], b: set[str]) -> float:
    if not a or not b:
        return 0.0
    return len(a & b) / len(a | b)


class ReasoningCache:
    """LRU cache for reasoning results with near-duplicate detection.

    Args:
        max_entries: Maximum number of cache entries (LRU eviction).
        similarity_threshold: Jaccard threshold for near-duplicate
            detection (0..1).  Default 0.85.
        ttl_s: Time-to-live for cache entries in seconds.  Default 3600
            (1 hour).  Entries older than this are considered stale.
    """

    def __init__(
        self,
        max_entries: int = 500,
        similarity_threshold: float = 0.85,
        ttl_s: float = 3600.0,
    ) -> None:
        self._cache: OrderedDict[str, dict[str, Any]] = OrderedDict()
        self._max = max_entries
        self._sim_threshold = similarity_threshold
        self._ttl = ttl_s
        self._hits = 0
        self._misses = 0

    def _key(self, question: str, strategy: str, **params: Any) -> str:
        """Build a deterministic cache key."""
        norm = _normalise(question)
        param_str = json.dumps(params, sort_keys=True, default=str)
        blob = f"{norm}|{strategy}|{param_str}"
        return hashlib.sha256(blob.encode()).hexdigest()

    def get(
        self,
        question: str,
        strategy: str,
        **params: Any,
    ) -> dict[str, Any] | None:
        """Return a cached reasoning result, or None if not cached.

        Tries exact-key match first, then falls back to near-duplicate
        detection via Jaccard similarity over word sets.
        """
        key = self._key(question, strategy, **params)
        # Exact match.
        entry = self._cache.get(key)
        if entry is not None:
            if time.time() - entry["ts"] <= self._ttl:
                self._cache.move_to_end(key)
                self._hits += 1
                return entry["result"]
            else:
                # Stale — evict.
                del self._cache[key]

        # Near-duplicate match.
        if self._sim_threshold < 1.0:
            query_words = _word_set(question)
            if query_words:
                for cached_key, entry in self._cache.items():
                    if time.time() - entry["ts"] > self._ttl:
                        continue
                    if entry["strategy"] != strategy:
                        continue
                    cached_words = _word_set(entry["question"])
                    if _jaccard(query_words, cached_words) >= self._sim_threshold:
                        self._cache.move_to_end(cached_key)
                        self._hits += 1
                        return entry["result"]

        self._misses += 1
        return None

    def put(
        self,
        question: str,
        strategy: str,
        result: dict[str, Any],
        **params: Any,
    ) -> None:
        """Store a reasoning result in the cache."""
        key = self._key(question, strategy, **params)
        self._cache[key] = {
            "question": question,
            "strategy": strategy,
            "result": result,
            "ts": time.time(),
            "params": params,
        }
        self._cache.move_to_end(key)
        while len(self._cache) > self._max:
            self._cache.popitem(last=False)

    def clear(self) -> None:
        """Flush all cached results."""
        self._cache.clear()
        self._hits = 0
        self._misses = 0

    def stats(self) -> dict[str, Any]:
        """Return cache statistics."""
        total = self._hits + self._misses
        return {
            "hits": self._hits,
            "misses": self._misses,
            "size": len(self._cache),
            "max_size": self._max,
            "hit_rate": (self._hits / total) if total > 0 else 0.0,
            "similarity_threshold": self._sim_threshold,
            "ttl_s": self._ttl,
        }

    def get_or_compute(
        self,
        question: str,
        strategy: str,
        compute_fn: Any,
        **params: Any,
    ) -> dict[str, Any]:
        """Synchronous cache-or-compute helper.

        ``compute_fn`` is called only on cache miss.  Since reasoning is
        async, this is a convenience wrapper for sync callers — async
        callers should use :meth:`get_or_compute_async`.
        """
        cached = self.get(question, strategy, **params)
        if cached is not None:
            return cached
        result = compute_fn(question, strategy, **params)
        self.put(question, strategy, result, **params)
        return result

    async def get_or_compute_async(
        self,
        question: str,
        strategy: str,
        compute_fn: Any,
        **params: Any,
    ) -> dict[str, Any]:
        """Async cache-or-compute helper.

        ``compute_fn`` must be an async callable.  Called only on cache
        miss.  The result is cached before returning.
        """
        cached = self.get(question, strategy, **params)
        if cached is not None:
            return cached
        result = await compute_fn(question, strategy, **params)
        self.put(question, strategy, result, **params)
        return result
