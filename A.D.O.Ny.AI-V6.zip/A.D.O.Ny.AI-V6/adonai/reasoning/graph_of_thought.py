"""Graph of Thought (GoT) — non-linear reasoning over a thought graph.

Unlike Chain-of-Thought (linear) and Tree-of-Thought (hierarchical),
Graph-of-Thought allows arbitrary connections between thoughts: a thought
can reference multiple parents, branches can merge, and the reasoner can
revisit + revise earlier thoughts based on later insights.

This implementation builds an in-memory directed graph of Thought nodes,
scores them with an LLM judge, and returns the highest-scoring path from
root to leaf.  Thoughts that score below the prune threshold are pruned
(unlike ToT, their children are NOT pruned — a child can still be
explored via a different parent).

The graph is also persisted to the ReasoningCache so future queries that
overlap with this one can reuse partial results instead of re-deriving
them from scratch.
"""
from __future__ import annotations

import hashlib
import json
import logging
import time
from dataclasses import dataclass, field
from typing import Any

from adonai.core.interfaces import LLMClient, Reasoner
from adonai.core.models import Task

log = logging.getLogger(__name__)


@dataclass
class Thought:
    """A single node in the reasoning graph."""
    id: str
    content: str
    parents: list[str] = field(default_factory=list)
    children: list[str] = field(default_factory=list)
    score: float = 0.0
    status: str = "pending"  # pending | explored | pruned | merged
    generation: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id, "content": self.content,
            "parents": list(self.parents), "children": list(self.children),
            "score": self.score, "status": self.status,
            "generation": self.generation, "metadata": self.metadata,
        }


class ThoughtGraph:
    """Directed graph of Thought nodes."""

    def __init__(self) -> None:
        self._nodes: dict[str, Thought] = {}
        self._root_id: str | None = None

    def add(self, thought: Thought) -> None:
        self._nodes[thought.id] = thought
        if not thought.parents and self._root_id is None:
            self._root_id = thought.id
        # Wire parent ↔ child edges.
        for pid in thought.parents:
            parent = self._nodes.get(pid)
            if parent is not None and thought.id not in parent.children:
                parent.children.append(thought.id)

    def get(self, tid: str) -> Thought | None:
        return self._nodes.get(tid)

    @property
    def root(self) -> Thought | None:
        return self._nodes.get(self._root_id) if self._root_id else None

    def all(self) -> list[Thought]:
        return list(self._nodes.values())

    def leaves(self) -> list[Thought]:
        return [t for t in self._nodes.values() if not t.children]

    def best_path(self) -> list[Thought]:
        """Return the highest-scoring root→leaf path."""
        if self.root is None:
            return []
        leaves = self.leaves()
        if not leaves:
            return [self.root]
        best_leaf = max(leaves, key=lambda t: t.score)
        # Walk backwards from best_leaf to root via parents.
        path: list[Thought] = [best_leaf]
        current = best_leaf
        while current.parents:
            best_parent = max(
                (self._nodes[pid] for pid in current.parents if pid in self._nodes),
                key=lambda t: t.score,
                default=None,
            )
            if best_parent is None or best_parent.id == current.id:
                break
            path.insert(0, best_parent)
            current = best_parent
        return path

    def to_dict(self) -> dict[str, Any]:
        return {
            "nodes": {tid: t.to_dict() for tid, t in self._nodes.items()},
            "root": self._root_id,
        }


class GraphOfThoughtReasoner(Reasoner):
    """Graph-of-Thought reasoner.

    Pipeline:
      1. Generate N initial thoughts (parallel, varying temperature).
      2. Score each thought with an LLM judge.
      3. For the top K thoughts, generate children that build on them
         (a child can have multiple parents — merge branches).
      4. Score the children.
      5. Repeat for ``max_depth`` generations.
      6. Return the best root→leaf path as the conclusion.

    The graph supports *merging*: when two thoughts from different branches
    converge on a similar idea, a child thought can reference both as
    parents, combining their evidence.
    """

    name = "graph_of_thought"

    def __init__(
        self,
        llm: LLMClient,
        *,
        branching_factor: int = 3,
        max_depth: int = 2,
        prune_threshold: float = 0.3,
        merge_threshold: float = 0.85,
    ) -> None:
        self.llm = llm
        self.branching_factor = branching_factor
        self.max_depth = max_depth
        self.prune_threshold = prune_threshold
        self.merge_threshold = merge_threshold

    async def reason(
        self,
        task: Task,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        import asyncio
        import uuid
        start = time.time()
        graph = ThoughtGraph()

        # 1. Generate initial thoughts (depth 0).
        initial = await self._generate_thoughts(task.goal, n=self.branching_factor)
        for content in initial:
            tid = f"t_{uuid.uuid4().hex[:8]}"
            graph.add(Thought(id=tid, content=content, generation=0))

        # 2. Score + expand for max_depth generations.
        for gen in range(self.max_depth):
            # Score all pending thoughts at this generation in parallel.
            pending = [t for t in graph.all() if t.status == "pending" and t.generation == gen]
            if not pending:
                break
            scores = await asyncio.gather(
                *(self._score_thought(task.goal, t.content) for t in pending),
                return_exceptions=True,
            )
            for t, score in zip(pending, scores):
                t.score = float(score) if not isinstance(score, Exception) else 0.0
                t.status = "explored" if t.score >= self.prune_threshold else "pruned"

            # Generate children for the top-K explored thoughts.
            explored = [t for t in pending if t.status == "explored"]
            explored.sort(key=lambda t: t.score, reverse=True)
            top_k = explored[:self.branching_factor]
            if not top_k:
                break

            # Generate children in parallel.
            child_tasks = []
            for parent in top_k:
                child_tasks.append(self._generate_thoughts(
                    f"{task.goal}\n\nBuilding on: {parent.content}",
                    n=2,
                ))
            child_results = await asyncio.gather(*child_tasks, return_exceptions=True)

            # Add children to the graph, checking for merge opportunities.
            for parent, children in zip(top_k, child_results):
                if isinstance(children, Exception):
                    continue
                for child_content in children:
                    # Check if any existing thought at gen+1 is similar
                    # enough to merge with.
                    merged = False
                    for existing in graph.all():
                        if existing.generation != gen + 1:
                            continue
                        sim = _similarity(child_content, existing.content)
                        if sim >= self.merge_threshold:
                            # Merge: add parent as a second parent of existing.
                            if parent.id not in existing.parents:
                                existing.parents.append(parent.id)
                                if parent.id not in parent.children:
                                    parent.children.append(existing.id)
                            existing.metadata.setdefault("merged_from", []).append(parent.id)
                            merged = True
                            break
                    if not merged:
                        cid = f"t_{uuid.uuid4().hex[:8]}"
                        graph.add(Thought(
                            id=cid, content=child_content,
                            parents=[parent.id], generation=gen + 1,
                        ))

        # 3. Score any remaining pending thoughts.
        for t in graph.all():
            if t.status == "pending":
                t.score = await self._score_thought(task.goal, t.content)
                t.status = "explored" if t.score >= self.prune_threshold else "pruned"

        # 4. Find the best path.
        best_path = graph.best_path()
        conclusion = best_path[-1].content if best_path else ""
        confidence = best_path[-1].score if best_path else 0.0

        return {
            "conclusion": conclusion,
            "confidence": float(confidence),
            "trace": {
                "strategy": "graph_of_thought",
                "total_thoughts": len(graph.all()),
                "explored": sum(1 for t in graph.all() if t.status == "explored"),
                "pruned": sum(1 for t in graph.all() if t.status == "pruned"),
                "merged": sum(1 for t in graph.all() if "merged_from" in t.metadata),
                "best_path_length": len(best_path),
                "graph": graph.to_dict(),
            },
            "alternatives": [
                t.content for t in graph.leaves()
                if t.id != best_path[-1].id and t.score >= self.prune_threshold
            ][:3],
            "strategy": "graph_of_thought",
        }

    async def _generate_thoughts(self, goal: str, n: int = 3) -> list[str]:
        """Generate N distinct thoughts for the goal."""
        try:
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": (
                        f"Generate {n} distinct approaches to answer the "
                        f"following question.  Each approach should be a "
                        f"short paragraph (2-4 sentences).  Output JSON: "
                        f'{{"thoughts": ["...", "...", "..."]}}'
                    )},
                    {"role": "user", "content": goal},
                ],
                temperature=0.7, max_tokens=512,
            )
            from adonai.core.json_utils import extract_json
            data = extract_json(resp.text or "")
            thoughts = data.get("thoughts", [])
            if isinstance(thoughts, list):
                return [str(t) for t in thoughts if t][:n]
        except Exception as e:
            log.debug("GoT thought generation failed: %s", e)
        return []

    async def _score_thought(self, goal: str, thought: str) -> float:
        """Score a thought on a 0..1 scale."""
        try:
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": (
                        "Score the quality of the following reasoning approach "
                        "for answering the question.  Output JSON: "
                        '{"score": 0.0-1.0, "rationale": "..."}'
                    )},
                    {"role": "user", "content": (
                        f"Question: {goal}\n\nApproach: {thought}"
                    )},
                ],
                temperature=0.2, max_tokens=128,
            )
            from adonai.core.json_utils import extract_json
            data = extract_json(resp.text or "")
            return float(data.get("score", 0.5))
        except Exception as e:
            log.debug("GoT scoring failed: %s", e)
            return 0.5


def _similarity(a: str, b: str) -> float:
    """Cheap Jaccard similarity over word sets."""
    wa = set(a.lower().split())
    wb = set(b.lower().split())
    if not wa or not wb:
        return 0.0
    return len(wa & wb) / len(wa | wb)
