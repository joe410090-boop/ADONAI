"""Docker sandbox wrapper for the A.D.O.N.AI safety layer.

This module is a thin re-export of :class:`adonai.pentest.sandbox.DockerSandbox`
+ :class:`adonai.pentest.sandbox.PentestSandbox` so callers can import
the sandbox from the canonical ``adonai.safety`` namespace alongside
the rest of the safety layer (watchdog, self_improvement, audit log).

The actual implementation lives in :mod:`adonai.pentest.sandbox` to
keep the pentest subsystem self-contained.
"""
from __future__ import annotations

# Re-export for canonical access via adonai.safety.docker_sandbox.
from adonai.pentest.sandbox import (  # noqa: F401
    DockerSandbox,
    DockerSandboxConfig,
    PentestConfig,
    PentestSandbox,
    ScanMode,
)

__all__ = [
    "DockerSandbox",
    "DockerSandboxConfig",
    "PentestConfig",
    "PentestSandbox",
    "ScanMode",
]
