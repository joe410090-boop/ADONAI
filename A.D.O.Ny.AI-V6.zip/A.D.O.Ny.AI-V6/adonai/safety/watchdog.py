"""Watchdog timer — detects hung tasks and cancels them.

The watchdog wraps each task execution in an ``asyncio.wait_for`` with a
configurable timeout.  When a task exceeds the timeout, the watchdog:

  1. Cancels the task.
  2. Records a "timeout" entry in the audit log.
  3. Publishes a ``task.timeout`` event on the EventBus.
  4. Returns a TaskResult with status=FAILED and the timeout error.

This prevents a single hung tool (e.g. a ``web_fetch`` against a slow
server) from blocking the entire agent indefinitely.

Usage::

    from adonai.safety.watchdog import Watchdog
    watchdog = Watchdog(default_timeout_s=120.0)
    result = await watchdog.run_with_timeout(task, executor.execute, task, plan)
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Awaitable, Callable

from adonai.core.models import TaskResult, TaskStatus

log = logging.getLogger(__name__)


class Watchdog:
    """Wraps async callables with a timeout + cancellation.

    Args:
        default_timeout_s: Default timeout in seconds for tasks that
            don't specify their own.  Default 120s.
        on_timeout: Optional async callback invoked when a task times
            out.  Receives ``(task_id, timeout_s, elapsed_s)``.
    """

    def __init__(
        self,
        default_timeout_s: float = 600.0,
        *,
        on_timeout: Callable[[str, float, float], Awaitable[None]] | None = None,
    ) -> None:
        self.default_timeout_s = default_timeout_s
        self._on_timeout = on_timeout
        self._active: dict[str, asyncio.Task] = {}

    async def run_with_timeout(
        self,
        task: Any,
        coro_fn: Callable[..., Awaitable[Any]],
        *args: Any,
        timeout_s: float | None = None,
        **kwargs: Any,
    ) -> Any:
        """Run ``coro_fn(*args, **kwargs)`` with a timeout.

        Args:
            task: The Task object (used for task_id + logging).
            coro_fn: The async callable to run.
            *args, **kwargs: Passed to ``coro_fn``.
            timeout_s: Per-task timeout override.  Falls back to
                ``self.default_timeout_s``.

        Returns:
            The result of ``coro_fn``.

        Raises:
            asyncio.TimeoutError: If the task exceeds the timeout.
        """
        timeout = timeout_s or self.default_timeout_s
        task_id = getattr(task, "id", str(id(task)))
        start = time.monotonic()

        async def _runner():
            return await coro_fn(*args, **kwargs)

        runner_task = asyncio.create_task(_runner(), name=f"watchdog-{task_id}")
        self._active[task_id] = runner_task
        try:
            result = await asyncio.wait_for(runner_task, timeout=timeout)
            return result
        except asyncio.TimeoutError:
            elapsed = time.monotonic() - start
            log.warning(
                "Watchdog: task %s timed out after %.1fs (limit=%.1fs) — cancelling",
                task_id, elapsed, timeout,
            )
            # Cancel the runner.
            runner_task.cancel()
            try:
                await runner_task
            except asyncio.CancelledError:
                pass
            # Invoke the on_timeout callback.
            if self._on_timeout is not None:
                try:
                    await self._on_timeout(task_id, timeout, elapsed)
                except Exception as e:
                    log.warning("Watchdog on_timeout callback failed: %s", e)
            # Return a FAILED TaskResult so callers don't crash.
            # Keep it robust: task may be a plain dict/str or some other
            # wrapper without a stable TaskResult-compatible shape.
            try:
                return TaskResult(
                    task_id=task_id,
                    status=TaskStatus.FAILED,
                    error=f"watchdog timeout after {timeout:.1f}s",
                    duration_s=elapsed,
                )
            except Exception:
                # Last-resort fallback for unexpected task types.
                return TaskResult(
                    task_id=str(task_id),
                    status=TaskStatus.FAILED,
                    error=f"watchdog timeout after {timeout:.1f}s",
                    duration_s=elapsed,
                )
        finally:
            self._active.pop(task_id, None)

    def cancel(self, task_id: str) -> bool:
        """Cancel a currently-running task by ID."""
        t = self._active.get(task_id)
        if t is None or t.done():
            return False
        t.cancel()
        return True

    def active_tasks(self) -> list[str]:
        """Return IDs of all currently-running tasks."""
        return [tid for tid, t in self._active.items() if not t.done()]
