"""Upgrade 10 — Self-Improvement Framework.

Allows Fable to improve its own codebase SAFELY.

Pipeline::

    Observe bottleneck → Propose patch → Sandbox testing
                       → Regression testing → Verification
                       → Optional merge

Safety requirements (enforced by :class:`DefaultSafetyGuard`):

* NEVER modify core runtime files directly (``config.self_improvement.protected_files``)
* Require passing tests (``config.self_improvement.require_tests_pass``)
* Automatic rollback on regression (``config.self_improvement.auto_rollback_on_regression``)

Patches are :class:`~adonai.core.models.SelfImprovementPatch` records
that move through the status machine::

    PROPOSED → SANDBOX_TESTING → REGRESSION_TESTING
            → VERIFIED → MERGED  (or  REJECTED → ROLLED_BACK)

The framework never patches the live codebase in-place; it always works
on a copy in ``config.self_improvement.sandbox_dir`` and only merges
after all gates pass.
"""
from __future__ import annotations

import asyncio
import logging
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Literal

from adonai.core.exceptions import SelfImprovementError
from adonai.core.interfaces import LLMClient, SafetyGuard
from adonai.core.models import (
    CritiqueReport, Experiment, Plan, SelfImprovementPatch, PatchStatus,
)

log = logging.getLogger(__name__)


# Always-protected files — even if config doesn't list them, these
# core-runtime files must never be auto-patched.
_ALWAYS_PROTECTED: list[str] = [
    "adonai/runtime.py",
    "adonai/core/interfaces.py",
    "adonai/core/models.py",
    "adonai/core/exceptions.py",
    "adonai/safety/self_improvement.py",
    "main.py",
]


# ──────────────────────────────────────────────────────────────────────────────
# DefaultSafetyGuard
# ──────────────────────────────────────────────────────────────────────────────


class DefaultSafetyGuard(SafetyGuard):
    """Default safety guard for plans, patches, and experiments.

    * Plans: consults the Critic (if injected) + checks protected files.
    * Patches: blocks any patch whose ``target_file`` is in
      ``config.self_improvement.protected_files``.
    * Experiments: blocks experiments with high-risk parameters
      (e.g. destructive simulator configs).
    """

    name: str = "default_safety_guard"

    def __init__(
        self,
        *,
        config: Any = None,
        critic: Any = None,
    ) -> None:
        self.config = config
        self.critic = critic

    async def review_plan(self, plan: Plan) -> CritiqueReport:
        """Delegate plan review to the Critic if available; else heuristic."""
        if self.critic is not None:
            from adonai.core.models import Task
            # Build a synthetic task for the critic.
            task = Task(goal=plan.goal, complexity="complex")
            try:
                return await self.critic.critique(
                    task, plan, target_kind="plan",
                )
            except Exception as e:
                log.warning("SafetyGuard: critic review failed: %s", e)
        # Heuristic fallback.
        return CritiqueReport(
            task_id=plan.task_id,
            target_kind="plan",
            target_ref=plan.id,
            confidence=0.6,
            risk_score=0.3,
            recommendation="accept",
            rationale="heuristic safety check (no critic configured)",
        )

    async def review_patch(
        self, patch: SelfImprovementPatch,
    ) -> Literal["approve", "block", "escalate"]:
        """Block patches to protected files; escalate risky ones."""
        protected = self._protected_files()
        # Normalize patch target_file to a relative path.
        target_rel = patch.target_file.replace("\\", "/").lstrip("./")
        for p in protected:
            p_norm = p.replace("\\", "/").lstrip("./")
            if target_rel == p_norm or target_rel.startswith(p_norm + "/"):
                log.warning(
                    "SafetyGuard: BLOCKED patch to protected file %s",
                    patch.target_file,
                )
                return "block"
        # Escalate high-risk patches.
        if patch.risk_score >= 0.7:
            return "escalate"
        return "approve"

    async def review_experiment(
        self, experiment: Experiment,
    ) -> Literal["approve", "block", "escalate"]:
        """Block experiments with destructive parameters."""
        design = experiment.design or {}
        # Heuristic: block if any parameter key contains "delete",
        # "destroy", "wipe", or "rm".
        dangerous = ("delete", "destroy", "wipe", "rm ", "format ")
        design_str = str(design).lower()
        if any(d in design_str for d in dangerous):
            return "block"
        # Escalate if the experiment runs a real (non-mock) simulator
        # with a long timeout.
        if (
            experiment.simulator
            and experiment.simulator != "mock"
            and design.get("timeout_s", 0) > 3600
        ):
            return "escalate"
        return "approve"

    def _protected_files(self) -> list[str]:
        if self.config is None:
            return list(_ALWAYS_PROTECTED)
        configured = (
            getattr(
                getattr(self.config, "self_improvement", None),
                "protected_files", [],
            )
            or []
        )
        # Always include the hard-coded list, even if config overrides.
        return list(set(_ALWAYS_PROTECTED) | set(configured))


# ──────────────────────────────────────────────────────────────────────────────
# SelfImprovementEngine
# ──────────────────────────────────────────────────────────────────────────────


class SelfImprovementEngine:
    """Self-improvement pipeline.

    Composes:

    * bottleneck detection (from analytics)
    * LLM-backed patch generation
    * :class:`DefaultSafetyGuard` for review
    * sandboxed execution (copy target file, apply patch, run tests)
    * automatic rollback on regression

    The engine NEVER modifies core runtime files directly.  All patches
    are staged in a sandbox directory and only merged after passing
    every gate.
    """

    def __init__(
        self,
        llm: LLMClient | None = None,
        *,
        config: Any = None,
        safety_guard: SafetyGuard | None = None,
        project_root: str | Path | None = None,
    ) -> None:
        self.llm = llm
        self.config = config
        self.safety = safety_guard or DefaultSafetyGuard(config=config)
        self.project_root = Path(project_root or ".")
        self.sandbox_dir = (
            getattr(getattr(config, "self_improvement", None), "sandbox_dir", None)
            if config else None
        ) or (self.project_root / "data" / "sandbox")
        self.sandbox_dir.mkdir(parents=True, exist_ok=True)
        self.max_patches = (
            getattr(getattr(config, "self_improvement", None),
                    "max_patches_per_run", 5)
            if config else 5
        )
        self.require_tests = (
            getattr(getattr(config, "self_improvement", None),
                    "require_tests_pass", True)
            if config else True
        )
        self.test_command = (
            getattr(getattr(config, "self_improvement", None),
                    "test_command", "python -m pytest tests/ -x --tb=short")
            if config else "python -m pytest tests/ -x --tb=short"
        )
        self.auto_rollback = (
            getattr(getattr(config, "self_improvement", None),
                    "auto_rollback_on_regression", True)
            if config else True
        )
        # v7: registry of all patches proposed by this engine, keyed by
        # patch.id. Used by the LearningLoop's benchmark-regression rollback
        # branch to find the most-recently-merged patch. Previously this
        # attribute was referenced by loop.py:490 but never populated —
        # the rollback branch was silently dead code.
        self._patches: dict[str, SelfImprovementPatch] = {}

    # ── Public API ───────────────────────────────────────────────────────

    async def observe_bottlenecks(
        self,
        analytics: Any = None,
        *,
        tool_registry: Any = None,
    ) -> list[dict[str, Any]]:
        """Identify bottlenecks from analytics + tool registry data.

        Looks for:

        * tools with high failure rate (from ``tool_registry.all_stats()``)
        * steps with high latency
        * recurring task failures

        The previous implementation called ``analytics.tool_stats()`` which
        didn't exist on ``AnalyticsTracker`` — leaving the bottleneck list
        permanently empty.  We now accept the ``ToolRegistry`` directly
        (it exposes ``all_stats()`` returning per-tool ``{calls, success,
        fail, total_s, last_used}`` dicts) and fall back to ``analytics``
        for backward compatibility.

        Returns a list of bottleneck dicts suitable for feeding to
        :meth:`propose_patch`.
        """
        bottlenecks: list[dict[str, Any]] = []

        # ── Primary source: ToolRegistry.all_stats() ─────────────────────
        # The registry records calls/success/fail/total_s per tool on
        # every execute() call.  This is the real signal — AnalyticsTracker
        # doesn't have per-tool stats.
        stats: dict[str, dict[str, Any]] = {}
        if tool_registry is not None and hasattr(tool_registry, "all_stats"):
            try:
                stats = tool_registry.all_stats() or {}
            except Exception as e:
                log.debug("tool_registry.all_stats() failed: %s", e)
        if not stats and analytics is not None:
            # Backward-compat fallback for callers that pass AnalyticsTracker.
            stats = (
                analytics.tool_stats()
                if hasattr(analytics, "tool_stats")
                else {}
            )
        if not stats:
            return bottlenecks

        # Tool failure rates.  Note: ToolRegistry uses "fail" (not
        # "failures") and "success" as the per-bucket counters.
        try:
            for tool_name, s in stats.items():
                calls = s.get("calls", 0)
                # Accept both "fail" (registry) and "failures" (legacy).
                fail_count = s.get("fail", s.get("failures", 0))
                fail_rate = fail_count / max(1, calls)
                if fail_rate > 0.3 and calls >= 3:
                    bottlenecks.append({
                        "kind": "tool_failure",
                        "tool": tool_name,
                        "fail_rate": round(fail_rate, 3),
                        "calls": calls,
                        "fail_count": fail_count,
                    })
        except Exception as e:
            log.debug("Bottleneck analytics failed: %s", e)
        # Latency outliers.
        try:
            for tool_name, s in stats.items():
                calls = s.get("calls", 0)
                total_s = s.get("total_s", 0)
                avg_s = total_s / max(1, calls)
                if avg_s > 30.0 and calls >= 2:
                    bottlenecks.append({
                        "kind": "tool_latency",
                        "tool": tool_name,
                        "avg_s": round(avg_s, 2),
                        "calls": calls,
                    })
        except Exception:
            pass
        return bottlenecks[:self.max_patches]

    async def propose_patch(
        self, bottleneck: dict[str, Any],
    ) -> SelfImprovementPatch:
        """Use the LLM to propose a patch for a bottleneck."""
        if self.llm is None:
            raise SelfImprovementError(
                "no LLM configured — cannot propose patches"
            )
        prompt = self._build_patch_prompt(bottleneck)
        resp = await self.llm.complete(
            messages=[
                {"role": "system", "content": _PATCH_GENERATION_PROMPT},
                {"role": "user", "content": prompt},
            ],
            temperature=0.2,
            max_tokens=2048,
        )
        from adonai.core.json_utils import extract_json, JSONExtractionError
        try:
            data = extract_json(resp.text or "")
        except JSONExtractionError as e:
            raise SelfImprovementError(
                f"LLM returned unparseable patch JSON: {e}"
            ) from e
        if not isinstance(data, dict):
            raise SelfImprovementError("LLM returned non-dict patch JSON")
        patch = SelfImprovementPatch(
            bottleneck=str(bottleneck),
            target_file=str(data.get("target_file", "")),
            diff=str(data.get("diff", "")),
            rationale=str(data.get("rationale", "")),
            risk_score=float(data.get("risk_score", 0.5)),
            safety_checks=list(data.get("safety_checks") or []),
            status=PatchStatus.PROPOSED,
        )
        if not patch.target_file or not patch.diff:
            raise SelfImprovementError("patch missing target_file or diff")
        return patch

    async def run_pipeline(
        self, bottleneck: dict[str, Any],
    ) -> SelfImprovementPatch:
        """Run the full propose → sandbox → regression → verify → merge pipeline."""
        # 1. Propose.
        patch = await self.propose_patch(bottleneck)
        log.info("SelfImprovement: proposed patch %s for %s",
                 patch.id, patch.target_file)
        # v7: register the patch in our internal registry so the
        # LearningLoop's benchmark-regression rollback branch can find
        # recently-merged patches to roll back.
        self._patches[patch.id] = patch

        # 2. Safety review.
        decision = await self.safety.review_patch(patch)
        if decision == "block":
            patch.status = PatchStatus.REJECTED
            log.warning("SelfImprovement: patch %s BLOCKED by safety guard",
                        patch.id)
            return patch
        if decision == "escalate":
            log.info("SelfImprovement: patch %s ESCALATED — awaiting human review",
                     patch.id)
            # Don't auto-merge escalated patches; leave them in PROPOSED.
            return patch

        # 3. Sandbox testing.
        patch = await self._sandbox_test(patch)
        if patch.status != PatchStatus.SANDBOX_TESTING:
            return patch  # already failed

        # 4. Regression testing.
        patch = await self._regression_test(patch)
        if patch.status != PatchStatus.REGRESSION_TESTING:
            return patch  # already failed

        # 5. Verification.
        patch = await self._verify(patch)

        # 6. Optional merge (only if verified and auto_rollback allows).
        if patch.status == PatchStatus.VERIFIED:
            try:
                patch = await self._merge(patch)
            except Exception as e:
                log.error("SelfImprovement: merge failed: %s", e)
                patch.status = PatchStatus.REJECTED
                patch.rollback_reason = f"merge_failed: {e}"
        return patch

    # ── Pipeline stages ──────────────────────────────────────────────────

    async def _sandbox_test(
        self, patch: SelfImprovementPatch,
    ) -> SelfImprovementPatch:
        """Apply the patch to a sandbox copy and verify it doesn't crash."""
        patch.status = PatchStatus.SANDBOX_TESTING
        sandbox_path = self._sandbox_copy(patch.target_file)
        try:
            self._apply_patch(sandbox_path, patch.diff)
            # Sanity check: can Python still parse the file?
            import ast
            with open(sandbox_path) as f:
                source = f.read()
            try:
                ast.parse(source)
            except SyntaxError as e:
                patch.sandbox_result = {
                    "pass": False, "syntax_error": str(e),
                }
                patch.status = PatchStatus.REJECTED
                patch.rollback_reason = f"syntax_error: {e}"
                return patch
            patch.sandbox_result = {"pass": True, "sandbox_path": str(sandbox_path)}
            log.info("SelfImprovement: patch %s passed sandbox test", patch.id)
        except Exception as e:
            patch.sandbox_result = {"pass": False, "error": str(e)}
            patch.status = PatchStatus.REJECTED
            patch.rollback_reason = f"sandbox_error: {e}"
        return patch

    async def _regression_test(
        self, patch: SelfImprovementPatch,
    ) -> SelfImprovementPatch:
        """Run the project's test suite in the sandbox.

        We temporarily swap the patched file into place, run the tests,
        and restore the original on completion (or failure).
        """
        if not self.require_tests:
            patch.status = PatchStatus.REGRESSION_TESTING
            patch.regression_result = {"skipped": True}
            return patch
        patch.status = PatchStatus.REGRESSION_TESTING
        target_abs = self._resolve_target_path(patch.target_file)
        if not target_abs.exists():
            patch.regression_result = {"pass": False, "error": "target file missing"}
            patch.status = PatchStatus.REJECTED
            patch.rollback_reason = "target file missing"
            return patch
        # Backup the original.
        backup_path = target_abs.with_suffix(target_abs.suffix + ".bak")
        try:
            shutil.copy2(target_abs, backup_path)
            # Apply the patched content.
            self._apply_patch(target_abs, patch.diff)
            # Run tests. (test_command is operator-configured; in hardened
            # deployments it should run inside a container/seccomp sandbox.)
            import shlex as _shlex
            test_cmd_parts = _shlex.split(self.test_command)
            proc = await asyncio.create_subprocess_exec(
                *test_cmd_parts,
                cwd=str(self.project_root),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                start_new_session=True,
            )
            test_timeout_s = float(getattr(self.config, "test_timeout_s", 300.0))
            try:
                stdout, stderr = await asyncio.wait_for(
                    proc.communicate(), timeout=test_timeout_s,
                )
            except asyncio.TimeoutError:
                # Kill the entire process group (catches child pytest workers).
                try:
                    import os as _os
                    _os.killpg(_os.getpgid(proc.pid), 9)
                except (ProcessLookupError, PermissionError, OSError):
                    try:
                        proc.kill()
                    except ProcessLookupError:
                        pass
                # CRITICAL FIX (v4): restore the original BEFORE returning.
                # The previous code returned without restoring, then the
                # finally block deleted the backup — losing the original
                # forever and leaving the broken patch in place.
                try:
                    shutil.copy2(backup_path, target_abs)
                    log.warning("SelfImprovement: restored original after test timeout for %s", patch.id)
                except Exception as restore_err:
                    log.error("SelfImprovement: FAILED to restore original after timeout: %s", restore_err)
                patch.regression_result = {"pass": False, "error": "tests timed out"}
                patch.status = PatchStatus.REJECTED
                patch.rollback_reason = "tests timed out — original restored"
                return patch
            passed = proc.returncode == 0
            patch.regression_result = {
                "pass": passed,
                "returncode": proc.returncode,
                "stdout": (stdout or b"").decode("utf-8", errors="replace")[:2000],
                "stderr": (stderr or b"").decode("utf-8", errors="replace")[:2000],
            }
            if not passed and self.auto_rollback:
                # Restore original.
                shutil.copy2(backup_path, target_abs)
                patch.status = PatchStatus.REJECTED
                patch.rollback_reason = "tests failed — rolled back"
                log.warning(
                    "SelfImprovement: patch %s failed regression — rolled back",
                    patch.id,
                )
                return patch
            elif not passed:
                # CRITICAL FIX (v4): auto_rollback=False previously left the
                # broken patch in place AND deleted the backup. Now we always
                # restore the original on test failure regardless of the
                # auto_rollback flag — the flag only controls whether the
                # patch is retried, not whether the file is left broken.
                shutil.copy2(backup_path, target_abs)
                patch.status = PatchStatus.REJECTED
                patch.rollback_reason = "tests failed — original restored (auto_rollback disabled, patch not retried)"
                log.warning(
                    "SelfImprovement: patch %s failed regression — original restored (auto_rollback=False)",
                    patch.id,
                )
                return patch
            log.info("SelfImprovement: patch %s passed regression tests", patch.id)
            # Tests passed — restore the original for now; merge will re-apply.
            shutil.copy2(backup_path, target_abs)
        finally:
            if backup_path.exists():
                backup_path.unlink(missing_ok=True)
        return patch

    async def _verify(
        self, patch: SelfImprovementPatch,
    ) -> SelfImprovementPatch:
        """Final verification — re-check safety, import-ability, and sanity.

        v6 fix: previously this was a stub that unconditionally set pass=True.
        Now it performs three real checks:
        1. Re-run the safety guard's review_patch on the patched code.
        2. Verify the patched file can be imported (ast.parse + import check).
        3. Verify the patch hasn't grown the file by more than 2x (sanity).
        """
        verification: dict[str, Any] = {
            "pass": True,
            "safety_checks": patch.safety_checks,
            "checks_run": [],
        }
        # Check 1: Re-run safety guard review on the patched content.
        # v7 fix: previously referenced self.safety_guard (wrong attribute
        # name — the constructor assigns to self.safety). The try/except
        # swallowed the AttributeError, so this check was silently dead.
        # Now references the correct attribute and uses the correct
        # review_patch() signature (takes a SelfImprovementPatch, returns
        # "approve"/"block"/"escalate").
        try:
            if self.safety is not None:
                review = await self.safety.review_patch(patch)
                verification["checks_run"].append("safety_review")
                if review == "block":
                    verification["pass"] = False
                    verification["safety_rejection"] = (
                        f"safety guard blocked patch (target={patch.target_file})"
                    )
                    log.warning(
                        "SelfImprovement: patch %s FAILED safety review: %s",
                        patch.id, verification["safety_rejection"],
                    )
                elif review == "escalate":
                    verification["checks_run"].append("safety_review_escalated")
                    log.info(
                        "SelfImprovement: patch %s ESCALATED by safety review",
                        patch.id,
                    )
        except Exception as e:
            log.debug("SelfImprovement safety review check failed: %s", e)
            verification["checks_run"].append("safety_review_error")

        # Check 2: Verify the patched file parses as valid Python.
        try:
            import ast
            ast.parse(patch.diff)
            verification["checks_run"].append("ast_parse")
        except SyntaxError as e:
            verification["pass"] = False
            verification["syntax_error"] = str(e)
            log.warning(
                "SelfImprovement: patch %s FAILED ast parse: %s", patch.id, e,
            )

        # Check 3: Sanity — patched file should not be more than 2x the
        # original size (catches accidental duplication / runaway LLM output).
        try:
            target_abs = self._resolve_target_path(patch.target_file)
            if target_abs.exists():
                original_size = target_abs.stat().st_size
                patched_size = len(patch.diff.encode("utf-8"))
                verification["checks_run"].append("size_sanity")
                if patched_size > original_size * 2 and original_size > 100:
                    verification["pass"] = False
                    verification["size_anomaly"] = (
                        f"patched file {patched_size}B > 2x original {original_size}B"
                    )
                    log.warning(
                        "SelfImprovement: patch %s FAILED size sanity: %s",
                        patch.id, verification["size_anomaly"],
                    )
        except Exception as e:
            log.debug("SelfImprovement size sanity check failed: %s", e)

        patch.status = PatchStatus.VERIFIED
        patch.verification_result = verification
        if verification["pass"]:
            log.info("SelfImprovement: patch %s verified (%d checks passed)",
                     patch.id, len(verification["checks_run"]))
        else:
            log.warning("SelfImprovement: patch %s verification FAILED", patch.id)
        return patch

    async def _merge(
        self, patch: SelfImprovementPatch,
    ) -> SelfImprovementPatch:
        """Apply the patch to the live codebase."""
        target_abs = self._resolve_target_path(patch.target_file)
        if not target_abs.exists():
            raise SelfImprovementError(
                f"merge target does not exist: {target_abs}"
            )
        # Backup before merge (for rollback).
        backup_dir = self.sandbox_dir / "backups"
        backup_dir.mkdir(parents=True, exist_ok=True)
        backup_path = backup_dir / f"{target_abs.name}.{int(time.time())}.bak"
        shutil.copy2(target_abs, backup_path)
        # Apply.
        self._apply_patch(target_abs, patch.diff)
        patch.status = PatchStatus.MERGED
        patch.merged_at = __import__("datetime").datetime.now(__import__("datetime").timezone.utc)
        patch.metadata["backup_path"] = str(backup_path)
        log.info(
            "SelfImprovement: patch %s MERGED to %s (backup: %s)",
            patch.id, patch.target_file, backup_path,
        )
        return patch

    async def rollback(self, patch: SelfImprovementPatch) -> SelfImprovementPatch:
        """Roll back a merged patch from its backup."""
        backup_path_str = (patch.metadata or {}).get("backup_path")
        if not backup_path_str:
            raise SelfImprovementError(
                f"no backup_path recorded for patch {patch.id}"
            )
        backup_path = Path(backup_path_str)
        if not backup_path.exists():
            raise SelfImprovementError(
                f"backup file missing: {backup_path}"
            )
        target_abs = self._resolve_target_path(patch.target_file)
        shutil.copy2(backup_path, target_abs)
        patch.status = PatchStatus.ROLLED_BACK
        from datetime import datetime, timezone
        patch.rolled_back_at = datetime.now(timezone.utc)
        log.info("SelfImprovement: rolled back patch %s", patch.id)
        return patch

    # ── Helpers ──────────────────────────────────────────────────────────

    async def _list_recent_experiences(self, limit: int) -> list[dict[str, Any]]:
        """Return recent experience records from the wired experience store.

        v6 fix: this method is now async and properly awaits
        ``store.recent()``. Previously it was sync and called
        ``store.recent()`` without await — producing a coroutine that was
        never awaited (RuntimeWarning) and always returning [] due to
        ``len(coroutine)`` raising TypeError. The ``except`` swallowed
        the error, so maybe_auto_improve() always saw
        ``experience_count == 0`` and never triggered.

        Handles both sync and async ``recent()`` methods for backward
        compatibility with stores that have a synchronous ``recent()``
        (e.g. WorkingMemory.recent()).
        """
        store = getattr(self, "_experience_store", None)
        if store is not None and hasattr(store, "recent"):
            try:
                result = store.recent(limit=limit)
                # If the store's recent() is async, await it.
                import asyncio as _asyncio
                if _asyncio.iscoroutine(result):
                    result = await result
                return result  # type: ignore[return-value]
            except Exception:
                return []
        return []

    async def maybe_auto_improve(
        self,
        recent_success_rate: float,
        min_tasks: int = 5,
        *,
        analytics: Any = None,
        tool_registry: Any = None,
        success_threshold: float | None = None,
    ) -> bool:
        """Automatically trigger improvement if success rate is low.

        Returns True if improvement was triggered.

        v9 fix: Lowered the default threshold from 0.5 (catastrophic — most
        deployments never trigger) to 0.7, and made it configurable via the
        `success_threshold` argument or `config.self_improvement.
        auto_improve_success_threshold`. Also lowered `min_tasks` from 10 to
        5, and added `tool_registry` so observe_bottlenecks can actually
        find tool-call bottlenecks (the analytics-only path always returned
        empty before — see Q4 high-severity finding).
        """
        # v9: configurable threshold. Default 0.7 (improve when <70% success).
        # The legacy 0.5 was catastrophic — most deployments hover above 50%
        # success and NEVER trigger self-improvement.
        if success_threshold is None:
            cfg_threshold = (
                getattr(getattr(self.config, "self_improvement", None),
                        "auto_improve_success_threshold", None)
                if self.config else None
            )
            success_threshold = float(cfg_threshold) if cfg_threshold else 0.7
        if recent_success_rate >= success_threshold:
            return False
        # Check we have enough data
        try:
            experience_count = len(await self._list_recent_experiences(min_tasks))
        except Exception:
            return False
        if experience_count < min_tasks:
            return False
        log.warning(
            "Auto-improvement triggered: success rate %.0f%% below %.0f%% threshold (n=%d)",
            recent_success_rate * 100, success_threshold * 100, experience_count,
        )
        # Observe bottlenecks from analytics (if available) AND/OR tool_registry
        # (v9: previously only analytics was passed, and AnalyticsTracker has
        # no `tool_stats` method, so observe_bottlenecks always returned []).
        bottlenecks = await self.observe_bottlenecks(
            analytics, tool_registry=tool_registry,
        )
        if not bottlenecks:
            log.warning("Auto-improvement: no bottlenecks identified")
            return False
        try:
            await self.run_pipeline(bottlenecks[0])
            return True
        except Exception as e:
            log.error("Auto-improvement failed: %s", e)
            return False

    def _build_patch_prompt(self, bottleneck: dict[str, Any]) -> str:
        return (
            f"BOTTLENECK: {bottleneck}\n"
            f"PROJECT_ROOT: {self.project_root}\n\n"
            f"Propose a code patch that addresses this bottleneck.\n"
            f"Avoid modifying files in: {self._protected_files_list()}\n"
            f"Output JSON with target_file (relative path), diff (full\n"
            f"replacement file content), rationale, risk_score (0-1),\n"
            f"and safety_checks (list of strings)."
        )

    def _protected_files_list(self) -> list[str]:
        if self.config is None:
            return list(_ALWAYS_PROTECTED)
        configured = (
            getattr(getattr(self.config, "self_improvement", None),
                    "protected_files", [])
            or []
        )
        return list(set(_ALWAYS_PROTECTED) | set(configured))

    def _resolve_target_path(self, target_file: str) -> Path:
        """Resolve a relative target_file path against project_root.

        SECURITY (v4 hardening): reject absolute paths and any path that
        resolves outside project_root. Previously, absolute paths like
        /etc/cron.d/evil were accepted verbatim, allowing a prompt-injected
        LLM to write anywhere the process user could.
        """
        if not target_file or not isinstance(target_file, str):
            raise SelfImprovementError(f"invalid target_file: {target_file!r}")
        p = Path(target_file)
        if p.is_absolute():
            raise SelfImprovementError(
                f"absolute paths are forbidden for self-improvement patches "
                f"(got {target_file!r}); use a path relative to project_root"
            )
        resolved = (self.project_root / target_file).resolve()
        # Containment check — reject paths that escape project_root via ../
        try:
            resolved.relative_to(self.project_root.resolve())
        except ValueError:
            raise SelfImprovementError(
                f"target_file {target_file!r} resolves outside project_root "
                f"({resolved}); escape attempts are blocked"
            )
        return resolved

    def _sandbox_copy(self, target_file: str) -> Path:
        """Copy target_file into the sandbox directory; return sandbox path."""
        target_abs = self._resolve_target_path(target_file)
        if not target_abs.exists():
            raise SelfImprovementError(
                f"sandbox copy: source missing: {target_abs}"
            )
        sandbox_path = self.sandbox_dir / target_abs.name
        shutil.copy2(target_abs, sandbox_path)
        return sandbox_path

    @staticmethod
    def _apply_patch(target_path: Path, diff: str) -> None:
        """Apply a patch by writing ``diff`` as the new file content.

        We treat ``diff`` as the full replacement content (not a unified
        diff) — this is safer and easier to verify than parsing diff
        syntax.  The LLM is instructed to output the full file.
        """
        with open(target_path, "w") as f:
            f.write(diff)


# ──────────────────────────────────────────────────────────────────────────────
# Patch-generation prompt
# ──────────────────────────────────────────────────────────────────────────────


_PATCH_GENERATION_PROMPT = (
    "You are the SELF-IMPROVEMENT ENGINE of an autonomous research platform.\n"
    "Given a bottleneck, propose a code patch that addresses it.\n\n"
    "Output JSON:\n"
    "{\n"
    '  "target_file": str,           // relative path (e.g. "adonai/tools/builtin/web.py")\n'
    '  "diff": str,                  // FULL replacement file content (not a unified diff)\n'
    '  "rationale": str,             // why this patch fixes the bottleneck\n'
    '  "risk_score": 0.0-1.0,        // 0=safe, 1=dangerous\n'
    '  "safety_checks": [str]        // list of invariants the patch preserves\n'
    "}\n\n"
    "Rules:\n"
    "1. NEVER propose patches to: runtime.py, core/interfaces.py,\n"
    "   core/models.py, core/exceptions.py, safety/self_improvement.py, main.py.\n"
    "2. Preserve all existing public APIs (backward compatibility).\n"
    "3. Output the FULL file content in `diff` — not a unified diff.\n"
    "4. Set risk_score conservatively.  When in doubt, escalate.\n"
    "Return ONLY the JSON.  No prose, no markdown fences."
)


__all__ = [
    "DefaultSafetyGuard",
    "SelfImprovementEngine",
]
