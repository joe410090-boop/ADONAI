"""ADONAI runtime — top-level facade wiring all subsystems together.

v4 — adds 12 research-grade subsystems (Critic, Knowledge Graph,
Tree-of-Thought planning, Reflection Engine, Skill Evolution,
Multi-Agent Debate, Hypothesis Generator, Experiment Loop, Model
Router, Self-Improvement, Simulation Abstraction, Strategic Reasoning).

All v4 subsystems are *opt-in* via config and *backward-compatible*:
existing public APIs (run, chat, run_background, get_task_status,
cancel_task, list_tasks, list_skills, clear_conversation,
get_conversation) are preserved.
"""
from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from adonai.agents.registry import build_default_registry
from adonai.collaboration.blackboard import Blackboard
from adonai.collaboration.voting import VotingSystem
from adonai.collaboration.consensus import ConsensusBuilder
from adonai.config.settings import Config, load_config
from adonai.core.container import Container
from adonai.core.events import EventBus, EventPublisher
from adonai.core.exceptions import AdonaiError
from adonai.core.models import Memory, MemoryType, Task, TaskResult, TaskStatus
from adonai.executors.checkpoint import CheckpointManager
from adonai.executors.executor import TaskExecutor
from adonai.executors.recovery import RecoveryManager
from adonai.executors.scheduler import TaskScheduler
from adonai.learning.analytics import AnalyticsTracker
from adonai.learning.loop import LearningLoop
from adonai.llm.factory import build_llm_client
from adonai.memory.manager import build_memory_manager
from adonai.planning.planner import HierarchicalPlanner
from adonai.reasoning.engine import ReasoningEngine
from adonai.skills.manager import SkillManager
from adonai.tools.permissions import PermissionPolicy
from adonai.tools.registry import ToolRegistry
from adonai.tools.builtin import all_builtin_tools

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Domain gate for the v5 Prompt Engineering Node
# ──────────────────────────────────────────────────────────────────────────────
# The node is engineered for software-engineering requests.  Running it on
# every chat / search / Q&A message rewrites the user's intent into a multi-
# page spec, which then breaks the planner's keyword heuristics (search,
# latest, news) and prevents web_search from ever being invoked.  This gate
# ensures the node only fires for genuine build/implement/design requests.
_ENGINEERING_TRIGGER_KEYWORDS: tuple[str, ...] = (
    "build", "implement", "create app", "create a app", "create an app",
    "develop", "scaffold", "design a system", "design the system",
    "architecture for", "architect a", "write code for", "write a program",
    "write a script", "write an application", "code a", "code the",
    "make a web app", "make a cli", "make a desktop", "make a mobile app",
    "fullstack", "full-stack", "frontend app", "backend service",
    "rest api", "graphql", "microservice", "micro-service",
    "dockerize", "containerize", "deploy a service",
)


def _looks_like_engineering_request(goal: str) -> bool:
    """Heuristic: only run the PromptEngineeringNode for build/implement tasks.

    Conservative — defaults to False so chat / search / Q&A / casual messages
    bypass the node and reach the planner with their original goal intact.
    """
    if not goal or not isinstance(goal, str):
        return False
    g = goal.lower().strip()
    # Long multi-paragraph requests are likely engineering specs already.
    if len(g) > 500:
        return True
    return any(kw in g for kw in _ENGINEERING_TRIGGER_KEYWORDS)


def _format_tool_transcript_for_history(transcript: list[dict[str, Any]]) -> str:
    """Format a tool-call transcript into a compact one-line summary.

    This is prepended to the assistant's recorded reply in
    :meth:`ADONAI.chat` so the model on the next turn knows what tools
    it called and what the results were.  Without this, small models
    (qwen3.5:4b) see only ``user → assistant_text`` in history and
    honestly (but wrongly) claim "I did not perform a web search" on
    follow-up turns — the model was telling the truth based on the
    text-only history it could see.

    Output format (one line per tool call, capped at 5 calls + a
    "and N more" suffix):

        [Tools used: web_search(query="latest AI news") → 5 results;
                     web_fetch(url="https://hai.stanford.edu/...") → 200 OK]

    The summary is short on purpose — it's metadata for the model's
    memory, not a verbose log.  The actual tool results were already
    fed back to the model as `role=tool` messages during the
    ToolCallingAgent loop; this summary just ensures the model
    *remembers* it called tools when it sees the history on the next
    turn.
    """
    if not transcript:
        return ""
    parts: list[str] = []
    for i, entry in enumerate(transcript[:5]):
        tool = entry.get("tool", "?")
        params = entry.get("parameters") or {}
        # Pick the most informative parameter to show.
        key_param = ""
        for k in ("query", "url", "path", "command", "code", "file"):
            if k in params and params[k]:
                val = str(params[k])
                # Truncate long values (code blocks, URLs, etc.).
                if len(val) > 60:
                    val = val[:57] + "..."
                key_param = f'{k}="{val}"'
                break
        if not key_param and params:
            # Fall back to the first parameter.
            k, v = next(iter(params.items()))
            val = str(v)
            if len(val) > 60:
                val = val[:57] + "..."
            key_param = f'{k}="{val}"'
        # Status — show success/fail compactly.
        success = entry.get("success", False)
        if success:
            # Include a short output preview for context.
            preview = (entry.get("output_preview") or "").strip()
            if len(preview) > 50:
                preview = preview[:47] + "..."
            status = f"→ {preview}" if preview else "→ ok"
        else:
            err = (entry.get("error") or "failed")[:60]
            status = f"→ FAILED: {err}"
        parts.append(f"{tool}({key_param}) {status}" if key_param else f"{tool} {status}")
    suffix = ""
    if len(transcript) > 5:
        suffix = f"; and {len(transcript) - 5} more"
    return f"[Tools used: {'; '.join(parts)}{suffix}]"


class ADONAI:
    """Top-level facade for A.D.O.N.AI v4 (research-grade autonomous platform).

    Wires together the v3 subsystems (LLM, tools, memory, skills,
    learning, agents, executors, MCP, reasoning, collaboration,
    analytics) PLUS the v4 research-grade extensions:

    * :attr:`critic` — :class:`~adonai.agents.critic.CriticAgent`
    * :attr:`model_router` — :class:`~adonai.llm.router.DefaultModelRouter`
    * :attr:`reflection_engine` — :class:`~adonai.reasoning.reflection_engine.DefaultReflectionEngine`
    * :attr:`skill_evolver` — :class:`~adonai.skills.evolution.DefaultSkillEvolver`
    * :attr:`debate_framework` — :class:`~adonai.collaboration.debate.DefaultDebateFramework`
    * :attr:`hypothesis_generator` — :class:`~adonai.discovery.hypothesis.DefaultHypothesisGenerator`
    * :attr:`experiment_loop` — :class:`~adonai.discovery.experiment_loop.DefaultExperimentLoop`
    * :attr:`safety_guard` — :class:`~adonai.safety.self_improvement.DefaultSafetyGuard`
    * :attr:`self_improvement` — :class:`~adonai.safety.self_improvement.SelfImprovementEngine`
    * :attr:`simulators` — :class:`~adonai.simulation.SimulatorRegistry`
    * :attr:`strategic_reasoner` — :class:`~adonai.strategy.hierarchy.DefaultStrategicReasoner`

    Provides start/shutdown lifecycle + convenience methods (run,
    run_background, chat).  All v3 public methods are preserved.
    """

    def __init__(
        self,
        config: Config | None = None,
        config_path: str | None = None,
        **overrides: Any,
    ) -> None:
        if config is not None:
            self.config = config
        else:
            self.config = load_config(path=config_path, **overrides)

        # Container holds all wired subsystems.
        self.container = Container()
        # EventBus for inter-agent communication.
        self.events = EventBus()
        # Inject the bus into every EventPublisher subclass so v4
        # subsystems can emit events without holding a direct reference.
        EventPublisher.set_event_bus(self.events)
        # Blackboard — multi-agent collaboration primitive.
        # Agents post observations/results; other agents read them.
        self.blackboard = Blackboard()
        # v8: VotingSystem was instantiated here but never called.
        # Removed to avoid wasted memory.  Re-instantiate if the debate
        # framework is wired up to use it.

        # Subsystem handles (populated in start()).
        self.llm: Any = None
        self.tools: ToolRegistry | None = None
        self.memory: Any = None
        self.skills: SkillManager | None = None
        self.planner: HierarchicalPlanner | None = None
        self.executor: TaskExecutor | None = None
        self.scheduler: TaskScheduler | None = None
        self.checkpoints: CheckpointManager | None = None
        self.recovery: RecoveryManager | None = None
        self.learning_loop: LearningLoop | None = None
        self.analytics: AnalyticsTracker | None = None
        self.reasoning: ReasoningEngine | None = None
        self.agents: Any = None  # AgentRegistry
        self.mcp_client: Any = None
        self.consensus: ConsensusBuilder | None = None
        self._started: bool = False
        # Guards `start()` against concurrent double-construction. Two
        # concurrent chat()/run() calls on a fresh instance would otherwise
        # both enter start() and double-construct every subsystem.
        self._start_lock: asyncio.Lock | None = None  # created lazily in start()

        # v4 — Research-grade subsystem handles (populated in start()).
        self.critic: Any = None
        self.model_router: Any = None
        self.reflection_engine: Any = None
        self.skill_evolver: Any = None
        self.debate_framework: Any = None
        self.hypothesis_generator: Any = None
        self.experiment_loop: Any = None
        self.safety_guard: Any = None
        self.self_improvement: Any = None
        self.simulators: Any = None
        # v5 — newly-wired subsystems
        self.prompt_optimizer: Any = None
        self.benchmark_runner: Any = None

        # v5 — Self-Prompt Engineering Node (first stage of pipeline).
        # Transforms raw user requests into structured PromptPackages
        # before the planner sees them.  Builder never sees raw request.
        self.prompt_engineer: Any = None
        self.strategic_reasoner: Any = None

        # v6 — Real tool-calling agent (used by chat()).
        # Replaces the old planner→executor pipeline for interactive
        # conversation.  Lets the LLM decide when to call web_search,
        # python_exec, file.read, etc. via native OpenAI/Ollama tool
        # calling — no hard-coded heuristics, no deflection filters.
        self.tool_calling_agent: Any = None

        # ── Observability singletons (previously dead module) ──────────
        # Activated here so /metrics, /health, and /trace endpoints have
        # somewhere to read from.  Construction is best-effort: if the
        # observability module fails to initialise (e.g. metrics DB path
        # is on a read-only filesystem), the runtime still works — we
        # just fall back to None and the endpoints return empty dicts.
        self.metrics: Any = None
        self.health_monitor: Any = None
        self.tracer: Any = None

        # ── Executive autonomy layer (previously dead module) ──────────
        # The ExecutiveController runs a perpetual background loop that
        # picks the next-best goal from its world model and works on it.
        # Off by default — operators opt in via config.agent.executive_loop.
        self.executive_controller: Any = None

        # ── v6 — OpenHuman-inspired subsystems ────────────────────────
        # Constructed in _start_impl(); torn down in shutdown().  All
        # are opt-in via config and degrade gracefully if their deps
        # are missing.
        self.memory_tree: Any = None
        self.subconscious: Any = None
        self.goals_todos: Any = None
        self.tokenjuice: Any = None
        self.workflow_engine: Any = None
        self.graph_harness: Any = None
        self.split_brain: Any = None
        self.agent_economy: Any = None
        self.super_context: Any = None
        self.batteries: Any = None
        self.meeting_agents: Any = None
        self.subconscious_bridge: Any = None
        try:
            from adonai.observability import (
                get_metrics, get_health_monitor, get_tracer,
            )
            # Pass the metrics DB path so counter/histogram snapshots
            # persist to disk instead of being lost on restart.
            try:
                from adonai.observability import MetricsRegistry
                from pathlib import Path as _Path
                metrics_db = _Path(str(self.config.analytics.metrics_path))
                self.metrics = MetricsRegistry(db_path=metrics_db)
                # NOTE: start_flush_loop() must run inside the event loop
                # — we defer it to _start_impl so construction is safe
                # outside a loop.
            except Exception as e:
                log.debug("MetricsRegistry init failed (non-fatal): %s", e)
                self.metrics = get_metrics()
            self.health_monitor = get_health_monitor()
            self.tracer = get_tracer()
            self.container.register_instance("metrics", self.metrics)
            self.container.register_instance("health_monitor", self.health_monitor)
            self.container.register_instance("tracer", self.tracer)
        except Exception as e:
            log.debug("Observability subsystem init skipped (non-fatal): %s", e)

        # ── Watchdog timer (prevents hung tasks from blocking the agent) ──
        # Every task execution is wrapped in asyncio.wait_for via the
        # watchdog.  Tasks that exceed the timeout are cancelled.
        # v6: on_timeout callback marks the task as PAUSED (not FAILED) so
        # it remains resumable on the next startup. Previously timed-out
        # tasks were marked FAILED and silently abandoned — the work was
        # lost even though a checkpoint existed.
        try:
            from adonai.safety.watchdog import Watchdog

            async def _on_timeout(task_id: str, timeout_s: float, elapsed_s: float) -> None:
                """v6: mark timed-out task as PAUSED so it's resumable."""
                try:
                    if self.checkpoints is not None:
                        await self.checkpoints.update_task_status(
                            task_id, TaskStatus.PAUSED.value,
                        )
                        log.info(
                            "Watchdog: task %s marked PAUSED after timeout "
                            "(%.1fs) — will resume on next startup",
                            task_id, timeout_s,
                        )
                except Exception as e:
                    log.debug("Watchdog on_timeout status update failed: %s", e)

            self.watchdog: Any = Watchdog(
                default_timeout_s=float(
                    getattr(self.config.safety, "max_task_duration_s", 3600)
                ),
                on_timeout=_on_timeout,
            )
        except Exception as e:
            log.debug("Watchdog init skipped (non-fatal): %s", e)
            self.watchdog = None

    def get_service(self, name: str):
        """Get a registered service from the container."""
        return self.container.get(name)

    # ------------------------------------------------------------------ #
    # Lifecycle
    # ------------------------------------------------------------------ #

    async def start(self) -> None:
        """Initialize all subsystems.  Idempotent + concurrency-safe."""
        if self._started:
            log.debug("ADONAI already started — skipping.")
            return
        # Lazy-init the lock (asyncio.Lock must be created inside a loop).
        if self._start_lock is None:
            self._start_lock = asyncio.Lock()
        async with self._start_lock:
            # Re-check inside the lock — another coroutine may have finished
            # start() while we were waiting.
            if self._started:
                return
            await self._start_impl()
            self._started = True

    async def _start_impl(self) -> None:
        """Actual subsystem construction (called under _start_lock)."""
        log.info(
            "Starting ADONAI v4  env=%s  model=%s  backend=%s",
            self.config.environment, self.config.llm.model_name, self.config.llm.backend,
        )

        # 1. LLM client (with cache).
        from adonai.llm.cache import ResponseCache
        cache = ResponseCache(max_entries=self.config.llm.cache_max_entries) if self.config.llm.enable_cache else None
        self.llm = build_llm_client(self.config.llm, cache=cache)
        self.container.register_instance("llm", self.llm)

        # 2. Tool registry + built-in tools.
        # Pass the configured workspace root to the terminal tool so its
        # cwd sandbox actually activates.  Without this, TerminalTool is
        # constructed with workspace_root=None and the entire cwd-check
        # branch is skipped — allowing commands to access absolute paths
        # anywhere on the filesystem.
        policy = PermissionPolicy(self.config.safety)
        # v9: persist tool stats to the same SQLite DB as the rest of the
        # agent's state so SelfImprovementEngine.observe_bottlenecks() sees
        # historical data across restarts.
        _tool_stats_db = (
            getattr(getattr(self.config, "memory", None), "sqlite_path", None)
            or "data/adonai.db"
        )
        self.tools = ToolRegistry(
            permission_policy=policy,
            stats_db_path=_tool_stats_db,
        )
        _ws_root = (
            str(self.config.workspace) if getattr(self.config, "workspace", "")
            else None
        )
        await self.tools.register_many(
            all_builtin_tools(workspace_root=_ws_root)
        )

        # 3. Memory manager (5-tier).
        self.memory = build_memory_manager(self.config, self.llm)

        # 4. Skill manager.
        self.skills = SkillManager(self.config, llm=self.llm)
        self.container.register_instance("skills_manager", self.skills)

        # 5. Planner.
        self.planner = HierarchicalPlanner(
            llm=self.llm, memory_manager=self.memory, tool_manager=self.tools,
        )

        # 6. Reasoning engine.
        self.reasoning = ReasoningEngine(
            llm=self.llm, config=self.config, tool_registry=self.tools,
        )
        self.container.register_instance("reasoning_engine", self.reasoning)

        # 7. Checkpoint manager + executor + scheduler.
        self.checkpoints = CheckpointManager(self.config)
        # Pick executor: AdvancedParallelExecutor (advanced parallelism) when
        # concurrency > 1, then fall back to EnhancedExecutor, then TaskExecutor.
        # AdvancedParallelExecutor extends EnhancedExecutor which extends
        # TaskExecutor so all existing call sites continue to work.
        max_concurrent = max(1, getattr(self.config.tasks, "max_concurrent_tasks", 1))
        advanced_cfg = getattr(self.config, "advanced_parallelism", None) or {}
        advanced_enabled = bool(getattr(advanced_cfg, "enabled", False))
        if max_concurrent > 1 and advanced_enabled:
            try:
                from adonai.executors.advanced_parallel_executor import AdvancedParallelExecutor
                self.executor = AdvancedParallelExecutor(
                    llm=self.llm, tool_registry=self.tools,
                    memory_manager=self.memory,
                    checkpoint_manager=self.checkpoints, config=self.config,
                    enable_parallel=True,
                    enable_dynamic_batching=getattr(advanced_cfg, "dynamic_batching", True),
                    enable_parallel_synthesis=getattr(advanced_cfg, "parallel_synthesis", True),
                    enable_speculative_execution=getattr(advanced_cfg, "speculative_execution", True),
                    planner=self.planner,
                )
                log.info(
                    "Using AdvancedParallelExecutor (max_concurrent=%d, "
                    "dynamic_batching=%s, parallel_synthesis=%s, "
                    "speculative_execution=%s)",
                    max_concurrent,
                    getattr(advanced_cfg, "dynamic_batching", True),
                    getattr(advanced_cfg, "parallel_synthesis", True),
                    getattr(advanced_cfg, "speculative_execution", True),
                )
            except Exception as e:
                log.warning(
                    "AdvancedParallelExecutor init failed (%s) — "
                    "falling back to EnhancedExecutor", e,
                )
                # Fall back to EnhancedExecutor.
                try:
                    from adonai.executors.parallel_executor import EnhancedExecutor
                    self.executor = EnhancedExecutor(
                        llm=self.llm, tool_registry=self.tools,
                        memory_manager=self.memory,
                        checkpoint_manager=self.checkpoints, config=self.config,
                        enable_parallel=True,
                        planner=self.planner,
                    )
                    log.info("Fell back to EnhancedExecutor (parallel)")
                except Exception as e2:
                    log.warning(
                        "EnhancedExecutor init also failed (%s) — "
                        "falling back to TaskExecutor", e2,
                    )
                    self.executor = TaskExecutor(
                        llm=self.llm, tool_registry=self.tools,
                        memory_manager=self.memory,
                        checkpoint_manager=self.checkpoints, config=self.config,
                        planner=self.planner,
                    )
        elif max_concurrent > 1:
            try:
                from adonai.executors.parallel_executor import EnhancedExecutor
                self.executor = EnhancedExecutor(
                    llm=self.llm, tool_registry=self.tools,
                    memory_manager=self.memory,
                    checkpoint_manager=self.checkpoints, config=self.config,
                    enable_parallel=True,
                    planner=self.planner,  # v6: wire planner for replan-on-failure
                )
                log.info(
                    "Using EnhancedExecutor (parallel, max_concurrent=%d)",
                    max_concurrent,
                )
            except Exception as e:
                log.warning(
                    "EnhancedExecutor init failed (%s) — falling back to TaskExecutor", e,
                )
                self.executor = TaskExecutor(
                    llm=self.llm, tool_registry=self.tools,
                    memory_manager=self.memory,
                    checkpoint_manager=self.checkpoints, config=self.config,
                    planner=self.planner,  # v6: wire planner for replan-on-failure
                )
        else:
            self.executor = TaskExecutor(
                llm=self.llm, tool_registry=self.tools,
                memory_manager=self.memory,
                checkpoint_manager=self.checkpoints, config=self.config,
                planner=self.planner,  # v6: wire planner for replan-on-failure
            )
        self.scheduler = TaskScheduler(
            self.config,
            agent=self._scheduler_agent,
            checkpoint_manager=self.checkpoints,  # v9: checkpoint at submit
        )
        self.container.register_instance("scheduler", self.scheduler)
        self.recovery = RecoveryManager(self.checkpoints, self._scheduler_agent, executor=self.executor)
        self.container.register_instance("recovery", self.recovery)
        # v9: wire recovery_manager into scheduler so recover_all() works.
        self.scheduler._recovery_manager = self.recovery

        # 8. Agent registry (7 built-in agents).
        # Build the facade first, then the registry, then wire the registry
        # back into the facade.  Doing this in three steps (rather than the
        # original one-liner `build_default_registry(parent=self._agent_facade())`)
        # ensures `facade.agent_registry` is the real registry, not None.
        # Without this fix, ExecutiveAgent.run() silently falls back to
        # `parent.run()` because `self.parent.agent_registry.get(...)` raises
        # AttributeError on None, which gets swallowed by the broad except.
        facade = self._agent_facade()
        self.agents = build_default_registry(parent=facade)
        facade.agent_registry = self.agents
        self.container.register_instance("agents", self.agents)
        self.container.register_instance("executor", self.executor)

        # 9. MCP client (best-effort).
        try:
            from adonai.mcp.client import build_mcp_client
            self.mcp_client = await build_mcp_client(self.config.mcp)
            if self.mcp_client is not None and self.tools is not None:
                await self.tools.load_mcp_tools(self.mcp_client)
        except Exception as e:
            log.debug("MCP load skipped: %s", e)

        # 10. Consensus builder — synthesizes multiple agent outputs into
        # a unified response when multi-agent collaboration produces
        # divergent results.
        self.consensus = ConsensusBuilder(self.llm)

        # 11. Analytics + learning loop.
        self.analytics = AnalyticsTracker(self.config)
        self.container.register_instance("analytics", self.analytics)
        self.learning_loop = LearningLoop(
            self.config, llm=self.llm,
            skill_manager=self.skills, analytics=self.analytics,
            memory_manager=self.memory,
            runtime=self,  # v5: needed for BenchmarkRunner.run_all → runtime.chat()
        )
        self.container.register_instance("learning_loop", self.learning_loop)
        self.learning_loop.start()

        # ── v4 — Research-grade subsystems (opt-in) ─────────────────────
        # NOTE: The Critic, Model Router, Reflection Engine, Skill Evolver,
        # Debate Framework, Hypothesis Generator, Experiment Loop, Safety
        # Guard, Self-Improvement Engine, Simulator Registry, Strategic
        # Reasoner, and Tree-of-Thought Planner are constructed in
        # `_start_v4_subsystems()` after the v3 stack is fully wired.
        # The v4 LearningLoop integrations (reflection_engine,
        # skill_evolver, knowledge_graph) are wired *after* the v4
        # subsystems exist — see `_start_v4_subsystems()`.

        # 12. Warm up the LLM (best-effort).
        try:
            await self._warmup_llm()
        except Exception as exc:
            log.warning("LLM warmup failed (non-fatal): %s", exc)

        # 13. Recover resumable tasks.
        # v6: actually AWAIT the recovery coroutines via wait_for_recovery().
        # Previously recover_all() spawned asyncio.create_task() per resumable
        # task and returned immediately — the recovery tasks were fire-and-
        # forget. A fast shutdown would cancel them mid-flight, and the
        # "Recovered N task(s)" log was misleading (it counted queued, not
        # completed). Now we wait up to 30s for them to finish.
        if self.config.tasks.recovery_on_startup:
            try:
                recovered = await self.recovery.recover_all()
                if recovered:
                    log.info("Recovered %d resumable task(s) — awaiting completion", len(recovered))
                    try:
                        await self.recovery.wait_for_recovery(timeout=30.0)
                        log.info("Recovery complete — %d task(s) resumed", len(recovered))
                    except asyncio.TimeoutError:
                        log.warning(
                            "Recovery timed out after 30s — %d task(s) may still "
                            "be resuming in the background", len(recovered),
                        )
                    except Exception as e:
                        log.debug("wait_for_recovery failed (non-fatal): %s", e)
            except Exception as e:
                log.warning("Task recovery failed: %s", e)

        # ── v4 — Research-grade subsystems (opt-in) ─────────────────────
        await self._start_v4_subsystems()

        # ── v5 — Self-Prompt Engineering Node ────────────────────────────
        # Always constructed (no opt-in flag) — it's the first stage of
        # the reasoning pipeline and degrades gracefully without an LLM.
        self._start_prompt_engineering()

        # ── v6 + v10 — Real tool-calling agent for interactive chat ──────
        # v10: uses ParallelToolCallingAgent which executes multiple tool
        # calls within a single LLM turn CONCURRENTLY via asyncio.gather.
        # This cuts multi-tool turn latency from sum(latencies) to
        # max(latencies) — typically 2-3× faster for web-search workflows.
        from adonai.agents.parallel_tool_agent import (
            ParallelToolCallingAgent, set_parallel_audit_log_path,
        )
        # v5: wire the audit log path so chat-path tool calls are written
        # to the same audit log as executor-path tool calls.
        try:
            audit_path = self.config.safety.audit_log_path
            from adonai.agents.tool_calling_agent import set_audit_log_path
            set_audit_log_path(audit_path)
            set_parallel_audit_log_path(str(audit_path) if audit_path else None)
        except Exception as e:
            log.debug("Could not set audit log path for ToolCallingAgent: %s", e)
        # Default max_iterations is 12 — enough headroom for multi-tool
        # workflows like "search the web, write a script, run it, save
        # the output to a file" (5 tool calls + 1 final synthesis).
        cfg_max_iter = getattr(self.config.agent, "max_iterations", 12) or 12
        cfg_max_tokens = getattr(self.config.llm, "max_tokens", 2048) or 2048
        # Split the token budget: tool-call decisions get a smaller budget
        # (the model only needs ~100-200 tokens for a function name + args
        # JSON), final synthesis gets the full budget.  This is the single
        # biggest speedup for small thinking-mode models like qwen3.5:4b —
        # it stops them from burning 1024 tokens on <think> when deciding
        # which URL to web_fetch.
        # v10: parallel_tool_execution=True enables concurrent tool execution
        # within each LLM turn. use_dependency_analysis=True conservatively
        # chains tools with likely data dependencies (web_search→web_fetch)
        # while running independent tools in parallel.
        self.tool_calling_agent = ParallelToolCallingAgent(
            llm=self.llm,
            tools=self.tools,
            max_iterations=max(cfg_max_iter, 12),
            temperature=getattr(self.config.agent, "default_temperature", 0.4) or 0.4,
            max_tokens=cfg_max_tokens,
            max_tokens_tool=max(384, cfg_max_tokens // 2),
            max_tokens_synthesis=cfg_max_tokens,
            # ── Parallel execution options ────────────────────────────
            parallel_tool_execution=True,
            use_dependency_analysis=True,
            max_parallel_tools=10,
        )

        # NOTE: _started is set by the start() wrapper after _start_impl returns.
        tool_count = len(await self.tools.list_tools())
        agent_count = len(self.agents.list_agents())
        log.info(
            "ADONAI started  tools=%d  agents=%d",
            tool_count, agent_count,
        )

        # ── Start observability flush loop (must run inside the event loop) ──
        if self.metrics is not None and hasattr(self.metrics, "start_flush_loop"):
            try:
                self.metrics.start_flush_loop()
                log.debug("MetricsRegistry flush loop started")
            except Exception as e:
                log.debug("MetricsRegistry flush loop start failed (non-fatal): %s", e)

        # ── Register subsystem health checks (activates HealthMonitor) ────
        if self.health_monitor is not None:
            async def _llm_health():
                # Cheap ping — the LLM client is constructed but we don't
                # call complete() to avoid burning tokens on every check.
                # Just verify the client object exists and is not closed.
                if self.llm is None:
                    return False, "llm client is None", {}
                # Heuristic: httpx clients expose is_closed.
                inner = getattr(self.llm, "_inner", self.llm)
                http = getattr(inner, "_http", None)
                if http is not None and getattr(http, "is_closed", False):
                    return False, "http client closed", {}
                return True, None, {"backend": self.config.llm.backend}

            async def _tools_health():
                if self.tools is None:
                    return False, "tool registry is None", {}
                try:
                    n = len(await self.tools.list_tools())
                    return True, None, {"count": n}
                except Exception as e:
                    return False, f"{type(e).__name__}: {e}", {}

            async def _memory_health():
                if self.memory is None:
                    return False, "memory manager is None", {}
                return True, None, {}

            try:
                self.health_monitor.register("llm", _llm_health, interval_s=60.0)
                self.health_monitor.register("tools", _tools_health, interval_s=60.0)
                self.health_monitor.register("memory", _memory_health, interval_s=60.0)
                log.debug("HealthMonitor checks registered (llm, tools, memory)")
                # v6: start the background poll loop so /health returns
                # fresh data instead of healthy=True forever.
                if hasattr(self.health_monitor, "start"):
                    self.health_monitor.start()
                    log.debug("HealthMonitor background poll started")
            except Exception as e:
                log.debug("HealthMonitor register failed (non-fatal): %s", e)

        # ── Executive autonomy layer (opt-in) ──────────────────────────
        # Activated when config.agent.executive_loop is true.  Spawns a
        # background asyncio task that runs the perpetual
        # observe→think→plan→execute→reflect loop.  When disabled, the
        # runtime works exactly as before — this is a pure addition.
        if bool(getattr(self.config.agent, "executive_loop", False)):
            try:
                from adonai.agents.executive_controller import (
                    ExecutiveController, GoalStore,
                )
                # Construct a SQLite-backed goal store so the goal tree
                # survives restarts.  Without this, the controller is
                # in-memory only and loses all goals on crash.
                goal_store: GoalStore | None = None
                try:
                    goal_store = GoalStore(
                        self.config.database.path.parent / "executive_goals.db"
                    )
                except Exception as e:
                    log.warning("GoalStore init failed (non-fatal): %s", e)
                self.executive_controller = ExecutiveController(
                    runtime=self,
                    tick_interval_s=float(
                        getattr(self.config.agent, "executive_tick_s", 5.0)
                    ),
                    max_concurrent_goals=int(
                        getattr(self.config.agent, "max_concurrent_agents", 4)
                    ),
                    goal_store=goal_store,
                )
                await self.executive_controller.start()
                self.container.register_instance(
                    "executive_controller", self.executive_controller,
                )
                log.info("Executive autonomy layer started (background loop)")
            except Exception as e:
                log.warning("ExecutiveController init failed (non-fatal): %s", e)

        # ── v6 — OpenHuman-inspired subsystems ──────────────────────────
        await self._start_v6_subsystems()

    async def _start_v6_subsystems(self) -> None:
        """Construct + start the 11 OpenHuman-inspired subsystems.

        Each subsystem is opt-in via config and wrapped in a try/except
        so a failure in one doesn't break the rest of the runtime.
        """
        # 1. Memory Tree + Obsidian Wiki mirror.
        if getattr(self.config.memory_tree, "enabled", False):
            try:
                from adonai.openhuman.memory_tree import MemoryTreeService
                self.memory_tree = MemoryTreeService(self.config.memory_tree)
                await self.memory_tree.start()
                self.container.register_instance("memory_tree", self.memory_tree)
                log.info("v6 Memory Tree started (vault: %s)",
                         self.config.memory_tree.vault_path)
            except Exception as e:
                log.warning("Memory Tree init failed (non-fatal): %s", e)

        # 2. Goals & Todos.
        if getattr(self.config.goals_todos, "enabled", False):
            try:
                from adonai.openhuman.goals_todos import GoalsTodosService
                self.goals_todos = GoalsTodosService(self.config.goals_todos)
                self.container.register_instance("goals_todos", self.goals_todos)
                log.info("v6 Goals & Todos started")
            except Exception as e:
                log.warning("Goals & Todos init failed (non-fatal): %s", e)

        # 4. TokenJuice (needs the LLM).
        if getattr(self.config.tokenjuice, "enabled", False):
            try:
                from adonai.openhuman.tokenjuice import TokenJuice
                self.tokenjuice = TokenJuice(self.config.tokenjuice, llm=self.llm)
                self.container.register_instance("tokenjuice", self.tokenjuice)
                log.info("v6 TokenJuice started (strategy: %s)",
                         self.config.tokenjuice.strategy)
            except Exception as e:
                log.warning("TokenJuice init failed (non-fatal): %s", e)

        # 6. Graph harness.
        if getattr(self.config.graph_harness, "enabled", False):
            try:
                from adonai.openhuman.graph_harness import GraphHarness
                self.graph_harness = GraphHarness(
                    self.config.graph_harness, runtime=self,
                )
                self.container.register_instance("graph_harness", self.graph_harness)
                log.info("v6 Graph Harness started")
            except Exception as e:
                log.warning("Graph Harness init failed (non-fatal): %s", e)

        # 5. Workflows.
        if getattr(self.config.workflows, "enabled", False):
            try:
                from adonai.openhuman.workflows import WorkflowEngine
                self.workflow_engine = WorkflowEngine(
                    self.config.workflows, runtime=self,
                )
                await self.workflow_engine.start()
                self.container.register_instance("workflow_engine", self.workflow_engine)
                log.info("v6 Workflow Engine started")
            except Exception as e:
                log.warning("Workflow Engine init failed (non-fatal): %s", e)

        # 9. SuperContext.
        if getattr(self.config.super_context, "enabled", False):
            try:
                from adonai.openhuman.super_context import SuperContext
                self.super_context = SuperContext(
                    self.config.super_context,
                    memory_tree=self.memory_tree,
                    workspace_root=str(self.config.workspace) if getattr(self.config, "workspace", "") else None,
                )
                self.container.register_instance("super_context", self.super_context)
                log.info("v6 SuperContext started")
            except Exception as e:
                log.warning("SuperContext init failed (non-fatal): %s", e)

        # 10. Batteries (voice + privacy mode + router extensions).
        try:
            from adonai.openhuman.batteries import Batteries
            self.batteries = Batteries(self.config.batteries)
            # Register the battery tools (e.g. voice.transcribe) with
            # the existing tool registry so the agent can call them.
            if self.tools is not None:
                for tool in self.batteries.tools():
                    try:
                        await self.tools.register(tool)
                    except Exception as e:
                        log.debug("Battery tool register failed (%s): %s", tool.name, e)
            self.container.register_instance("batteries", self.batteries)
            log.info("v6 Batteries started (voice=%s, privacy=%s)",
                     self.config.batteries.voice_enabled, self.batteries.privacy_mode.enabled)
        except Exception as e:
            log.warning("Batteries init failed (non-fatal): %s", e)

        # 7. Split brain (needs the LLM for reflex triage).
        if getattr(self.config.split_brain, "enabled", False):
            try:
                from adonai.openhuman.split_brain import SplitBrain
                self.split_brain = SplitBrain(
                    self.config.split_brain,
                    reflex_llm=self.llm,
                    deep_llm=self.llm,
                    deep_runtime=self,
                )
                self.container.register_instance("split_brain", self.split_brain)
                log.info("v6 Split Brain started")
            except Exception as e:
                log.warning("Split Brain init failed (non-fatal): %s", e)

        # 12. Subconscious → executive_loop bridge (constructed before
        # the subconscious so we can pass it as the bridge callback).
        if getattr(self.config.subconscious, "bridge_to_executive", False):
            try:
                from adonai.openhuman.subconscious_bridge import SubconsciousExecutiveBridge
                endpoint = self.config.subconscious.bridge_endpoint
                http_ep = endpoint if endpoint.startswith("http") else None
                self.subconscious_bridge = SubconsciousExecutiveBridge(
                    self.config.subconscious,
                    runtime=self,
                    http_endpoint=http_ep,
                )
                self.container.register_instance("subconscious_bridge", self.subconscious_bridge)
                log.info("v6 Subconscious→Executive bridge started")
            except Exception as e:
                log.warning("Subconscious bridge init failed (non-fatal): %s", e)

        # 2. Subconscious (needs the LLM + memory tree + goals + bridge).
        if getattr(self.config.subconscious, "enabled", False):
            try:
                from adonai.openhuman.subconscious import SubconsciousEngine
                self.subconscious = SubconsciousEngine(
                    self.config.subconscious,
                    llm=self.llm,
                    memory_tree=self.memory_tree,
                    goals=self.goals_todos,
                    bridge=self.subconscious_bridge,
                )
                await self.subconscious.start()
                self.container.register_instance("subconscious", self.subconscious)
                log.info("v6 Subconscious started (tick every %.0fs)",
                         self.config.subconscious.tick_interval_s)
            except Exception as e:
                log.warning("Subconscious init failed (non-fatal): %s", e)

        # 8. Agent economy (opt-in, off by default).
        if getattr(self.config.agent_economy, "enabled", False):
            try:
                from adonai.openhuman.agent_economy import AgentEconomy
                self.agent_economy = AgentEconomy(self.config.agent_economy)
                await self.agent_economy.start()
                self.container.register_instance("agent_economy", self.agent_economy)
                log.info("v6 Agent Economy started (handle: %s)",
                         self.config.agent_economy.handle or "headless")
            except Exception as e:
                log.warning("Agent Economy init failed (non-fatal): %s", e)

        # 11. Meeting agents.
        if getattr(self.config.meeting_agents, "enabled", False):
            try:
                from adonai.openhuman.meeting_agents import MeetingAgentsService
                voice = getattr(self.batteries, "voice", None) if self.batteries else None
                self.meeting_agents = MeetingAgentsService(
                    self.config.meeting_agents,
                    llm=self.llm,
                    memory_tree=self.memory_tree,
                    voice_transcriber=voice,
                )
                await self.meeting_agents.start()
                self.container.register_instance("meeting_agents", self.meeting_agents)
                log.info("v6 Meeting Agents started (platforms: %s)",
                         ", ".join(self.config.meeting_agents.platforms))
            except Exception as e:
                log.warning("Meeting Agents init failed (non-fatal): %s", e)

    async def shutdown(self) -> None:
        """Release all resources.  Idempotent."""
        if not self._started:
            return
        log.info("Shutting down ADONAI v4 ...")
        # Stop the executive loop first — it submits work to the scheduler
        # and we don't want it racing the scheduler shutdown.
        if self.executive_controller is not None:
            try:
                await self.executive_controller.stop()
            except Exception as e:
                log.warning("ExecutiveController stop error: %s", e)
            self.executive_controller = None

        # ── v6 — shut down OpenHuman-inspired subsystems ──────────────────
        # Stop the subconscious first — it submits work to the scheduler
        # via the bridge, so we want it quiesced before the scheduler.
        for name, attr in (
            ("subconscious", self.subconscious),
            ("meeting_agents", self.meeting_agents),
            ("workflow_engine", self.workflow_engine),
            ("agent_economy", self.agent_economy),
            ("memory_tree", self.memory_tree),
        ):
            if attr is not None:
                try:
                    stop = getattr(attr, "stop", None) or getattr(attr, "close", None)
                    if stop is not None:
                        result = stop()
                        if asyncio.iscoroutine(result):
                            await result
                except Exception as e:
                    log.debug("v6 %s stop (non-fatal): %s", name, e)
        # Close the bridge journal + stores that don't have async stop().
        for name, attr in (
            ("subconscious_bridge", self.subconscious_bridge),
            ("goals_todos", self.goals_todos),
            ("graph_harness", self.graph_harness),
        ):
            if attr is not None:
                try:
                    close = getattr(attr, "close", None)
                    if close is not None:
                        close()
                except Exception as e:
                    log.debug("v6 %s close (non-fatal): %s", name, e)
        self.subconscious = None
        self.meeting_agents = None
        self.workflow_engine = None
        self.agent_economy = None
        self.memory_tree = None
        self.subconscious_bridge = None
        self.goals_todos = None
        self.graph_harness = None
        # Stop the metrics flush loop so it doesn't try to write to a
        # closed DB during the rest of shutdown.
        if self.metrics is not None and hasattr(self.metrics, "stop_flush_loop"):
            try:
                await self.metrics.stop_flush_loop()
            except Exception as e:
                log.debug("MetricsRegistry flush loop stop (non-fatal): %s", e)
        # Stop foreground schedulers/loops first so no new work is spawned.
        if self.scheduler is not None:
            try:
                await self.scheduler.shutdown()
            except Exception as e:
                log.warning("Scheduler shutdown error: %s", e)
        if self.learning_loop is not None:
            try:
                await self.learning_loop.stop()
            except Exception as e:
                log.warning("LearningLoop stop error: %s", e)
        if self.mcp_client is not None:
            try:
                await self.mcp_client.close()
            except Exception as e:
                log.debug("MCP close failed: %s", e)
        # Container shutdown — closes every registered subsystem that exposes
        # close()/aclose()/stop(). Previously this was missing, leaking 10+
        # subsystems (critic, model_router, reflection_engine, skill_evolver,
        # debate_framework, hypothesis_generator, experiment_loop,
        # safety_guard, self_improvement, simulators, strategic_reasoner).
        try:
            await self.container.shutdown()
        except Exception as e:
            log.warning("Container shutdown error: %s", e)
        # LLM client (may already have been closed by container.shutdown()).
        if self.llm is not None:
            try:
                await self.llm.close()
            except Exception as e:
                log.debug("LLM close error (non-fatal, likely already closed): %s", e)
        self._started = False
        log.info("ADONAI v4 shut down.")

    # ------------------------------------------------------------------ #
    # Task execution
    # ------------------------------------------------------------------ #

    async def run(self, goal: str, *, session_id: str | None = None, **kwargs: Any) -> TaskResult:
        """Run a goal to completion (blocking).

        If *session_id* is provided, the turn is recorded into the
        conversation history — so Run Goal mode also has memory.
        """
        if not self._started:
            await self.start()

        # ── Prompt injection detection on user input ──
        # The previous implementation logged a warning and called
        # sanitize_input() (which only strips control chars) — the
        # injected text was still passed to the LLM.  We now reject
        # high-confidence injection patterns outright and return a
        # FAILED TaskResult explaining the rejection, so the LLM never
        # sees the malicious input.
        try:
            from adonai.prompt_engineering.detector import PromptInjectionDetector
            if not hasattr(self, '_injection_detector'):
                self._injection_detector = PromptInjectionDetector()
            is_inj, matches = self._injection_detector.detect(goal)
            if is_inj:
                log.warning(
                    "Prompt injection detected — REJECTING input: %s",
                    matches[0][:120],
                )
                # Reject outright instead of sanitizing-and-continuing.
                # Surface a clear error so the caller knows why their
                # request was refused.
                rejected_goal = "[rejected: prompt injection detected]"
                return TaskResult(
                    task_id=f"rej_{int(time.time())}",
                    status=TaskStatus.FAILED,
                    error=(
                        f"Request rejected by prompt-injection guard. "
                        f"Matched patterns: {'; '.join(m[:100] for m in matches[:3])}"
                    ),
                    duration_s=0.0,
                )
        except Exception as e:
            log.debug("Injection detection skipped: %s", e)

        task = Task(goal=goal, **kwargs)
        if session_id:
            task.session_id = session_id
        log.info("Running task %s: %s", task.id, goal[:120])
        return await self._run_task(task)

    async def run_background(self, goal: str, **kwargs: Any) -> str:
        """Schedule a goal for background execution.  Returns task_id."""
        if not self._started:
            await self.start()
        task = Task(goal=goal, **kwargs)
        if self.scheduler is not None:
            return await self.scheduler.submit(task)
        # Fallback — run synchronously.
        result = await self._run_task(task)
        return task.id

    async def chat(self, user_message: str, session_id: str | None = None) -> str:
        """Conversational chat via the real tool-calling agent loop.

        The LLM is given the tool schemas up front and decides for itself
        when to call web_search, python_exec, file.read, terminal, etc.
        Tool results are fed back as `role=tool` messages and the loop
        continues until the LLM produces a final text answer.

        Conversation history (per session_id) is preserved across calls
        and persisted to SQLite by the executor's ConversationStore.

        Tool-aware history: when the agent calls tools, a one-line
        summary of those calls is prepended to the recorded assistant
        reply so the model remembers what it did on previous turns.
        Without this, small models (qwen3.5:4b) see only
        ``user → assistant_text`` in history and honestly (but wrongly)
        claim "I did not perform a web search" on follow-up turns.

        v5 unification: the chat path now uses the SAME memory
        infrastructure as the run path — long-term episodic/semantic
        memory is recalled before the LLM generates a reply, and the
        user's message is written as an episodic memory so future
        conversations can recall it. Previously chat() only used the
        ConversationStore (chat history), bypassing long-term memory
        entirely.
        """
        if not self._started:
            await self.start()
        sid = session_id or "default"

        # ── Prompt injection detection on chat input ──
        # Same hardening as run(): reject high-confidence injection
        # patterns outright instead of sanitizing-and-continuing.
        try:
            from adonai.prompt_engineering.detector import PromptInjectionDetector
            if not hasattr(self, '_injection_detector'):
                self._injection_detector = PromptInjectionDetector()
            is_inj, matches = self._injection_detector.detect(user_message)
            if is_inj:
                log.warning(
                    "Prompt injection detected in chat — REJECTING: %s",
                    matches[0][:120],
                )
                return (
                    "I can't process that request — it matched a known "
                    "prompt-injection pattern.  If this is a mistake, "
                    "please rephrase your message without phrases like "
                    "'ignore previous instructions', 'DAN mode', or "
                    "'jailbreak'."
                )
        except Exception as e:
            log.debug("Injection detection skipped: %s", e)

        # ── v6: Split-brain reflex triage ──────────────────────────────────
        # Every inbound message goes through the reflex agent first.  If
        # it can answer in <2s (greetings, simple Q&A, acknowledgements),
        # it replies directly — no tool loop, no deep reasoning.  If it
        # decides the message needs multi-step work, it hands a concise
        # brief to the deep reasoning core (which is the existing
        # tool-calling agent loop below).
        #
        # The split-brain is opt-in via config.split_brain.enabled.
        # When disabled, chat() works exactly as before.
        if self.split_brain is not None:
            try:
                triage = await self.split_brain.triage(user_message)
                if triage.verdict == "drop":
                    log.info("Split-brain dropped message (%.0fms): %s",
                             triage.latency_ms, user_message[:80])
                    return "(message dropped by reflex triage)"
                if triage.verdict == "reply_now" and triage.reply:
                    log.info("Split-brain replied directly (%.0fms): %s",
                             triage.latency_ms, user_message[:80])
                    # Record the turn so future calls remember it.
                    if self.executor is not None:
                        self.executor._record_turn(sid, user_message, triage.reply)
                    # Bump the chat counter.
                    if self.metrics is not None:
                        try:
                            self.metrics.counter("adonai_chat_total").inc()
                            self.metrics.counter("adonai_split_brain_reply_total").inc()
                        except Exception:
                            pass
                    return triage.reply
                # hand_to_deep — fall through to the normal tool-calling
                # loop, optionally using the reflex agent's brief instead
                # of the raw user message.
                if triage.verdict == "hand_to_deep" and triage.brief:
                    log.info("Split-brain handed to deep core (%.0fms): brief=%s",
                             triage.latency_ms, triage.brief[:80])
                    # Use the brief as the effective message for the deep
                    # core, but record the ORIGINAL user message in history
                    # so the conversation reads naturally.
                    effective_user_message_for_deep = triage.brief
                else:
                    effective_user_message_for_deep = user_message
            except Exception as e:
                log.debug("Split-brain triage failed (non-fatal): %s", e)
                effective_user_message_for_deep = user_message
        else:
            effective_user_message_for_deep = user_message

        # ── v6: SuperContext pre-message scout ─────────────────────────────
        # Before the deep core reads the message, a research scout sweeps
        # the Memory Tree + workspace for relevant context.  No cold starts.
        # The scout has a hard 3s budget and degrades gracefully.
        super_context_prefix = ""
        if self.super_context is not None:
            try:
                pack = await self.super_context.sweep(user_message)
                super_context_prefix = pack.to_prompt()
                if pack.tokens_estimated > 0:
                    log.debug("SuperContext injected %d tokens (%.0fms)",
                              pack.tokens_estimated, pack.elapsed_ms)
            except Exception as e:
                log.debug("SuperContext sweep failed (non-fatal): %s", e)

        # Pull conversation history (mirrors what the executor uses,
        # so /run, /chat, and the API all share the same memory).
        history: list[dict[str, str]] = []
        if self.executor is not None:
            history = self.executor._get_history(sid)

        # ── v5: Long-term memory recall ──────────────────────────────────
        # Retrieve relevant episodic + semantic memories so the LLM has
        # context from past sessions/tasks. This is the SAME recall path
        # the executor uses (executor.py:145), so chat and run now share
        # identical memory infrastructure.
        recalled_context = ""
        if self.memory is not None:
            try:
                from adonai.core.models import MemoryType
                recalled = await self.memory.recall(
                    user_message, top_k=5,
                    types=[MemoryType.EPISODIC, MemoryType.SEMANTIC],
                )
                if recalled:
                    blocks = []
                    for m in recalled[:5]:
                        blocks.append(
                            f"- [{m.type.value if hasattr(m.type, 'value') else m.type}] "
                            f"{m.content[:300]}"
                        )
                    recalled_context = (
                        "\n\nRecalled long-term memory (use this if relevant):\n"
                        + "\n".join(blocks)
                    )
                    log.debug(
                        "Chat: recalled %d memories for session %s", len(recalled), sid,
                    )
            except Exception as e:
                log.debug("Chat memory recall failed (non-fatal): %s", e)

        # Augment the user message with recalled context so the LLM sees it.
        # v6: use the split-brain's brief (if triage handed to deep) as the
        # base message, then layer on SuperContext + recalled long-term memory.
        effective_message = effective_user_message_for_deep
        if super_context_prefix:
            effective_message = f"{super_context_prefix}\n\n[User message]\n{effective_message}"
        if recalled_context:
            effective_message = effective_message + recalled_context

        # Run the real tool-calling loop — get both the final text AND
        # the transcript of tool calls so we can record a tool-aware
        # history entry.
        reply, transcript = await self.tool_calling_agent.run_with_transcript(
            user_message=effective_message,
            history=history,
            session_id=sid,
        )

        # Record the turn so future calls remember it.  If tools were
        # called, prepend a compact one-line summary so the model on the
        # next turn knows what it did.  This is the fix for the
        # "I did not perform a web search" hallucination — the model
        # was telling the truth based on the text-only history it could
        # see; it just didn't remember the tool calls because they
        # weren't in the recorded history.
        recorded_reply = reply
        if transcript:
            tool_summary = _format_tool_transcript_for_history(transcript)
            recorded_reply = f"{tool_summary}\n\n{reply}"

        if self.executor is not None:
            self.executor._record_turn(sid, user_message, recorded_reply)

        # ── v5: Write episodic memory for this chat turn ─────────────────
        # Promote the chat turn into long-term episodic memory so future
        # sessions (and run() tasks) can recall it. This closes the loop:
        # chat now reads AND writes long-term memory, same as run().
        if self.memory is not None:
            try:
                from adonai.core.models import Memory, MemoryType
                await self.memory.add(Memory(
                    type=MemoryType.EPISODIC,
                    content=f"User: {user_message[:500]}\nAssistant: {reply[:500]}",
                    importance=0.4,  # chat turns are lower-importance than task results
                    confidence=0.8,
                    source="chat",
                    tags=["chat", sid],
                    metadata={"session_id": sid, "channel": "chat"},
                ))
            except Exception as e:
                log.debug("Chat episodic memory write failed (non-fatal): %s", e)

        # ── v5: Update knowledge graph from chat content ─────────────────
        # Extract entities/relations from the user message + reply so the
        # KG accumulates user facts over time. Previously the KG was only
        # updated from the LearningLoop (run path), so chat content never
        # enriched it.
        # v6 fix: removed the session_id= kwarg — extract_from_text() doesn't
        # accept it (its signature is (text, *, source, source_kind, max_entities)).
        # This was a silent TypeError on every chat turn, caught by the broad
        # except and logged at debug level — KG was never enriched from chat.
        if self.memory is not None and hasattr(self.memory, 'kg') and self.memory.kg is not None:
            try:
                kg_text = f"{user_message}\n{reply}"
                await self.memory.kg.extract_from_text(
                    kg_text, source=f"chat:{sid}", source_kind="chat",
                )
            except Exception as e:
                log.debug("Chat KG extraction failed (non-fatal): %s", e)

        # Observability: bump chat counter so /metrics has real data.
        # v6 fix: removed the per-session UUID from labels — it caused
        # unbounded counter growth (100k chats = 200k permanent entries,
        # all flushed to SQLite every 60s). Now we use a fixed label set.
        if self.metrics is not None:
            try:
                self.metrics.counter("adonai_chat_total").inc()
                if transcript:
                    self.metrics.counter("adonai_tool_calls_total").inc(
                        sum(1 for t in transcript)
                    )
            except Exception as _nf932:
                log.debug("Non-fatal: %s", _nf932)
        return reply

    async def _run_task(self, task: Task) -> TaskResult:
        """Internal: plan + execute a task.

        First checks if a specialist agent (scientist, file_analyst, etc.)
        should handle the task.  If so, delegates directly to that agent.
        Otherwise, falls through to the normal planner → executor pipeline.
        """
        if self.planner is None or self.executor is None:
            raise AdonaiError("ADONAI not started")
        task.status = TaskStatus.RUNNING
        task.started_at = datetime.now(timezone.utc)

        # Emit task.started event for subscribers (analytics, audit, etc.).
        from adonai.core.events import Event, EventTypes
        await self.events.publish(Event(
            type=EventTypes.TASK_STARTED,
            payload={"task_id": task.id, "goal": task.goal[:200]},
            source="ADONAI",
        ))

        # ── Early-exit: response cache for identical questions ─────────
        # If the exact same goal was asked recently and the result was
        # successful, return the cached response immediately without
        # going through the full planning → execution pipeline.
        # This saves 7-15+ LLM calls for repeated simple queries.
        _cache_key = f"run_cache::{task.goal.strip().lower()[:200]}"
        _cached = getattr(self, "_response_cache", {})
        if _cached.get(_cache_key) is not None:
            cached_entry = _cached[_cache_key]
            if isinstance(cached_entry, dict) and cached_entry.get("status") == TaskStatus.COMPLETED.value:
                log.info(
                    "Response cache HIT for goal '%s' — returning cached result "
                    "(saved ~%d LLM calls)",
                    task.goal[:80], cached_entry.get("saved_llm_calls", 10),
                )
                return TaskResult(
                    task_id=task.id, status=TaskStatus.COMPLETED,
                    output=cached_entry.get("output"),
                    confidence=0.9,
                    steps_executed=0,
                    duration_s=0.0,
                )

        # ── Agent routing ────────────────────────────────────────────────
        # Check if a specialist agent (scientist, file_analyst, etc.)
        # should handle the task.  Only
        # delegate to agents that have their OWN run() implementation
        # (not inherited from BaseAgent, which calls parent.run() and
        # would cause infinite recursion).
        if self.agents is not None:
            from adonai.agents.base import BaseAgent
            # Score every eligible agent so we can decide between
            # single-agent routing, multi-agent consensus, or planner fallback.
            eligible: list[tuple[float, "BaseAgent"]] = []
            for agent in self.agents.list_agents():
                if agent.name == "executive":
                    continue  # executive is the fallback, not a specialist
                # Skip agents that inherit BaseAgent.run() without
                # overriding it — they'd call parent.run() → _run_task()
                # → route again → infinite recursion.
                if type(agent).run is BaseAgent.run:
                    continue
                try:
                    score = agent.can_handle(task.goal)
                except Exception:
                    score = 0.0
                if score > 0:
                    eligible.append((score, agent))
            eligible.sort(key=lambda t: t[0], reverse=True)

            # Multi-agent consensus path: when 2+ agents agree they can
            # handle the task (each scoring ≥ 0.6), run them in parallel
            # and synthesise their outputs via the ConsensusBuilder.
            # This activates the previously-dead ConsensusBuilder and
            # produces higher-quality answers for ambiguous requests
            # that span multiple domains.
            multi_agent_enabled = bool(
                getattr(self.config.agent, "enable_multi_agent", False)
            )
            if (
                multi_agent_enabled
                and self.consensus is not None
                and len(eligible) >= 2
                and eligible[0][0] >= 0.6
                and eligible[1][0] >= 0.6
            ):
                try:
                    return await self._run_multi_agent(task, eligible[:3])
                except Exception as e:
                    log.warning(
                        "Multi-agent consensus failed (%s) — falling back "
                        "to single-agent routing",
                        e,
                    )

            if eligible and eligible[0][0] >= 0.7:
                best_score, best_agent = eligible[0]
                log.info(
                    "Routing task %s to specialist agent '%s' (score=%.2f)",
                    task.id, best_agent.name, best_score,
                )
                task.assigned_agent = best_agent.name
                try:
                    result = await best_agent.run(task)
                    # Post to Blackboard so other agents can read this result.
                    try:
                        await self.blackboard.post(
                            agent=best_agent.name,
                            key="task_result",
                            value={
                                "task_id": task.id,
                                "status": result.status.value,
                                "output": result.output,
                                "confidence": result.confidence,
                            },
                            task_id=task.id,
                        )
                    except Exception as _nf1030:
                        log.debug("Non-fatal: %s", _nf1030)  # non-fatal
                    # Record to conversation history if we have a session.
                    if task.session_id and self.executor is not None:
                        reply = result.output if result.output is not None else (
                            f"[error] {result.error}" if result.error else "[no response]"
                        )
                        self.executor._record_turn(task.session_id, task.goal, str(reply))
                    # Persist final status.
                    if self.checkpoints is not None:
                        try:
                            await self.checkpoints.update_task_status(
                                task.id, result.status, result.output,
                            )
                        except Exception as _nf1044:
                            log.debug("Non-fatal: %s", _nf1044)
                    # Submit to learning loop.
                    if self.learning_loop is not None:
                        try:
                            await self.learning_loop.submit(task, None, result)
                        except Exception as _nf1050:
                            log.debug("Non-fatal: %s", _nf1050)
                    return result
                except Exception as e:
                    log.warning(
                        "Specialist agent '%s' failed (%s) — falling back to planner",
                        best_agent.name, e,
                    )

        # ── Normal planner → executor pipeline ───────────────────────────
        # ── PERF OPT: Skip ModelRouter for TRIVIAL/SIMPLE tasks ──────
        # These tasks need exactly one LLM call — routing adds latency
        # without benefit when only one model tier exists.
        if task.complexity.value not in ("trivial", "simple") and self.model_router is not None:
            try:
                route = await self.model_router.route(task=task)
                # v6 fix: route.tier → route.model_tier (the attribute is
                # named model_tier on ModelRoute, not tier). Previously this
                # raised AttributeError, silently swallowed by the except,
                # so the routing decision was never logged.
                _tier = getattr(route, "model_tier", None) or getattr(route, "tier", None)
                _tier_val = _tier.value if hasattr(_tier, "value") else _tier
                log.debug(
                    "ModelRouter routed task %s to tier=%s rationale=%s",
                    task.id, _tier_val,
                    (route.rationale[:80] if route.rationale else ""),
                )
            except Exception as e:
                log.debug("ModelRouter.route failed (non-fatal): %s", e)
        else:
            log.debug(
                "ModelRouter: skipping for task %s (complexity=%s) — PERF OPT",
                task.id, task.complexity.value,
            )

        # v5 — Prompt Engineering Node (FIRST STAGE), gated by domain.
        # The node is designed for software-engineering requests
        # ("build a REST API", "write a CLI tool", "design a system").
        # Running it on every request — especially chat / search / Q&A —
        # rewrites the user's goal into a multi-page engineering spec,
        # which then breaks the planner's keyword-based fallback
        # heuristic (the keywords "search", "latest", "news" get buried
        # in spec boilerplate) and the LLM never sees a recognisable
        # search request, so web_search is never invoked.
        #
        # Fix: only run the node when the request looks like a software
        # engineering task. For everything else, pass the raw goal
        # through unchanged so the planner's greeting/search/code
        # heuristics can fire correctly.
        if self.prompt_engineer is not None and _looks_like_engineering_request(task.goal):
            try:
                prompt_package = await self.prompt_engineer.engineer(
                    task.goal, context=dict(task.context or {}),
                )
                task.context["prompt_package"] = prompt_package
                # Attach the engineered prompt as context, but do NOT
                # overwrite task.goal. The planner/executor still see
                # the user's original request; the engineered spec is
                # available as a hint for the coder agent.
                task.context["engineered_prompt"] = prompt_package.engineered_prompt
                log.info(
                    "PromptEngineering: %s for task %s",
                    prompt_package.summary(), task.id,
                )
            except Exception as e:
                log.debug(
                    "PromptEngineeringNode failed (non-fatal, using raw goal): %s", e,
                )

        # Pre-planning reasoning enrichment (best-effort).  The
        # ReasoningEngine picks a strategy (CoT/ToT/self-consistency/debate)
        # based on task complexity and stores its conclusion in
        # task.context["reasoning"] so the planner / executor can use it.
        # v9 fix: gate on task complexity so TRIVIAL/SIMPLE tasks skip
        # the 1-4 LLM setup calls. Previously the engine ran on every
        # task including TRIVIAL ones (single LLM call) and SIMPLE ones
        # (1-3 tool calls) — adding 1-4 extra LLM calls per task that
        # almost never changed the plan for trivial work. The strategy
        # picker (engine.py:67-115) only ever returns CoT for TRIVIAL
        # and SIMP for SIMPLE anyway, and a single CoT call adds ~30s
        # on a small model — pure overhead for tasks that don't need it.
        if self.reasoning is not None and task.complexity.value not in ("trivial", "simple"):
            try:
                reasoning_result = await self.reasoning.reason(task, context={})
                task.context["reasoning"] = reasoning_result
                log.info(
                    "ReasoningEngine: confidence=%.2f for task %s (complexity=%s)",
                    reasoning_result.get("confidence", 0.0),
                    task.id, task.complexity.value,
                )
            except Exception as e:
                log.debug("ReasoningEngine enrichment failed (non-fatal): %s", e)
        elif self.reasoning is not None:
            log.debug(
                "ReasoningEngine: skipping for task %s (complexity=%s)",
                task.id, task.complexity.value,
            )

        # v9 fix: proactive discovery — when ``config.discovery.autonomous``
        # is True, the runtime may invoke the HypothesisGenerator for
        # COMPLEX/OPEN_ENDED tasks whose goal matches a science/research
        # domain signal. Generated hypotheses are stashed in
        # task.context["hypotheses"] so the planner can use them as
        # additional context (the planner's _build_user_prompt already
        # surfaces task.context values to the LLM). Previously the
        # HypothesisGenerator was reachable ONLY via POST /hypotheses or
        # the ScientificDiscoveryAgent — never proactively from the
        # standard run path. Default False (opt-in) since this adds an
        # LLM call per qualifying task.
        discovery_cfg = getattr(self.config, "discovery", None)
        if (
            discovery_cfg is not None
            and getattr(discovery_cfg, "autonomous", False)
            and self.hypothesis_generator is not None
            and task.complexity.value in ("complex", "open_ended")
        ):
            try:
                signals = getattr(discovery_cfg, "domain_signals", []) or []
                goal_lower = task.goal.lower()
                if any(sig in goal_lower for sig in signals):
                    max_hyp = getattr(discovery_cfg, "max_hypotheses_per_task", 3)
                    hypotheses = await self.hypothesis_generator.generate(
                        observation=task.goal,
                        domain="science",
                        max_hypotheses=max_hyp,
                        context=dict(task.context or {}),
                    )
                    if hypotheses:
                        # Store as plain dicts so the planner's prompt
                        # builder can serialise them without needing
                        # the Hypothesis pydantic model.
                        task.context["hypotheses"] = [
                            getattr(h, "model_dump", lambda: None)() or
                            {
                                "statement": getattr(h, "statement", str(h)),
                                "falsifiability": getattr(h, "falsifiability_score", None),
                                "prior": getattr(h, "prior_probability", None),
                            }
                            for h in hypotheses
                        ]
                        log.info(
                            "Discovery: generated %d hypothesis/hypotheses for "
                            "task %s (autonomous mode, complexity=%s)",
                            len(hypotheses), task.id, task.complexity.value,
                        )
            except Exception as e:
                log.debug("Autonomous discovery generation failed (non-fatal): %s", e)

        # Plan.
        # v5 fix: pass task.context (which contains "reasoning" and
        # "engineered_prompt" from the pre-planning stages above) into the
        # planner so its _build_user_prompt can surface them as labeled
        # blocks. Previously plan() was called with no context argument, so
        # the reasoning/engineering LLM calls ran but their output was
        # silently discarded — 2-4 wasted LLM calls per run() task.
        # v8: Planner retry — the planner can fail on LLM errors (JSON
        # parse failure, timeout).  Retry once before giving up.
        plan = None
        for _planner_attempt in range(2):
            try:
                plan = await self.planner.plan(task, context=dict(task.context or {}))
                break
            except Exception as e:
                log.error("Planner attempt %d raised: %s", _planner_attempt + 1, e, exc_info=True)
                if _planner_attempt == 0:
                    continue
                # Both attempts failed — return a single-step fallback plan.
                log.warning("Planner failed twice — using single-step fallback")
                from adonai.planning.planner import Plan, PlanStep
                from adonai.core.models import VerificationType
                plan = Plan(
                    task_id=task.id, goal=task.goal,
                    steps=[PlanStep(
                        description=f"Respond to: {task.goal}",
                        tool=None, parameters={},
                        expected_outcome="A direct response to the user's goal",
                        risk_level="low",
                        verification_type=VerificationType.UNVERIFIED,
                    )],
                    strategy="fallback: planner failed twice",
                    confidence=0.2,
                )

        # Execute — wrapped in the watchdog so hung tasks are cancelled.
        if self.watchdog is not None:
            result = await self.watchdog.run_with_timeout(
                task, self.executor.execute, task, plan,
                timeout_s=getattr(task, "max_duration_s", None),
            )
        else:
            result = await self.executor.execute(task, plan)

        # Post to Blackboard so other agents / subscribers can read.
        try:
            await self.blackboard.post(
                agent="planner_executor_pipeline",
                key="task_result",
                value={
                    "task_id": task.id,
                    "status": result.status.value,
                    "output": result.output,
                    "confidence": result.confidence,
                },
                task_id=task.id,
            )
        except Exception as _nf1191:
            log.debug("Non-fatal: %s", _nf1191)  # non-fatal

        # Persist final status.
        if self.checkpoints is not None:
            try:
                await self.checkpoints.update_task_status(task.id, result.status, result.output)
            except Exception as e:
                log.debug("Final status persist failed: %s", e)

        # Submit to learning loop (async, non-blocking).
        if self.learning_loop is not None:
            try:
                await self.learning_loop.submit(task, plan, result)
            except Exception as e:
                log.debug("LearningLoop submit failed: %s", e)

        # Emit task.completed / task.failed event.
        try:
            event_type = (
                EventTypes.TASK_COMPLETED if result.status == TaskStatus.COMPLETED
                else EventTypes.TASK_FAILED
            )
            await self.events.publish(Event(
                type=event_type,
                payload={
                    "task_id": task.id,
                    "status": result.status.value,
                    "duration_s": result.duration_s,
                    "steps_executed": result.steps_executed,
                    "confidence": result.confidence,
                    "error": result.error,
                },
                source="ADONAI",
            ))
        except Exception as e:
            log.debug("Task event emit failed (non-fatal): %s", e)

        # ── PERF OPT: Write successful results to the response cache ──
        # Cache the output so identical questions skip the pipeline.
        # Only cache COMPLETED results with non-empty output.
        # Use an LRU-like dict capped at 50 entries to prevent unbounded growth.
        if result.status == TaskStatus.COMPLETED and result.output and len(str(result.output)) < 10000:
            _cache_key = f"run_cache::{task.goal.strip().lower()[:200]}"
            if not hasattr(self, "_response_cache"):
                self._response_cache: dict[str, dict] = {}
            # LRU: if cache exceeds 50, remove oldest 10
            if len(self._response_cache) >= 50:
                # Remove first 10 entries (approximate LRU)
                for _ in range(10):
                    if self._response_cache:
                        self._response_cache.pop(next(iter(self._response_cache)), None)
            self._response_cache[_cache_key] = {
                "output": result.output,
                "status": TaskStatus.COMPLETED.value,
                "saved_llm_calls": 10,  # estimate
            }
            log.debug(
                "Response cache: stored result for '%s' (cache size=%d)",
                task.goal[:80], len(self._response_cache),
            )

        return result

    # ------------------------------------------------------------------ #
    # Background-task introspection
    # ------------------------------------------------------------------ #

    async def get_task_status(self, task_id: str) -> dict[str, Any] | None:
        if self.scheduler is not None:
            return await self.scheduler.status(task_id)
        return None

    async def cancel_task(self, task_id: str) -> bool:
        if self.scheduler is not None:
            return await self.scheduler.cancel(task_id)
        return False

    async def list_tasks(self) -> list[dict[str, Any]]:
        if self.scheduler is not None:
            return await self.scheduler.list_all()
        return []

    async def list_skills(self) -> list:
        if self.skills is not None:
            return await self.skills.list_all()
        return []

    async def clear_conversation(self, session_id: str | None = None) -> None:
        if self.executor is not None:
            self.executor.clear_conversation(session_id)

    async def get_conversation(self, session_id: str) -> list[dict[str, str]]:
        if self.executor is not None:
            return self.executor._get_history(session_id)
        return []

    # ------------------------------------------------------------------ #
    # v4 — Research-grade public API
    # ------------------------------------------------------------------ #

    async def critique(
        self,
        goal: str | Task,
        target: Any,
        *,
        target_kind: str = "result",
    ) -> Any:
        """Run the Critic on an arbitrary target.

        Returns a :class:`~adonai.core.models.CritiqueReport`.
        """
        if self.critic is None:
            raise AdonaiError("Critic not enabled (config.critic.enabled=False)")
        task = goal if isinstance(goal, Task) else Task(goal=str(goal))
        return await self.critic.critique(task, target, target_kind=target_kind)

    async def debate(
        self,
        question: str,
        *,
        rounds: int | None = None,
        participants: list[str] | None = None,
    ) -> Any:
        """Run a multi-agent debate; returns a :class:`~adonai.core.models.Debate`."""
        if self.debate_framework is None:
            raise AdonaiError("Debate framework not enabled")
        return await self.debate_framework.debate(
            question, rounds=rounds or 2, participants=participants,
        )

    async def generate_hypotheses(
        self,
        observation: str,
        *,
        domain: str | None = None,
        max_hypotheses: int = 3,
    ) -> list:
        """Generate falsifiable hypotheses from an observation."""
        if self.hypothesis_generator is None:
            raise AdonaiError("Hypothesis generator not enabled")
        return await self.hypothesis_generator.generate(
            observation, domain=domain, max_hypotheses=max_hypotheses,
        )

    async def run_experiment_loop(
        self,
        goal: str,
        *,
        max_iterations: int = 10,
        confidence_threshold: float = 0.85,
        resource_budget_s: float | None = None,
    ) -> dict[str, Any]:
        """Run the autonomous experiment loop until convergence."""
        if self.experiment_loop is None:
            raise AdonaiError("Experiment loop not enabled")
        return await self.experiment_loop.run(
            goal,
            max_iterations=max_iterations,
            confidence_threshold=confidence_threshold,
            resource_budget_s=resource_budget_s,
        )

    async def decompose_strategy(
        self, mission: str, *, depth: int = 3,
    ) -> list:
        """Decompose a mission into a strategic→tactical→task goal hierarchy."""
        if self.strategic_reasoner is None:
            raise AdonaiError("Strategic reasoner not enabled")
        return await self.strategic_reasoner.decompose(mission, depth=depth)

    async def run_simulation(self, spec: Any) -> Any:
        """Run a simulation via the Simulation Abstraction Layer."""
        if self.simulators is None:
            raise AdonaiError("Simulation layer not enabled")
        return await self.simulators.run(spec)

    async def recall_lessons(
        self, *, domain: str | None = None, top_k: int = 10,
    ) -> list:
        """Recall past lessons from the Reflection Engine."""
        if self.reflection_engine is None:
            return []
        return await self.reflection_engine.recall_lessons(
            domain=domain, top_k=top_k,
        )

    async def self_improve(
        self, force: bool = False, dry_run: bool = False,
    ) -> dict[str, Any]:
        """Run one self-improvement cycle (observe → propose → patch → verify).

        Args:
            force: If True, run even if recent success rate is above the
                auto-trigger threshold. Useful for manual invocation via
                POST /self-improve.
            dry_run: If True, run observe + propose only — skip the sandbox,
                regression, verify, and merge stages. Returns the proposed
                patches without applying them.
        """
        if self.self_improvement is None:
            raise AdonaiError("Self-improvement not enabled (config.self_improvement.enabled=False)")
        bottlenecks = await self.self_improvement.observe_bottlenecks(
            self.analytics, tool_registry=self.tools,
        )
        results: list[dict[str, Any]] = []
        for bn in bottlenecks:
            try:
                if dry_run:
                    # Propose only — no sandbox/regression/merge.
                    patch = await self.self_improvement.propose_patch(bn)
                    results.append({
                        "bottleneck": bn,
                        "patch_id": patch.id,
                        "status": "proposed (dry-run)",
                        "target_file": patch.target_file,
                        "rationale": patch.rationale,
                        "risk_score": patch.risk_score,
                    })
                else:
                    patch = await self.self_improvement.run_pipeline(bn)
                    results.append({
                        "bottleneck": bn,
                        "patch_id": patch.id,
                        "status": patch.status.value,
                        "target_file": patch.target_file,
                    })
            except Exception as e:
                log.warning("Self-improvement pipeline failed: %s", e)
                results.append({"bottleneck": bn, "error": str(e)})
        return {
            "bottlenecks": bottlenecks,
            "patches": results,
            "force": force,
            "dry_run": dry_run,
        }

    # ------------------------------------------------------------------ #
    # Internals
    # ------------------------------------------------------------------ #

    async def _run_multi_agent(
        self,
        task: Task,
        eligible: list[tuple[float, Any]],
    ) -> TaskResult:
        """Run multiple specialist agents in parallel and synthesise their
        outputs via the ConsensusBuilder.

        Activates the previously-dead ConsensusBuilder and the multi-agent
        collaboration subsystem.  Returns a TaskResult whose ``output`` is
        the consensus synthesis; ``confidence`` is the mean of the
        individual confidences; ``steps_executed`` counts the agent runs.

        Args:
            task: The task to run.
            eligible: Ordered list of (score, agent) tuples — top N will
                actually be invoked (default 3, capped at 4).
        """
        import asyncio as _asyncio
        from adonai.core.models import TaskResult, TaskStatus
        agents_to_run = [a for _, a in eligible[:4]]
        log.info(
            "Multi-agent consensus: running %d agents (%s) for task %s",
            len(agents_to_run),
            ", ".join(a.name for a in agents_to_run),
            task.id,
        )
        # Run all agents concurrently.
        results = await _asyncio.gather(
            *(a.run(task) for a in agents_to_run),
            return_exceptions=True,
        )
        # Collect successful outputs + record failures on the blackboard.
        outputs: list[str] = []
        agent_names: list[str] = []
        confidences: list[float] = []
        errors: list[str] = []
        for agent, res in zip(agents_to_run, results):
            if isinstance(res, Exception):
                errors.append(f"{agent.name}: {type(res).__name__}: {res}")
                log.warning(
                    "Multi-agent: agent '%s' raised: %s", agent.name, res,
                )
                continue
            if res.status == TaskStatus.COMPLETED and res.output is not None:
                outputs.append(str(res.output))
                agent_names.append(agent.name)
                confidences.append(float(res.confidence or 0.0))
                # Post each agent's result so subscribers see them.
                try:
                    await self.blackboard.post(
                        agent=agent.name, key="multi_agent_result",
                        value={
                            "task_id": task.id,
                            "output": res.output,
                            "confidence": res.confidence,
                        },
                        task_id=task.id,
                    )
                except Exception as _nf1467:
                    log.debug("Non-fatal: %s", _nf1467)
            else:
                errors.append(
                    f"{agent.name}: status={res.status.value} error={res.error}"
                )

        if not outputs:
            # All agents failed — surface the collective error.
            return TaskResult(
                task_id=task.id, status=TaskStatus.FAILED,
                error="all multi-agent runs failed: " + "; ".join(errors),
                duration_s=0.0,
            )

        # If only one agent succeeded, skip consensus and return its output.
        if len(outputs) == 1:
            return TaskResult(
                task_id=task.id, status=TaskStatus.COMPLETED,
                output=outputs[0],
                confidence=confidences[0] if confidences else 0.5,
                steps_executed=1,
                duration_s=0.0,
            )

        # Consensus synthesis — uses self.consensus (ConsensusBuilder).
        try:
            consensus_text = await self.consensus.build(
                task.goal, outputs, agents=agent_names,
            )
        except Exception as e:
            log.warning(
                "ConsensusBuilder.build failed (%s) — falling back to longest output",
                e,
            )
            consensus_text = max(outputs, key=len)

        # Record to conversation history if we have a session.
        if task.session_id and self.executor is not None:
            self.executor._record_turn(
                task.session_id, task.goal, str(consensus_text),
            )

        return TaskResult(
            task_id=task.id, status=TaskStatus.COMPLETED,
            output=consensus_text,
            confidence=(
                sum(confidences) / len(confidences) if confidences else 0.5
            ),
            steps_executed=len(outputs),
            duration_s=0.0,
        )

    async def _warmup_llm(self) -> None:
        resp = await self.llm.complete(
            messages=[{"role": "user", "content": "ping"}],
            temperature=0.0, max_tokens=5,
        )
        log.info(
            "LLM warmup complete  tokens_in=%d  tokens_out=%d",
            resp.tokens_in, resp.tokens_out,
        )

    def _agent_facade(self):
        """Build a minimal facade that sub-agents can call back into."""
        outer = self

        class _Facade:
            llm = outer.llm
            tools = outer.tools
            memory = outer.memory
            config = outer.config
            agent_registry = None  # set after agents are built
            async def run(self, task: Task) -> TaskResult:
                return await outer._run_task(task)

        facade = _Facade()
        # Wire up the registry after creation.
        facade.agent_registry = self.agents
        return facade

    async def _scheduler_agent(self, task: Task) -> TaskResult:
        """Adapter so TaskScheduler can call back into _run_task."""
        return await self._run_task(task)

    # ------------------------------------------------------------------ #
    # v4 — Research-grade subsystem startup
    # ------------------------------------------------------------------ #

    async def _start_v4_subsystems(self) -> None:
        """Construct + wire all v4 research-grade subsystems.

        All subsystems are best-effort: failures are logged but never
        fatal.  Each subsystem is gated by its own config flag (e.g.
        ``config.critic.enabled``).
        """
        # ── Upgrade 1: Critic Agent ──────────────────────────────────────
        if self.config.critic.enabled:
            try:
                from adonai.agents.critic import CriticAgent
                self.critic = CriticAgent(llm=self.llm, config=self.config)
                self.container.register_instance("critic", self.critic)
                log.info("v4: Critic agent enabled")
            except Exception as e:
                log.warning("v4: Critic init failed: %s", e)

        # ── Upgrade 9: Model Router ──────────────────────────────────────
        if self.config.model_router.enabled:
            try:
                # v9 fix: construct DefaultModelRouter (not PassthroughRouter)
                # so the 260-LOC routing logic (latency EMA, quality tracking,
                # tier downgrade, capability routing) actually executes.
                # We build per-tier LLM clients from the config's tier
                # definitions; if a tier's backend differs from the primary
                # LLM's backend, we attempt to construct a client for it.
                # If construction fails for any tier, we fall back to using
                # the primary self.llm for all tiers (still routes by tier,
                # just with the same underlying client).
                from adonai.llm.router import DefaultModelRouter, PassthroughRouter
                from adonai.llm.factory import build_llm_client
                from adonai.core.models import ModelTier
                from adonai.config.settings import LLMConfig

                tier_clients: dict = {}
                tier_configs = getattr(self.config.model_router, "tiers", {}) or {}
                if tier_configs:
                    for tier_name, tier_cfg in tier_configs.items():
                        try:
                            tier_enum = ModelTier(tier_name)
                        except ValueError:
                            continue
                        # Try to build a dedicated client for this tier.
                        # If the tier config matches the primary LLM,
                        # reuse self.llm (no extra connection).
                        backend = tier_cfg.get("backend")
                        model_name = tier_cfg.get("model_name")
                        primary_backend = getattr(self.config.llm, "backend", None)
                        primary_model = getattr(self.config.llm, "model_name", None)
                        if backend == primary_backend and model_name == primary_model:
                            tier_clients[tier_enum] = self.llm
                        else:
                            try:
                                tier_llm_cfg = LLMConfig(
                                    backend=backend,
                                    model_name=model_name,
                                    base_url=getattr(self.config.llm, "base_url", "http://localhost:11434"),
                                    api_key=getattr(self.config.llm, "api_key", None),
                                    temperature=getattr(self.config.llm, "temperature", 0.7),
                                    max_tokens=getattr(self.config.llm, "max_tokens", 2048),
                                    request_timeout=getattr(self.config.llm, "request_timeout", 300.0),
                                )
                                tier_clients[tier_enum] = build_llm_client(tier_llm_cfg)
                            except Exception as tier_e:
                                log.debug(
                                    "v9: could not build dedicated client for tier %s "
                                    "(falling back to primary LLM): %s",
                                    tier_name, tier_e,
                                )
                                tier_clients[tier_enum] = self.llm

                if tier_clients:
                    self.model_router = DefaultModelRouter(
                        tier_clients, config=self.config,
                    )
                    log.info(
                        "v9: Model router enabled (DefaultModelRouter, %d tier(s))",
                        len(tier_clients),
                    )
                else:
                    # No tier configs — fall back to PassthroughRouter.
                    self.model_router = PassthroughRouter(self.llm, config=self.config)
                    log.info("v4: Model router enabled (passthrough — no tier configs)")
                self.container.register_instance("model_router", self.model_router)
            except Exception as e:
                log.warning("v4: Model router init failed: %s", e)
                # Fallback: use PassthroughRouter so the rest of the runtime
                # still has a model_router attribute.
                try:
                    from adonai.llm.router import PassthroughRouter
                    self.model_router = PassthroughRouter(self.llm, config=self.config)
                except Exception:
                    self.model_router = None

        # ── Upgrade 4: Reflection Engine ─────────────────────────────────
        if self.config.reflection.enabled:
            try:
                from adonai.reasoning.reflection_engine import (
                    DefaultReflectionEngine,
                )
                self.reflection_engine = DefaultReflectionEngine(
                    llm=self.llm, config=self.config,
                )
                self.container.register_instance(
                    "reflection_engine", self.reflection_engine,
                )
                log.info("v4: Reflection engine enabled")
            except Exception as e:
                log.warning("v4: Reflection engine init failed: %s", e)

        # ── Upgrade 5: Skill Evolver ─────────────────────────────────────
        if self.config.skill_evolution.enabled:
            try:
                from adonai.skills.evolution import DefaultSkillEvolver
                self.skill_evolver = DefaultSkillEvolver(
                    llm=self.llm,
                    experience_store=getattr(self.learning_loop, "experiences", None) if self.learning_loop else None,
                    skill_manager=self.skills,
                    tool_registry=self.tools,
                    config=self.config,
                    memory_manager=self.memory,
                    # v9 fix: pass a runtime reference so verify_skill
                    # can replay held-out experiences through the full
                    # runtime pipeline (planner→executor→skill) instead
                    # of faking a pass with a trivial Task(goal=…).
                    runtime=self,
                )
                self.container.register_instance(
                    "skill_evolver", self.skill_evolver,
                )
                log.info("v4: Skill evolver enabled")
            except Exception as e:
                log.warning("v4: Skill evolver init failed: %s", e)

        # ── Upgrade 6: Multi-Agent Debate Framework ──────────────────────
        if self.config.debate.enabled:
            try:
                from adonai.collaboration.debate import DefaultDebateFramework
                # v9 fix: construct a real VotingSystem and pass it to the
                # debate framework. Previously this was hardcoded to None
                # (comment: "v8: was self.voting (unused elsewhere)"),
                # which made the formal-vote branches in debate.py:193-205
                # and 220-234 unreachable dead code. Wiring a real
                # VotingSystem here activates the per-stance vote casting
                # + tally that the Debate metadata exposes to downstream
                # consumers (UI, /debates API, audit logs).
                self.voting = VotingSystem()
                self.debate_framework = DefaultDebateFramework(
                    llm=self.llm, config=self.config,
                    voting_system=self.voting,
                )
                self.container.register_instance(
                    "debate_framework", self.debate_framework,
                )
                self.container.register_instance("voting_system", self.voting)
                log.info("v4: Debate framework enabled (voting system wired)")
            except Exception as e:
                log.warning("v4: Debate framework init failed: %s", e)

        # ── Upgrade 11: Simulation Abstraction Layer ─────────────────────
        if self.config.simulation.enabled:
            try:
                from adonai.simulation import build_default_registry
                self.simulators = build_default_registry(self.config)
                self.container.register_instance("simulators", self.simulators)
                log.info(
                    "v4: Simulation layer enabled (backends: %s)",
                    self.simulators.list_simulators(),
                )
            except Exception as e:
                log.warning("v4: Simulation layer init failed: %s", e)

        # ── Upgrade 7: Hypothesis Generator ──────────────────────────────
        if self.config.hypothesis.enabled:
            try:
                from adonai.discovery.hypothesis import DefaultHypothesisGenerator
                self.hypothesis_generator = DefaultHypothesisGenerator(
                    llm=self.llm, config=self.config,
                    simulator_registry=self.simulators,
                )
                self.container.register_instance(
                    "hypothesis_generator", self.hypothesis_generator,
                )
                log.info("v4: Hypothesis generator enabled")
            except Exception as e:
                log.warning("v4: Hypothesis generator init failed: %s", e)

        # ── Upgrade 8: Autonomous Experiment Loop ────────────────────────
        if self.config.experiment_loop.enabled and self.hypothesis_generator is not None:
            try:
                from adonai.discovery.experiment_loop import DefaultExperimentLoop
                from adonai.discovery.experiment_loop_store import ExperimentLoopStore
                # Wire SQLite persistence so loops survive restarts.
                loop_store = ExperimentLoopStore(
                    self.config.database.experiment_loops_db
                )
                self.experiment_loop = DefaultExperimentLoop(
                    self.hypothesis_generator,
                    llm=self.llm,
                    reflection_engine=self.reflection_engine,
                    simulator_registry=self.simulators,
                    config=self.config,
                    store=loop_store,
                )
                self.container.register_instance(
                    "experiment_loop", self.experiment_loop,
                )
                log.info("v4: Experiment loop enabled (persistence: on)")
            except Exception as e:
                log.warning("v4: Experiment loop init failed: %s", e)

        # ── Upgrade 10: Self-Improvement + Safety Guard ──────────────────
        try:
            from adonai.safety.self_improvement import (
                DefaultSafetyGuard, SelfImprovementEngine,
            )
            self.safety_guard = DefaultSafetyGuard(
                config=self.config, critic=self.critic,
            )
            self.container.register_instance("safety_guard", self.safety_guard)
            if self.config.self_improvement.enabled:
                self.self_improvement = SelfImprovementEngine(
                    llm=self.llm, config=self.config,
                    safety_guard=self.safety_guard,
                )
                # Wire the ExperienceStore so maybe_auto_improve() can
                # actually look up recent task outcomes.  Without this,
                # _list_recent_experiences() always returns [] and the
                # auto-improvement trigger never fires.
                if self.learning_loop is not None:
                    try:
                        self.self_improvement._experience_store = (
                            getattr(self.learning_loop, "experiences", None)
                        )
                        # v5: wire the engine into the LearningLoop so
                        # maybe_auto_improve() is actually called after
                        # each task. Previously the engine was constructed
                        # but never invoked — maybe_auto_improve() had
                        # zero callers.
                        self.learning_loop.self_improvement_engine = self.self_improvement
                    except Exception as e:
                        log.debug("ExperienceStore wiring failed: %s", e)
                self.container.register_instance(
                    "self_improvement", self.self_improvement,
                )
                log.info("v4: Self-improvement engine enabled (v5: wired into LearningLoop)")
            log.info("v4: Safety guard enabled")
        except Exception as e:
            log.warning("v4: Safety/self-improvement init failed: %s", e)

        # ── Upgrade 12: Strategic Reasoner ───────────────────────────────
        if self.config.strategy.enabled:
            try:
                from adonai.strategy.hierarchy import DefaultStrategicReasoner
                self.strategic_reasoner = DefaultStrategicReasoner(
                    llm=self.llm, config=self.config,
                )
                self.container.register_instance(
                    "strategic_reasoner", self.strategic_reasoner,
                )
                log.info("v4: Strategic reasoner enabled")
            except Exception as e:
                log.warning("v4: Strategic reasoner init failed: %s", e)

        # ── Upgrade 3: Tree-of-Thought Planner ───────────────────────────
        # Wrap the existing HierarchicalPlanner in a TreeOfThoughtPlanner
        # so plan() generates N candidates.  This preserves the public
        # `self.planner` attribute (still a Planner) while transparently
        # upgrading it.
        if (
            self.config.tot.enabled
            and self.planner is not None
        ):
            try:
                from adonai.planning.tot_planner import TreeOfThoughtPlanner
                self.planner = TreeOfThoughtPlanner(
                    self.planner,
                    branching_factor=self.config.tot.branching_factor,
                    max_depth=self.config.tot.max_depth,
                    parallel_generation=self.config.tot.parallel_generation,
                    knowledge_graph=getattr(self.memory, "kg", None) if self.memory else None,
                    critic=self.critic,
                    config=self.config,
                )
                log.info(
                    "v4: Tree-of-Thought planner enabled (branching=%d)",
                    self.config.tot.branching_factor,
                )
            except Exception as e:
                log.warning("v4: ToT planner init failed: %s", e)

        # ── Wire v4 subsystems into the LearningLoop ─────────────────────
        # The loop was constructed in step 11 with v3-only deps; we now
        # inject the v4 reflection_engine, skill_evolver, and
        # knowledge_graph so the loop's _process() can call them.
        if self.learning_loop is not None:
            try:
                self.learning_loop.reflection_engine = self.reflection_engine
                self.learning_loop.skill_evolver = self.skill_evolver
                self.learning_loop.knowledge_graph = (
                    getattr(self.memory, "kg", None) if self.memory else None
                )
            except Exception as e:
                log.debug("v4 LearningLoop wiring failed (non-fatal): %s", e)

        # ── Wire v4 reflection_engine into the HierarchicalPlanner ───────
        # The planner calls recall_lessons(domain=task.goal, top_k=3) to
        # inject past lessons into the planning prompt.  Without this
        # wiring, the planner's reflection_engine attribute is None and
        # the call site is skipped — lessons are written but never read
        # during planning.
        if self.planner is not None and self.reflection_engine is not None:
            try:
                # The planner may have been wrapped in TreeOfThoughtPlanner;
                # set the attribute on the wrapper (which delegates plan()
                # to the inner HierarchicalPlanner).  Also set on the inner
                # planner if it's accessible (ToT uses `self.base`).
                self.planner.reflection_engine = self.reflection_engine
                inner = getattr(self.planner, "base", None) or getattr(
                    self.planner, "_base", None,
                ) or getattr(self.planner, "planner", None)
                if inner is not None:
                    inner.reflection_engine = self.reflection_engine
                log.debug(
                    "Wired reflection_engine into planner (%s)",
                    type(self.planner).__name__,
                )
            except Exception as e:
                log.debug(
                    "Planner reflection_engine wiring failed (non-fatal): %s", e,
                )

        # v5: Wire the Knowledge Graph into the base planner so
        # _build_user_prompt can call kg.context_for(). Previously only
        # the TreeOfThoughtPlanner queried the KG; the base
        # HierarchicalPlanner never did, so KG data accumulated but was
        # never used in standard planning.
        if self.planner is not None and self.memory is not None:
            try:
                kg = getattr(self.memory, "kg", None)
                if kg is not None:
                    self.planner.knowledge_graph = kg
                    inner = getattr(self.planner, "base", None) or getattr(
                        self.planner, "_base", None,
                    ) or getattr(self.planner, "planner", None)
                    if inner is not None:
                        inner.knowledge_graph = kg
                    log.debug(
                        "Wired knowledge_graph into planner (%s)",
                        type(self.planner).__name__,
                    )
            except Exception as e:
                log.debug(
                    "Planner knowledge_graph wiring failed (non-fatal): %s", e,
                )

        # ── v9 fix: Wire skills_manager into the planner ──────────────
        # The planner checks `if hasattr(self, 'skills_manager') and
        # self.skills_manager is not None:` to fetch evolved skills
        # (list_skills) and find relevant skills (find_skills_for_goal).
        # Without this wiring, extracted/ranked skills are dead data —
        # the SkillRanker, find_skills_for_goal, and find_by_trigger
        # code paths never execute in production.
        if self.planner is not None and self.skills is not None:
            try:
                self.planner.skills_manager = self.skills
                inner = getattr(self.planner, "base", None) or getattr(
                    self.planner, "_base", None,
                ) or getattr(self.planner, "planner", None)
                if inner is not None:
                    inner.skills_manager = self.skills
                log.info(
                    "v9: Wired skills_manager into planner (%s) — "
                    "skill-lookup branch is now active",
                    type(self.planner).__name__,
                )
            except Exception as e:
                log.warning(
                    "Planner skills_manager wiring failed (non-fatal): %s", e,
                )

        # ── v9 fix: Wire strategic_reasoner into the planner ──────────
        # The planner queries `strategic_reasoner.store.get_pending()` to
        # inject active strategic goals into the planning prompt. Without
        # this wiring, the Strategic Reasoner decomposed missions into
        # goals that were persisted to SQLite but NEVER consulted during
        # planning — the goal store was write-only.
        if self.planner is not None and self.strategic_reasoner is not None:
            try:
                self.planner.strategic_reasoner = self.strategic_reasoner
                inner = getattr(self.planner, "base", None) or getattr(
                    self.planner, "_base", None,
                ) or getattr(self.planner, "planner", None)
                if inner is not None:
                    inner.strategic_reasoner = self.strategic_reasoner
                log.info(
                    "v9: Wired strategic_reasoner into planner (%s) — "
                    "strategic goals now feed into planning prompts",
                    type(self.planner).__name__,
                )
            except Exception as e:
                log.warning(
                    "Planner strategic_reasoner wiring failed (non-fatal): %s", e,
                )

        # ── v5: PromptOptimizer + BenchmarkRunner ───────────────────────
        # Previously both were fully implemented (239 + 272 LOC) but NEVER
        # instantiated in production. Now they are constructed here and
        # wired into the LearningLoop so they run periodically.

        # PromptOptimizer — auto-tunes system prompts based on task outcomes.
        if getattr(self.config, "prompt_optimizer", None) and self.config.prompt_optimizer.enabled:
            try:
                from adonai.learning.prompt_optimizer import PromptOptimizer
                self.prompt_optimizer = PromptOptimizer(
                    llm=self.llm,
                    db_path=self.config.prompt_optimizer.db_path,
                    promotion_margin=self.config.prompt_optimizer.promotion_margin,
                    max_variants=self.config.prompt_optimizer.max_variants,
                )
                if self.learning_loop is not None:
                    self.learning_loop.prompt_optimizer = self.prompt_optimizer
                # v7: wire the optimizer into the ToolCallingAgent so its
                # current best variant is actually applied to the agent's
                # system prompt. Previously the optimizer promoted variants
                # but nothing read them back — the feedback loop was broken.
                if self.tool_calling_agent is not None:
                    self.tool_calling_agent.prompt_optimizer = self.prompt_optimizer
                    log.info("v7: wired PromptOptimizer into ToolCallingAgent (feedback loop closed)")
                self.container.register_instance("prompt_optimizer", self.prompt_optimizer)
                log.info("v5: PromptOptimizer enabled (wired into LearningLoop)")
            except Exception as e:
                log.warning("v5: PromptOptimizer init failed: %s", e)

        # BenchmarkRunner — periodically measures agent performance on a
        # fixed suite. Results persist to SQLite so trends survive restarts.
        if getattr(self.config, "benchmark", None) and self.config.benchmark.enabled:
            try:
                from adonai.learning.benchmark import BenchmarkRunner
                self.benchmark_runner = BenchmarkRunner(
                    db_path=self.config.benchmark.db_path,
                )
                if self.learning_loop is not None:
                    self.learning_loop.benchmark_runner = self.benchmark_runner
                self.container.register_instance("benchmark_runner", self.benchmark_runner)
                log.info("v5: BenchmarkRunner enabled (wired into LearningLoop)")
            except Exception as e:
                log.warning("v5: BenchmarkRunner init failed: %s", e)

        # ── v7: Wire safety_guard + critic into the executor ────────────
        # The executor was constructed in _start_impl() before the v4
        # subsystems existed, so its safety_guard and critic slots are
        # still None. We inject them here so the execute pipeline can
        # call review_plan() pre-execution and critique() post-execution.
        # This closes the "Planner → Executor → Critic → Verifier" loop
        # that ARCHITECTURE.md advertises but previously never ran.
        if self.executor is not None:
            try:
                if self.safety_guard is not None:
                    self.executor.safety_guard = self.safety_guard
                    log.info("v7: wired SafetyGuard into executor (plan review gate)")
                if self.critic is not None:
                    self.executor.critic = self.critic
                    log.info("v7: wired CriticAgent into executor (post-execution review)")
            except Exception as e:
                log.debug("Executor safety_guard/critic wiring failed (non-fatal): %s", e)

    # ------------------------------------------------------------------ #
    # v5 — Self-Prompt Engineering Node startup
    # ------------------------------------------------------------------ #

    def _start_prompt_engineering(self) -> None:
        """Construct the Prompt Engineering Node.

        Best-effort: failures are logged but never fatal.  When the
        node fails to construct, ``self.prompt_engineer`` remains None
        and ``_run_task`` falls back to passing the raw request to the
        planner (legacy behaviour).
        """
        try:
            from adonai.prompt_engineering import (
                PromptEngineeringNode,
                PromptStore,
            )
            store: PromptStore | None = None
            try:
                db_path = self.config.database.prompt_engineering_db
                store = PromptStore(db_path)
            except Exception as e:
                log.debug("PromptStore init skipped: %s", e)

            self.prompt_engineer = PromptEngineeringNode(
                llm=self.llm,
                store=store,
                config=self.config,
            )
            self.container.register_instance(
                "prompt_engineering_node", self.prompt_engineer,
            )
            log.info(
                "v5: Prompt Engineering Node enabled (domains=%d)",
                len(self.prompt_engineer.registry.domains()),
            )
        except Exception as e:
            log.warning("v5: Prompt Engineering Node init failed: %s", e)
            self.prompt_engineer = None

    async def engineer_prompt(self, request: str, *, context: dict | None = None) -> Any:
        """Public API: engineer a prompt for a raw user request.

        Returns a :class:`~adonai.prompt_engineering.models.PromptPackage`.
        Raises ``AdonaiError`` if the node is not enabled.
        """
        if self.prompt_engineer is None:
            raise AdonaiError("Prompt Engineering Node not enabled")
        return await self.prompt_engineer.engineer(request, context=context)
