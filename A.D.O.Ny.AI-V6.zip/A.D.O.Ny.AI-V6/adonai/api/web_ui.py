"""Web UI routes — register the chat dashboard on a FastAPI app."""
# NOTE: do NOT add `from __future__ import annotations` here — breaks
# FastAPI's get_type_hints() for HTMLResponse return types.

from pathlib import Path

from fastapi import Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles

STATIC_DIR = Path(__file__).resolve().parent / "static"


def register_web_routes(app, ai) -> None:
    """Mount the static HTML chat UI on *app*."""
    if STATIC_DIR.exists():
        app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    @app.get("/", response_class=HTMLResponse)
    async def _index() -> HTMLResponse:
        index = STATIC_DIR / "index.html"
        if index.exists():
            return HTMLResponse(index.read_text(encoding="utf-8"))
        return HTMLResponse("<h1>A.D.O.N.AI v3</h1>", status_code=404)

    @app.get("/ui", response_class=HTMLResponse)
    async def _ui_alias() -> HTMLResponse:
        index = STATIC_DIR / "index.html"
        if index.exists():
            return HTMLResponse(index.read_text(encoding="utf-8"))
        return HTMLResponse("<h1>A.D.O.N.AI v3</h1>", status_code=404)
