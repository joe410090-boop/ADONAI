"""FastAPI server — comprehensive REST + WebSocket API for ADONAI v4.

Endpoints:
  GET  /health                  — liveness probe
  GET  /                        — web UI
  GET  /introspect              — combined system summary
  GET  /config                  — sanitized config dump
  POST /chat                    — one-shot chat (POST/GET)
  POST /run                     — blocking goal execution
  POST /background              — schedule background goal
  GET  /tasks                   — list background tasks
  GET  /tasks/{task_id}         — task status
  POST /tasks/cancel/{task_id}  — cancel a task
  GET  /tools                   — list tools + schemas
  GET  /tools/{name}            — single tool detail
  GET  /agents                  — list agents
  GET  /agents/{name}           — single agent detail
  GET  /skills                  — list learned skills
  GET  /skills/{id}             — skill detail
  DELETE /skills/{id}           — delete a skill
  GET  /memory                  — recall memories
  GET  /sessions                — list chat sessions
  GET  /sessions/{id}           — get session history
  DELETE /sessions/{id}         — clear session history
  GET  /stats                   — per-tool statistics
  GET  /audit                   — audit log
  GET  /analytics               — analytics summary
  GET  /report                  — full performance report
  GET  /knowledge               — knowledge graph snapshot
  WS   /ws/chat                 — streaming chat
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from pathlib import Path
from typing import Any

# Module-level imports of FastAPI types so type-hint introspection works
# (PEP 563 + FastAPI's get_type_hints() requires this).
from fastapi import FastAPI, HTTPException, Query, Request as _FastAPIRequest, WebSocket, WebSocketDisconnect, UploadFile, File
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from adonai.config.settings import Config
from adonai.runtime import ADONAI

log = logging.getLogger(__name__)


def create_app(config: Config) -> FastAPI:
    """Build a FastAPI app bound to a fresh :class:`ADONAI` runtime."""
    from contextlib import asynccontextmanager

    # Construct the runtime eagerly so we can wire its lifecycle into
    # the FastAPI lifespan.  (Previously this used @app.on_event which
    # is deprecated in FastAPI >= 0.93.)
    ai = ADONAI(config=config)

    @asynccontextmanager
    async def _lifespan(app: FastAPI):
        try:
            await ai.start()
        except Exception as exc:
            log.error("ADONAI startup failed: %s", exc, exc_info=True)
        try:
            yield
        finally:
            try:
                await ai.shutdown()
            except Exception as exc:
                log.warning("ADONAI shutdown error: %s", exc)

    app = FastAPI(
        title="A.D.O.N.AI v4",
        version="4.0.0",
        docs_url="/docs" if config.api.enable_docs else None,
        redoc_url=None,
        lifespan=_lifespan,
    )

    # CORS hardening: refuse wildcard origins when credentials are enabled
    # (browsers reject this combo anyway, and non-browser clients can
    # exploit it). If the operator truly wants open CORS, they must
    # explicitly set cors_origins=["*"] AND allow_credentials=False.
    cors_origins = list(config.api.cors_origins or [])
    allow_credentials = True
    if "*" in cors_origins:
        # Auto-expand the wildcard into a sane localhost allowlist so
        # the server keeps working in development.  In production the
        # operator should set explicit origins in config.api.cors_origins.
        if config.environment == "development":
            cors_origins = [
                "http://localhost:3000",
                "http://localhost:5173",
                "http://localhost:8000",
                "http://127.0.0.1:3000",
                "http://127.0.0.1:5173",
                "http://127.0.0.1:8000",
            ]
            log.warning(
                "API: cors_origins contains '*' in development — "
                "auto-expanded to localhost allowlist. Set explicit origins "
                "in config.api.cors_origins for production."
            )
        else:
            log.warning(
                "API: cors_origins contains '*' in %s — forcing "
                "allow_credentials=False. Set explicit origins in "
                "config.api.cors_origins to enable credentials.",
                config.environment,
            )
            allow_credentials = False
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=allow_credentials,
        allow_methods=["GET", "POST", "PUT", "DELETE", "PATCH", "WebSocket"],
        allow_headers=["Content-Type", "Authorization", "X-API-Key", "X-Request-ID"],
    )

    # ── Authentication middleware ─────────────────────────────────────────
    # If config.api.api_key is set, every non-/health route requires a
    # matching X-API-Key header. This closes the CRITICAL security hole
    # where the entire API was unauthenticated by default.
    _api_key = config.api.api_key.get_secret_value() if config.api.api_key else None
    _PUBLIC_PATHS = {"/health", "/docs", "/openapi.json", "/redoc"}

    @app.middleware("http")
    async def _auth_middleware(request: _FastAPIRequest, call_next):
        if _api_key is not None and request.url.path not in _PUBLIC_PATHS:
            provided = request.headers.get("X-API-Key") or request.headers.get("Authorization", "").replace("Bearer ", "")
            if provided != _api_key:
                return JSONResponse(
                    status_code=401,
                    content={"detail": "invalid or missing API key (X-API-Key header required)"},
                )
        # Body-size limit (default 1 MB).
        response = await call_next(request)
        return response

    # ── Body-size limiting middleware ─────────────────────────────────────
    @app.middleware("http")
    async def _body_size_middleware(request: _FastAPIRequest, call_next):
        max_bytes = getattr(config.api, "max_request_body_size", 1_048_576)
        cl = request.headers.get("content-length")
        if cl and int(cl) > max_bytes:
            return JSONResponse(
                status_code=413,
                content={"detail": f"request body too large: {cl} > {max_bytes} bytes"},
            )
        return await call_next(request)

    # ── Rate limiting middleware (token bucket per IP) ───────────────────
    # Implements config.api.rate_limit_per_minute (default 60).
    # Previously this config field was defined but never enforced.
    # The bucket refills at rate_limit_per_minute/60 tokens per second;
    # each request consumes 1 token; empty bucket → 429 Too Many Requests.
    rate_limit = int(getattr(config.api, "rate_limit_per_minute", 60) or 0)
    _rate_buckets: dict[str, list[float]] = {}  # IP → [timestamps]
    import time as _time_mod
    import asyncio as _aio

    @app.middleware("http")
    async def _rate_limit_middleware(request: _FastAPIRequest, call_next):
        if rate_limit <= 0:
            return await call_next(request)
        # Skip health/docs (cheap, high-frequency polling endpoints).
        if request.url.path in _PUBLIC_PATHS:
            return await call_next(request)
        client_ip = request.client.host if request.client else "unknown"
        now = _time_mod.monotonic()
        window = 60.0  # 1 minute sliding window
        # Get or create the bucket for this IP.
        timestamps = _rate_buckets.setdefault(client_ip, [])
        # Evict timestamps older than the window.
        cutoff = now - window
        while timestamps and timestamps[0] < cutoff:
            timestamps.pop(0)
        # Check if the IP is over the limit.
        if len(timestamps) >= rate_limit:
            retry_after = int(window - (now - timestamps[0])) + 1
            return JSONResponse(
                status_code=429,
                content={
                    "detail": f"rate limit exceeded: {rate_limit} requests/minute",
                    "retry_after_s": retry_after,
                },
                headers={"Retry-After": str(retry_after)},
            )
        timestamps.append(now)
        return await call_next(request)

    # Friendly 422 handler.
    @app.exception_handler(RequestValidationError)
    async def _validation_handler(request, exc):
        path = request.url.path
        method = request.method
        post_endpoints = {"/chat", "/run", "/background"}
        hints: list[str] = []
        if method == "POST" and path in post_endpoints:
            if path == "/chat":
                body_example = '{"message":"hello","session_id":"..."}'
            else:
                body_example = '{"goal":"..."}'
            hints.append(
                f"POST {path} expects a JSON body.  Example:\n"
                f"  curl -X POST http://<host>{path} -H 'Content-Type: application/json' -d '{body_example}'"
            )
        return JSONResponse(
            status_code=422,
            content={
                "detail": exc.errors(), "hints": hints,
                "method": method, "path": path,
            },
        )

    # NOTE: `ai` is now constructed at the top of create_app() so the
    # FastAPI lifespan can wire its start/shutdown.  Don't re-construct it.

    # Register web UI.
    try:
        from adonai.api.web_ui import register_web_routes
        register_web_routes(app, ai)
    except Exception as exc:
        log.warning("Web UI registration failed: %s", exc)

    # Register file upload + analysis endpoints.
    try:
        from adonai.agents.file_analyst import register_file_upload_route
        register_file_upload_route(app, ai)
    except Exception as exc:
        log.warning("File upload routes failed: %s", exc)

    # Register scientific discovery endpoints.
    try:
        from adonai.api.discovery_routes import register_discovery_routes
        register_discovery_routes(app, ai)
    except Exception as exc:
        log.warning("Discovery routes failed: %s", exc)

    # Register v4 research-grade endpoints (critique, debate, hypotheses,
    # experiment-loop, strategy, simulations, events, prompt-engineer).
    try:
        from adonai.api.v4_routes import register_v4_routes
        register_v4_routes(app, ai)
    except Exception as exc:
        log.warning("v4 routes failed: %s", exc)

    # ── Models ────────────────────────────────────────────────────────────
    class ChatRequest(BaseModel):
        message: str
        session_id: str | None = None

    class RunRequest(BaseModel):
        goal: str
        max_steps: int | None = None
        max_duration_s: int | None = None

    class BackgroundRequest(BaseModel):
        goal: str
        max_steps: int | None = None

    class TaskResponse(BaseModel):
        task_id: str
        status: str
        output: Any | None = None
        error: str | None = None
        steps_executed: int | None = None
        duration_s: float | None = None
        session_id: str | None = None

    # ── Lifecycle ─────────────────────────────────────────────────────────
    # Startup/shutdown are handled by the lifespan context manager defined
    # at the top of create_app().  The previous @app.on_event decorators
    # are deprecated in FastAPI >= 0.93.

    # ── Health & introspection ────────────────────────────────────────────
    @app.get("/health")
    async def _health() -> dict:
        return {
            "status": "ok", "started": ai._started,
            "version": "4.0.0", "environment": config.environment,
        }

    @app.get("/introspect")
    async def _introspect() -> dict:
        tools_count = agents_count = skills_count = 0
        tool_names: list[str] = []
        agent_names: list[str] = []
        try:
            if ai.tools is not None:
                tools = await ai.tools.list_tools()
                tools_count = len(tools)
                tool_names = [t.name for t in tools]
        except Exception:
            pass
        try:
            if ai.agents is not None:
                agents = ai.agents.list_agents()
                agents_count = len(agents)
                agent_names = [a.name for a in agents]
        except Exception:
            pass
        try:
            skills = await ai.list_skills()
            skills_count = len(skills)
        except Exception:
            pass
        return {
            "started": ai._started, "environment": config.environment,
            "llm_backend": config.llm.backend, "llm_model": config.llm.model_name,
            "tools_count": tools_count, "agents_count": agents_count,
            "skills_count": skills_count,
            "tool_names": tool_names, "agent_names": agent_names,
        }

    @app.get("/config")
    async def _config() -> dict:
        def _redact(obj):
            if isinstance(obj, dict):
                return {k: ("***" if any(s in k.lower() for s in ("key", "password", "secret")) else _redact(v))
                        for k, v in obj.items()}
            if isinstance(obj, list):
                return [_redact(x) for x in obj]
            return obj
        return _redact(config.model_dump(mode="json"))

    # ── Tools ─────────────────────────────────────────────────────────────
    @app.get("/tools")
    async def _list_tools() -> list[dict]:
        if ai.tools is None:
            return []
        tools = await ai.tools.list_tools()
        return [{
            "name": t.name, "description": t.description,
            "risk_level": getattr(t, "risk_level", "low"),
            "requires_approval": getattr(t, "requires_approval", False),
            "tags": list(getattr(t, "tags", []) or []),
            "parameters": t.parameters, "category": getattr(t, "category", "general"),
        } for t in tools]

    @app.get("/tools/{name}")
    async def _tool_detail(name: str) -> dict:
        if ai.tools is None:
            raise HTTPException(404, "tool manager not initialized")
        tool = await ai.tools.get_tool(name)
        if tool is None:
            raise HTTPException(404, f"tool {name!r} not found")
        return {
            "name": tool.name, "description": tool.description,
            "risk_level": getattr(tool, "risk_level", "low"),
            "parameters": tool.parameters,
            "effectiveness": ai.tools.effectiveness(name),
            "stats": ai.tools.all_stats().get(name),
        }

    @app.get("/stats")
    async def _stats() -> dict:
        if ai.tools is None:
            return {}
        return ai.tools.all_stats()

    # ── Agents ────────────────────────────────────────────────────────────
    @app.get("/agents")
    async def _list_agents() -> list[dict]:
        if ai.agents is None:
            return []
        return [{
            "name": a.name, "role": a.role,
            "capabilities": list(getattr(a, "capabilities", []) or []),
            "preferred_tools": list(getattr(a, "preferred_tools", []) or []),
            "system_prompt": (getattr(a, "system_prompt", "") or "")[:500],
        } for a in ai.agents.list_agents()]

    @app.get("/agents/{name}")
    async def _agent_detail(name: str) -> dict:
        if ai.agents is None:
            raise HTTPException(404, "agent registry not initialized")
        a = ai.agents.get(name)
        if a is None:
            raise HTTPException(404, f"agent {name!r} not found")
        return {
            "name": a.name, "role": a.role,
            "capabilities": list(getattr(a, "capabilities", []) or []),
            "preferred_tools": list(getattr(a, "preferred_tools", []) or []),
            "system_prompt": getattr(a, "system_prompt", ""),
        }

    # ── Skills ────────────────────────────────────────────────────────────
    @app.get("/skills")
    async def _list_skills() -> list[dict]:
        if ai.skills is None:
            return []
        skills = await ai.skills.list_all()
        return [{
            "id": s.id, "name": s.name, "description": s.description,
            "category": s.category, "success_rate": s.success_rate,
            "usage_count": s.usage_count, "active": s.active,
        } for s in skills]

    @app.get("/skills/{skill_id}")
    async def _skill_detail(skill_id: str) -> dict:
        if ai.skills is None:
            raise HTTPException(404, "skill manager not initialized")
        s = await ai.skills.store.load(skill_id)
        if s is None:
            raise HTTPException(404, f"skill {skill_id!r} not found")
        return {
            "id": s.id, "name": s.name, "description": s.description,
            "category": s.category, "trigger_patterns": s.trigger_patterns,
            "procedure": [step.model_dump(mode="json") for step in s.procedure],
            "success_rate": s.success_rate, "usage_count": s.usage_count,
        }

    @app.delete("/skills/{skill_id}")
    async def _skill_delete(skill_id: str) -> dict:
        if ai.skills is None:
            raise HTTPException(404, "skill manager not initialized")
        ok = await ai.skills.store.delete(skill_id)
        if not ok:
            raise HTTPException(404, f"skill {skill_id!r} not found")
        return {"deleted": skill_id}

    # ── Memory ────────────────────────────────────────────────────────────
    @app.get("/memory")
    async def _memory_search(
        query: str = Query("", description="Semantic search query (empty = recent)"),
        top_k: int = Query(10, ge=1, le=50),
    ) -> list[dict]:
        if ai.memory is None:
            return []
        from adonai.core.models import MemoryType
        if not query.strip():
            recent = ai.memory.working.recent(top_k)
            return [{
                "id": m.id, "type": m.type.value, "content": m.content[:500],
                "importance": m.importance, "source": m.source,
                "session_id": m.session_id,
                "created_at": str(m.created_at) if m.created_at else None,
            } for m in recent]
        results = await ai.memory.recall(
            query, top_k=top_k,
            types=[MemoryType.EPISODIC, MemoryType.SEMANTIC],
        )
        return [{
            "id": m.id, "type": m.type.value, "content": m.content[:500],
            "importance": m.importance, "source": m.source,
            "session_id": m.session_id,
            "created_at": str(m.created_at) if m.created_at else None,
        } for m in results]

    # ── Sessions (conversation history) ───────────────────────────────────
    @app.get("/sessions")
    async def _list_sessions() -> list[dict]:
        if ai.executor is None:
            return []
        out = []
        for sid, msgs in ai.executor._conversations.items():
            out.append({
                "session_id": sid, "message_count": len(msgs),
                "turn_count": len(msgs) // 2,
                "first_message": msgs[0]["content"][:100] if msgs else None,
                "last_message": msgs[-1]["content"][:100] if msgs else None,
            })
        return out
    # In adonai/api/server.py, inside create_app():
    import logging
    class _HealthFilter(logging.Filter):
        def filter(self, record):
            msg = record.getMessage()
            return "/health" not in msg and "/introspect" not in msg

    logging.getLogger("uvicorn.access").addFilter(_HealthFilter())
    @app.get("/sessions/{session_id}")
    async def _get_session(session_id: str) -> dict:
        if ai.executor is None:
            raise HTTPException(404, "executor not initialized")
        msgs = ai.executor._get_history(session_id)
        return {
            "session_id": session_id,
            "message_count": len(msgs),
            "turn_count": len(msgs) // 2,
            "messages": msgs,
        }

    @app.delete("/sessions/{session_id}")
    async def _clear_session(session_id: str) -> dict:
        if ai.executor is not None:
            await ai.executor.clear_conversation(session_id)
        return {"cleared": session_id}

    # ── Tasks ─────────────────────────────────────────────────────────────
    @app.get("/tasks")
    async def _list_tasks() -> list[dict]:
        return await ai.list_tasks()

    @app.get("/tasks/{task_id}")
    async def _task_status(task_id: str) -> dict:
        s = await ai.get_task_status(task_id)
        if s is None:
            raise HTTPException(404, "task not found")
        # Surface the plan + step statuses (todo-list view) if available.
        try:
            if ai.executor is not None:
                s["steps"] = ai.executor.get_step_statuses(task_id)
                plan = ai.executor.get_plan(task_id)
                if plan is not None:
                    s["plan"] = {
                        "id": plan.id, "goal": plan.goal,
                        "strategy": plan.strategy, "confidence": plan.confidence,
                        "revised": plan.revised, "step_count": len(plan.steps),
                    }
        except Exception as exc:
            log.debug("get_step_statuses failed: %s", exc)
        return s

    @app.post("/tasks/cancel/{task_id}")
    async def _task_cancel(task_id: str) -> dict:
        ok = await ai.cancel_task(task_id)
        if not ok:
            raise HTTPException(404, "task not found or already done")
        return {"cancelled": task_id}

    # ── Todos (session-scoped checklist written by the `todo.write` tool) ─
    @app.get("/todos/{session_id}")
    async def _get_todos(session_id: str) -> dict:
        """Read the live todo list for a chat session.

        The LLM maintains this list by calling the `todo.write` tool.
        Each call also fires a `todo.updated` event on /events/stream.
        """
        from adonai.tools.builtin.todo import get_todos
        todos = get_todos(session_id)
        return {
            "session_id": session_id,
            "todos": todos,
            "counts": {
                "total": len(todos),
                "pending": sum(1 for t in todos if t["status"] == "pending"),
                "in_progress": sum(1 for t in todos if t["status"] == "in_progress"),
                "completed": sum(1 for t in todos if t["status"] == "completed"),
            },
        }

    # ── Chat / Run / Background ───────────────────────────────────────────
    async def _extract_params(request, *names):
        body_data: dict[str, Any] = {}
        try:
            ct = request.headers.get("content-type", "")
            if "application/json" in ct or await request.body():
                try:
                    parsed = await request.json()
                    if isinstance(parsed, dict):
                        body_data = parsed
                except Exception:
                    pass
        except Exception:
            pass
        form_data: dict[str, Any] = {}
        try:
            form = await request.form()
            form_data = {k: v for k, v in form.items()}
        except Exception:
            pass
        query_data = dict(request.query_params)
        out: dict[str, Any] = {}
        for name in names:
            for source in (body_data, form_data, query_data):
                if name in source and source[name] not in (None, ""):
                    out[name] = source[name]
                    break
            else:
                out[name] = None
        return out

    @app.post("/chat", response_model=TaskResponse)
    async def _chat(request: _FastAPIRequest) -> TaskResponse:
        params = await _extract_params(request, "message", "session_id")
        message = params["message"]
        session_id = params["session_id"]
        if not message:
            raise HTTPException(422, "message is required")
        if not session_id:
            session_id = f"sess_{uuid.uuid4().hex[:12]}"
        try:
            reply = await ai.chat(str(message), session_id=session_id)
            return TaskResponse(
                task_id="chat", status="completed",
                output=reply, session_id=session_id,
            )
        except Exception as exc:
            raise HTTPException(500, detail=str(exc))

    @app.get("/chat", response_model=TaskResponse)
    async def _chat_get(
        message: str = Query(...), session_id: str | None = Query(None),
    ) -> TaskResponse:
        if not session_id:
            session_id = f"sess_{uuid.uuid4().hex[:12]}"
        try:
            reply = await ai.chat(message, session_id=session_id)
            return TaskResponse(
                task_id="chat", status="completed",
                output=reply, session_id=session_id,
            )
        except Exception as exc:
            raise HTTPException(500, detail=str(exc))

    @app.post("/run", response_model=TaskResponse)
    async def _run(request: _FastAPIRequest) -> TaskResponse:
        params = await _extract_params(request, "goal", "max_steps", "max_duration_s", "session_id")
        goal = params["goal"]
        if not goal:
            raise HTTPException(422, "goal is required")
        kwargs: dict[str, Any] = {}
        if params["max_steps"] is not None:
            try: kwargs["max_steps"] = int(params["max_steps"])
            except (TypeError, ValueError): raise HTTPException(422, "max_steps must be int")
        if params["max_duration_s"] is not None:
            try: kwargs["max_duration_s"] = int(params["max_duration_s"])
            except (TypeError, ValueError): raise HTTPException(422, "max_duration_s must be int")
        session_id = params.get("session_id")
        if not session_id:
            import uuid
            session_id = f"sess_{uuid.uuid4().hex[:12]}"
        try:
            r = await ai.run(str(goal), session_id=session_id, **kwargs)
            return TaskResponse(
                task_id=r.task_id, status=r.status.value, output=r.output,
                error=r.error, steps_executed=r.steps_executed, duration_s=r.duration_s,
                session_id=session_id,
            )
        except Exception as exc:
            raise HTTPException(500, detail=str(exc))

    @app.get("/run", response_model=TaskResponse)
    async def _run_get(
        goal: str = Query(...), max_steps: int | None = Query(None),
        max_duration_s: int | None = Query(None),
        session_id: str | None = Query(None),
    ) -> TaskResponse:
        kwargs: dict[str, Any] = {}
        if max_steps is not None: kwargs["max_steps"] = max_steps
        if max_duration_s is not None: kwargs["max_duration_s"] = max_duration_s
        if not session_id:
            import uuid
            session_id = f"sess_{uuid.uuid4().hex[:12]}"
        try:
            r = await ai.run(goal, session_id=session_id, **kwargs)
            return TaskResponse(
                task_id=r.task_id, status=r.status.value, output=r.output,
                error=r.error, steps_executed=r.steps_executed, duration_s=r.duration_s,
                session_id=session_id,
            )
        except Exception as exc:
            raise HTTPException(500, detail=str(exc))

    @app.post("/background")
    async def _background(request: _FastAPIRequest) -> dict:
        params = await _extract_params(request, "goal", "max_steps")
        goal = params["goal"]
        if not goal:
            raise HTTPException(422, "goal is required")
        kwargs: dict[str, Any] = {}
        if params["max_steps"] is not None:
            try: kwargs["max_steps"] = int(params["max_steps"])
            except (TypeError, ValueError): pass
        try:
            task_id = await ai.run_background(str(goal), **kwargs)
            return {"task_id": task_id, "status": "scheduled"}
        except Exception as exc:
            raise HTTPException(500, detail=str(exc))

    @app.get("/background")
    async def _background_get(
        goal: str = Query(...), max_steps: int | None = Query(None),
    ) -> dict:
        kwargs: dict[str, Any] = {}
        if max_steps is not None: kwargs["max_steps"] = max_steps
        try:
            task_id = await ai.run_background(goal, **kwargs)
            return {"task_id": task_id, "status": "scheduled"}
        except Exception as exc:
            raise HTTPException(500, detail=str(exc))

    # ── Analytics + Audit + Knowledge ─────────────────────────────────────
    @app.get("/analytics")
    async def _analytics() -> dict:
        if ai.analytics is None:
            return {}
        return ai.analytics.summary()

    @app.get("/report")
    async def _report() -> dict:
        from adonai.analytics.reporter import ReportGenerator
        from adonai.learning.experience import ExperienceStore
        from adonai.learning.patterns import PatternExtractor
        gen = ReportGenerator(
            ai.analytics,
            ExperienceStore(ai.config) if ai.config else None,
            PatternExtractor(ai.config) if ai.config else None,
        )
        return await gen.generate()

    @app.get("/audit")
    async def _audit(limit: int = Query(200, ge=1, le=10_000)) -> list[dict]:
        log_path = Path(config.safety.audit_log_path)
        if not log_path.exists():
            return []
        try:
            with open(log_path, "r", encoding="utf-8") as f:
                lines = f.readlines()
        except Exception:
            return []
        out: list[dict] = []
        for line in reversed(lines[-limit:]):
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                out.append({"_raw": line})
        return out

    @app.get("/knowledge")
    async def _knowledge() -> dict:
        if ai.memory is None or ai.memory.kg is None:
            return {"entities": [], "relations": []}
        snap = await ai.memory.kg.snapshot(limit=100)
        return {
            "entities": [e.model_dump(mode="json") for e in snap.entities],
            "relations": [r.model_dump(mode="json") for r in snap.relations],
        }

    # ── Observability endpoints (activate the previously-dead module) ────
    @app.get("/metrics")
    async def _metrics() -> dict:
        """Return the current metrics snapshot.

        Counters, gauges, and histograms are tracked by the
        MetricsRegistry.  When observability is disabled (e.g. metrics
        DB path on a read-only filesystem), returns an empty dict.
        """
        if ai.metrics is None:
            return {"enabled": False, "counters": {}, "gauges": {}, "histograms": {}}
        try:
            snap = ai.metrics.snapshot()
            snap["enabled"] = True
            return snap
        except Exception as exc:
            log.warning("/metrics snapshot failed: %s", exc)
            return {"enabled": True, "error": str(exc)}

    @app.get("/metrics/prometheus")
    async def _metrics_prometheus() -> str:
        """Return metrics in Prometheus text-exposition format.

        This endpoint is scrapeable by Prometheus / Grafana Agent /
        VictoriaMetrics.  Each counter/gauge/histogram is emitted as a
        ``# HELP`` + ``# TYPE`` + sample line.  Histograms are emitted
        as _sum / _count / _bucket lines per the Prometheus convention.

        When observability is disabled, returns a single comment line.
        """
        from fastapi.responses import PlainTextResponse
        if ai.metrics is None:
            return PlainTextResponse(
                "# observability disabled\n", media_type="text/plain",
            )
        try:
            snap = ai.metrics.snapshot()
        except Exception as exc:
            return PlainTextResponse(
                f"# snapshot failed: {exc}\n", media_type="text/plain",
            )
        lines: list[str] = []
        # Counters.
        for c in snap.get("counters", []):
            name = f"adonai_{c['name'].replace('.', '_')}"
            labels = ",".join(
                f'{k}="{v}"' for k, v in (c.get("labels") or {}).items()
            )
            label_str = f"{{{labels}}}" if labels else ""
            lines.append(f"# HELP {name} A counter metric")
            lines.append(f"# TYPE {name} counter")
            lines.append(f"{name}{label_str} {c['value']}")
        # Gauges.
        for g in snap.get("gauges", []):
            name = f"adonai_{g['name'].replace('.', '_')}"
            labels = ",".join(
                f'{k}="{v}"' for k, v in (g.get("labels") or {}).items()
            )
            label_str = f"{{{labels}}}" if labels else ""
            lines.append(f"# HELP {name} A gauge metric")
            lines.append(f"# TYPE {name} gauge")
            lines.append(f"{name}{label_str} {g['value']}")
        # Histograms.
        for h in snap.get("histograms", []):
            name = f"adonai_{h['name'].replace('.', '_')}"
            labels = ",".join(
                f'{k}="{v}"' for k, v in (h.get("labels") or {}).items()
            )
            label_str = f"{{{labels}}}" if labels else ""
            lines.append(f"# HELP {name} A histogram metric")
            lines.append(f"# TYPE {name} histogram")
            lines.append(f"{name}_sum{label_str} {h.get('sum', 0)}")
            lines.append(f"{name}_count{label_str} {h.get('count', 0)}")
            for bucket_le, bucket_count in h.get("buckets", []):
                bucket_labels = (
                    f'{{{labels},"le"="{bucket_le}"}}' if labels
                    else f'{{"le"="{bucket_le}"}}'
                )
                lines.append(f"{name}_bucket{bucket_labels} {bucket_count}")
        # Reasoning cache stats (if available).
        if ai.reasoning is not None and hasattr(ai.reasoning, "cache"):
            try:
                cache_stats = ai.reasoning.cache.stats()
                lines.append("# HELP adonai_reasoning_cache_hits Cache hits")
                lines.append("# TYPE adonai_reasoning_cache_hits counter")
                lines.append(f"adonai_reasoning_cache_hits {cache_stats['hits']}")
                lines.append("# HELP adonai_reasoning_cache_misses Cache misses")
                lines.append("# TYPE adonai_reasoning_cache_misses counter")
                lines.append(f"adonai_reasoning_cache_misses {cache_stats['misses']}")
                lines.append("# HELP adonai_reasoning_cache_size Cache size")
                lines.append("# TYPE adonai_reasoning_cache_size gauge")
                lines.append(f"adonai_reasoning_cache_size {cache_stats['size']}")
            except Exception:
                pass
        return PlainTextResponse(
            "\n".join(lines) + "\n", media_type="text/plain",
        )

    @app.get("/health-check")
    async def _health_check() -> dict:
        """Return per-subsystem health status.

        Each registered subsystem is checked on its own schedule.  When
        observability is disabled, returns just the basic liveness info.
        """
        if ai.health_monitor is None:
            return {
                "enabled": False,
                "started": ai._started,
                "environment": config.environment,
            }
        try:
            snap = ai.health_monitor.snapshot()
            snap["enabled"] = True
            snap["started"] = ai._started
            return snap
        except Exception as exc:
            log.warning("/health-check snapshot failed: %s", exc)
            return {"enabled": True, "error": str(exc)}

    @app.get("/traces")
    async def _traces(limit: int = Query(20, ge=1, le=200)) -> list[dict]:
        """Return recent execution traces (root span IDs + span counts)."""
        if ai.tracer is None:
            return []
        try:
            return ai.tracer.recent_traces(limit=limit)
        except Exception as exc:
            log.warning("/traces recent failed: %s", exc)
            return []

    @app.get("/traces/{root_id}")
    async def _trace_detail(root_id: str) -> dict:
        """Return the full span tree for a single trace."""
        if ai.tracer is None:
            return {"root_id": root_id, "spans": []}
        try:
            spans = ai.tracer.get_trace(root_id)
            return {"root_id": root_id, "spans": spans}
        except Exception as exc:
            log.warning("/traces/%s failed: %s", root_id, exc)
            return {"root_id": root_id, "spans": [], "error": str(exc)}

    # ── Executive autonomy layer (opt-in) ────────────────────────────────
    @app.get("/executive")
    async def _executive_state() -> dict:
        """Return the executive controller's world model snapshot."""
        if ai.executive_controller is None:
            return {
                "enabled": False,
                "message": "Executive loop not enabled (set agent.executive_loop=true in config)",
            }
        try:
            world = ai.executive_controller.world
            return {
                "enabled": True,
                "running": ai.executive_controller._task is not None
                and not ai.executive_controller._task.done(),
                "goals": {
                    "total": len(world.goals),
                    "active": len(world.active_goals()),
                    "pending": len(world.pending_goals()),
                },
                "recent_actions": world.recent_actions[-20:],
                "recent_reflections": world.recent_reflections[-10:],
                "available_tools": world.available_tools,
                "system_resources": world.system_resources,
            }
        except Exception as exc:
            log.warning("/executive snapshot failed: %s", exc)
            return {"enabled": True, "error": str(exc)}

    @app.post("/executive/goals")
    async def _executive_submit_goal(request: _FastAPIRequest) -> dict:
        """Submit a new goal to the executive controller."""
        if ai.executive_controller is None:
            raise HTTPException(
                503,
                "Executive loop not enabled (set agent.executive_loop=true in config)",
            )
        try:
            body = await request.json()
        except Exception:
            body = {}
        title = body.get("title") or body.get("goal") or ""
        if not title:
            raise HTTPException(422, "title (or goal) is required")
        try:
            goal_id = await ai.executive_controller.submit_goal(
                title=title,
                description=body.get("description", ""),
                tier=body.get("tier", "goal"),
                priority=int(body.get("priority", 5)),
                deadline=body.get("deadline"),
                parent_id=body.get("parent_id"),
            )
            return {"goal_id": goal_id, "status": "submitted"}
        except Exception as exc:
            raise HTTPException(500, f"executive submit failed: {exc}")

    @app.delete("/executive/goals/{goal_id}")
    async def _executive_cancel_goal(goal_id: str) -> dict:
        """Cancel a goal in the executive controller."""
        if ai.executive_controller is None:
            raise HTTPException(503, "Executive loop not enabled")
        try:
            ok = await ai.executive_controller.cancel_goal(goal_id)
            if not ok:
                raise HTTPException(404, f"goal {goal_id!r} not found")
            return {"cancelled": goal_id}
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(500, f"executive cancel failed: {exc}")

    # ── Human approval gate (for high-risk tool execution) ───────────────
    # When config.safety.require_approval is True, the PermissionPolicy
    # calls the registered approval callback for every high-risk tool.
    # The callback below parks the request in a pending-approvals dict
    # and polls for a human decision via the /approvals endpoints.
    _pending_approvals: dict[str, dict[str, Any]] = {}
    _approval_callbacks: dict[str, asyncio.Future] = {}

    async def _approval_callback(
        tool_name: str, params: dict[str, Any],
    ) -> tuple[bool, str]:
        """Park a high-risk tool call for human approval.

        Creates a pending-approval entry and blocks until a human
        POSTs to /approvals/{id}/decision or the timeout expires.
        """
        import uuid as _uuid
        approval_id = f"appr_{_uuid.uuid4().hex[:12]}"
        loop = asyncio.get_event_loop()
        future: asyncio.Future = loop.create_future()
        _pending_approvals[approval_id] = {
            "id": approval_id,
            "tool": tool_name,
            "params": params,
            "status": "pending",
            "created_at": time.time(),
        }
        _approval_callbacks[approval_id] = future
        try:
            # Wait up to 300s for a human decision.
            decision = await asyncio.wait_for(future, timeout=300.0)
            approved, reason = decision
            _pending_approvals[approval_id]["status"] = (
                "approved" if approved else "rejected"
            )
            _pending_approvals[approval_id]["reason"] = reason
            return approved, reason
        except asyncio.TimeoutError:
            _pending_approvals[approval_id]["status"] = "timeout"
            return False, "approval timed out (no human response in 300s)"
        finally:
            _approval_callbacks.pop(approval_id, None)

    # Wire the callback into the permission policy (if the runtime has one).
    if ai.tools is not None and hasattr(ai.tools, "_permissions"):
        try:
            ai.tools._permissions.set_approval_callback(_approval_callback)
        except Exception as exc:
            log.warning("Failed to wire approval callback: %s", exc)

    @app.get("/approvals")
    async def _list_pending_approvals() -> list[dict]:
        """List all pending / recently-decided approval requests."""
        return list(_pending_approvals.values())

    @app.post("/approvals/{approval_id}/decision")
    async def _submit_approval_decision(approval_id: str, request: _FastAPIRequest) -> dict:
        """Submit a human decision for a pending approval request.

        Body: ``{"approved": true/false, "reason": "..."}``
        """
        if approval_id not in _pending_approvals:
            raise HTTPException(404, f"approval {approval_id!r} not found")
        try:
            body = await request.json()
        except Exception:
            body = {}
        approved = bool(body.get("approved", False))
        reason = str(body.get("reason", ""))
        future = _approval_callbacks.get(approval_id)
        if future is not None and not future.done():
            future.set_result((approved, reason))
            return {"status": "decided", "approved": approved}
        else:
            # Already decided or timed out.
            return {
                "status": _pending_approvals[approval_id].get("status", "unknown"),
                "approved": approved,
            }

    # ── v5: Self-improvement endpoint ────────────────────────────────────
    # ARCHITECTURE.md:573 advertised POST /self-improve but the endpoint
    # never existed. This wires it to ADONAI.self_improve(), which runs
    # the SelfImprovementEngine pipeline (propose → sandbox → regression
    # → verify → merge) when config.self_improvement.enabled is True.
    @app.post("/self-improve")
    async def _self_improve(request: _FastAPIRequest) -> dict:
        """Trigger the SelfImprovementEngine pipeline manually.

        Body (all optional):
            ``{"force": false, "dry_run": false}``

        Returns a summary of the improvement cycle. The pipeline is
        safety-hardened: path containment, automatic rollback on test
        failure, protected-files list. See safety/self_improvement.py.
        """
        try:
            body = await request.json()
        except Exception:
            body = {}
        force = bool(body.get("force", False))
        dry_run = bool(body.get("dry_run", False))
        if not getattr(ai, "self_improvement", None):
            return {
                "status": "disabled",
                "message": (
                    "SelfImprovementEngine is not enabled. Set "
                    "config.self_improvement.enabled = true to activate."
                ),
            }
        try:
            result = await ai.self_improve(force=force, dry_run=dry_run)
            return {
                "status": "completed",
                "result": result if isinstance(result, dict) else {"output": str(result)},
            }
        except Exception as e:
            return {
                "status": "failed",
                "error": f"{type(e).__name__}: {e}",
            }

    @app.get("/self-improve/status")
    async def _self_improve_status() -> dict:
        """Check whether SelfImprovementEngine is enabled and ready."""
        si = getattr(ai, "self_improvement", None)
        return {
            "enabled": si is not None,
            "engine": type(si).__name__ if si is not None else None,
            "config": (
                getattr(ai.config, "self_improvement", None).model_dump()
                if getattr(ai.config, "self_improvement", None) else None
            ),
        }

    # ── v5: Benchmark + PromptOptimizer endpoints ───────────────────────
    @app.post("/benchmark")
    async def _run_benchmark() -> dict:
        """Run the benchmark suite manually.

        Runs all benchmark tasks against the runtime via runtime.chat()
        and returns the results. Results are also persisted to SQLite
        so /benchmark/history can retrieve past runs.
        """
        runner = getattr(ai, "benchmark_runner", None)
        if runner is None:
            return {
                "status": "disabled",
                "message": "BenchmarkRunner is not enabled. Set config.benchmark.enabled = true.",
            }
        try:
            results = await runner.run_all(ai)
            return {
                "status": "completed",
                "results": [r.to_dict() for r in results],
                "summary": runner.summary(),
            }
        except Exception as e:
            return {"status": "failed", "error": f"{type(e).__name__}: {e}"}

    @app.get("/benchmark/history")
    async def _benchmark_history(task_id: str | None = None, limit: int = 50) -> dict:
        """Retrieve historical benchmark results."""
        runner = getattr(ai, "benchmark_runner", None)
        if runner is None:
            return {"status": "disabled", "history": []}
        return {
            "status": "ok",
            "history": runner.history(task_id=task_id, limit=limit),
            "summary": runner.summary(),
        }

    @app.get("/prompt-optimizer/stats")
    async def _prompt_optimizer_stats() -> dict:
        """Return PromptOptimizer statistics."""
        opt = getattr(ai, "prompt_optimizer", None)
        if opt is None:
            return {"status": "disabled", "message": "PromptOptimizer is not enabled."}
        return {
            "status": "ok",
            "stats": opt.stats(),
            "has_current_prompt": opt.current_prompt is not None,
        }

    # ── WebSocket ─────────────────────────────────────────────────────────
    @app.websocket("/ws/chat")
    async def _ws_chat(websocket: WebSocket) -> None:
        await websocket.accept()
        ws_session_id = str(uuid.uuid4())
        try:
            await websocket.send_json({
                "type": "connected", "session_id": ws_session_id, "version": "4.0.0",
            })
            while True:
                try:
                    raw = await websocket.receive_text()
                except WebSocketDisconnect:
                    break
                if not raw or not raw.strip():
                    continue
                try:
                    msg = json.loads(raw)
                except json.JSONDecodeError:
                    stripped = raw.strip()
                    if stripped and not stripped.startswith("{") and not stripped.startswith("["):
                        msg = {"type": "chat", "message": stripped}
                    else:
                        await websocket.send_json({
                            "type": "error", "message": "invalid JSON",
                        })
                        continue
                msg_type = (msg.get("type") or "").lower()
                if not msg_type and msg.get("message"):
                    msg_type = "chat"
                if msg_type == "ping":
                    await websocket.send_json({"type": "pong"})
                    continue
                if msg_type == "chat":
                    message = (msg.get("message") or "").strip()
                    session_id = msg.get("session_id") or ws_session_id
                    if not message:
                        await websocket.send_json({"type": "error", "message": "empty message"})
                        continue
                    await websocket.send_json({"type": "thinking"})
                    try:
                        reply = await ai.chat(message, session_id=session_id)
                        await websocket.send_json({
                            "type": "message", "content": reply,
                            "session_id": session_id,
                        })
                    except Exception as exc:
                        await websocket.send_json({
                            "type": "error", "message": f"{type(exc).__name__}: {exc}",
                        })
                elif msg_type == "run":
                    goal = (msg.get("goal") or "").strip()
                    if not goal:
                        await websocket.send_json({"type": "error", "message": "empty goal"})
                        continue
                    await websocket.send_json({"type": "thinking"})
                    try:
                        kwargs = {}
                        if msg.get("max_steps") is not None:
                            kwargs["max_steps"] = int(msg["max_steps"])
                        r = await ai.run(goal, **kwargs)
                        await websocket.send_json({
                            "type": "result", "status": r.status.value,
                            "output": r.output, "error": r.error,
                            "steps_executed": r.steps_executed, "duration_s": r.duration_s,
                        })
                    except Exception as exc:
                        await websocket.send_json({
                            "type": "error", "message": f"{type(exc).__name__}: {exc}",
                        })
                elif msg_type == "debate":
                    # Streaming debate: subscribe to debate.* events,
                    # run the debate, forward each turn to the client,
                    # then send the final verdict.
                    question = (msg.get("question") or "").strip()
                    if not question:
                        await websocket.send_json({"type": "error", "message": "empty question"})
                        continue
                    if ai.debate_framework is None:
                        await websocket.send_json({
                            "type": "error", "message": "debate framework not enabled",
                        })
                        continue
                    from adonai.core.events import EventTypes
                    debate_q: asyncio.Queue = asyncio.Queue()

                    async def _debate_sub(event):
                        try:
                            await debate_q.put(event)
                        except Exception:
                            pass

                    ai.events.subscribe(EventTypes.DEBATE_TURN, _debate_sub)
                    ai.events.subscribe(EventTypes.DEBATE_STARTED, _debate_sub)
                    ai.events.subscribe(EventTypes.DEBATE_COMPLETED, _debate_sub)
                    try:
                        await websocket.send_json({
                            "type": "debate_started", "question": question,
                        })
                        # Run the debate in a background task so we can
                        # stream turns as they're produced.
                        rounds = msg.get("rounds")
                        participants = msg.get("participants")
                        debate_task = asyncio.create_task(ai.debate(
                            question,
                            rounds=rounds,
                            participants=participants,
                        ))
                        # Stream turns until the debate completes.
                        while True:
                            try:
                                event = await asyncio.wait_for(debate_q.get(), timeout=0.5)
                            except asyncio.TimeoutError:
                                if debate_task.done():
                                    break
                                continue
                            if event.type == EventTypes.DEBATE_TURN:
                                await websocket.send_json({
                                    "type": "debate_turn",
                                    "round": event.payload.get("round"),
                                    "stance": event.payload.get("stance"),
                                    "content": event.payload.get("content_preview"),
                                    "confidence": event.payload.get("confidence"),
                                })
                            elif event.type == EventTypes.DEBATE_COMPLETED:
                                # Final result will come from debate_task.
                                pass
                        debate = await debate_task
                        await websocket.send_json({
                            "type": "debate_completed",
                            "debate_id": debate.id,
                            "winner": debate.winner.value if debate.winner else None,
                            "winning_argument": debate.winning_argument,
                            "verdict": debate.verdict,
                            "confidence": debate.confidence,
                            "turns": [
                                {
                                    "stance": t.stance.value,
                                    "content": t.content,
                                    "citations": t.citations,
                                    "confidence": t.confidence,
                                }
                                for t in debate.turns
                            ],
                        })
                    except Exception as exc:
                        await websocket.send_json({
                            "type": "error", "message": f"debate failed: {type(exc).__name__}: {exc}",
                        })
                    finally:
                        try:
                            ai.events.unsubscribe(EventTypes.DEBATE_TURN, _debate_sub)
                            ai.events.unsubscribe(EventTypes.DEBATE_STARTED, _debate_sub)
                            ai.events.unsubscribe(EventTypes.DEBATE_COMPLETED, _debate_sub)
                        except Exception:
                            pass
                else:
                    await websocket.send_json({
                        "type": "error",
                        "message": f"unknown type {msg_type!r}; expected chat/run/debate/ping",
                    })
        except WebSocketDisconnect:
            log.debug("WebSocket /ws/chat disconnected")
        except Exception as exc:
            log.warning("WebSocket /ws/chat error: %s", exc)
        finally:
            try:
                await websocket.close()
            except Exception:
                pass

    # ════════════════════════════════════════════════════════════════════════
    # v6 — OpenHuman-inspired subsystem routes
    #
    # All routes are mounted under /v6/* and degrade gracefully when the
    # corresponding subsystem is disabled (return 503 with a clear message).
    # ════════════════════════════════════════════════════════════════════════

    def _v6_unavailable(subsystem: str) -> HTTPException:
        return HTTPException(
            503,
            detail=f"{subsystem} is not enabled — set {subsystem}.enabled=true in config",
        )

    # ── Memory Tree ────────────────────────────────────────────────────────

    @app.post("/v6/memory_tree/ingest")
    async def _v6_mt_ingest(request: _FastAPIRequest):
        if ai.memory_tree is None:
            raise _v6_unavailable("memory_tree")
        from adonai.openhuman.memory_tree import Chunk
        params = await _extract_params(
            request, "source_kind", "source_id", "content",
            "source_authority", "metadata",
        )
        try:
            chunk = Chunk(
                id=str(uuid.uuid4()),
                source_kind=params["source_kind"],
                source_id=params["source_id"],
                source_authority=float(params.get("source_authority") or 0.5),
                content=params["content"],
                created_at=int(time.time() * 1000),
                metadata=params.get("metadata") or {},
            )
            chunk_id = ai.memory_tree.ingest(chunk)
            return {"chunk_id": chunk_id, "status": "ingested"}
        except Exception as exc:
            raise HTTPException(500, detail=str(exc))

    @app.get("/v6/memory_tree/search")
    async def _v6_mt_search(
        q: str = Query(..., description="Keyword search query"),
        k: int = Query(10, ge=1, le=50),
    ):
        if ai.memory_tree is None:
            raise _v6_unavailable("memory_tree")
        hits = ai.memory_tree.search(q, k=k)
        return {
            "query": q,
            "hits": [
                {
                    "id": h.id, "title": h.title, "summary": h.summary[:500],
                    "score": h.score, "score_breakdown": h.score_breakdown,
                    "depth": h.depth,
                }
                for h in hits
            ],
        }

    @app.get("/v6/memory_tree/recall")
    async def _v6_mt_recall(
        q: str = Query(...), k: int = Query(5, ge=1, le=50),
    ):
        if ai.memory_tree is None:
            raise _v6_unavailable("memory_tree")
        hits = ai.memory_tree.recall(q, k=k)
        return {"query": q, "hits": [{"id": h.id, "title": h.title, "score": h.score} for h in hits]}

    @app.get("/v6/memory_tree/sources")
    async def _v6_mt_sources():
        if ai.memory_tree is None:
            raise _v6_unavailable("memory_tree")
        return {"sources": ai.memory_tree.list_sources()}

    @app.get("/v6/memory_tree/entities")
    async def _v6_mt_entities(k: int = Query(10, ge=1, le=100)):
        if ai.memory_tree is None:
            raise _v6_unavailable("memory_tree")
        return {"entities": [{"name": n, "count": c} for n, c in ai.memory_tree.top_entities(k)]}

    @app.post("/v6/memory_tree/rebuild")
    async def _v6_mt_rebuild():
        if ai.memory_tree is None:
            raise _v6_unavailable("memory_tree")
        n = ai.memory_tree.build_tree()
        return {"nodes_created": n, "status": "rebuilt"}

    @app.post("/v6/memory_tree/mirror")
    async def _v6_mt_mirror():
        if ai.memory_tree is None:
            raise _v6_unavailable("memory_tree")
        n = ai.memory_tree.mirror_now()
        return {"files_written": n, "vault_path": str(ai.memory_tree.config.vault_path)}

    # ── Goals & Todos ─────────────────────────────────────────────────────

    @app.get("/v6/goals")
    async def _v6_goals_list(
        scope: str = Query("long_term", pattern="^(long_term|per_thread|kanban)$"),
        session_id: str | None = Query(None),
    ):
        if ai.goals_todos is None:
            raise _v6_unavailable("goals_todos")
        if scope == "long_term":
            goals = ai.goals_todos.list_long_term()
        elif scope == "per_thread":
            if not session_id:
                raise HTTPException(400, "session_id is required for per_thread scope")
            goals = ai.goals_todos.list_per_thread(session_id)
        else:  # kanban
            if not session_id:
                raise HTTPException(400, "session_id is required for kanban scope")
            board = ai.goals_todos.kanban_board(session_id)
            return {"session_id": session_id, "board": {
                col: [{"id": g.id, "title": g.title, "status": g.status,
                       "priority": g.priority, "notes": g.notes}
                      for g in items]
                for col, items in board.items()
            }}
        return {"goals": [
            {"id": g.id, "title": g.title, "status": g.status,
             "priority": g.priority, "notes": g.notes,
             "created_at": g.created_at, "updated_at": g.updated_at}
            for g in goals
        ]}

    @app.post("/v6/goals")
    async def _v6_goals_create(request: _FastAPIRequest):
        if ai.goals_todos is None:
            raise _v6_unavailable("goals_todos")
        params = await _extract_params(
            request, "title", "scope", "session_id", "status", "priority", "notes",
        )
        try:
            scope = params.get("scope") or "long_term"
            title = params["title"]
            if scope == "long_term":
                g = ai.goals_todos.add_long_term(title, notes=params.get("notes") or "")
            elif scope == "per_thread":
                sid = params.get("session_id") or "default"
                g = ai.goals_todos.add_per_thread(sid, title, notes=params.get("notes") or "")
            else:  # kanban
                sid = params.get("session_id") or "default"
                status = params.get("status") or "backlog"
                g = ai.goals_todos.add_kanban_card(sid, title, status=status, notes=params.get("notes") or "")
            return {"id": g.id, "scope": g.scope, "title": g.title, "status": g.status}
        except ValueError as exc:
            raise HTTPException(400, detail=str(exc))
        except Exception as exc:
            raise HTTPException(500, detail=str(exc))

    @app.patch("/v6/goals/{goal_id}")
    async def _v6_goals_update(goal_id: str, request: _FastAPIRequest):
        if ai.goals_todos is None:
            raise _v6_unavailable("goals_todos")
        params = await _extract_params(request, "status", "notes")
        if params.get("status"):
            ai.goals_todos.update_status(goal_id, params["status"])
        if params.get("notes") is not None:
            ai.goals_todos.update_notes(goal_id, params["notes"])
        return {"id": goal_id, "status": "updated"}

    @app.delete("/v6/goals/{goal_id}")
    async def _v6_goals_delete(goal_id: str):
        if ai.goals_todos is None:
            raise _v6_unavailable("goals_todos")
        ai.goals_todos.delete(goal_id)
        return {"id": goal_id, "status": "deleted"}

    # ── Subconscious ──────────────────────────────────────────────────────

    @app.get("/v6/subconscious/status")
    async def _v6_sc_status():
        if ai.subconscious is None:
            raise _v6_unavailable("subconscious")
        return {
            "running": ai.subconscious._running,
            "failure_count": ai.subconscious._failure_count,
            "tasks": len(ai.subconscious.store.list_tasks()),
            "enabled_tasks": len(ai.subconscious.store.list_tasks(only_enabled=True)),
        }

    @app.get("/v6/subconscious/tasks")
    async def _v6_sc_tasks():
        if ai.subconscious is None:
            raise _v6_unavailable("subconscious")
        tasks = ai.subconscious.store.list_tasks()
        return {"tasks": [
            {"id": t.id, "title": t.title, "intent": t.intent,
             "enabled": t.enabled, "system": t.system,
             "last_decision": t.last_decision, "last_result": t.last_result[:200]}
            for t in tasks
        ]}

    @app.post("/v6/subconscious/tasks")
    async def _v6_sc_add_task(request: _FastAPIRequest):
        if ai.subconscious is None:
            raise _v6_unavailable("subconscious")
        params = await _extract_params(request, "id", "title", "intent")
        tid = params.get("id") or f"usr_{uuid.uuid4().hex[:8]}"
        ai.subconscious.store.add_task(tid, params["title"], params.get("intent") or "read")
        return {"id": tid, "status": "added"}

    @app.delete("/v6/subconscious/tasks/{task_id}")
    async def _v6_sc_delete_task(task_id: str):
        if ai.subconscious is None:
            raise _v6_unavailable("subconscious")
        ai.subconscious.store.delete_task(task_id)
        return {"id": task_id, "status": "deleted"}

    @app.get("/v6/subconscious/activity")
    async def _v6_sc_activity(k: int = Query(50, ge=1, le=500)):
        if ai.subconscious is None:
            raise _v6_unavailable("subconscious")
        return {"activity": ai.subconscious.store.recent_activity(k)}

    @app.post("/v6/subconscious/run")
    async def _v6_sc_run_now():
        if ai.subconscious is None:
            raise _v6_unavailable("subconscious")
        result = await ai.subconscious.run_now()
        return result

    @app.get("/v6/briefing")
    async def _v6_briefing():
        """Get the latest morning briefing (or trigger one if stale)."""
        if ai.subconscious is None:
            raise _v6_unavailable("subconscious")
        briefing = ai.subconscious.get_briefing()
        if not briefing:
            # Generate one on demand.
            briefing = await ai.subconscious._generate_briefing()
        return {"briefing": briefing}

    # ── Workflows ─────────────────────────────────────────────────────────

    @app.get("/v6/workflows")
    async def _v6_wf_list(enabled_only: bool = Query(False)):
        if ai.workflow_engine is None:
            raise _v6_unavailable("workflows")
        flows = ai.workflow_engine.store.list_workflows(only_enabled=enabled_only)
        return {"workflows": [
            {"id": w.id, "name": w.name, "description": w.description,
             "enabled": w.enabled, "nodes": len(w.nodes),
             "require_approval": w.require_approval_for_outbound,
             "updated_at": w.updated_at}
            for w in flows
        ]}

    @app.post("/v6/workflows/propose")
    async def _v6_wf_propose(request: _FastAPIRequest):
        """Validate + describe a candidate workflow.  Does NOT save it."""
        if ai.workflow_engine is None:
            raise _v6_unavailable("workflows")
        params = await _extract_params(request, "name", "description", "graph")
        proposal = ai.workflow_engine.propose_workflow(
            params["name"], params.get("description") or "", params["graph"],
        )
        return proposal

    @app.post("/v6/workflows")
    async def _v6_wf_create(request: _FastAPIRequest):
        """Save a workflow.  This is the only path from proposal → saved flow."""
        if ai.workflow_engine is None:
            raise _v6_unavailable("workflows")
        params = await _extract_params(
            request, "name", "description", "graph", "enabled", "require_approval",
        )
        try:
            wf = ai.workflow_engine.save_workflow(
                params["name"], params.get("description") or "", params["graph"],
                enabled=bool(params.get("enabled", False)),
                require_approval=bool(params.get("require_approval", True)),
            )
            return {"id": wf.id, "name": wf.name, "enabled": wf.enabled}
        except ValueError as exc:
            raise HTTPException(400, detail=str(exc))

    @app.get("/v6/workflows/{wf_id}")
    async def _v6_wf_get(wf_id: str):
        if ai.workflow_engine is None:
            raise _v6_unavailable("workflows")
        wf = ai.workflow_engine.store.get_workflow(wf_id)
        if wf is None:
            raise HTTPException(404, detail="workflow not found")
        return {
            "id": wf.id, "name": wf.name, "description": wf.description,
            "enabled": wf.enabled, "require_approval": wf.require_approval_for_outbound,
            "nodes": {
                nid: {"id": n.id, "kind": n.kind, "label": n.label,
                      "config": n.config, "next": n.next}
                for nid, n in wf.nodes.items()
            },
            "trigger_node_id": wf.trigger_node_id,
            "schedule": wf.schedule,
            "app_event": wf.app_event,
        }

    @app.patch("/v6/workflows/{wf_id}")
    async def _v6_wf_set_enabled(wf_id: str, request: _FastAPIRequest):
        if ai.workflow_engine is None:
            raise _v6_unavailable("workflows")
        params = await _extract_params(request, "enabled")
        ai.workflow_engine.store.set_enabled(wf_id, bool(params.get("enabled", False)))
        return {"id": wf_id, "status": "updated"}

    @app.delete("/v6/workflows/{wf_id}")
    async def _v6_wf_delete(wf_id: str):
        if ai.workflow_engine is None:
            raise _v6_unavailable("workflows")
        ai.workflow_engine.store.delete_workflow(wf_id)
        return {"id": wf_id, "status": "deleted"}

    @app.post("/v6/workflows/{wf_id}/run")
    async def _v6_wf_run(wf_id: str, request: _FastAPIRequest):
        if ai.workflow_engine is None:
            raise _v6_unavailable("workflows")
        params = await _extract_params(request, "trigger_payload")
        try:
            run = await ai.workflow_engine.run_workflow(wf_id, params.get("trigger_payload"))
            return {
                "run_id": run.id, "workflow_id": run.workflow_id,
                "status": run.status, "started_at": run.started_at,
                "finished_at": run.finished_at,
                "node_outputs": run.node_outputs,
                "pending_approval": run.pending_approval,
                "error": run.error,
            }
        except ValueError as exc:
            raise HTTPException(400, detail=str(exc))

    @app.post("/v6/workflows/runs/{run_id}/resume")
    async def _v6_wf_resume(run_id: str):
        if ai.workflow_engine is None:
            raise _v6_unavailable("workflows")
        try:
            run = await ai.workflow_engine.resume_run(run_id)
            return {"run_id": run.id, "status": run.status}
        except ValueError as exc:
            raise HTTPException(400, detail=str(exc))

    @app.get("/v6/workflows/{wf_id}/runs")
    async def _v6_wf_runs(wf_id: str, k: int = Query(20, ge=1, le=100)):
        if ai.workflow_engine is None:
            raise _v6_unavailable("workflows")
        runs = ai.workflow_engine.store.list_runs(wf_id, k)
        return {"runs": [
            {"id": r.id, "status": r.status, "started_at": r.started_at,
             "finished_at": r.finished_at, "error": r.error[:200]}
            for r in runs
        ]}

    # ── Graph Harness ─────────────────────────────────────────────────────

    @app.post("/v6/graph/run")
    async def _v6_graph_run(request: _FastAPIRequest):
        if ai.graph_harness is None:
            raise _v6_unavailable("graph_harness")
        params = await _extract_params(request, "goal", "max_steps")
        try:
            run = await ai.graph_harness.run(
                params["goal"],
                max_steps=int(params.get("max_steps") or 20),
            )
            return {
                "run_id": run.id, "goal": run.goal, "status": run.status,
                "started_at": run.started_at, "finished_at": run.finished_at,
                "steps": len(run.steps), "error": run.error,
            }
        except Exception as exc:
            raise HTTPException(500, detail=str(exc))

    @app.get("/v6/graph/runs")
    async def _v6_graph_runs(k: int = Query(20, ge=1, le=100)):
        if ai.graph_harness is None:
            raise _v6_unavailable("graph_harness")
        return {"runs": ai.graph_harness.list_runs(k)}

    @app.get("/v6/graph/runs/{run_id}")
    async def _v6_graph_replay(run_id: str):
        if ai.graph_harness is None:
            raise _v6_unavailable("graph_harness")
        result = ai.graph_harness.replay(run_id)
        if result is None:
            raise HTTPException(404, detail="run not found")
        return result

    # ── Split Brain ───────────────────────────────────────────────────────

    @app.post("/v6/split_brain/triage")
    async def _v6_sb_triage(request: _FastAPIRequest):
        if ai.split_brain is None:
            raise _v6_unavailable("split_brain")
        params = await _extract_params(request, "message")
        result = await ai.split_brain.triage(params["message"])
        return {
            "verdict": result.verdict, "reply": result.reply,
            "brief": result.brief, "confidence": result.confidence,
            "latency_ms": result.latency_ms,
        }

    @app.post("/v6/split_brain/directive")
    async def _v6_sb_set_directive(request: _FastAPIRequest):
        if ai.split_brain is None:
            raise _v6_unavailable("split_brain")
        params = await _extract_params(request, "text")
        ai.split_brain.set_directive(params["text"])
        return {"status": "set", "length": len(params["text"])}

    # ── SuperContext ──────────────────────────────────────────────────────

    @app.post("/v6/super_context/sweep")
    async def _v6_sc_sweep(request: _FastAPIRequest):
        if ai.super_context is None:
            raise _v6_unavailable("super_context")
        params = await _extract_params(request, "message")
        pack = await ai.super_context.sweep(params["message"])
        return {
            "prompt": pack.to_prompt(),
            "tokens_estimated": pack.tokens_estimated,
            "elapsed_ms": pack.elapsed_ms,
            "memory_hits": len(pack.memory_hits),
            "recent_files": len(pack.recent_files),
        }

    # ── TokenJuice ────────────────────────────────────────────────────────

    @app.post("/v6/tokenjuice/compress")
    async def _v6_tj_compress(request: _FastAPIRequest):
        if ai.tokenjuice is None:
            raise _v6_unavailable("tokenjuice")
        params = await _extract_params(request, "text", "strategy", "source_tool")
        out = ai.tokenjuice.compress(
            params["text"],
            source_tool=params.get("source_tool") or "",
            strategy=params.get("strategy"),
        )
        return {"compressed": out, "stats": ai.tokenjuice.stats_snapshot()}

    @app.get("/v6/tokenjuice/stats")
    async def _v6_tj_stats():
        if ai.tokenjuice is None:
            raise _v6_unavailable("tokenjuice")
        return ai.tokenjuice.stats_snapshot()

    # ── Agent Economy ─────────────────────────────────────────────────────

    @app.get("/v6/agent_economy/status")
    async def _v6_ae_status():
        if ai.agent_economy is None:
            raise _v6_unavailable("agent_economy")
        return ai.agent_economy.status()

    @app.get("/v6/agent_economy/pairings")
    async def _v6_ae_pairings():
        if ai.agent_economy is None:
            raise _v6_unavailable("agent_economy")
        return {"pairings": [
            {"peer_handle": p.peer_handle, "state": p.state,
             "trust": p.trust, "paired_at": p.paired_at}
            for p in ai.agent_economy.list_pairings()
        ]}

    @app.post("/v6/agent_economy/pair")
    async def _v6_ae_pair(request: _FastAPIRequest):
        if ai.agent_economy is None:
            raise _v6_unavailable("agent_economy")
        params = await _extract_params(request, "peer_handle")
        pairing = await ai.agent_economy.request_pairing(params["peer_handle"])
        return {
            "peer_handle": pairing.peer_handle, "state": pairing.state,
            "trust": pairing.trust,
        }

    @app.delete("/v6/agent_economy/pair/{peer_handle}")
    async def _v6_ae_unpair(peer_handle: str):
        if ai.agent_economy is None:
            raise _v6_unavailable("agent_economy")
        await ai.agent_economy.revoke_pairing(peer_handle)
        return {"peer_handle": peer_handle, "state": "revoked"}

    @app.get("/v6/agent_economy/bounties")
    async def _v6_ae_bounties(status: str | None = Query(None)):
        if ai.agent_economy is None:
            raise _v6_unavailable("agent_economy")
        bounties = ai.agent_economy.list_bounties(status=status)
        return {"bounties": [
            {"id": b.id, "description": b.description, "amount_usdc": b.amount_usdc,
             "chain": b.chain, "status": b.status, "claimant": b.claimant,
             "created_at": b.created_at, "paid_at": b.paid_at}
            for b in bounties
        ]}

    @app.post("/v6/agent_economy/bounties")
    async def _v6_ae_post_bounty(request: _FastAPIRequest):
        if ai.agent_economy is None:
            raise _v6_unavailable("agent_economy")
        params = await _extract_params(request, "description", "amount_usdc")
        try:
            bounty = await ai.agent_economy.post_bounty(
                params["description"], float(params["amount_usdc"]),
            )
            return {"id": bounty.id, "status": bounty.status, "amount_usdc": bounty.amount_usdc}
        except ValueError as exc:
            raise HTTPException(400, detail=str(exc))

    @app.post("/v6/agent_economy/bounties/{bounty_id}/pay")
    async def _v6_ae_pay_bounty(bounty_id: str):
        if ai.agent_economy is None:
            raise _v6_unavailable("agent_economy")
        ok = await ai.agent_economy.pay_bounty(bounty_id)
        return {"id": bounty_id, "paid": ok}

    # ── Meeting Agents ────────────────────────────────────────────────────

    @app.get("/v6/meetings")
    async def _v6_ma_list(include_ended: bool = Query(False)):
        if ai.meeting_agents is None:
            raise _v6_unavailable("meeting_agents")
        meetings = ai.meeting_agents.list_meetings(include_ended=include_ended)
        return {"meetings": [
            {"id": m.id, "platform": m.platform, "url": m.url,
             "title": m.title, "start_at": m.start_at, "duration_min": m.duration_min,
             "attending": m.attending, "status": m.status,
             "summary": m.summary[:300] if m.summary else "",
             "action_items": m.action_items}
            for m in meetings
        ]}

    @app.post("/v6/meetings")
    async def _v6_ma_schedule(request: _FastAPIRequest):
        if ai.meeting_agents is None:
            raise _v6_unavailable("meeting_agents")
        params = await _extract_params(
            request, "id", "platform", "url", "title", "start_at",
            "duration_min", "attending",
        )
        from adonai.openhuman.meeting_agents import Meeting
        m = Meeting(
            id=params.get("id") or str(uuid.uuid4()),
            platform=params["platform"],
            url=params["url"],
            title=params["title"],
            start_at=int(params["start_at"]),
            duration_min=int(params.get("duration_min") or 30),
            attending=bool(params.get("attending", True)),
        )
        ai.meeting_agents.schedule_meeting(m)
        return {"id": m.id, "status": "scheduled"}

    @app.get("/v6/meetings/status")
    async def _v6_ma_status():
        if ai.meeting_agents is None:
            raise _v6_unavailable("meeting_agents")
        return ai.meeting_agents.status()

    # ── Batteries ─────────────────────────────────────────────────────────

    @app.get("/v6/batteries/status")
    async def _v6_bat_status():
        if ai.batteries is None:
            raise _v6_unavailable("batteries")
        return {
            "voice_enabled": ai.batteries.config.voice_enabled,
            "whisper_model": ai.batteries.config.whisper_model,
            "whisper_available": ai.batteries.voice._check_available() if ai.batteries.voice else False,
            "privacy_mode": ai.batteries.privacy_mode.enabled,
            "web_search_enabled": ai.batteries.config.web_search_enabled,
            "browser_enabled": ai.batteries.config.browser_enabled,
        }

    @app.post("/v6/batteries/privacy_mode")
    async def _v6_bat_privacy(request: _FastAPIRequest):
        if ai.batteries is None:
            raise _v6_unavailable("batteries")
        params = await _extract_params(request, "enabled")
        if bool(params.get("enabled", False)):
            ai.batteries.privacy_mode.enable()
        else:
            ai.batteries.privacy_mode.disable()
        return {"privacy_mode": ai.batteries.privacy_mode.enabled}

    # ── Voice (multipart audio upload → transcript) ───────────────────────
    #
    # This is the endpoint the web UI's mic button hits.  The browser
    # records audio via MediaRecorder, POSTs the blob here, and we
    # transcribe it via Whisper (through the VoiceTool's transcribe_bytes
    # helper).  Returns the transcript text which the UI drops into the
    # chat input box.

    @app.post("/v6/voice/transcribe")
    async def _v6_voice_transcribe(
        audio: UploadFile = File(..., description="Audio blob from MediaRecorder"),
        language: str | None = Query(None, description="Optional language code (e.g. 'en')"),
    ):
        if ai.batteries is None or ai.batteries.voice is None:
            raise _v6_unavailable("batteries (voice)")
        # Read the uploaded audio bytes.
        try:
            audio_bytes = await audio.read()
        except Exception as exc:
            raise HTTPException(400, detail=f"failed to read audio upload: {exc}")
        if not audio_bytes:
            raise HTTPException(400, detail="empty audio upload")
        # Pick a suffix based on the content type so Whisper can decode it.
        ct = (audio.content_type or "").lower()
        if "webm" in ct:
            suffix = ".webm"
        elif "ogg" in ct:
            suffix = ".ogg"
        elif "wav" in ct:
            suffix = ".wav"
        elif "mp3" in ct or "mpeg" in ct:
            suffix = ".mp3"
        elif "m4a" in ct or "mp4" in ct:
            suffix = ".m4a"
        else:
            # Fall back to the filename extension if present.
            fname = (audio.filename or "").lower()
            if "." in fname:
                suffix = "." + fname.rsplit(".", 1)[-1]
            else:
                suffix = ".webm"  # MediaRecorder default
        # Check Whisper availability up front so we return a clear error.
        if not ai.batteries.voice._check_available():
            raise HTTPException(
                503,
                detail="Whisper is not installed on the server — "
                       "run `pip install openai-whisper` to enable voice transcription.",
            )
        try:
            result = await ai.batteries.voice.transcribe_bytes(
                audio_bytes, language=language, suffix=suffix,
            )
            return {
                "transcript": result.get("transcript", ""),
                "language": result.get("language"),
                "segments": result.get("segments", 0),
                "error": result.get("error"),
                "audio_bytes": len(audio_bytes),
                "audio_format": suffix.lstrip("."),
            }
        except Exception as exc:
            log.exception("Voice transcription failed")
            raise HTTPException(500, detail=str(exc))

    # ── Subconscious → Executive Bridge ───────────────────────────────────

    @app.get("/v6/bridge/recent")
    async def _v6_bridge_recent(k: int = Query(20, ge=1, le=100)):
        if ai.subconscious_bridge is None:
            raise _v6_unavailable("subconscious_bridge")
        return {"entries": ai.subconscious_bridge.recent(k)}

    return app
