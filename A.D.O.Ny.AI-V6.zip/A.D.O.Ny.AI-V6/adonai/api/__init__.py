"""FastAPI server exposing the ADONAI v3 runtime over HTTP + WebSocket."""
from adonai.api.server import create_app

__all__ = ["create_app"]
