"""Scientific Discovery API routes — start/status/report endpoints."""
# NOTE: no `from __future__ import annotations` — breaks FastAPI type hints.

import json
import logging
from pathlib import Path
from typing import Any

from fastapi import HTTPException
from pydantic import BaseModel

log = logging.getLogger(__name__)


class DiscoveryRequest(BaseModel):
    objective: str
    max_generations: int = 8
    population_size: int = 6
    target_fitness: float = 0.85
    constraints: dict[str, float] | None = None


def register_discovery_routes(app, ai) -> None:
    """Register /discovery/* endpoints on a FastAPI app."""

    @app.post("/discovery/run")
    async def run_discovery(req: DiscoveryRequest) -> dict:
        """Run a scientific discovery campaign synchronously.  Returns the report."""
        if ai.llm is None:
            raise HTTPException(503, "LLM not initialized")
        from adonai.discovery.discovery_node import ResearchDirector
        director = ResearchDirector(
            llm=ai.llm,
            db_path=str(ai.config.memory.sqlite_path),
            max_generations=req.max_generations,
            population_size=req.population_size,
            target_fitness=req.target_fitness,
            constraints=req.constraints or {},
        )
        report = await director.run_campaign(req.objective)
        return report

    @app.get("/discovery/campaigns")
    async def list_campaigns() -> list[dict]:
        """List all discovery campaigns."""
        from adonai.discovery.discovery_node import DiscoveryMemory
        mem = DiscoveryMemory(str(ai.config.memory.sqlite_path))
        return mem.list_campaigns()

    @app.get("/discovery/campaigns/{campaign_id}")
    async def get_campaign(campaign_id: str) -> dict:
        """Get a campaign + all its generations."""
        from adonai.discovery.discovery_node import DiscoveryMemory
        mem = DiscoveryMemory(str(ai.config.memory.sqlite_path))
        campaign = mem.load_campaign(campaign_id)
        if not campaign:
            raise HTTPException(404, f"campaign {campaign_id!r} not found")
        generations = mem.load_generations(campaign_id)
        campaign["generations"] = generations
        return campaign

    @app.get("/discovery/report")
    async def get_latest_report() -> dict:
        """Get the latest research report from disk."""
        report_path = Path("data/discovery/research_report.md")
        design_path = Path("data/discovery/best_design.json")
        result: dict[str, Any] = {}
        if report_path.exists():
            result["report_md"] = report_path.read_text()
        if design_path.exists():
            result["best_design"] = json.loads(design_path.read_text())
        if not result:
            raise HTTPException(404, "no reports found — run a campaign first")
        return result
