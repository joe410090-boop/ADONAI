"""v4 API routes — expose research-grade subsystems via FastAPI.

Endpoints:

  POST /critique              — run the Critic on a target
  POST /debate                — run a multi-agent debate
  POST /hypotheses            — generate falsifiable hypotheses
  POST /experiment-loop       — run the autonomous experiment loop
  POST /strategy              — decompose a mission into strategic goals
  POST /simulations           — run a simulation
  GET  /events                — recent EventBus history (filtered by type)
  GET  /events/stream         — SSE stream of new events (live)
  POST /prompt-engineer       — run the Prompt Engineering Node on a request
"""
# NOTE: no `from __future__ import annotations` — breaks FastAPI type hints.

import asyncio
import json
import logging
from typing import Any

from fastapi import HTTPException
from pydantic import BaseModel

from adonai.core.events import EventTypes

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Request models
# ──────────────────────────────────────────────────────────────────────────────

class CritiqueRequest(BaseModel):
    goal: str
    target: Any
    target_kind: str = "result"  # result | plan | step | hypothesis | experiment


class DebateRequest(BaseModel):
    question: str
    rounds: int | None = None
    participants: list[str] | None = None


class HypothesisRequest(BaseModel):
    observation: str
    domain: str | None = None
    max_hypotheses: int = 3


class ExperimentLoopRequest(BaseModel):
    goal: str
    max_iterations: int = 10
    confidence_threshold: float = 0.85
    resource_budget_s: float | None = None


class StrategyRequest(BaseModel):
    mission: str
    depth: int = 3


class SimulationRequest(BaseModel):
    simulator: str
    parameters: dict[str, Any] = {}
    config: dict[str, Any] = {}
    metrics: list[str] = []


class PromptEngineerRequest(BaseModel):
    request: str
    context: dict[str, Any] | None = None


# ──────────────────────────────────────────────────────────────────────────────
# Registration
# ──────────────────────────────────────────────────────────────────────────────

def register_v4_routes(app, ai) -> None:
    """Register all v4 endpoints on a FastAPI app."""

    # ── /critique ────────────────────────────────────────────────────────
    @app.post("/critique")
    async def _critique(req: CritiqueRequest) -> dict:
        if ai.critic is None:
            raise HTTPException(503, "Critic not enabled (config.critic.enabled=False)")
        try:
            report = await ai.critique(
                goal=req.goal, target=req.target, target_kind=req.target_kind,
            )
            return report.model_dump()
        except Exception as e:
            raise HTTPException(500, f"critique failed: {e}") from e

    # ── /debate ─────────────────────────────────────────────────────────
    @app.post("/debate")
    async def _debate(req: DebateRequest) -> dict:
        if ai.debate_framework is None:
            raise HTTPException(503, "Debate framework not enabled")
        try:
            debate = await ai.debate(
                req.question,
                rounds=req.rounds,
                participants=req.participants,
            )
            return debate.model_dump()
        except Exception as e:
            raise HTTPException(500, f"debate failed: {e}") from e

    # ── /hypotheses ─────────────────────────────────────────────────────
    @app.post("/hypotheses")
    async def _hypotheses(req: HypothesisRequest) -> list[dict]:
        if ai.hypothesis_generator is None:
            raise HTTPException(503, "Hypothesis generator not enabled")
        try:
            hyps = await ai.generate_hypotheses(
                req.observation,
                domain=req.domain,
                max_hypotheses=req.max_hypotheses,
            )
            return [h.model_dump() for h in hyps]
        except Exception as e:
            raise HTTPException(500, f"hypothesis generation failed: {e}") from e

    # ── /experiment-loop ────────────────────────────────────────────────
    @app.post("/experiment-loop")
    async def _experiment_loop(req: ExperimentLoopRequest) -> dict:
        if ai.experiment_loop is None:
            raise HTTPException(503, "Experiment loop not enabled")
        try:
            state = await ai.run_experiment_loop(
                req.goal,
                max_iterations=req.max_iterations,
                confidence_threshold=req.confidence_threshold,
                resource_budget_s=req.resource_budget_s,
            )
            # Serialise: state contains Pydantic models (Hypothesis, Experiment, Lesson).
            return _serialise_state(state)
        except Exception as e:
            raise HTTPException(500, f"experiment loop failed: {e}") from e

    # ── /strategy ───────────────────────────────────────────────────────
    @app.post("/strategy")
    async def _strategy(req: StrategyRequest) -> list[dict]:
        if ai.strategic_reasoner is None:
            raise HTTPException(503, "Strategic reasoner not enabled")
        try:
            goals = await ai.decompose_strategy(req.mission, depth=req.depth)
            return [g.model_dump() for g in goals]
        except Exception as e:
            raise HTTPException(500, f"strategy decomposition failed: {e}") from e

    # ── /simulations ────────────────────────────────────────────────────
    @app.post("/simulations")
    async def _simulations(req: SimulationRequest) -> dict:
        if ai.simulators is None:
            raise HTTPException(503, "Simulation layer not enabled")
        try:
            from adonai.core.models import SimulationSpec
            spec = SimulationSpec(
                simulator=req.simulator,
                parameters=req.parameters,
                config=req.config,
                metrics=req.metrics,
            )
            result = await ai.run_simulation(spec)
            return result.model_dump()
        except Exception as e:
            raise HTTPException(500, f"simulation failed: {e}") from e

    # ── /prompt-engineer ────────────────────────────────────────────────
    @app.post("/prompt-engineer")
    async def _prompt_engineer(req: PromptEngineerRequest) -> dict:
        if ai.prompt_engineer is None:
            raise HTTPException(503, "Prompt Engineering Node not enabled")
        try:
            package = await ai.engineer_prompt(
                req.request, context=req.context,
            )
            return package.model_dump()
        except Exception as e:
            raise HTTPException(500, f"prompt engineering failed: {e}") from e

    # ── /events ─────────────────────────────────────────────────────────
    @app.get("/events")
    async def _events(
        event_type: str | None = None,
        limit: int = 100,
    ) -> list[dict]:
        """Return recent EventBus history."""
        events = ai.events.history(event_type=event_type, limit=limit)
        return [
            {
                "type": e.type,
                "source": e.source,
                "timestamp": e.timestamp.isoformat(),
                "payload": e.payload,
            }
            for e in events
        ]

    # ── /events/stream (SSE) ────────────────────────────────────────────
    @app.get("/events/stream")
    async def _events_stream(event_type: str | None = None):
        """Server-Sent Events stream of new EventBus events.

        Clients can subscribe with ``EventSource('/events/stream')`` and
        optionally filter by ``?event_type=...``.
        """
        from fastapi.responses import StreamingResponse
        import queue

        q: asyncio.Queue = asyncio.Queue()

        async def _subscriber(event):
            if event_type is None or event.type == event_type:
                try:
                    await q.put(event)
                except Exception:
                    pass

        ai.events.subscribe(event_type or "*", _subscriber)

        async def _gen():
            try:
                while True:
                    event = await q.get()
                    payload = {
                        "type": event.type,
                        "source": event.source,
                        "timestamp": event.timestamp.isoformat(),
                        "payload": event.payload,
                    }
                    yield f"data: {json.dumps(payload)}\n\n"
            finally:
                # Best-effort unsubscribe on disconnect.
                try:
                    ai.events.unsubscribe(event_type or "*", _subscriber)
                except Exception:
                    pass

        return StreamingResponse(_gen(), media_type="text/event-stream")


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _serialise_state(state: dict[str, Any]) -> dict[str, Any]:
    """Convert experiment-loop state (with Pydantic models) to plain dicts."""
    out: dict[str, Any] = {}
    for k, v in state.items():
        if isinstance(v, list):
            out[k] = [
                item.model_dump() if hasattr(item, "model_dump") else item
                for item in v
            ]
        elif hasattr(v, "model_dump"):
            out[k] = v.model_dump()
        else:
            out[k] = v
    return out
