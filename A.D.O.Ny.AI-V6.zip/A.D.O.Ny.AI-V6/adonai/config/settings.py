"""Typed configuration for A.D.O.N.AI v3.

Layered: defaults < env vars < YAML config < CLI overrides.
All paths resolved relative to PROJECT_ROOT (the repo root, not the
package root) so data/ stays in the user-visible project dir.
"""
from __future__ import annotations

import os
import re
from functools import lru_cache
from pathlib import Path
from typing import Any, Literal

import yaml
from pydantic import BaseModel, Field, SecretStr, field_validator


# PROJECT_ROOT = parent of the adonai/ package = the repo root.
PROJECT_ROOT = Path(__file__).resolve().parents[2]
_BUNDLED_DEFAULTS_YAML = PROJECT_ROOT / "config" / "default.yaml"


# ──────────────────────────────────────────────────────────────────────────────
# Sub-configs
# ──────────────────────────────────────────────────────────────────────────────

class LLMConfig(BaseModel):
    """Local LLM backend configuration."""
    backend: Literal["ollama", "vllm", "llama_cpp", "openai_compat"] = "ollama"
    model_name: str = "kamekichi128/qwen3-4b-instruct-2507"
    base_url: str = "http://localhost:11434"
    api_key: SecretStr = SecretStr("")
    temperature: float = 0.7
    top_p: float = 0.9
    top_k: int = 20
    # Penalties — default 0 because Modelfiles often ship with aggressive
    # values (qwen3.5:4b ships with presence_penalty=1.5) that cause small
    # models to hallucinate wildly.  Set non-zero in config to override.
    presence_penalty: float = 0.0
    frequency_penalty: float = 0.0
    # Thinking mode — qwen3-series models ship with "thinking" enabled by
    # default.  For tool-calling agents this is COUNTERPRODUCTIVE: the model
    # burns its entire max_tokens budget on `<think>...</think>` blocks and
    # never produces a real answer.  Default false (disabled).  Set true
    # only if you're using the model for pure reasoning without tools AND
    # you've raised max_tokens to ≥4096.
    enable_thinking: bool = False  # CRITICAL: keep False for qwen3 tool-calling
    max_tokens: int = 32768
    context_window: int = 262144
    request_timeout: float = 300.0
    max_retries: int = 7
    # Embedding
    embedding_model: str = "nomic-embed-text:latest"
    embedding_dim: int = 768
    embedding_base_url: str | None = None
    # Cache (response cache for repeated identical prompts)
    enable_cache: bool = True
    cache_max_entries: int = 500
    # Vision capability override — lets the user force the FileAnalysisAgent
    # to either attempt or skip image-analysis calls regardless of the
    # heuristic / runtime detection.
    #
    #   None  (default) — auto-detect: try /api/show first, fall back to
    #                     the is_vision_model() name-based heuristic.
    #   True            — always treat the model as vision-capable and
    #                     attempt the multimodal call.  Use this if you've
    #                     attached a custom vision projector to a model
    #                     whose name doesn't match any known pattern
    #                     (e.g. a user-namespace Modelfile like
    #                     "frob/qwen3.5-instruct:4b" with PROJECTOR set).
    #   False           — never attempt the vision call; always fall
    #                     through to the PIL metadata fallback.  Use this
    #                     to silence false-positive vision attempts.
    vision_capable: bool | None = None

    @field_validator("temperature")
    @classmethod
    def _temp_range(cls, v: float) -> float:
        if not 0.0 <= v <= 2.0:
            raise ValueError("temperature must be between 0.0 and 2.0")
        return v


class MemoryConfig(BaseModel):
    """5-tier memory system configuration."""
    # Paths
    sqlite_path: Path = PROJECT_ROOT / "data" / "adonai.db"
    chroma_path: Path = PROJECT_ROOT / "data" / "chroma"
    faiss_path: Path = PROJECT_ROOT / "data" / "faiss.index"
    graph_path: Path = PROJECT_ROOT / "data" / "knowledge_graph.db"
    # Backends
    use_sqlite: bool = True
    use_chroma: bool = True
    use_faiss: bool = False  # ChromaDB covers the same use-case; FAISS is opt-in
    use_knowledge_graph: bool = True
    # Sizes
    working_window: int = 32
    episodic_top_k: int = 8
    semantic_top_k: int = 8
    consolidation_interval: int = 50  # run consolidation every N writes
    max_memory_items: int = 100_000
    # Consolidation
    consolidation_min_age_s: int = 3600
    consolidation_importance_threshold: float = 0.3


class BrowserConfig(BaseModel):
    headless: bool = True
    browser: Literal["chromium", "firefox", "webkit"] = "chromium"
    viewport: dict = Field(default_factory=lambda: {"width": 1280, "height": 720})
    default_timeout_ms: int = 30_000
    screenshot_dir: Path = PROJECT_ROOT / "data" / "screenshots"
    proxy: str | None = None


class MCPConfig(BaseModel):
    enabled: bool = True
    config_path: Path = PROJECT_ROOT / "config" / "mcp_servers.yaml"
    discovery_timeout_s: float = 5.0
    tool_call_timeout_s: float = 60.0
    health_check_interval_s: float = 60.0
    allowed_servers: list[str] | None = None
    deny_tools: list[str] = Field(default_factory=list)
    # v6: MCP tools are remote-controlled and their declared risk_level
    # cannot be trusted (a malicious server can self-declare "low"). We
    # now default ALL MCP tools to "high" risk, which means they trigger
    # the human-approval gate. Operators can opt out per-tool by listing
    # the tool name in `trusted_tools` below.
    default_risk_level: str = "high"
    trusted_tools: list[str] = Field(default_factory=list)


class SafetyConfig(BaseModel):
    # v5: require_approval now defaults to True. High-risk tools
    # (terminal, python_exec) trigger the human-approval callback when
    # one is registered. The API server registers one automatically.
    # Set to False only in sandboxed/CI environments.
    require_approval: bool = True
    sandbox_execution: bool = True
    audit_log_path: Path = PROJECT_ROOT / "data" / "audit.log"
    max_actions_per_task: int = 50
    max_task_duration_s: int = 3600
    forbidden_paths: list[str] = Field(
        default_factory=lambda: ["/etc", "/var", "/root", "/System", "/Windows"]
    )
    forbidden_commands: list[str] = Field(
        default_factory=lambda: ["rm -rf /", "shutdown", "reboot", "mkfs", "dd if=/dev/zero of=/dev/"]
    )


class TasksConfig(BaseModel):
    checkpoint_dir: Path = PROJECT_ROOT / "data" / "checkpoints"
    checkpoint_interval_s: int = 30
    max_concurrent_tasks: int = 4
    max_retries: int = 5
    recovery_on_startup: bool = True
    queue_poll_interval_s: float = 0.5


class AgentConfig(BaseModel):
    """Per-agent runtime tunables."""
    max_iterations: int = 8
    max_concurrent_agents: int = 4
    # DEPRECATED: use config.reflection.enabled and
    # config.self_improvement.enabled instead.
    checkpoint_interval_seconds: int = 30
    default_temperature: float = 0.2
    reflection_confidence_threshold: float = 0.5
    fast_mode: bool = True
    learn_preferences: bool = True
    # Reasoning
    # v6: added "graph_of_thought" — previously the strategy was registered
    # in the engine but unreachable from config (the Literal forbade it).
    reasoning_strategy: Literal[
        "cot", "tot", "self_consistency", "debate", "graph_of_thought",
        "reflection_engine", "auto"
    ] = "auto"
    reasoning_candidates: int = 3  # for self-consistency / ToT branching
    # Multi-agent
    enable_multi_agent: bool = True
    enable_voting: bool = True
    # Executive autonomy layer — perpetual background loop that picks the
    # next-best goal from the world model and works on it.
    # v5: now enabled by default. The loop coordinates planner, executor,
    # reflection, memory, learning, and recovery. Set to false to disable
    # unattended operation in development environments.
    executive_loop: bool = True
    executive_tick_s: float = 5.0  # how often the loop polls for new work
    # Skills
    auto_extract_skills: bool = True
    min_success_rate: float = 0.6  # retire below this


class APIConfig(BaseModel):
    # v4 hardening: default to loopback (127.0.0.1) instead of 0.0.0.0.
    # Operators who want to expose the API must explicitly set host="0.0.0.0".
    host: str = "127.0.0.1"
    port: int = 8000
    # v4 hardening: default to a restrictive CORS allowlist. The previous
    # default of ["*"] combined with allow_credentials=True was insecure.
    cors_origins: list[str] = Field(default_factory=lambda: ["http://localhost:3000", "http://localhost:8000"])
    api_key: SecretStr | None = None
    enable_docs: bool = True
    max_request_body_size: int = 1_048_576
    # v4: rate limiting (requests per minute per IP). 0 = disabled.
    rate_limit_per_minute: int = 60


class SkillsConfig(BaseModel):
    skills_dir: Path = PROJECT_ROOT / "data" / "skills"
    auto_extract: bool = True
    min_success_rate: float = 0.6
    version_lock: bool = True
    retirement_age_days: int = 30


class AnalyticsConfig(BaseModel):
    enabled: bool = True
    metrics_path: Path = PROJECT_ROOT / "data" / "metrics.db"
    # Snapshot interval for rolling stats
    snapshot_interval_s: int = 300


class IntegrationsConfig(BaseModel):
    neo4j_uri: str = "bolt://localhost:7687"
    neo4j_user: str = "neo4j"
    neo4j_password: SecretStr = SecretStr("")
    neo4j_enabled: bool = False
    hallucination_reports_dir: Path = PROJECT_ROOT / "data" / "hallucination_reports"
    pattern_analysis_enabled: bool = True


class DatabaseConfig(BaseModel):
    """Central database paths used by v4+ persistence layers."""
    path: Path = PROJECT_ROOT / "data" / "adonai.db"
    experiment_loops_db: Path = PROJECT_ROOT / "data" / "experiment_loops.db"
    prompt_engineering_db: Path = PROJECT_ROOT / "data" / "prompt_engineering.db"
    metrics_db: Path = PROJECT_ROOT / "data" / "metrics.db"
    knowledge_graph_db: Path = PROJECT_ROOT / "data" / "knowledge_graph.db"


# ──────────────────────────────────────────────────────────────────────────────
# v4 — Research-grade extensions
# ──────────────────────────────────────────────────────────────────────────────


class CriticConfig(BaseModel):
    """Upgrade 1 — Critic Agent."""
    enabled: bool = True
    # Where in the pipeline the critic runs.
    run_on_plan: bool = True
    run_on_step: bool = False  # expensive; opt-in
    run_on_result: bool = True
    run_on_hypothesis: bool = True
    # Decision thresholds.
    revise_threshold: float = 0.45  # confidence below this → revise
    reject_threshold: float = 0.20  # confidence below this → reject
    risk_block_threshold: float = 0.80  # risk_score above this → reject
    # LLM tuning.
    temperature: float = 0.2
    max_tokens: int = 1024


class KnowledgeGraphConfig(BaseModel):
    """Upgrade 2 — Knowledge Graph."""
    enabled: bool = True
    # Confidence + evidence tracking.
    default_confidence: float = 0.5
    min_evidence_to_promote: float = 0.7
    decay_rate: float = 0.01  # per day
    # Entity extraction.
    auto_extract_from_observations: bool = True
    auto_extract_from_web_results: bool = True
    max_entities_per_observation: int = 10
    # Planner integration.
    inject_into_planner: bool = True
    max_neighborhood_hops: int = 2
    max_context_entities: int = 20


class TreeOfThoughtConfig(BaseModel):
    """Upgrade 3 — Tree-of-Thought Planning."""
    enabled: bool = True
    branching_factor: int = 3
    """Number of candidate plans to generate."""
    max_depth: int = 2
    """How many levels of plan refinement to consider."""
    parallel_generation: bool = True
    score_weights: dict[str, float] = Field(
        default_factory=lambda: {
            "confidence": 0.4,
            "step_count": 0.15,
            "tool_coverage": 0.15,
            "dep_structure": 0.15,
            "risk": 0.15,
        }
    )
    min_score_delta: float = 0.05
    """If the top-2 plans differ by less than this, flag for critic review."""


class ReflectionConfig(BaseModel):
    """Upgrade 4 — Reflection Engine."""
    enabled: bool = True
    run_after_every_task: bool = True
    questions: list[str] = Field(
        default_factory=lambda: [
            "What worked?",
            "What failed?",
            "What surprised us?",
            "What should change?",
        ]
    )
    max_lessons_per_task: int = 5
    min_lesson_confidence: float = 0.4
    # Persistence.
    sqlite_table: str = "lessons"
    # Reinforcement tracking.
    reinforcement_window_days: int = 30


class SkillEvolutionConfig(BaseModel):
    """Upgrade 5 — Skill Evolution System."""
    enabled: bool = True
    min_observations_to_extract: int = 3
    """How many times a pattern must repeat before becoming a skill."""
    min_success_rate_to_promote: float = 0.7
    behavioral_verification_samples: int = 3
    """How many held-out examples a new skill must pass."""
    auto_promote_to_tool: bool = True
    retire_after_n_failures: int = 5
    version_on_change: bool = True

class DebateConfig(BaseModel):
    """Upgrade 6 — Multi-Agent Debate."""
    enabled: bool = True
    default_rounds: int = 2
    default_participants: list[str] = Field(
        default_factory=lambda: ["researcher", "skeptic", "engineer"]
    )
    judge_temperature: float = 0.1
    participant_temperature: float = 0.6
    max_argument_tokens: int = 600
    require_evidence: bool = True
    consensus_threshold: float = 0.65


class HypothesisConfig(BaseModel):
    """Upgrade 7 — Hypothesis Generator."""
    enabled: bool = True
    max_hypotheses_per_observation: int = 3
    min_falsifiability_score: float = 0.5
    """Reject hypotheses that can't be falsified."""
    default_prior: float = 0.5
    # Bayesian update parameters.
    supporting_evidence_weight: float = 0.15
    contradicting_evidence_weight: float = 0.20
    max_supported_confidence: float = 0.95
    min_refuted_confidence: float = 0.05


class ExperimentLoopConfig(BaseModel):
    """Upgrade 8 — Autonomous Experiment Loop."""
    enabled: bool = True
    default_max_iterations: int = 10
    default_confidence_threshold: float = 0.85
    default_resource_budget_s: float = 3600.0
    # Stopping criteria.
    stop_on_convergence: bool = True
    stop_on_resource_limit: bool = True
    stop_on_user_intervention: bool = True
    # Iteration pacing.
    min_iteration_s: float = 1.0
    backoff_on_failure: float = 1.5


class ModelRouterConfig(BaseModel):
    """Upgrade 9 — Resource Intelligence Layer."""
    enabled: bool = True
    # Tier definitions — each tier maps to a (backend, model_name) pair.
    tiers: dict[str, dict[str, str]] = Field(
        default_factory=lambda: {
            "small": {"backend": "ollama", "model_name": "qwen2.5:1.5b"},
            "medium": {"backend": "ollama", "model_name": "qwen2.5:7b"},
            "large": {"backend": "ollama", "model_name": "qwen2.5:32b"},
            "vision": {"backend": "ollama", "model_name": "llava:7b"},
            "embedding": {"backend": "ollama", "model_name": "nomic-embed-text:latest"},
        }
    )
    # Routing heuristics.
    complexity_to_tier: dict[str, str] = Field(
        default_factory=lambda: {
            "trivial": "small",
            "simple": "small",
            "moderate": "medium",
            "complex": "large",
            "open_ended": "large",
        }
    )
    # Cost / latency awareness.
    latency_ema_alpha: float = 0.3
    max_cost_tokens_per_task: int = 100_000
    fallback_to_cheaper_on_timeout: bool = True
    # Quality scoring.
    quality_window: int = 20  # last N calls


class SelfImprovementConfig(BaseModel):
    """Upgrade 10 — Self-Improvement Framework.
    
    v5: now enabled by default. The engine is safety-hardened (path
    containment, automatic rollback, protected files) and auto-triggered
    by the LearningLoop when recent success rate < 50%.
    """
    enabled: bool = True  # v5: enabled by default
    # Safety — files that must NEVER be patched.
    protected_files: list[str] = Field(
        default_factory=lambda: [
            "adonai/runtime.py",
            "adonai/core/interfaces.py",
            "adonai/core/models.py",
            "adonai/core/exceptions.py",
            "adonai/safety/self_improvement.py",
            "main.py",
        ]
    )
    sandbox_dir: Path = PROJECT_ROOT / "data" / "sandbox"
    require_tests_pass: bool = True
    test_command: str = "python -m pytest tests/ -x --tb=short"
    auto_rollback_on_regression: bool = True
    max_patches_per_run: int = 5
    # Pattern detection.
    bottleneck_min_observations: int = 3
    bottleneck_latency_threshold_s: float = 30.0


class SimulationConfig(BaseModel):
    """Upgrade 11 — Simulation Abstraction Layer."""
    enabled: bool = True
    # Registered simulators (name → config dict).
    simulators: dict[str, dict[str, Any]] = Field(
        default_factory=lambda: {
            "mock": {"backend": "mock"},
            "openfoam": {"backend": "cli", "binary": "simpleFoam"},
            "pybullet": {"backend": "python", "module": "pybullet"},
            "carla": {"backend": "python", "module": "carla"},
            "isaac_sim": {"backend": "python", "module": "isaacsim"},
        }
    )
    default_simulator: str = "mock"
    default_timeout_s: float = 600.0
    max_concurrent_simulations: int = 2
    working_dir: Path = PROJECT_ROOT / "data" / "simulations"


class StrategyConfig(BaseModel):
    """Upgrade 12 — Long-Term Strategic Reasoning."""
    enabled: bool = True
    default_depth: int = 3
    max_goals: int = 100
    # Replanning.
    auto_replan_blocked_goals: bool = True
    replan_cooldown_s: float = 60.0
    # Probability model.
    success_probability_decay: float = 0.05
    """How much success probability decays per failed sub-goal."""
    # Persistence.
    sqlite_table: str = "strategic_goals"


class PromptOptimizerConfig(BaseModel):
    """v5 — PromptOptimizer now wired into LearningLoop.

    Runs every ``optimization_interval_tasks`` tasks. Generates N variants
    of the current system prompt, scores them by success_rate ×
    mean_confidence, and promotes the winner if it beats the current
    by ``promotion_margin``.
    """
    enabled: bool = True
    promotion_margin: float = 0.05
    max_variants: int = 3
    optimization_interval_tasks: int = 50
    db_path: Path = PROJECT_ROOT / "data" / "prompt_variants.db"


class BenchmarkConfig(BaseModel):
    """v5 — BenchmarkRunner now wired into LearningLoop + API.

    Runs the default benchmark suite every ``interval_tasks`` tasks
    (or via POST /benchmark). Results persist to SQLite so trends
    survive restarts.
    """
    enabled: bool = True
    interval_tasks: int = 100
    db_path: Path = PROJECT_ROOT / "data" / "benchmarks.db"


class DiscoveryConfig(BaseModel):
    """v9 — Discovery subsystem configuration.

    Aggregates settings that control the autonomous discovery
    pipeline (hypothesis generation + experiment loop). Most
    discovery behaviour is still gated by ``hypothesis.enabled``
    and ``experiment_loop.enabled`` above; this config adds the
    ``autonomous`` flag that, when True, lets the planner/runtime
    proactively invoke hypothesis generation for COMPLEX/OPEN_ENDED
    tasks with a science/research domain signal — without requiring
    a manual POST /hypotheses or POST /experiments call.
    """
    autonomous: bool = False
    """When True, the runtime's _run_task() may invoke the
    HypothesisGenerator for COMPLEX/OPEN_ENDED tasks whose goal
    matches a science/research domain signal. Default False to
    preserve the existing manual-only behaviour — operators must
    opt in (e.g. via config/default.yaml) to enable proactive
    discovery, since it adds LLM cost per qualifying task."""
    # Domain signals — if any of these keywords appear in the task
    # goal AND the task is COMPLEX/OPEN_ENDED AND autonomous=True,
    # the runtime will generate hypotheses and stash them in
    # task.context["hypotheses"] for the planner to consume.
    domain_signals: list[str] = Field(
        default_factory=lambda: [
            "research", "experiment", "hypothesis", "study", "analyse",
            "analyze", "investigate", "scientific", "physics", "chemistry",
            "biology", "materials", "simulation", "model", "phenomenon",
        ]
    )
    max_hypotheses_per_task: int = 3


# ──────────────────────────────────────────────────────────────────────────────
# Pentest subsystem config (absorbed from Strix)
# ──────────────────────────────────────────────────────────────────────────────


class PentestDockerConfig(BaseModel):
    """Docker sandbox configuration for offensive tool execution."""
    enabled: bool = True
    image: str = "adonai/pentest-sandbox:latest"
    network_mode: str = "bridge"
    mem_limit: str = "2g"
    cpus: str = "2.0"
    run_as_user: str = "pentester"
    auto_remove: bool = True


class PentestProxyConfig(BaseModel):
    """HTTP interception proxy config (Caido or passive capture)."""
    caido_url: str | None = None
    caido_key: str | None = None
    capture_buffer_size: int = 500


class PentestSettingsConfig(BaseModel):
    """Top-level config for the pentest subsystem.

    Named ``PentestSettingsConfig`` to avoid collision with
    :class:`adonai.pentest.sandbox.PentestConfig` (the per-scan runtime
    config). This is the *static* config loaded from YAML; the per-scan
    config is built from it + task context.
    """
    docker: PentestDockerConfig = Field(default_factory=PentestDockerConfig)
    proxy: PentestProxyConfig = Field(default_factory=PentestProxyConfig)
    default_scan_mode: str = "deep"
    default_max_turns: int = 50
    default_run_dir: str = "workspace/pentest_runs"
    forbidden_targets: list[str] = Field(
        default_factory=lambda: [
            "169.254.169.254", "metadata.google.internal", "metadata.azure.com",
            "fd00:ec2::254", "localhost", "127.0.0.1", "0.0.0.0",
        ]
    )


# ──────────────────────────────────────────────────────────────────────────────
# v6 — OpenHuman-inspired subsystems
# ──────────────────────────────────────────────────────────────────────────────


class MemoryTreeConfig(BaseModel):
    """Memory Tree + Obsidian Wiki mirror.

    Your data compressed into scored Markdown trees in SQLite on your
    machine, mirrored as an Obsidian vault you can open and edit.
    No vector-soup black box.
    """
    enabled: bool = True
    db_path: Path = PROJECT_ROOT / "data" / "memory_tree.db"
    vault_path: Path = PROJECT_ROOT / "data" / "obsidian_vault"
    # Scoring weights for chunk importance (0.0–1.0).
    score_weights: dict[str, float] = Field(
        default_factory=lambda: {
            "recency": 0.25,
            "frequency": 0.20,
            "entity_density": 0.20,
            "source_authority": 0.15,
            "user_pin": 0.20,
        }
    )
    # Compression: how aggressively to summarize when building tree nodes.
    target_chunk_tokens: int = 512
    max_tree_depth: int = 4
    # Mirror: how often to sync the SQLite tree to the Obsidian vault.
    mirror_interval_s: float = 60.0
    auto_pin_user_messages: bool = True


class SubconsciousConfig(BaseModel):
    """Background loop that diffs your world, advances your goals, and
    writes your morning briefing.  Thinking continues after you stop typing.
    """
    enabled: bool = True
    tick_interval_s: float = 300.0  # 5 minutes
    context_budget_tokens: int = 4096
    # The morning briefing is generated at this local hour, if set.
    morning_briefing_hour: int | None = 8
    # The bridge to the executive_loop: when a tick finds actionable
    # work, it fires a goal at the executive loop via this URL.
    bridge_to_executive: bool = True
    bridge_endpoint: str = "/background"
    # World-diff sources — each is polled per tick.
    diff_sources: list[str] = Field(
        default_factory=lambda: ["memory_tree", "git", "channels", "calendar"]
    )


class GoalsTodosConfig(BaseModel):
    """Long-term goals, durable per-thread goals, and a shared kanban
    board per conversation."""
    enabled: bool = True
    db_path: Path = PROJECT_ROOT / "data" / "goals_todos.db"
    # Kanban columns — fixed in OpenHuman for parity, but configurable.
    kanban_columns: list[str] = Field(
        default_factory=lambda: ["backlog", "todo", "doing", "review", "done"]
    )
    max_long_term_goals: int = 20
    max_per_thread_goals: int = 8
    # Auto-promote a per-thread goal to long-term when it survives N turns.
    promote_to_long_term_after_turns: int = 10


class TokenJuiceConfig(BaseModel):
    """Tool output compressed before it hits the model: same
    information, up to 80% fewer tokens."""
    enabled: bool = True
    # Compression strategy: "summary" (LLM-based) or "extractive" (TF-IDF)
    # or "auto" (extractive for short outputs, summary for long ones).
    strategy: Literal["summary", "extractive", "auto"] = "auto"
    # Outputs shorter than this are passed through uncompressed.
    min_tokens_to_compress: int = 256
    # Target compression ratio (output_tokens / input_tokens).
    target_ratio: float = 0.20
    # Hard cap on output tokens after compression.
    max_output_tokens: int = 1024
    # Cache compressed outputs by SHA-256 of the input.
    cache_enabled: bool = True
    cache_max_entries: int = 500


class WorkflowsConfig(BaseModel):
    """Durable, trigger-driven, approval-gated runs on a tinyflows-style
    graph engine. The agent proposes the automation; you review it on a
    canvas and save."""
    enabled: bool = True
    db_path: Path = PROJECT_ROOT / "data" / "workflows.db"
    # 12 node kinds (parity with OpenHuman).
    node_kinds: list[str] = Field(
        default_factory=lambda: [
            "trigger", "agent", "tool_call", "http_request", "code",
            "condition", "switch", "transform", "split_out", "merge",
            "output_parser", "sub_workflow",
        ]
    )
    # Trigger kinds live today.
    trigger_kinds: list[str] = Field(
        default_factory=lambda: ["schedule", "app_event", "manual", "resume"]
    )
    # A per-flow dispatch lock means a schedule burst can never run the
    # same flow twice concurrently.
    dispatch_lock: bool = True
    # Default approval policy.
    require_approval_for_outbound: bool = True


class GraphHarnessConfig(BaseModel):
    """Checkpointed graph runs. Stuck agents get steered, halted ones
    return a root cause, and every run replays with real per-call costs."""
    enabled: bool = True
    # No-progress circuit breaker: stop after N consecutive steps with no
    # state change.
    no_progress_breaker_steps: int = 3
    # Max sub-agent depth (OpenHuman parity: 3 levels deep).
    max_subagent_depth: int = 3
    # Per-call cost tracking — persisted for replay.
    track_per_call_costs: bool = True
    cost_db_path: Path = PROJECT_ROOT / "data" / "graph_costs.db"


class SplitBrainConfig(BaseModel):
    """A fast reflex agent triages inbound traffic while a deep reasoning
    core delegates to worker fleets, steered by the subconscious."""
    enabled: bool = True
    # Reflex agent target latency (seconds).
    reflex_target_s: float = 2.0
    # Reflex model tier (small/fast). Falls back to main LLM if unset.
    reflex_model_tier: str = "small"
    # Deep reasoning core model tier.
    deep_model_tier: str = "large"
    # 20:1 history compression ratio (OpenHuman parity).
    history_compression_ratio: int = 20
    # Superstep cap — guarantees termination.
    max_supersteps: int = 6


class AgentEconomyConfig(BaseModel):
    """A @handle on tiny.place, Signal-encrypted agent-to-agent
    orchestration, x402 USDC bounties and trading. Keys never touch disk."""
    enabled: bool = False  # Opt-in: requires network access to tiny.place.
    handle: str | None = None  # e.g. "adonai@tiny.place"
    # Signal protocol identity — kept in-memory only, never persisted.
    ephemeral_keys: bool = True
    # x402 USDC payment config.
    x402_enabled: bool = False
    x402_chain: Literal["base", "polygon", "optimism"] = "base"
    x402_usdc_contract: str = "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913"
    # Max bounty the agent may post without human approval (USDC units).
    x402_max_auto_bounty: float = 1.0
    # Pairing is consent-based and fails closed.
    require_pairing_consent: bool = True


class SuperContextConfig(BaseModel):
    """A research scout sweeps your memory and files before the model
    reads your first message. No cold starts."""
    enabled: bool = True
    # Max tokens of context the scout may inject.
    max_context_tokens: int = 2048
    # Sweep memory_tree, workspace, and (optionally) web.
    sweep_sources: list[str] = Field(
        default_factory=lambda: ["memory_tree", "workspace", "recent_files"]
    )
    # Time budget for the sweep — the model must not wait more than this.
    max_sweep_s: float = 3.0


class BatteriesConfig(BaseModel):
    """Batteries included: web search, scraper, coder toolset, a real
    browser, and native voice with in-process Whisper. Model routing
    picks the right LLM per workload on one subscription, with local
    AI optional."""
    web_search_enabled: bool = True
    scraper_enabled: bool = True
    browser_enabled: bool = True
    voice_enabled: bool = True
    whisper_model: str = "base"  # tiny, base, small, medium, large
    whisper_in_process: bool = True
    # Model routing — extend the existing ModelRouterConfig with these
    # additional hints.
    local_ai_optional: bool = True
    image_tools_enabled: bool = True
    video_tools_enabled: bool = True


class MeetingAgentsConfig(BaseModel):
    """Joins Meet, Zoom, Teams, and Webex with a face and a voice.
    Auto-joins from your calendar, streams a live transcript, answers
    by name, and files a summary with action items."""
    enabled: bool = True
    # Calendar providers to watch for meeting links.
    calendar_providers: list[str] = Field(
        default_factory=lambda: ["google", "outlook", "ical"]
    )
    # Platforms supported by the headless joiner.
    platforms: list[str] = Field(
        default_factory=lambda: ["meet", "zoom", "teams", "webex"]
    )
    # Bot display name + face.
    bot_name: str = "ADON.AI"
    bot_avatar_path: Path | None = None
    # Auto-join meetings where you've marked yourself as "attending".
    auto_join_attending: bool = True
    # File a summary + action items to this channel after the meeting.
    summary_destination: str | None = None  # e.g. "slack:#standups"
    # Live transcript language (auto-detect if None).
    transcript_language: str | None = None
    # Max speaking time per turn (seconds) to avoid monologues.
    max_speaking_s: float = 60.0


# ──────────────────────────────────────────────────────────────────────────────
# Top-level Config
# ──────────────────────────────────────────────────────────────────────────────

class Config(BaseModel):
    """Top-level configuration."""
    environment: Literal["development", "staging", "production"] = "development"
    debug: bool = False
    log_level: Literal["DEBUG", "INFO", "WARNING", "ERROR"] = "INFO"

    # Workspace root for sandboxed file operations. Defaults to <project>/workspace.
    # All file.* tools, terminal cwd, and verification-gate FILE_EXISTS checks
    # resolve paths relative to this root.
    workspace: str = ""

    llm: LLMConfig = Field(default_factory=LLMConfig)
    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    browser: BrowserConfig = Field(default_factory=BrowserConfig)
    mcp: MCPConfig = Field(default_factory=MCPConfig)
    safety: SafetyConfig = Field(default_factory=SafetyConfig)
    tasks: TasksConfig = Field(default_factory=TasksConfig)
    agent: AgentConfig = Field(default_factory=AgentConfig)
    api: APIConfig = Field(default_factory=APIConfig)
    skills: SkillsConfig = Field(default_factory=SkillsConfig)
    analytics: AnalyticsConfig = Field(default_factory=AnalyticsConfig)
    integrations: IntegrationsConfig = Field(default_factory=IntegrationsConfig)
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)

    # v4 — Research-grade extensions
    critic: CriticConfig = Field(default_factory=CriticConfig)
    knowledge_graph: KnowledgeGraphConfig = Field(default_factory=KnowledgeGraphConfig)
    tot: TreeOfThoughtConfig = Field(default_factory=TreeOfThoughtConfig)
    reflection: ReflectionConfig = Field(default_factory=ReflectionConfig)
    skill_evolution: SkillEvolutionConfig = Field(default_factory=SkillEvolutionConfig)
    debate: DebateConfig = Field(default_factory=DebateConfig)
    hypothesis: HypothesisConfig = Field(default_factory=HypothesisConfig)
    experiment_loop: ExperimentLoopConfig = Field(default_factory=ExperimentLoopConfig)
    model_router: ModelRouterConfig = Field(default_factory=ModelRouterConfig)
    self_improvement: SelfImprovementConfig = Field(default_factory=SelfImprovementConfig)
    simulation: SimulationConfig = Field(default_factory=SimulationConfig)
    strategy: StrategyConfig = Field(default_factory=StrategyConfig)
    # v5 — newly-wired subsystems
    prompt_optimizer: PromptOptimizerConfig = Field(default_factory=PromptOptimizerConfig)
    benchmark: BenchmarkConfig = Field(default_factory=BenchmarkConfig)
    # v9 — Discovery subsystem (autonomous hypothesis generation flag).
    discovery: DiscoveryConfig = Field(default_factory=DiscoveryConfig)
    # Pentest subsystem (absorbed from Strix).
    pentest: PentestSettingsConfig = Field(default_factory=PentestSettingsConfig)
    # v6 — OpenHuman-inspired subsystems.
    memory_tree: MemoryTreeConfig = Field(default_factory=MemoryTreeConfig)
    subconscious: SubconsciousConfig = Field(default_factory=SubconsciousConfig)
    goals_todos: GoalsTodosConfig = Field(default_factory=GoalsTodosConfig)
    tokenjuice: TokenJuiceConfig = Field(default_factory=TokenJuiceConfig)
    workflows: WorkflowsConfig = Field(default_factory=WorkflowsConfig)
    graph_harness: GraphHarnessConfig = Field(default_factory=GraphHarnessConfig)
    split_brain: SplitBrainConfig = Field(default_factory=SplitBrainConfig)
    agent_economy: AgentEconomyConfig = Field(default_factory=AgentEconomyConfig)
    super_context: SuperContextConfig = Field(default_factory=SuperContextConfig)
    batteries: BatteriesConfig = Field(default_factory=BatteriesConfig)
    meeting_agents: MeetingAgentsConfig = Field(default_factory=MeetingAgentsConfig)

    model_config = {"extra": "ignore"}

    def ensure_dirs(self) -> None:
        """Create all required data directories."""
        dirs = [
            self.memory.sqlite_path.parent,
            self.memory.chroma_path,
            self.memory.faiss_path.parent,
            self.memory.graph_path.parent,
            self.browser.screenshot_dir,
            self.tasks.checkpoint_dir,
            self.safety.audit_log_path.parent,
            self.skills.skills_dir,
            self.analytics.metrics_path.parent,
            self.integrations.hallucination_reports_dir,
            self.database.path.parent,
            self.self_improvement.sandbox_dir,
            self.simulation.working_dir,
            self.memory_tree.db_path.parent,
            self.memory_tree.vault_path,
            self.goals_todos.db_path.parent,
            self.workflows.db_path.parent,
            self.graph_harness.cost_db_path.parent,
            # Additional configured paths
            self.workspace and Path(self.workspace) or None,
            self.prompt_optimizer.db_path.parent,
            self.benchmark.db_path.parent,
        ]
        for d in dirs:
            if d:
                d.mkdir(parents=True, exist_ok=True)


# ──────────────────────────────────────────────────────────────────────────────
# Loader
# ──────────────────────────────────────────────────────────────────────────────

def _expand_env(value):
    """Recursively expand ${VAR:default} placeholders against os.environ."""
    if isinstance(value, str):
        pattern = re.compile(r"\$\{([A-Z_][A-Z0-9_]*)(?::([^}]*))?\}")
        def repl(m: re.Match) -> str:
            var, default = m.group(1), m.group(2)
            return os.environ.get(var, default if default is not None else m.group(0))
        return pattern.sub(repl, value)
    if isinstance(value, dict):
        return {k: _expand_env(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_expand_env(v) for v in value]
    return value


def load_config(path: str | Path | None = None, **overrides) -> Config:
    """Load configuration in priority order:
        1. Caller overrides (kwargs)
        2. YAML at *path* (or env ADONAI_CONFIG)
        3. Bundled config/default.yaml
        4. Built-in Pydantic defaults
    """
    data: dict = {}

    # 1. Bundled defaults
    if _BUNDLED_DEFAULTS_YAML.exists():
        try:
            with open(_BUNDLED_DEFAULTS_YAML) as f:
                bundled = yaml.safe_load(f) or {}
            if isinstance(bundled, dict):
                data.update(bundled)
        except Exception:
            pass

    # 2. User YAML
    yaml_path = Path(path) if path else os.environ.get("ADONAI_CONFIG")
    if yaml_path and Path(yaml_path).exists():
        with open(yaml_path) as f:
            user_yaml = yaml.safe_load(f) or {}
        if isinstance(user_yaml, dict):
            data.update(user_yaml)

    # 3. Env var expansion
    data = _expand_env(data)

    # 4. Top-level env overrides
    for key in ("environment", "debug", "log_level"):
        env_val = os.environ.get(f"ADONAI_{key.upper()}")
        if env_val is not None:
            data[key] = env_val

    # 5. Caller overrides
    data.update(overrides)

    config = Config(**data)
    config.ensure_dirs()
    return config


@lru_cache(maxsize=1)
def _default_config() -> Config:
    return load_config()


def get_config() -> Config:
    return _default_config()


def reload_config() -> Config:
    _default_config.cache_clear()
    return get_config()
