"""v6 — SuperContext.

A research scout sweeps your memory and files before the model reads
your first message.  No cold starts.

Design (ported from OpenHuman's SuperContext):

  * Before the LLM sees the user's message, a **research scout** runs:
        - keyword search over the Memory Tree
        - recent-file scan over the workspace
        - (optionally) a web search for fresh context

  * The scout has a hard time budget (default 3 seconds) — it must
    return *something* useful within that budget or it gets skipped.

  * The scout's output is a compact "context pack" (max 2048 tokens)
    prepended to the user's message as system context.

  * The scout is intentionally cheap: it uses keyword search, not
    embeddings, to stay fast.  Embedding-based recall is already
    handled by the 5-tier memory manager; SuperContext is the
    pre-message scout layer on top.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from adonai.config.settings import SuperContextConfig

log = logging.getLogger(__name__)


@dataclass
class ContextPack:
    """The scout's output — prepended to the user's message."""
    memory_hits: list[dict[str, Any]] = field(default_factory=list)
    recent_files: list[dict[str, Any]] = field(default_factory=list)
    web_hits: list[dict[str, Any]] = field(default_factory=list)
    elapsed_ms: float = 0.0
    tokens_estimated: int = 0

    def to_prompt(self) -> str:
        """Render the pack as a system-prompt prefix."""
        parts: list[str] = []
        if self.memory_hits:
            parts.append("[Memory context]")
            for h in self.memory_hits[:5]:
                parts.append(f"  • {h.get('title', '?')}: {h.get('summary', '')[:120]}")
        if self.recent_files:
            parts.append("[Recent files]")
            for f in self.recent_files[:5]:
                parts.append(f"  • {f.get('path', '?')} ({f.get('modified', '?')})")
        if self.web_hits:
            parts.append("[Web context]")
            for h in self.web_hits[:3]:
                parts.append(f"  • {h.get('title', '?')}: {h.get('snippet', '')[:120]}")
        return "\n".join(parts)


class SuperContext:
    """Pre-message research scout."""

    def __init__(
        self,
        config: SuperContextConfig,
        *,
        memory_tree: Any = None,
        workspace_root: str | Path | None = None,
        web_search: Any = None,
    ) -> None:
        self.config = config
        self.memory_tree = memory_tree
        self.workspace_root = Path(workspace_root) if workspace_root else None
        self.web_search = web_search

    async def sweep(self, user_message: str) -> ContextPack:
        """Sweep memory + files + web for context relevant to ``user_message``.

        Returns within ``config.max_sweep_s`` seconds — partial results
        are returned if the budget is exceeded.
        """
        start = time.time()
        pack = ContextPack()
        try:
            await asyncio.wait_for(
                self._sweep_all(user_message, pack),
                timeout=self.config.max_sweep_s,
            )
        except asyncio.TimeoutError:
            log.debug("SuperContext sweep timed out after %.1fs — returning partial", self.config.max_sweep_s)
        pack.elapsed_ms = (time.time() - start) * 1000
        # Estimate tokens (4 chars/token).
        pack.tokens_estimated = len(pack.to_prompt()) // 4
        # Truncate to budget.
        if pack.tokens_estimated > self.config.max_context_tokens:
            # Drop web hits first, then recent files.
            pack.web_hits = []
            pack.recent_files = pack.recent_files[:2]
            pack.tokens_estimated = len(pack.to_prompt()) // 4
        return pack

    async def _sweep_all(self, message: str, pack: ContextPack) -> None:
        """Run all sweep sources concurrently."""
        tasks = []
        if "memory_tree" in self.config.sweep_sources and self.memory_tree is not None:
            tasks.append(self._sweep_memory(message, pack))
        if "workspace" in self.config.sweep_sources and self.workspace_root is not None:
            tasks.append(self._sweep_workspace(message, pack))
        if "recent_files" in self.config.sweep_sources and self.workspace_root is not None:
            tasks.append(self._sweep_recent_files(pack))
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _sweep_memory(self, message: str, pack: ContextPack) -> None:
        """Keyword search over the Memory Tree."""
        try:
            hits = self.memory_tree.search(message, k=5)
            pack.memory_hits = [
                {"title": h.title, "summary": h.summary, "score": h.score}
                for h in hits
            ]
        except Exception as e:
            log.debug("SuperContext memory sweep failed: %s", e)

    async def _sweep_workspace(self, message: str, pack: ContextPack) -> None:
        """Grep the workspace for files mentioning keywords from the message."""
        if self.workspace_root is None or not self.workspace_root.exists():
            return
        try:
            keywords = [w for w in message.split() if len(w) > 3][:5]
            if not keywords:
                return
            matches: list[dict[str, Any]] = []
            for fpath in self.workspace_root.rglob("*"):
                if not fpath.is_file() or fpath.suffix in {".pyc", ".bin", ".png", ".jpg", ".db"}:
                    continue
                if len(matches) >= 5:
                    break
                try:
                    text = fpath.read_text(encoding="utf-8", errors="ignore")
                    if any(kw.lower() in text.lower() for kw in keywords):
                        matches.append({
                            "path": str(fpath.relative_to(self.workspace_root)),
                            "modified": int(fpath.stat().st_mtime * 1000),
                            "snippet": text[:200],
                        })
                except Exception:
                    continue
            pack.recent_files = matches
        except Exception as e:
            log.debug("SuperContext workspace sweep failed: %s", e)

    async def _sweep_recent_files(self, pack: ContextPack) -> None:
        """List the most-recently-modified files in the workspace."""
        if self.workspace_root is None or not self.workspace_root.exists():
            return
        try:
            files = []
            for fpath in self.workspace_root.rglob("*"):
                if not fpath.is_file() or fpath.suffix in {".pyc", ".bin", ".png", ".jpg", ".db"}:
                    continue
                files.append((fpath.stat().st_mtime, fpath))
            files.sort(reverse=True)
            pack.recent_files = [
                {"path": str(f.relative_to(self.workspace_root)), "modified": int(mtime * 1000)}
                for mtime, f in files[:5]
            ]
        except Exception as e:
            log.debug("SuperContext recent-files sweep failed: %s", e)

    def inject(self, user_message: str, pack: ContextPack) -> str:
        """Prepend the context pack to the user message."""
        prefix = pack.to_prompt()
        if not prefix:
            return user_message
        return f"{prefix}\n\n[User message]\n{user_message}"
