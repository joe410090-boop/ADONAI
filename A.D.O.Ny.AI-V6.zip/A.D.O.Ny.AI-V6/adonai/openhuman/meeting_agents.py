"""v6 — Meeting agents.

Joins Meet, Zoom, Teams, and Webex with a face and a voice.
Auto-joins from your calendar, streams a live transcript, answers by
name, and files a summary with action items.

Design (ported from OpenHuman's Meeting Agents):

  * A calendar watcher polls the configured providers (Google, Outlook,
    iCal) for upcoming meetings.
  * When a meeting is about to start (and you've marked yourself as
    attending), the bot auto-joins with a face + voice.
  * During the meeting:
        - live transcript (Whisper in-process)
        - the bot can answer by name when addressed
        - max speaking time per turn to avoid monologues
  * After the meeting:
        - generates a summary with action items
        - files the summary to the configured destination (e.g. Slack)
        - ingest the transcript into the Memory Tree

NOTE: The actual headless-joiner for Meet/Zoom/Teams/Webex requires a
headless browser + platform-specific OAuth.  This module provides the
orchestration layer; the platform joiners are stubs that operators
implement for their environment.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any, Callable, Literal

from adonai.config.settings import MeetingAgentsConfig

log = logging.getLogger(__name__)

Platform = Literal["meet", "zoom", "teams", "webex"]
MeetingStatus = Literal["scheduled", "joining", "in_meeting", "ended", "failed"]


@dataclass
class Meeting:
    id: str
    platform: Platform
    url: str
    title: str
    start_at: int           # epoch ms
    duration_min: int = 30
    attending: bool = True
    status: MeetingStatus = "scheduled"
    # Populated after the meeting.
    transcript: str = ""
    summary: str = ""
    action_items: list[str] = field(default_factory=list)


class PlatformJoiner:
    """Stub for the headless meeting joiner.

    Operators implement `join()` and `leave()` for their environment.
    A real implementation uses Playwright + platform-specific OAuth.
    """

    async def join(self, meeting: Meeting) -> bool:
        log.info("Joining %s meeting: %s", meeting.platform, meeting.url)
        # Stub: always succeeds.
        return True

    async def leave(self, meeting: Meeting) -> None:
        log.info("Leaving %s meeting: %s", meeting.platform, meeting.url)


class MeetingAgentsService:
    """Calendar watcher + meeting joiner + summariser."""

    def __init__(
        self,
        config: MeetingAgentsConfig,
        *,
        llm: Any = None,
        memory_tree: Any = None,
        voice_transcriber: Any = None,
        summary_sender: Callable[[str, str], Any] | None = None,
    ) -> None:
        self.config = config
        self.llm = llm
        self.memory_tree = memory_tree
        self.voice_transcriber = voice_transcriber
        self.summary_sender = summary_sender
        self.joiner = PlatformJoiner()
        self._meetings: dict[str, Meeting] = {}
        self._watcher_task: asyncio.Task | None = None
        self._running = False

    async def start(self) -> None:
        if self._running or not self.config.enabled:
            return
        self._running = True
        self._watcher_task = asyncio.create_task(self._watch_loop())
        log.info("MeetingAgentsService started (platforms: %s)",
                 ", ".join(self.config.platforms))

    async def stop(self) -> None:
        self._running = False
        if self._watcher_task is not None:
            try:
                self._watcher_task.cancel()
                await self._watcher_task
            except Exception:
                pass
            self._watcher_task = None

    # ── Calendar watcher ──────────────────────────────────────────────────

    async def _watch_loop(self) -> None:
        while self._running:
            try:
                await self._check_upcoming()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("MeetingAgents watcher tick failed: %s", e)
            await asyncio.sleep(60.0)  # check every minute

    async def _check_upcoming(self) -> None:
        """Check for meetings starting in the next 2 minutes and join them."""
        now_ms = int(time.time() * 1000)
        for meeting in list(self._meetings.values()):
            if meeting.status != "scheduled":
                continue
            if not (self.config.auto_join_attending and meeting.attending):
                continue
            # Join 1 minute before start.
            if meeting.start_at - now_ms <= 60_000 and meeting.start_at - now_ms > -30_000:
                asyncio.create_task(self._attend(meeting))

    def schedule_meeting(self, meeting: Meeting) -> None:
        self._meetings[meeting.id] = meeting
        log.info("Scheduled meeting: %s (%s) at %s",
                 meeting.title, meeting.platform,
                 datetime.fromtimestamp(meeting.start_at / 1000).isoformat())

    def list_meetings(self, include_ended: bool = False) -> list[Meeting]:
        if include_ended:
            return list(self._meetings.values())
        return [m for m in self._meetings.values() if m.status != "ended"]

    # ── Attend a meeting ──────────────────────────────────────────────────

    async def _attend(self, meeting: Meeting) -> None:
        """Join a meeting, transcribe, summarise, and file."""
        meeting.status = "joining"
        joined = await self.joiner.join(meeting)
        if not joined:
            meeting.status = "failed"
            return
        meeting.status = "in_meeting"
        log.info("Bot joined meeting: %s", meeting.title)

        # Stub: in a real implementation, we'd capture audio here and
        # run the voice_transcriber on it.  For now, we just wait for
        # the meeting duration.
        await asyncio.sleep(meeting.duration_min * 60)

        await self.joiner.leave(meeting)
        meeting.status = "ended"

        # Generate summary + action items.
        await self._summarise(meeting)

        # File the summary.
        if self.summary_sender is not None and meeting.summary:
            try:
                result = self.summary_sender(meeting.title, meeting.summary)
                if asyncio.iscoroutine(result):
                    await result
            except Exception as e:
                log.warning("Failed to send meeting summary: %s", e)

        # Ingest transcript into the Memory Tree.
        if self.memory_tree is not None and meeting.transcript:
            try:
                from adonai.openhuman.memory_tree import Chunk
                self.memory_tree.ingest(Chunk(
                    id=f"meeting_{meeting.id}",
                    source_kind="meeting",
                    source_id=meeting.id,
                    source_authority=0.8,
                    content=meeting.transcript,
                    created_at=int(time.time() * 1000),
                    metadata={"title": meeting.title, "platform": meeting.platform},
                ))
            except Exception as e:
                log.debug("Failed to ingest meeting transcript: %s", e)

    async def _summarise(self, meeting: Meeting) -> None:
        if self.llm is None:
            meeting.summary = "(no LLM to summarise)"
            return
        prompt = (
            "You attended a meeting and took the transcript below.  Generate:\n"
            "1. A 3-5 sentence summary.\n"
            "2. A bulleted list of action items (each with an owner if mentioned).\n\n"
            f"Meeting: {meeting.title} ({meeting.platform})\n"
            f"Transcript:\n{meeting.transcript[:4000]}\n\nSummary:"
        )
        try:
            resp = await self.llm.complete(prompt, max_tokens=400, temperature=0.3)
            text = resp.text if hasattr(resp, "text") else str(resp)
            meeting.summary = text
            # Naive action-item extraction.
            for line in text.split("\n"):
                line = line.strip()
                if line.startswith(("- ", "* ", "• ")):
                    meeting.action_items.append(line[2:].strip())
        except Exception as e:
            meeting.summary = f"(summary error: {e})"

    # ── Status ────────────────────────────────────────────────────────────

    def status(self) -> dict[str, Any]:
        return {
            "enabled": self.config.enabled,
            "platforms": self.config.platforms,
            "scheduled": len([m for m in self._meetings.values() if m.status == "scheduled"]),
            "in_meeting": len([m for m in self._meetings.values() if m.status == "in_meeting"]),
            "ended": len([m for m in self._meetings.values() if m.status == "ended"]),
        }
