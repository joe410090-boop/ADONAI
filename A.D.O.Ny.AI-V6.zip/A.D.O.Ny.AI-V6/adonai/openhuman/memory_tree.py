"""v6 — Memory Tree + Obsidian Wiki mirror.

Your data compressed into scored Markdown trees in SQLite on your
machine, mirrored as an Obsidian vault you can open and edit.
No vector-soup black box.

Design (ported from OpenHuman's Memory Tree concept):

  * Source documents (chat messages, emails, files, web pages, tool
    outputs) are *ingested* into the tree as **chunks**.  Each chunk
    carries:
        - source_kind  (chat | email | file | web | tool | agent)
        - source_id    (opaque identifier within the source)
        - source_authority  (0.0–1.0; e.g. user > assistant > web)
        - content      (the raw text)
        - created_at   (epoch ms)

  * Chunks are then organised into a **tree**.  Each tree node has:
        - id, parent_id, depth
        - title (auto-generated from the first sentence)
        - summary (LLM-generated or extractive)
        - score (recency × frequency × entity_density × source_authority
          × user_pin)
        - children (1..N)

  * The tree is mirrored to an Obsidian-vault directory on disk.  Each
    node becomes a Markdown file with YAML frontmatter; links between
    files mirror the parent/child edges.  You can open the vault in
    Obsidian, edit it, and the next mirror pass will *not* clobber
    user edits (it writes only nodes the user hasn't touched).

  * Retrieval is keyword + score-weighted.  No vector soup — every hit
    is a real Markdown chunk with a visible score breakdown.

The implementation is intentionally SQLite-only and stdlib-only so it
runs anywhere ADON.AI runs.  ChromaDB is *not* required.
"""
from __future__ import annotations

import hashlib
import json
import logging
import math
import re
import sqlite3
import threading
import time
import uuid
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from adonai.config.settings import MemoryTreeConfig

log = logging.getLogger(__name__)

# ──────────────────────────────────────────────────────────────────────────────
# Data classes
# ──────────────────────────────────────────────────────────────────────────────


@dataclass
class Chunk:
    """A single piece of ingested content, before it's organised into the tree."""
    id: str
    source_kind: str           # chat | email | file | web | tool | agent
    source_id: str             # opaque id within the source
    source_authority: float    # 0.0–1.0
    content: str
    created_at: int            # epoch ms
    # Optional structured metadata (sender, subject, url, etc.).
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class TreeNode:
    """A scored summary node in the Memory Tree."""
    id: str
    parent_id: str | None
    depth: int
    title: str
    summary: str
    score: float
    # Chunk ids that were folded into this node.
    chunk_ids: list[str]
    # Score breakdown for transparency.
    score_breakdown: dict[str, float] = field(default_factory=dict)
    created_at: int = 0
    updated_at: int = 0
    # When True, the user has edited the mirrored Markdown file and we
    # must not overwrite it on the next mirror pass.
    user_edited: bool = False


# ──────────────────────────────────────────────────────────────────────────────
# Scoring
# ──────────────────────────────────────────────────────────────────────────────


_WORD_RE = re.compile(r"[A-Za-z][A-Za-z0-9_]{1,}")


def _tokenize(text: str) -> list[str]:
    return [w.lower() for w in _WORD_RE.findall(text)]


def _entity_density(content: str) -> float:
    """Heuristic: ratio of capitalised tokens (proper nouns) to all tokens."""
    tokens = _WORD_RE.findall(content)
    if not tokens:
        return 0.0
    caps = sum(1 for t in tokens if t[:1].isupper() and len(t) > 2)
    return min(1.0, caps / max(1, len(tokens)))


def _recency_score(created_at_ms: int, now_ms: int | None = None) -> float:
    """Exponential decay: 1.0 at creation, ~0.37 after 7 days."""
    if now_ms is None:
        now_ms = int(time.time() * 1000)
    age_s = max(0, (now_ms - created_at_ms) / 1000.0)
    # 7-day half-life in seconds.
    half_life_s = 7 * 24 * 3600
    return math.exp(-age_s / half_life_s)


def _score_node(
    node: TreeNode,
    chunks: list[Chunk],
    frequency_counts: Counter,
    weights: dict[str, float],
    now_ms: int | None = None,
) -> tuple[float, dict[str, float]]:
    """Compute a 0..1 score for a node from its constituent chunks.

    Returns (score, breakdown) so the caller can show *why* a node
    scored the way it did — no black box.
    """
    if now_ms is None:
        now_ms = int(time.time() * 1000)
    if not node.chunk_ids:
        return 0.0, {}

    chunk_map = {c.id: c for c in chunks}
    own = [chunk_map[c] for c in node.chunk_ids if c in chunk_map]
    if not own:
        return 0.0, {}

    # Recency: max over chunks (the most recent one dominates).
    recency = max(_recency_score(c.created_at, now_ms) for c in own)

    # Frequency: how often the node's tokens appear across *all* chunks.
    node_tokens = _tokenize(node.summary + " " + node.title)
    freq = (
        sum(frequency_counts.get(t, 0) for t in set(node_tokens))
        / max(1, sum(frequency_counts.values()))
    ) if frequency_counts else 0.0

    # Entity density of the summary.
    density = _entity_density(node.summary)

    # Source authority: mean over chunks.
    authority = sum(c.source_authority for c in own) / len(own)

    # User pin: 1.0 if any chunk is pinned, else 0.0.
    pinned = 1.0 if any(c.metadata.get("pinned") for c in own) else 0.0

    w = weights
    score = (
        w.get("recency", 0.25) * recency
        + w.get("frequency", 0.20) * freq
        + w.get("entity_density", 0.20) * density
        + w.get("source_authority", 0.15) * authority
        + w.get("user_pin", 0.20) * pinned
    )
    breakdown = {
        "recency": round(recency, 3),
        "frequency": round(freq, 3),
        "entity_density": round(density, 3),
        "source_authority": round(authority, 3),
        "user_pin": round(pinned, 3),
    }
    return round(score, 4), breakdown


# ──────────────────────────────────────────────────────────────────────────────
# Store
# ──────────────────────────────────────────────────────────────────────────────


class MemoryTreeStore:
    """SQLite-backed Memory Tree with Obsidian-vault mirror.

    Two tables:
        chunks  — raw ingested text
        nodes   — scored summary nodes organised into a tree
    """

    def __init__(self, config: MemoryTreeConfig) -> None:
        self.config = config
        self.db_path = Path(config.db_path)
        self.vault_path = Path(config.vault_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.vault_path.mkdir(parents=True, exist_ok=True)

        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._lock = threading.RLock()
        self._ensure_schema()

        # In-memory frequency counter for scoring.  Refreshed lazily.
        self._freq_cache: Counter | None = None
        self._freq_dirty: bool = True

    # ── Schema ────────────────────────────────────────────────────────────

    def _ensure_schema(self) -> None:
        with self._conn:
            self._conn.execute("""
                CREATE TABLE IF NOT EXISTS chunks (
                    id              TEXT PRIMARY KEY,
                    source_kind     TEXT NOT NULL,
                    source_id       TEXT NOT NULL,
                    source_authority REAL NOT NULL DEFAULT 0.5,
                    content         TEXT NOT NULL,
                    created_at      INTEGER NOT NULL,
                    metadata        TEXT NOT NULL DEFAULT '{}',
                    ingested_at     INTEGER NOT NULL
                )
            """)
            self._conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_chunks_source
                ON chunks(source_kind, source_id)
            """)
            self._conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_chunks_created
                ON chunks(created_at DESC)
            """)
            self._conn.execute("""
                CREATE TABLE IF NOT EXISTS nodes (
                    id              TEXT PRIMARY KEY,
                    parent_id       TEXT,
                    depth           INTEGER NOT NULL,
                    title           TEXT NOT NULL,
                    summary         TEXT NOT NULL,
                    score           REAL NOT NULL DEFAULT 0.0,
                    score_breakdown TEXT NOT NULL DEFAULT '{}',
                    chunk_ids       TEXT NOT NULL DEFAULT '[]',
                    created_at      INTEGER NOT NULL,
                    updated_at      INTEGER NOT NULL,
                    user_edited     INTEGER NOT NULL DEFAULT 0
                )
            """)
            self._conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_nodes_parent
                ON nodes(parent_id)
            """)
            self._conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_nodes_score
                ON nodes(score DESC)
            """)

    # ── Ingest ────────────────────────────────────────────────────────────

    def ingest(self, chunk: Chunk) -> str:
        """Insert a chunk.  Returns the chunk id."""
        with self._lock, self._conn:
            self._conn.execute(
                """INSERT OR REPLACE INTO chunks
                   (id, source_kind, source_id, source_authority,
                    content, created_at, metadata, ingested_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    chunk.id, chunk.source_kind, chunk.source_id,
                    chunk.source_authority, chunk.content,
                    chunk.created_at, json.dumps(chunk.metadata),
                    int(time.time() * 1000),
                ),
            )
        self._freq_dirty = True
        log.debug("Ingested chunk %s (%s, %d chars)",
                  chunk.id, chunk.source_kind, len(chunk.content))
        return chunk.id

    def ingest_many(self, chunks: Iterable[Chunk]) -> int:
        n = 0
        for c in chunks:
            self.ingest(c)
            n += 1
        return n

    # ── Build tree ────────────────────────────────────────────────────────

    def _frequency_counts(self) -> Counter:
        if self._freq_cache is not None and not self._freq_dirty:
            return self._freq_cache
        c: Counter = Counter()
        for row in self._conn.execute("SELECT content FROM chunks"):
            c.update(set(_tokenize(row["content"])))
        self._freq_cache = c
        self._freq_dirty = False
        return c

    def build_tree(self, max_depth: int | None = None) -> int:
        """Rebuild the tree from scratch.

        Groups chunks by source_kind, then by source_id, and folds each
        group into a single node.  Top-level nodes are children of a
        synthetic 'root' (parent_id=None).  Deeper levels are produced
        by sub-grouping on the next metadata key, up to ``max_depth``.

        Returns the number of nodes created.
        """
        max_depth = max_depth or self.config.max_tree_depth
        now_ms = int(time.time() * 1000)
        freq = self._frequency_counts()

        # Wipe the existing tree (chunks are preserved).
        with self._lock, self._conn:
            self._conn.execute("DELETE FROM nodes")

        rows = list(self._conn.execute(
            "SELECT * FROM chunks ORDER BY created_at ASC"
        ))
        if not rows:
            return 0

        # Group by source_kind → source_id.
        groups: dict[tuple[str, str], list[sqlite3.Row]] = defaultdict(list)
        for r in rows:
            groups[(r["source_kind"], r["source_id"])].append(r)

        n_created = 0
        for (kind, sid), group in groups.items():
            chunk_ids = [r["id"] for r in group]
            # Build a summary: concatenate the first 200 chars of each chunk.
            parts = [r["content"][:200] for r in group[:5]]
            summary = "\n\n---\n\n".join(parts)
            # Title: take the first sentence of the first chunk.
            first = group[0]["content"]
            title = first.split(".")[0][:80] or f"{kind}:{sid}"

            node = TreeNode(
                id=str(uuid.uuid4()),
                parent_id=None,
                depth=0,
                title=title,
                summary=summary,
                score=0.0,
                chunk_ids=chunk_ids,
                created_at=now_ms,
                updated_at=now_ms,
            )
            # Score it.
            chunks = [
                Chunk(
                    id=r["id"], source_kind=r["source_kind"],
                    source_id=r["source_id"],
                    source_authority=r["source_authority"],
                    content=r["content"], created_at=r["created_at"],
                    metadata=json.loads(r["metadata"] or "{}"),
                )
                for r in group
            ]
            node.score, node.score_breakdown = _score_node(
                node, chunks, freq, self.config.score_weights, now_ms,
            )
            self._save_node(node)
            n_created += 1

        log.info("Memory Tree rebuilt: %d nodes from %d chunks",
                 n_created, len(rows))
        return n_created

    def _save_node(self, node: TreeNode) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                """INSERT OR REPLACE INTO nodes
                   (id, parent_id, depth, title, summary, score,
                    score_breakdown, chunk_ids, created_at, updated_at,
                    user_edited)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    node.id, node.parent_id, node.depth, node.title,
                    node.summary, node.score,
                    json.dumps(node.score_breakdown),
                    json.dumps(node.chunk_ids),
                    node.created_at, node.updated_at,
                    1 if node.user_edited else 0,
                ),
            )

    # ── Retrieve ──────────────────────────────────────────────────────────

    def search(self, query: str, k: int = 10) -> list[TreeNode]:
        """Keyword search over node titles + summaries, ranked by score."""
        q_tokens = set(_tokenize(query))
        if not q_tokens:
            return []
        scored: list[tuple[float, TreeNode]] = []
        for row in self._conn.execute("SELECT * FROM nodes"):
            node = self._row_to_node(row)
            node_tokens = set(_tokenize(node.title + " " + node.summary))
            overlap = len(q_tokens & node_tokens)
            if overlap == 0:
                continue
            # Combined rank: token overlap × node score.
            rank = (overlap / max(1, len(q_tokens))) * node.score
            scored.append((rank, node))
        scored.sort(key=lambda t: t[0], reverse=True)
        return [n for _, n in scored[:k]]

    def recall(self, query: str, k: int = 5) -> list[TreeNode]:
        """Semantic-ish recall: top-k by score among nodes that share ≥1 token."""
        return self.search(query, k=k)

    def top_entities(self, k: int = 10) -> list[tuple[str, int]]:
        """Most-referenced proper nouns across all chunks."""
        c: Counter = Counter()
        for row in self._conn.execute("SELECT content FROM chunks"):
            tokens = _WORD_RE.findall(row["content"])
            for t in tokens:
                if t[:1].isupper() and len(t) > 2:
                    c[t] += 1
        return c.most_common(k)

    def list_sources(self) -> list[dict[str, Any]]:
        """Distinct ingest sources with chunk counts + last activity."""
        rows = self._conn.execute("""
            SELECT source_kind, source_id,
                   COUNT(*) AS n, MAX(created_at) AS last
            FROM chunks GROUP BY source_kind, source_id
            ORDER BY last DESC
        """)
        return [
            {
                "source_kind": r["source_kind"],
                "source_id": r["source_id"],
                "chunk_count": r["n"],
                "last_activity_ms": r["last"],
            }
            for r in rows
        ]

    # ── Obsidian mirror ───────────────────────────────────────────────────

    def mirror_to_vault(self) -> int:
        """Write the current tree to the Obsidian vault directory.

        Each node becomes a Markdown file named after its title, with
        YAML frontmatter capturing the score, source, and parent link.
        Files that the user has edited (user_edited=1) are skipped.
        """
        n_written = 0
        for row in self._conn.execute("SELECT * FROM nodes"):
            node = self._row_to_node(row)
            if node.user_edited:
                continue
            # Filename: slug of the title + first 8 chars of node id.
            slug = re.sub(r"[^A-Za-z0-9]+", "-", node.title).strip("-").lower()[:60]
            fname = f"{slug}-{node.id[:8]}.md"
            fpath = self.vault_path / fname

            # If the file exists and was modified after the node's
            # updated_at, treat it as user-edited and skip.
            if fpath.exists():
                mtime = int(fpath.stat().st_mtime * 1000)
                if mtime > node.updated_at:
                    log.debug("Skipping user-edited vault file %s", fname)
                    with self._lock, self._conn:
                        self._conn.execute(
                            "UPDATE nodes SET user_edited=1 WHERE id=?",
                            (node.id,),
                        )
                    continue

            front = [
                "---",
                f"id: {node.id}",
                f"parent: {node.parent_id or 'root'}",
                f"depth: {node.depth}",
                f"score: {node.score:.4f}",
                f"score_breakdown: {json.dumps(node.score_breakdown)}",
                f"chunks: {json.dumps(node.chunk_ids)}",
                f"created_at: {node.created_at}",
                f"updated_at: {node.updated_at}",
                "---",
                "",
            ]
            body = [f"# {node.title}", "", node.summary, ""]
            fpath.write_text("\n".join(front) + "\n".join(body), encoding="utf-8")
            n_written += 1
        log.info("Memory Tree mirrored to vault: %d files", n_written)
        return n_written

    # ── Helpers ───────────────────────────────────────────────────────────

    def _row_to_node(self, row: sqlite3.Row) -> TreeNode:
        return TreeNode(
            id=row["id"],
            parent_id=row["parent_id"],
            depth=row["depth"],
            title=row["title"],
            summary=row["summary"],
            score=row["score"],
            score_breakdown=json.loads(row["score_breakdown"] or "{}"),
            chunk_ids=json.loads(row["chunk_ids"] or "[]"),
            created_at=row["created_at"],
            updated_at=row["updated_at"],
            user_edited=bool(row["user_edited"]),
        )

    def close(self) -> None:
        with self._lock:
            try:
                self._conn.close()
            except Exception:
                pass


# ──────────────────────────────────────────────────────────────────────────────
# Service wrapper
# ──────────────────────────────────────────────────────────────────────────────


class MemoryTreeService:
    """High-level service used by the runtime.

    Wires :class:`MemoryTreeStore` and runs a background mirror loop
    that periodically syncs the SQLite tree to the Obsidian vault.
    """

    def __init__(self, config: MemoryTreeConfig) -> None:
        self.config = config
        self.store = MemoryTreeStore(config)
        self._mirror_task: asyncio.Task | None = None  # type: ignore[name-defined]
        self._running = False

    async def start(self) -> None:
        if self._running:
            return
        self._running = True
        import asyncio
        async def _loop():
            while self._running:
                try:
                    self.store.mirror_to_vault()
                except Exception as e:
                    log.warning("Memory Tree mirror failed: %s", e)
                await asyncio.sleep(self.config.mirror_interval_s)
        self._mirror_task = asyncio.create_task(_loop())
        log.info("MemoryTreeService started (mirror every %.0fs)",
                 self.config.mirror_interval_s)

    async def stop(self) -> None:
        self._running = False
        if self._mirror_task is not None:
            try:
                self._mirror_task.cancel()
                await self._mirror_task
            except Exception:
                pass
            self._mirror_task = None
        self.store.close()

    # Convenience pass-throughs
    def ingest(self, chunk: Chunk) -> str:
        return self.store.ingest(chunk)

    def ingest_many(self, chunks: Iterable[Chunk]) -> int:
        return self.store.ingest_many(chunks)

    def build_tree(self) -> int:
        return self.store.build_tree()

    def search(self, query: str, k: int = 10) -> list[TreeNode]:
        return self.store.search(query, k=k)

    def recall(self, query: str, k: int = 5) -> list[TreeNode]:
        return self.store.recall(query, k=k)

    def top_entities(self, k: int = 10) -> list[tuple[str, int]]:
        return self.store.top_entities(k)

    def list_sources(self) -> list[dict[str, Any]]:
        return self.store.list_sources()

    def mirror_now(self) -> int:
        return self.store.mirror_to_vault()
