"""v6 — Workflows.

Durable, trigger-driven, approval-gated runs on a tinyflows-style graph
engine.  The agent proposes the automation; you review it on a canvas
and save.

Design (ported from OpenHuman's Workflows, which itself is inspired by
n8n and Zapier):

  * A workflow is a typed graph of **12 node kinds**:
        trigger, agent, tool_call, http_request, code, condition,
        switch, transform, split_out, merge, output_parser, sub_workflow

  * Triggers come in 4 kinds:
        schedule  — cron-backed, re-registers on every boot
        app_event — a live trigger from a connected integration
        manual    — a Run button or `flows_run` RPC
        resume    — continuing a run that paused at an approval gate

  * The agent proposes a workflow (via `propose_workflow`), which only
    *validates and describes* the candidate graph.  The ONLY path from
    a proposal to a saved workflow is the user clicking "Save & enable",
    which calls `flows_create` directly — not the agent.

  * Saved flows run durably and checkpointed.  Each flow has a
    "Require approval for outbound actions" switch; when on, every
    external-effect node parks at the approval gate and waits for a
    real decision.

  * A per-flow dispatch lock means a schedule burst can never run the
    same flow twice concurrently.

The implementation here is the graph engine + persistence + dispatch
loop.  The visual canvas lives in the API/UI layer; this module is
the backend.
"""
from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, Literal

from adonai.config.settings import WorkflowsConfig

log = logging.getLogger(__name__)

NodeKind = Literal[
    "trigger", "agent", "tool_call", "http_request", "code",
    "condition", "switch", "transform", "split_out", "merge",
    "output_parser", "sub_workflow",
]
TriggerKind = Literal["schedule", "app_event", "manual", "resume"]
RunStatus = Literal["pending", "running", "paused_approval", "completed", "failed", "cancelled"]


# ──────────────────────────────────────────────────────────────────────────────
# Data classes
# ──────────────────────────────────────────────────────────────────────────────


@dataclass
class WorkflowNode:
    id: str
    kind: NodeKind
    label: str = ""
    config: dict[str, Any] = field(default_factory=dict)
    # Edges: list of target node ids.
    next: list[str] = field(default_factory=list)


@dataclass
class Workflow:
    id: str
    name: str
    description: str = ""
    nodes: dict[str, WorkflowNode] = field(default_factory=dict)
    trigger_node_id: str | None = None
    enabled: bool = False
    require_approval_for_outbound: bool = True
    created_at: int = 0
    updated_at: int = 0
    # Cron expression for schedule triggers.
    schedule: str | None = None
    # App-event trigger spec: {toolkit, trigger_slug}
    app_event: dict[str, str] | None = None


@dataclass
class WorkflowRun:
    id: str
    workflow_id: str
    status: RunStatus = "pending"
    started_at: int = 0
    finished_at: int = 0
    # Per-node outputs: {node_id: {output, status, started_at, finished_at}}
    node_outputs: dict[str, dict[str, Any]] = field(default_factory=dict)
    # Pending approval node ids.
    pending_approval: list[str] = field(default_factory=list)
    error: str = ""
    trigger_payload: dict[str, Any] = field(default_factory=dict)


# ──────────────────────────────────────────────────────────────────────────────
# Store
# ──────────────────────────────────────────────────────────────────────────────


class WorkflowStore:
    """SQLite-backed store for workflows + runs."""

    def __init__(self, config: WorkflowsConfig) -> None:
        self.config = config
        self.db_path = config.db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._lock = threading.RLock()
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        with self._conn:
            self._conn.execute("""
                CREATE TABLE IF NOT EXISTS workflows (
                    id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    description TEXT NOT NULL DEFAULT '',
                    graph TEXT NOT NULL DEFAULT '{}',
                    enabled INTEGER NOT NULL DEFAULT 0,
                    require_approval INTEGER NOT NULL DEFAULT 1,
                    created_at INTEGER NOT NULL,
                    updated_at INTEGER NOT NULL,
                    schedule TEXT,
                    app_event TEXT
                )
            """)
            self._conn.execute("""
                CREATE TABLE IF NOT EXISTS runs (
                    id TEXT PRIMARY KEY,
                    workflow_id TEXT NOT NULL,
                    status TEXT NOT NULL DEFAULT 'pending',
                    started_at INTEGER NOT NULL,
                    finished_at INTEGER NOT NULL DEFAULT 0,
                    node_outputs TEXT NOT NULL DEFAULT '{}',
                    pending_approval TEXT NOT NULL DEFAULT '[]',
                    error TEXT NOT NULL DEFAULT '',
                    trigger_payload TEXT NOT NULL DEFAULT '{}'
                )
            """)
            self._conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_runs_workflow
                ON runs(workflow_id, started_at DESC)
            """)

    # ── Workflow CRUD ─────────────────────────────────────────────────────

    def save_workflow(self, wf: Workflow) -> None:
        graph = {
            "nodes": {nid: {"id": n.id, "kind": n.kind, "label": n.label,
                            "config": n.config, "next": n.next}
                      for nid, n in wf.nodes.items()},
            "trigger_node_id": wf.trigger_node_id,
        }
        with self._lock, self._conn:
            self._conn.execute(
                """INSERT OR REPLACE INTO workflows
                   (id, name, description, graph, enabled, require_approval,
                    created_at, updated_at, schedule, app_event)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (wf.id, wf.name, wf.description, json.dumps(graph),
                 1 if wf.enabled else 0,
                 1 if wf.require_approval_for_outbound else 0,
                 wf.created_at, wf.updated_at,
                 wf.schedule,
                 json.dumps(wf.app_event) if wf.app_event else None),
            )

    def get_workflow(self, wf_id: str) -> Workflow | None:
        r = self._conn.execute("SELECT * FROM workflows WHERE id=?", (wf_id,)).fetchone()
        if not r:
            return None
        return self._row_to_workflow(r)

    def list_workflows(self, only_enabled: bool = False) -> list[Workflow]:
        q = "SELECT * FROM workflows"
        if only_enabled:
            q += " WHERE enabled=1"
        q += " ORDER BY updated_at DESC"
        return [self._row_to_workflow(r) for r in self._conn.execute(q)]

    def set_enabled(self, wf_id: str, enabled: bool) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                "UPDATE workflows SET enabled=?, updated_at=? WHERE id=?",
                (1 if enabled else 0, int(time.time() * 1000), wf_id),
            )

    def delete_workflow(self, wf_id: str) -> None:
        with self._lock, self._conn:
            self._conn.execute("DELETE FROM workflows WHERE id=?", (wf_id,))

    def _row_to_workflow(self, r: sqlite3.Row) -> Workflow:
        graph = json.loads(r["graph"] or "{}")
        nodes = {
            nid: WorkflowNode(
                id=n["id"], kind=n["kind"],  # type: ignore[arg-type]
                label=n.get("label", ""), config=n.get("config", {}),
                next=n.get("next", []),
            )
            for nid, n in graph.get("nodes", {}).items()
        }
        return Workflow(
            id=r["id"], name=r["name"], description=r["description"],
            nodes=nodes, trigger_node_id=graph.get("trigger_node_id"),
            enabled=bool(r["enabled"]),
            require_approval_for_outbound=bool(r["require_approval"]),
            created_at=r["created_at"], updated_at=r["updated_at"],
            schedule=r["schedule"],
            app_event=json.loads(r["app_event"]) if r["app_event"] else None,
        )

    # ── Run CRUD ─────────────────────────────────────────────────────────

    def create_run(self, run: WorkflowRun) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                """INSERT OR REPLACE INTO runs
                   (id, workflow_id, status, started_at, finished_at,
                    node_outputs, pending_approval, error, trigger_payload)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (run.id, run.workflow_id, run.status, run.started_at,
                 run.finished_at, json.dumps(run.node_outputs),
                 json.dumps(run.pending_approval), run.error,
                 json.dumps(run.trigger_payload)),
            )

    def update_run(self, run: WorkflowRun) -> None:
        self.create_run(run)

    def get_run(self, run_id: str) -> WorkflowRun | None:
        r = self._conn.execute("SELECT * FROM runs WHERE id=?", (run_id,)).fetchone()
        if not r:
            return None
        return WorkflowRun(
            id=r["id"], workflow_id=r["workflow_id"],
            status=r["status"],  # type: ignore[arg-type]
            started_at=r["started_at"], finished_at=r["finished_at"],
            node_outputs=json.loads(r["node_outputs"] or "{}"),
            pending_approval=json.loads(r["pending_approval"] or "[]"),
            error=r["error"],
            trigger_payload=json.loads(r["trigger_payload"] or "{}"),
        )

    def list_runs(self, wf_id: str, k: int = 20) -> list[WorkflowRun]:
        rows = self._conn.execute(
            "SELECT * FROM runs WHERE workflow_id=? ORDER BY started_at DESC LIMIT ?",
            (wf_id, k),
        )
        return [
            WorkflowRun(
                id=r["id"], workflow_id=r["workflow_id"], status=r["status"],  # type: ignore[arg-type]
                started_at=r["started_at"], finished_at=r["finished_at"],
                node_outputs=json.loads(r["node_outputs"] or "{}"),
                pending_approval=json.loads(r["pending_approval"] or "[]"),
                error=r["error"],
                trigger_payload=json.loads(r["trigger_payload"] or "{}"),
            )
            for r in rows
        ]

    def close(self) -> None:
        with self._lock:
            try:
                self._conn.close()
            except Exception:
                pass


# ──────────────────────────────────────────────────────────────────────────────
# Engine
# ──────────────────────────────────────────────────────────────────────────────


class WorkflowEngine:
    """Executes workflow graphs with checkpointing + approval gates."""

    def __init__(
        self,
        config: WorkflowsConfig,
        *,
        runtime: Any = None,
        approval_callback: Callable[[str, str, dict[str, Any]], Any] | None = None,
    ) -> None:
        self.config = config
        self.runtime = runtime
        self.approval_callback = approval_callback
        self.store = WorkflowStore(config)
        # Per-flow dispatch locks.
        self._dispatch_locks: dict[str, asyncio.Lock] = {}
        self._locks_guard = threading.Lock()
        self._scheduler_task: asyncio.Task | None = None
        self._running = False

    async def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._scheduler_task = asyncio.create_task(self._scheduler_loop())
        log.info("WorkflowEngine started")

    async def stop(self) -> None:
        self._running = False
        if self._scheduler_task is not None:
            try:
                self._scheduler_task.cancel()
                await self._scheduler_task
            except Exception:
                pass
            self._scheduler_task = None
        self.store.close()

    def _get_dispatch_lock(self, wf_id: str) -> asyncio.Lock:
        with self._locks_guard:
            if wf_id not in self._dispatch_locks:
                self._dispatch_locks[wf_id] = asyncio.Lock()
            return self._dispatch_locks[wf_id]

    # ── Proposal (validate + describe, never save) ────────────────────────

    def propose_workflow(self, name: str, description: str, graph: dict[str, Any]) -> dict[str, Any]:
        """Validate + describe a candidate workflow.

        This NEVER creates or enables a flow — it only returns a
        human-readable summary for the user to review on the canvas.
        """
        errors = self._validate_graph(graph)
        if errors:
            return {"valid": False, "errors": errors, "summary": ""}
        summary = self._describe(name, description, graph)
        return {"valid": True, "errors": [], "summary": summary, "graph": graph}

    def _validate_graph(self, graph: dict[str, Any]) -> list[str]:
        errors: list[str] = []
        nodes = graph.get("nodes", {})
        if not nodes:
            errors.append("Graph has no nodes.")
            return errors
        # Exactly one trigger.
        triggers = [n for n in nodes.values() if n.get("kind") == "trigger"]
        if len(triggers) == 0:
            errors.append("Graph must have exactly one trigger node.")
        elif len(triggers) > 1:
            errors.append(f"Graph has {len(triggers)} triggers; only one is allowed.")
        # Validate node kinds.
        for nid, n in nodes.items():
            kind = n.get("kind")
            if kind not in self.config.node_kinds:
                errors.append(f"Node {nid} has unknown kind: {kind}")
            for next_id in n.get("next", []):
                if next_id not in nodes:
                    errors.append(f"Node {nid} → unknown next node: {next_id}")
        return errors

    def _describe(self, name: str, description: str, graph: dict[str, Any]) -> str:
        nodes = graph.get("nodes", {})
        lines = [f"Workflow: {name}", f"Description: {description}",
                 f"Nodes: {len(nodes)}"]
        for n in nodes.values():
            lines.append(f"  • [{n['kind']}] {n.get('label', n['id'])}")
        return "\n".join(lines)

    # ── Save (user-driven, not agent-driven) ──────────────────────────────

    def save_workflow(self, name: str, description: str, graph: dict[str, Any],
                      *, enabled: bool = False,
                      require_approval: bool = True) -> Workflow:
        proposal = self.propose_workflow(name, description, graph)
        if not proposal["valid"]:
            raise ValueError(f"Invalid graph: {proposal['errors']}")
        now_ms = int(time.time() * 1000)
        nodes = {
            nid: WorkflowNode(
                id=n["id"], kind=n["kind"], label=n.get("label", ""),
                config=n.get("config", {}), next=n.get("next", []),
            )
            for nid, n in graph["nodes"].items()
        }
        trigger_id = next((n["id"] for n in graph["nodes"].values()
                           if n["kind"] == "trigger"), None)
        wf = Workflow(
            id=str(uuid.uuid4()), name=name, description=description,
            nodes=nodes, trigger_node_id=trigger_id,
            enabled=enabled,
            require_approval_for_outbound=require_approval,
            created_at=now_ms, updated_at=now_ms,
            schedule=graph.get("schedule"),
            app_event=graph.get("app_event"),
        )
        self.store.save_workflow(wf)
        log.info("Saved workflow %s (%s) — enabled=%s", wf.id[:8], name, enabled)
        return wf

    # ── Execution ─────────────────────────────────────────────────────────

    async def run_workflow(self, wf_id: str, trigger_payload: dict[str, Any] | None = None) -> WorkflowRun:
        """Run a workflow.  Returns the WorkflowRun (final or paused)."""
        wf = self.store.get_workflow(wf_id)
        if wf is None:
            raise ValueError(f"Unknown workflow: {wf_id}")
        if not wf.enabled:
            raise ValueError(f"Workflow {wf_id} is not enabled")

        # Dispatch lock — prevents concurrent runs of the same flow.
        lock = self._get_dispatch_lock(wf_id)
        async with lock:
            run = WorkflowRun(
                id=str(uuid.uuid4()), workflow_id=wf_id,
                status="running", started_at=int(time.time() * 1000),
                trigger_payload=trigger_payload or {},
            )
            self.store.create_run(run)
            try:
                await self._execute_graph(wf, run)
                if run.status == "running":
                    run.status = "completed"
            except Exception as e:
                run.status = "failed"
                run.error = str(e)
                log.exception("Workflow %s run %s failed", wf_id, run.id[:8])
            run.finished_at = int(time.time() * 1000)
            self.store.update_run(run)
            return run

    async def _execute_graph(self, wf: Workflow, run: WorkflowRun) -> None:
        """Walk the graph from the trigger node, executing each node."""
        if wf.trigger_node_id is None:
            raise ValueError("Workflow has no trigger node")
        # Start from the trigger's next nodes.
        trigger = wf.nodes[wf.trigger_node_id]
        queue: list[str] = list(trigger.next)
        visited: set[str] = set()
        while queue:
            nid = queue.pop(0)
            if nid in visited:
                continue
            visited.add(nid)
            node = wf.nodes.get(nid)
            if node is None:
                continue
            # Approval gate for outbound nodes.
            if (wf.require_approval_for_outbound
                    and node.kind in ("http_request", "tool_call", "code")
                    and self.approval_callback is not None):
                approved = self.approval_callback(run.id, nid, {"config": node.config})
                if asyncio.iscoroutine(approved):
                    approved = await approved
                if not approved:
                    run.status = "paused_approval"
                    run.pending_approval.append(nid)
                    self.store.update_run(run)
                    return
            # Execute the node.
            output = await self._execute_node(node, run)
            run.node_outputs[nid] = {
                "output": output,
                "status": "completed",
                "started_at": int(time.time() * 1000),
                "finished_at": int(time.time() * 1000),
            }
            self.store.update_run(run)
            queue.extend(node.next)

    async def _execute_node(self, node: WorkflowNode, run: WorkflowRun) -> Any:
        kind = node.kind
        cfg = node.config
        if kind == "agent":
            if self.runtime is None:
                return "(no runtime)"
            result = await self.runtime.run(cfg.get("goal", ""), session_id=f"workflow:{run.id}")
            return getattr(result, "output", str(result))
        if kind == "tool_call":
            if self.runtime is None or self.runtime.tools is None:
                return "(no tools)"
            tool_name = cfg.get("tool", "")
            params = cfg.get("params", {})
            tool = await self.runtime.tools.get(tool_name)
            if tool is None:
                return f"(unknown tool: {tool_name})"
            return await tool.execute(**params)
        if kind == "http_request":
            import aiohttp
            async with aiohttp.ClientSession() as session:
                async with session.request(
                    cfg.get("method", "GET"), cfg.get("url", ""),
                    headers=cfg.get("headers"), json=cfg.get("body"),
                ) as resp:
                    return {"status": resp.status, "body": await resp.text()}
        if kind == "code":
            # Sandboxed code execution — delegate to the existing python_exec tool.
            if self.runtime is None or self.runtime.tools is None:
                return "(no runtime)"
            tool = await self.runtime.tools.get("python_exec")
            if tool is None:
                return "(no python_exec tool)"
            return await tool.execute(code=cfg.get("code", ""))
        if kind == "condition":
            expr = cfg.get("expr", "True")
            try:
                return {"passed": bool(eval(expr, {"__builtins__": {}}, {}))}
            except Exception as e:
                return {"passed": False, "error": str(e)}
        if kind == "transform":
            return cfg.get("value")
        # Default: pass through.
        return None

    async def resume_run(self, run_id: str) -> WorkflowRun:
        """Resume a run paused at an approval gate."""
        run = self.store.get_run(run_id)
        if run is None:
            raise ValueError(f"Unknown run: {run_id}")
        if run.status != "paused_approval":
            raise ValueError(f"Run {run_id} is not paused")
        wf = self.store.get_workflow(run.workflow_id)
        if wf is None:
            raise ValueError("Workflow disappeared")
        run.status = "running"
        run.pending_approval = []
        self.store.update_run(run)
        # Re-enter execution from where we paused.
        # (Simplified: re-run from the trigger.  A full implementation
        # would checkpoint the visited set and resume from the paused node.)
        try:
            await self._execute_graph(wf, run)
            if run.status == "running":
                run.status = "completed"
        except Exception as e:
            run.status = "failed"
            run.error = str(e)
        run.finished_at = int(time.time() * 1000)
        self.store.update_run(run)
        return run

    # ── Scheduler loop (cron + app_event triggers) ───────────────────────

    async def _scheduler_loop(self) -> None:
        while self._running:
            try:
                await self._fire_scheduled()
            except asyncio.CancelledError:
                raise
            except Exception as e:
                log.warning("Workflow scheduler tick failed: %s", e)
            await asyncio.sleep(30.0)

    async def _fire_scheduled(self) -> None:
        """Fire any cron-triggered workflows whose schedule is due."""
        import datetime as dt
        now = dt.datetime.now()
        for wf in self.store.list_workflows(only_enabled=True):
            if not wf.schedule:
                continue
            # Very simple cron: only support "every N minutes" via "*/N * * * *".
            # A full cron parser is out of scope here.
            sched = wf.schedule.strip()
            if sched.startswith("*/") and sched.endswith(" * * * *"):
                try:
                    minutes = int(sched[2:].split()[0])
                except Exception:
                    continue
                if now.minute % minutes == 0 and now.second < 30:
                    log.info("Firing scheduled workflow %s", wf.id[:8])
                    asyncio.create_task(self.run_workflow(wf.id))
