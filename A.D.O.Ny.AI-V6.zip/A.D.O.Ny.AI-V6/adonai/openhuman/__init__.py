"""v6 — OpenHuman-inspired subsystems ported into ADON.AI.

Eleven capabilities adapted from the OpenHuman project
(https://github.com/tinyhumansai/openhuman), re-implemented on the
ADON.AI runtime so they share its existing LLM, tool registry,
event bus, and SQLite persistence layer:

    1.  Memory Tree + Obsidian Wiki mirror       — memory_tree.py
    2.  Subconscious loop                        — subconscious.py
    3.  Goals & Todos                            — goals_todos.py
    4.  TokenJuice (tool output compressor)      — tokenjuice.py
    5.  Workflows (tinyflows-style graph engine) — workflows.py
    6.  Checkpointed graph harness               — graph_harness.py
    7.  Split brain (reflex + deep core)         — split_brain.py
    8.  Agent economy (tiny.place + x402 USDC)   — agent_economy.py
    9.  SuperContext (pre-message scout)         — super_context.py
    10. Batteries (voice + privacy + router)     — batteries.py
    11. Meeting agents (Meet/Zoom/Teams/Webex)   — meeting_agents.py
    12. Subconscious → executive_loop bridge     — subconscious_bridge.py

All subsystems are opt-in via config and backward-compatible with the
existing v4/v5 public API.
"""
from __future__ import annotations

__all__: list[str] = [
    "MemoryTreeService",
    "SubconsciousEngine",
    "GoalsTodosService",
    "TokenJuice",
    "WorkflowEngine",
    "GraphHarness",
    "SplitBrain",
    "AgentEconomy",
    "SuperContext",
    "Batteries",
    "MeetingAgentsService",
    "SubconsciousExecutiveBridge",
]
