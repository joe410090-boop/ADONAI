"""v6 — TokenJuice.

Tool output compressed before it hits the model: same information, up
to 80% fewer tokens.  A brain this big would be unaffordable without it.

Design (ported from OpenHuman's TokenJuice):

  * Every tool result passes through :meth:`TokenJuice.compress` before
    being fed back to the LLM.  Short outputs (< min_tokens_to_compress)
    are passed through unchanged.

  * Three strategies:
        - extractive  — TF-IDF sentence ranking (no LLM calls, deterministic)
        - summary     — LLM-based summarisation (highest quality, costs tokens)
        - auto        — extractive for outputs < 4k tokens, summary above

  * Compression is cached by SHA-256 of the input — repeated tool
    outputs (e.g. the same file read twice) don't get re-compressed.

  * The compressor records stats: input_tokens, output_tokens, ratio,
    strategy_used, source_tool.  These feed back into the analytics
    tracker so you can see exactly how many tokens TokenJuice saved.

The extractive path is intentionally dependency-free (no nltk, no
spacy).  It uses a simple TF-IDF + sentence-score heuristic that works
well on code output, file dumps, and HTTP responses.
"""
from __future__ import annotations

import hashlib
import logging
import math
import re
import sqlite3
import threading
import time
from collections import Counter
from dataclasses import dataclass, field
from typing import Any, Literal

from adonai.config.settings import TokenJuiceConfig

log = logging.getLogger(__name__)

Strategy = Literal["summary", "extractive", "auto"]


# ──────────────────────────────────────────────────────────────────────────────
# Token estimator
# ──────────────────────────────────────────────────────────────────────────────


def _estimate_tokens(text: str) -> int:
    """Rough token count: 4 chars ≈ 1 token (GPT-style)."""
    return max(1, len(text) // 4)


# ──────────────────────────────────────────────────────────────────────────────
# Extractive compressor (TF-IDF sentence ranking)
# ──────────────────────────────────────────────────────────────────────────────


_SENT_SPLIT = re.compile(r"(?<=[.!?])\s+|\n+")
_WORD = re.compile(r"[A-Za-z][A-Za-z0-9_]+")


def _sentences(text: str) -> list[str]:
    return [s.strip() for s in _SENT_SPLIT.split(text) if s.strip() and len(s.strip()) > 8]


def _tfidf(sentences: list[str]) -> list[float]:
    """Score each sentence by TF-IDF against the whole document."""
    if not sentences:
        return []
    doc_tokens = [_WORD.findall(s.lower()) for s in sentences]
    doc_freq: Counter = Counter()
    for toks in doc_tokens:
        for t in set(toks):
            doc_freq[t] += 1
    n = len(sentences)
    scores: list[float] = []
    for toks in doc_tokens:
        if not toks:
            scores.append(0.0)
            continue
        tf = Counter(toks)
        score = 0.0
        for t, c in tf.items():
            idf = math.log((1 + n) / (1 + doc_freq[t])) + 1.0
            score += c * idf
        # Normalise by sentence length so we don't bias toward long sentences.
        scores.append(score / max(1, len(toks)))
    return scores


def _extractive_summary(text: str, target_tokens: int) -> str:
    """Return the top-N sentences (by TF-IDF) that fit in ``target_tokens``."""
    sents = _sentences(text)
    if not sents:
        return text[: target_tokens * 4]
    scores = _tfidf(sents)
    # Rank sentences by score, preserve original order.
    ranked = sorted(range(len(sents)), key=lambda i: scores[i], reverse=True)
    selected: list[tuple[int, str]] = []
    total = 0
    for i in ranked:
        s = sents[i]
        stoks = _estimate_tokens(s)
        if total + stoks > target_tokens:
            continue
        selected.append((i, s))
        total += stoks
        if total >= target_tokens:
            break
    selected.sort(key=lambda t: t[0])
    return " ".join(s for _, s in selected)


# ──────────────────────────────────────────────────────────────────────────────
# Stats
# ──────────────────────────────────────────────────────────────────────────────


@dataclass
class CompressionStats:
    total_inputs: int = 0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    total_cache_hits: int = 0
    by_strategy: dict[str, dict[str, int]] = field(default_factory=dict)

    def record(self, strategy: str, in_t: int, out_t: int, cache_hit: bool) -> None:
        self.total_inputs += 1
        if not cache_hit:
            self.total_input_tokens += in_t
            self.total_output_tokens += out_t
        else:
            self.total_cache_hits += 1
        s = self.by_strategy.setdefault(strategy, {"inputs": 0, "in_tokens": 0, "out_tokens": 0})
        s["inputs"] += 1
        if not cache_hit:
            s["in_tokens"] += in_t
            s["out_tokens"] += out_t

    def ratio(self) -> float:
        if self.total_input_tokens == 0:
            return 0.0
        return self.total_output_tokens / self.total_input_tokens

    def to_dict(self) -> dict[str, Any]:
        return {
            "total_inputs": self.total_inputs,
            "total_input_tokens": self.total_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "total_cache_hits": self.total_cache_hits,
            "ratio": round(self.ratio(), 4),
            "saved_tokens": self.total_input_tokens - self.total_output_tokens,
            "by_strategy": self.by_strategy,
        }


# ──────────────────────────────────────────────────────────────────────────────
# TokenJuice
# ──────────────────────────────────────────────────────────────────────────────


class TokenJuice:
    """Compresses tool output before it hits the LLM."""

    def __init__(self, config: TokenJuiceConfig, *, llm: Any = None) -> None:
        self.config = config
        self.llm = llm
        self.stats = CompressionStats()
        self._cache: dict[str, str] = {}
        self._cache_order: list[str] = []
        self._lock = threading.Lock()

    def _cache_get(self, key: str) -> str | None:
        with self._lock:
            return self._cache.get(key)

    def _cache_put(self, key: str, value: str) -> None:
        with self._lock:
            self._cache[key] = value
            self._cache_order.append(key)
            while len(self._cache) > self.config.cache_max_entries:
                oldest = self._cache_order.pop(0)
                self._cache.pop(oldest, None)

    def compress(self, text: str, *, source_tool: str = "", strategy: Strategy | None = None) -> str:
        """Compress ``text``.

        Returns the compressed text.  If the input is shorter than
        ``min_tokens_to_compress`` tokens, it's returned unchanged.
        """
        if not self.config.enabled or not text:
            return text

        in_tokens = _estimate_tokens(text)
        if in_tokens < self.config.min_tokens_to_compress:
            self.stats.record("passthrough", in_tokens, in_tokens, cache_hit=False)
            return text

        # Cache lookup.
        if self.config.cache_enabled:
            key = hashlib.sha256(text.encode("utf-8")).hexdigest()
            cached = self._cache_get(key)
            if cached is not None:
                self.stats.record(strategy or "cached", in_tokens, _estimate_tokens(cached), cache_hit=True)
                return cached
        else:
            key = ""

        # Pick strategy.
        strat: Strategy = strategy or self.config.strategy
        if strat == "auto":
            strat = "extractive" if in_tokens < 4000 else "summary"

        # Compress.
        target = max(64, int(in_tokens * self.config.target_ratio))
        target = min(target, self.config.max_output_tokens)

        if strat == "extractive":
            out = _extractive_summary(text, target)
        elif strat == "summary":
            out = self._llm_summary(text, target)
        else:
            out = _extractive_summary(text, target)

        # Cache.
        if self.config.cache_enabled and key:
            self._cache_put(key, out)

        out_tokens = _estimate_tokens(out)
        self.stats.record(strat, in_tokens, out_tokens, cache_hit=False)
        log.debug(
            "TokenJuice %s: %d → %d tokens (%.0f%% reduction) [%s]",
            strat, in_tokens, out_tokens,
            100 * (1 - out_tokens / max(1, in_tokens)),
            source_tool or "?",
        )
        return out

    def _llm_summary(self, text: str, target_tokens: int) -> str:
        """LLM-based summarisation.  Falls back to extractive on failure."""
        if self.llm is None:
            return _extractive_summary(text, target_tokens)
        prompt = (
            f"Compress the following tool output to ~{target_tokens} tokens. "
            f"Preserve every fact, every number, every identifier.  Drop only "
            f"redundancy and boilerplate.\n\n{text}\n\nCompressed:"
        )
        try:
            resp = self.llm.complete(prompt, max_tokens=target_tokens, temperature=0.0)
            out = resp.text if hasattr(resp, "text") else str(resp)
            return out.strip()
        except Exception as e:
            log.warning("TokenJuice LLM summary failed (%s) — falling back to extractive", e)
            return _extractive_summary(text, target_tokens)

    # ── Stats ─────────────────────────────────────────────────────────────

    def stats_snapshot(self) -> dict[str, Any]:
        return self.stats.to_dict()
