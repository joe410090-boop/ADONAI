"""v6 — Subconscious → executive_loop bridge.

ADON.AI has its own executive_loop (observe→think→plan→execute→reflect).
The subconscious can be the trigger source: on its 5-min tick it scans
the memory diff (new emails, new commits), and when something warrants,
it fires a goal at the executive loop.  ADON.AI becomes the
deep-reasoning worker for the subconscious's idle thread.

Design:

  * The :class:`SubconsciousExecutiveBridge` connects two existing loops:
        - :class:`adonai.openhuman.subconscious.SubconsciousEngine`
        - :class:`adonai.agents.executive_controller.ExecutiveController`

  * On each subconscious tick, if the engine escalates a task, the
    bridge:
        1. Converts the task into an executive goal.
        2. Submits it via ``runtime.run_background()`` (or the
           configured HTTP endpoint, if the runtime is remote).
        3. Records the submission in a journal so the user can see
           what the subconscious delegated to the executive loop.

  * The bridge respects the subconscious's "tainted" flag: if the
    tick reacted to external changes, the bridge marks the submitted
    goal as tainted, and the executive loop's approval gate refuses
    external-effect tools for that goal.

  * If the configured endpoint is an HTTP URL (e.g. when ADON.AI runs
    headless and the subconscious is on a different machine), the
    bridge POSTs to ``{endpoint}`` with the goal as the body.
"""
from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable

from adonai.config.settings import SubconsciousConfig

log = logging.getLogger(__name__)


@dataclass
class BridgeEntry:
    """One goal submitted by the subconscious to the executive loop."""
    id: str
    goal: str
    tainted: bool
    submitted_at: int
    task_id: str = ""          # executive loop task id (if submitted locally)
    status: str = "submitted"  # submitted | running | completed | failed
    error: str = ""


class BridgeJournal:
    """SQLite-backed journal of subconscious → executive submissions."""

    def __init__(self, db_path: str | None = None) -> None:
        from pathlib import Path
        from adonai.config.settings import PROJECT_ROOT
        path = Path(db_path) if db_path else PROJECT_ROOT / "data" / "subconscious_bridge.db"
        path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._lock = threading.RLock()
        with self._conn:
            self._conn.execute("""
                CREATE TABLE IF NOT EXISTS bridge_entries (
                    id TEXT PRIMARY KEY,
                    goal TEXT NOT NULL,
                    tainted INTEGER NOT NULL DEFAULT 0,
                    submitted_at INTEGER NOT NULL,
                    task_id TEXT NOT NULL DEFAULT '',
                    status TEXT NOT NULL DEFAULT 'submitted',
                    error TEXT NOT NULL DEFAULT ''
                )
            """)
            self._conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_bridge_submitted
                ON bridge_entries(submitted_at DESC)
            """)

    def add(self, entry: BridgeEntry) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                """INSERT OR REPLACE INTO bridge_entries
                   (id, goal, tainted, submitted_at, task_id, status, error)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (entry.id, entry.goal, 1 if entry.tainted else 0,
                 entry.submitted_at, entry.task_id, entry.status, entry.error),
            )

    def update(self, entry_id: str, *, task_id: str | None = None,
               status: str | None = None, error: str | None = None) -> None:
        with self._lock, self._conn:
            cur = self._conn.execute(
                "SELECT * FROM bridge_entries WHERE id=?", (entry_id,),
            ).fetchone()
            if cur is None:
                return
            task_id = task_id if task_id is not None else cur["task_id"]
            status = status if status is not None else cur["status"]
            error = error if error is not None else cur["error"]
            self._conn.execute(
                """UPDATE bridge_entries SET task_id=?, status=?, error=?
                   WHERE id=?""",
                (task_id, status, error, entry_id),
            )

    def recent(self, k: int = 20) -> list[dict[str, Any]]:
        rows = self._conn.execute(
            "SELECT * FROM bridge_entries ORDER BY submitted_at DESC LIMIT ?", (k,),
        )
        return [dict(r) for r in rows]

    def close(self) -> None:
        with self._lock:
            try:
                self._conn.close()
            except Exception:
                pass


class SubconsciousExecutiveBridge:
    """Connects the subconscious loop to the executive loop.

    Used as the ``bridge`` callback by :class:`SubconsciousEngine`.
    """

    def __init__(
        self,
        config: SubconsciousConfig,
        *,
        runtime: Any = None,
        http_endpoint: str | None = None,
    ) -> None:
        self.config = config
        self.runtime = runtime
        self.http_endpoint = http_endpoint or (
            config.bridge_endpoint if config.bridge_endpoint.startswith("http")
            else None
        )
        self.journal = BridgeJournal()

    async def __call__(self, goal: str, context: dict[str, Any]) -> str:
        """Submit a goal to the executive loop.

        Returns a submission id (the BridgeEntry.id).  The actual
        executive task id is recorded in the journal once the runtime
        acknowledges it.
        """
        entry = BridgeEntry(
            id=str(uuid.uuid4()),
            goal=goal,
            tainted=bool(context.get("tainted", False)),
            submitted_at=int(time.time() * 1000),
        )
        self.journal.add(entry)
        try:
            if self.http_endpoint is not None:
                task_id = await self._submit_http(goal, context)
            else:
                task_id = await self._submit_local(goal, context)
            self.journal.update(entry.id, task_id=task_id, status="running")
            log.info("Bridge submitted goal %s → task %s (tainted=%s)",
                     entry.id[:8], task_id[:8] if task_id else "?", entry.tainted)
            return task_id or entry.id
        except Exception as e:
            self.journal.update(entry.id, status="failed", error=str(e))
            log.warning("Bridge submission failed: %s", e)
            return entry.id

    async def _submit_local(self, goal: str, context: dict[str, Any]) -> str:
        """Submit to a local ADON.AI runtime via run_background()."""
        if self.runtime is None:
            raise RuntimeError("No runtime configured for local bridge submission")
        # The tainted flag propagates into the task context so the
        # executive loop's approval gate can refuse external-effect tools.
        kwargs: dict[str, Any] = {}
        if entry_tainted := context.get("tainted"):
            kwargs["context"] = {"tainted": True, "source": "subconscious"}
        return await self.runtime.run_background(goal, **kwargs)

    async def _submit_http(self, goal: str, context: dict[str, Any]) -> str:
        """Submit to a remote ADON.AI HTTP endpoint."""
        import aiohttp
        payload = {
            "goal": goal,
            "context": context,
            "source": "subconscious_bridge",
        }
        async with aiohttp.ClientSession() as session:
            async with session.post(
                self.http_endpoint or "",
                json=payload,
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                if resp.status != 200:
                    raise RuntimeError(f"HTTP {resp.status}: {await resp.text()}")
                data = await resp.json()
                return data.get("task_id", "")

    # ── Status ────────────────────────────────────────────────────────────

    def recent(self, k: int = 20) -> list[dict[str, Any]]:
        return self.journal.recent(k)

    def close(self) -> None:
        self.journal.close()
