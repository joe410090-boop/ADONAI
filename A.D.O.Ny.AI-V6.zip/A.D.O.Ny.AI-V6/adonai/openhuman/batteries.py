"""v6 — Batteries included.

Batteries: web search, scraper, coder toolset, a real browser, and
native voice with in-process Whisper.  Model routing picks the right
LLM per workload on one subscription, with local AI optional.

Design (ported from OpenHuman's "batteries included" surface):

  * ADON.AI already ships web_search, web_fetch, terminal, python_exec,
    and a browser tool.  This module extends them with:

    1. **Voice**: in-process Whisper for speech-to-text.  Adds a
       `voice.transcribe` tool that takes an audio file path and
       returns the transcript.
    2. **Model routing extensions**: routes tasks to the right LLM
       tier based on complexity.  Builds on the existing
       ModelRouterConfig but adds workload-type hints.
    3. **Local AI optional**: a single switch that forces all inference
       to stay on-device (Privacy Mode).

  * The voice tool is optional — it gracefully degrades when the
    `whisper` package isn't installed.
"""
from __future__ import annotations

import asyncio
import logging
import shutil
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any, Literal

from adonai.config.settings import BatteriesConfig
from adonai.core.interfaces import Tool
from adonai.core.models import ToolResult

log = logging.getLogger(__name__)


class VoiceTool(Tool):
    """In-process Whisper speech-to-text tool.

    Inherits from :class:`adonai.core.interfaces.Tool` so it has the
    ``parameters`` JSON-schema attribute, ``category``, ``risk_level``,
    and returns :class:`ToolResult` from :meth:`execute` — matching
    every other tool in the registry.
    """

    name = "voice.transcribe"
    description = "Transcribe an audio file to text using in-process Whisper."
    risk_level = "low"
    category = "media"
    requires_approval = False
    cacheable = False  # side-effect: reads from disk + loads a model
    tags = ["voice", "audio", "whisper", "stt"]

    # JSON schema for the tool-calling agent.
    parameters: dict = {
        "type": "object",
        "properties": {
            "audio_path": {
                "type": "string",
                "description": "Path to the audio file to transcribe.",
            },
            "language": {
                "type": "string",
                "description": "Optional language code (e.g. 'en', 'fr'). "
                               "Auto-detected if omitted.",
            },
        },
        "required": ["audio_path"],
    }

    def __init__(self, config: BatteriesConfig) -> None:
        self.config = config
        self._model = None
        self._available: bool | None = None

    def _check_available(self) -> bool:
        if self._available is not None:
            return self._available
        try:
            import whisper  # type: ignore[import-untyped]
            self._available = True
        except ImportError:
            self._available = False
            log.info("VoiceTool: `whisper` not installed — voice transcription disabled")
        return self._available

    async def execute(self, **params: Any) -> ToolResult:
        """Transcribe an audio file.  Returns a ToolResult."""
        call_id = f"voice_{int(time.time() * 1000)}"
        audio_path = params.get("audio_path", "")
        language = params.get("language")

        if not self._check_available():
            return ToolResult(
                call_id=call_id, tool=self.name, success=False,
                error="whisper package not installed — run `pip install openai-whisper`",
                output={"error": "whisper not installed", "transcript": ""},
            )
        if not audio_path or not Path(audio_path).exists():
            return ToolResult(
                call_id=call_id, tool=self.name, success=False,
                error=f"audio file not found: {audio_path}",
                output={"error": f"audio file not found: {audio_path}", "transcript": ""},
            )

        import whisper  # type: ignore[import-untyped]
        loop = asyncio.get_event_loop()

        def _transcribe():
            if self._model is None:
                self._model = whisper.load_model(self.config.whisper_model)
            return self._model.transcribe(str(audio_path), language=language)

        try:
            result = await loop.run_in_executor(None, _transcribe)
            output = {
                "transcript": result.get("text", "").strip(),
                "language": result.get("language"),
                "segments": len(result.get("segments", [])),
            }
            return ToolResult(
                call_id=call_id, tool=self.name, success=True,
                output=output,
            )
        except Exception as e:
            log.exception("VoiceTool transcribe failed")
            return ToolResult(
                call_id=call_id, tool=self.name, success=False,
                error=str(e),
                output={"error": str(e), "transcript": ""},
            )

    # ── Direct (non-tool) API: used by the /v6/voice/transcribe endpoint ──

    async def transcribe_bytes(
        self, audio_bytes: bytes, *, language: str | None = None,
        suffix: str = ".webm",
    ) -> dict[str, Any]:
        """Transcribe raw audio bytes (e.g. from a multipart upload).

        Writes the bytes to a temp file, calls Whisper, returns the
        transcript dict.  Used by the ``POST /v6/voice/transcribe``
        HTTP endpoint so the web UI can upload browser-recorded audio.
        """
        if not self._check_available():
            return {"error": "whisper not installed", "transcript": ""}

        # Write to a temp file — Whisper needs a path on disk.
        tmp = Path(tempfile.gettempdir()) / f"adonai_voice_{uuid.uuid4().hex}{suffix}"
        try:
            tmp.write_bytes(audio_bytes)
            # Reuse the same execute() path so we get model caching + the
            # executor offload.
            result = await self.execute(audio_path=str(tmp), language=language)
            if result.success:
                return result.output  # type: ignore[return-value]
            return {
                "error": result.error or "transcription failed",
                "transcript": "",
            }
        finally:
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass


class PrivacyMode:
    """One-switch Privacy Mode: no inference leaves the machine.

    When enabled, all LLM calls are forced to the local backend
    (Ollama).  Remote backends (OpenAI-compat, Anthropic, etc.) are
    refused at the router level.
    """

    def __init__(self) -> None:
        self._enabled = False

    def enable(self) -> None:
        self._enabled = True
        log.info("Privacy Mode ENABLED — all inference forced local")

    def disable(self) -> None:
        self._enabled = False
        log.info("Privacy Mode disabled")

    @property
    def enabled(self) -> bool:
        return self._enabled

    def check_backend(self, backend: str) -> bool:
        """Returns True if the backend is allowed under Privacy Mode."""
        if not self._enabled:
            return True
        allowed = {"ollama", "llama_cpp", "vllm"}
        if backend not in allowed:
            log.warning("Privacy Mode refused backend: %s", backend)
            return False
        return True


class ModelRouterExtensions:
    """Workload-type hints for the existing ModelRouter.

    Adds a `route_by_workload(workload_type)` method that maps a
    workload type to a model tier:
        - chat         → small (fast reflex)
        - coding       → medium
        - reasoning    → large
        - vision       → vision
        - embedding    → embedding
    """

    WORKLOAD_TO_TIER: dict[str, str] = {
        "chat": "small",
        "coding": "medium",
        "reasoning": "large",
        "vision": "vision",
        "embedding": "embedding",
    }

    def __init__(self, config: BatteriesConfig) -> None:
        self.config = config

    def route(self, workload_type: str) -> str:
        return self.WORKLOAD_TO_TIER.get(workload_type, "medium")

    def available_tiers(self) -> list[str]:
        return list(self.WORKLOAD_TO_TIER.values())


class Batteries:
    """Aggregates the batteries-included tools."""

    def __init__(self, config: BatteriesConfig) -> None:
        self.config = config
        self.voice = VoiceTool(config) if config.voice_enabled else None
        self.privacy_mode = PrivacyMode()
        self.router_ext = ModelRouterExtensions(config)

    def tools(self) -> list[Any]:
        """Return the list of battery tools to register."""
        tools: list[Any] = []
        if self.voice is not None:
            tools.append(self.voice)
        return tools
