"""v6 — Goals & Todos.

Long-term goals, durable per-thread goals, and a shared kanban board
per conversation.

Design (ported from OpenHuman's Goals & Todos):

  * Three scopes:
        - long_term  — survives across sessions, capped at N
        - per_thread — bound to a session_id, capped at M
        - kanban     — one board per conversation, with columns:
                       backlog → todo → doing → review → done

  * A goal is a typed record:
        id, scope, title, status, created_at, updated_at,
        parent_id (for sub-goals), session_id (for per_thread + kanban),
        priority, notes

  * The subconscious loop advances long_term goals on each tick.
  * Per-thread goals auto-promote to long_term when they survive N turns.
  * The kanban board is shared between user + agent: the agent can move
    cards forward, the user can reorder them.

SQLite-backed, stdlib-only.
"""
from __future__ import annotations

import json
import logging
import sqlite3
import threading
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Literal

from adonai.config.settings import GoalsTodosConfig

log = logging.getLogger(__name__)

Scope = Literal["long_term", "per_thread", "kanban"]
Status = Literal["backlog", "todo", "doing", "review", "done"]


@dataclass
class Goal:
    id: str
    scope: Scope
    title: str
    status: Status = "backlog"
    session_id: str | None = None
    parent_id: str | None = None
    priority: int = 0
    notes: str = ""
    created_at: int = 0
    updated_at: int = 0
    # Turn counter — when ≥ promote_to_long_term_after_turns, a
    # per_thread goal is auto-promoted to long_term.
    turn_count: int = 0


class GoalsTodosStore:
    """SQLite-backed store for goals + kanban boards."""

    def __init__(self, config: GoalsTodosConfig) -> None:
        self.config = config
        self.db_path = config.db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._lock = threading.RLock()
        self._ensure_schema()

    def _ensure_schema(self) -> None:
        with self._conn:
            self._conn.execute("""
                CREATE TABLE IF NOT EXISTS goals (
                    id          TEXT PRIMARY KEY,
                    scope       TEXT NOT NULL,
                    title       TEXT NOT NULL,
                    status      TEXT NOT NULL DEFAULT 'backlog',
                    session_id  TEXT,
                    parent_id   TEXT,
                    priority    INTEGER NOT NULL DEFAULT 0,
                    notes       TEXT NOT NULL DEFAULT '',
                    created_at  INTEGER NOT NULL,
                    updated_at  INTEGER NOT NULL,
                    turn_count  INTEGER NOT NULL DEFAULT 0
                )
            """)
            self._conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_goals_scope
                ON goals(scope, status)
            """)
            self._conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_goals_session
                ON goals(session_id)
            """)
            self._conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_goals_parent
                ON goals(parent_id)
            """)

    def _row_to_goal(self, r: sqlite3.Row) -> Goal:
        return Goal(
            id=r["id"], scope=r["scope"],  # type: ignore[arg-type]
            title=r["title"], status=r["status"],  # type: ignore[arg-type]
            session_id=r["session_id"], parent_id=r["parent_id"],
            priority=r["priority"], notes=r["notes"],
            created_at=r["created_at"], updated_at=r["updated_at"],
            turn_count=r["turn_count"],
        )

    # ── CRUD ──────────────────────────────────────────────────────────────

    def add_goal(
        self,
        title: str,
        scope: Scope = "long_term",
        *,
        session_id: str | None = None,
        parent_id: str | None = None,
        priority: int = 0,
        status: Status = "backlog",
        notes: str = "",
    ) -> Goal:
        # Enforce caps.
        if scope == "long_term":
            existing = self.list_long_term()
            if len(existing) >= self.config.max_long_term_goals:
                raise ValueError(
                    f"Long-term goal cap reached ({self.config.max_long_term_goals})"
                )
        elif scope == "per_thread":
            if session_id and len(self.list_per_thread(session_id)) >= self.config.max_per_thread_goals:
                raise ValueError(
                    f"Per-thread goal cap reached ({self.config.max_per_thread_goals})"
                )
        now_ms = int(time.time() * 1000)
        goal = Goal(
            id=str(uuid.uuid4()), scope=scope, title=title, status=status,
            session_id=session_id, parent_id=parent_id, priority=priority,
            notes=notes, created_at=now_ms, updated_at=now_ms,
        )
        with self._lock, self._conn:
            self._conn.execute(
                """INSERT INTO goals
                   (id, scope, title, status, session_id, parent_id,
                    priority, notes, created_at, updated_at, turn_count)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)""",
                (goal.id, goal.scope, goal.title, goal.status,
                 goal.session_id, goal.parent_id, goal.priority,
                 goal.notes, goal.created_at, goal.updated_at),
            )
        log.info("Added %s goal %s: %s", scope, goal.id[:8], title[:80])
        return goal

    def get(self, goal_id: str) -> Goal | None:
        r = self._conn.execute("SELECT * FROM goals WHERE id=?", (goal_id,)).fetchone()
        return self._row_to_goal(r) if r else None

    def update_status(self, goal_id: str, status: Status) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                "UPDATE goals SET status=?, updated_at=? WHERE id=?",
                (status, int(time.time() * 1000), goal_id),
            )

    def update_notes(self, goal_id: str, notes: str) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                "UPDATE goals SET notes=?, updated_at=? WHERE id=?",
                (notes, int(time.time() * 1000), goal_id),
            )

    def delete(self, goal_id: str) -> None:
        with self._lock, self._conn:
            self._conn.execute("DELETE FROM goals WHERE id=?", (goal_id,))

    # ── Listing ──────────────────────────────────────────────────────────

    def list_long_term(self, include_done: bool = False) -> list[Goal]:
        q = "SELECT * FROM goals WHERE scope='long_term'"
        if not include_done:
            q += " AND status != 'done'"
        q += " ORDER BY priority DESC, created_at ASC"
        return [self._row_to_goal(r) for r in self._conn.execute(q)]

    def list_per_thread(self, session_id: str, include_done: bool = False) -> list[Goal]:
        q = "SELECT * FROM goals WHERE scope='per_thread' AND session_id=?"
        if not include_done:
            q += " AND status != 'done'"
        q += " ORDER BY priority DESC, created_at ASC"
        return [self._row_to_goal(r) for r in self._conn.execute(q, (session_id,))]

    def kanban_board(self, session_id: str) -> dict[str, list[Goal]]:
        """Return the kanban board for a conversation as {column: [goals]}."""
        out: dict[str, list[Goal]] = {col: [] for col in self.config.kanban_columns}
        rows = self._conn.execute(
            """SELECT * FROM goals WHERE scope='kanban' AND session_id=?
               ORDER BY priority DESC, created_at ASC""",
            (session_id,),
        )
        for r in rows:
            g = self._row_to_goal(r)
            if g.status in out:
                out[g.status].append(g)
        return out

    # ── Promotion ────────────────────────────────────────────────────────

    def bump_turn(self, session_id: str) -> list[Goal]:
        """Increment the turn counter for all per_thread goals in a session.

        Returns the goals that were promoted to long_term as a result.
        """
        promoted: list[Goal] = []
        threshold = self.config.promote_to_long_term_after_turns
        with self._lock, self._conn:
            self._conn.execute(
                """UPDATE goals SET turn_count = turn_count + 1, updated_at=?
                   WHERE scope='per_thread' AND session_id=?""",
                (int(time.time() * 1000), session_id),
            )
            rows = self._conn.execute(
                """SELECT * FROM goals
                   WHERE scope='per_thread' AND session_id=? AND turn_count >= ?""",
                (session_id, threshold),
            )
            for r in rows:
                if len(self.list_long_term()) >= self.config.max_long_term_goals:
                    break
                self._conn.execute(
                    """UPDATE goals SET scope='long_term', updated_at=? WHERE id=?""",
                    (int(time.time() * 1000), r["id"]),
                )
                # Build the Goal AFTER the UPDATE so scope reflects the new value.
                promoted.append(Goal(
                    id=r["id"], scope="long_term", title=r["title"],
                    status=r["status"],  # type: ignore[arg-type]
                    session_id=r["session_id"], parent_id=r["parent_id"],
                    priority=r["priority"], notes=r["notes"],
                    created_at=r["created_at"], updated_at=int(time.time() * 1000),
                    turn_count=r["turn_count"],
                ))
        if promoted:
            log.info("Promoted %d per-thread goal(s) to long-term", len(promoted))
        return promoted

    # ── Close ─────────────────────────────────────────────────────────────

    def close(self) -> None:
        with self._lock:
            try:
                self._conn.close()
            except Exception:
                pass


class GoalsTodosService:
    """High-level service used by the runtime."""

    def __init__(self, config: GoalsTodosConfig) -> None:
        self.config = config
        self.store = GoalsTodosStore(config)

    # Long-term
    def add_long_term(self, title: str, **kw: Any) -> Goal:
        return self.store.add_goal(title, scope="long_term", **kw)

    def list_long_term(self, include_done: bool = False) -> list[Goal]:
        return self.store.list_long_term(include_done)

    # Per-thread
    def add_per_thread(self, session_id: str, title: str, **kw: Any) -> Goal:
        return self.store.add_goal(title, scope="per_thread", session_id=session_id, **kw)

    def list_per_thread(self, session_id: str, include_done: bool = False) -> list[Goal]:
        return self.store.list_per_thread(session_id, include_done)

    # Kanban
    def add_kanban_card(self, session_id: str, title: str, status: Status = "backlog", **kw: Any) -> Goal:
        return self.store.add_goal(title, scope="kanban", session_id=session_id, status=status, **kw)

    def move_card(self, goal_id: str, status: Status) -> None:
        self.store.update_status(goal_id, status)

    def kanban_board(self, session_id: str) -> dict[str, list[Goal]]:
        return self.store.kanban_board(session_id)

    # Shared
    def get(self, goal_id: str) -> Goal | None:
        return self.store.get(goal_id)

    def update_status(self, goal_id: str, status: Status) -> None:
        self.store.update_status(goal_id, status)

    def update_notes(self, goal_id: str, notes: str) -> None:
        self.store.update_notes(goal_id, notes)

    def delete(self, goal_id: str) -> None:
        self.store.delete(goal_id)

    def bump_turn(self, session_id: str) -> list[Goal]:
        return self.store.bump_turn(session_id)

    def close(self) -> None:
        self.store.close()
