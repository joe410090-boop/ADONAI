"""v6 — Subconscious loop.

A background loop that diffs your world, advances your goals, and
writes your morning briefing.  Thinking continues after you stop typing.

Design (ported from OpenHuman's Subconscious):

  * A heartbeat tick fires every N seconds (default 300s / 5 min).
  * On each tick:
        1. Load due tasks (system + user).
        2. Mark each in-progress.
        3. Build a situation report from the world diff:
           - new memory_tree chunks since last tick
           - new git commits since last tick
           - new channel messages since last tick
           - upcoming calendar events
        4. For each task, the LLM returns one of:
              Skip     — nothing relevant
              Act      — execute on the local model
              Escalate — hand to the deep reasoning core
        5. Execute the decision.
        6. Write the outcome to the activity log.

  * The morning briefing is generated at a configured local hour.  It
    reads the last 24h of memory_tree chunks + calendar + email and
    produces a four-bucket digest: Highlights, Action items, Mentions,
    FYI.  Collapses to "nothing pressing" on quiet days.

  * Bridge to executive_loop: when a tick surfaces actionable work,
    it fires a goal at the runtime's `run_background()` (or the
    configured HTTP endpoint).  ADON.AI becomes the deep-reasoning
    worker for the subconscious's idle thread.

The loop is strictly offline by default — it never contacts anyone and
never takes external actions on its own.  Ticks that reacted to
external changes run "tainted", so the approval gate refuses
external-effect tools.
"""
from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Literal

from adonai.config.settings import SubconsciousConfig

log = logging.getLogger(__name__)

Decision = Literal["skip", "act", "escalate"]


@dataclass
class SubconsciousTask:
    """A task evaluated by the subconscious on each tick."""
    id: str
    title: str
    intent: Literal["read", "write"]
    enabled: bool = True
    system: bool = False           # system tasks can't be deleted
    last_evaluated_ms: int = 0
    last_decision: Decision | None = None
    last_result: str = ""


@dataclass
class ActivityEntry:
    """One row in the activity log."""
    timestamp_ms: int
    task_id: str
    task_title: str
    decision: Decision
    state: str                     # "evaluating" | "acted" | "skipped" | "escalated" | "failed"
    result: str = ""
    tainted: bool = False          # True if the tick reacted to external changes


# ──────────────────────────────────────────────────────────────────────────────
# Store
# ──────────────────────────────────────────────────────────────────────────────


class SubconsciousStore:
    """SQLite-backed store for tasks + activity log + world diff state."""

    def __init__(self, db_path: str | None = None) -> None:
        from adonai.config.settings import PROJECT_ROOT
        path = Path(db_path) if db_path else PROJECT_ROOT / "data" / "subconscious.db"
        path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._lock = threading.RLock()
        self._ensure_schema()
        self._seed_system_tasks()

    def _ensure_schema(self) -> None:
        with self._conn:
            self._conn.execute("""
                CREATE TABLE IF NOT EXISTS tasks (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    intent TEXT NOT NULL,
                    enabled INTEGER NOT NULL DEFAULT 1,
                    system INTEGER NOT NULL DEFAULT 0,
                    last_evaluated_ms INTEGER NOT NULL DEFAULT 0,
                    last_decision TEXT,
                    last_result TEXT NOT NULL DEFAULT ''
                )
            """)
            self._conn.execute("""
                CREATE TABLE IF NOT EXISTS activity (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp_ms INTEGER NOT NULL,
                    task_id TEXT NOT NULL,
                    task_title TEXT NOT NULL,
                    decision TEXT NOT NULL,
                    state TEXT NOT NULL,
                    result TEXT NOT NULL DEFAULT '',
                    tainted INTEGER NOT NULL DEFAULT 0
                )
            """)
            self._conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_activity_ts
                ON activity(timestamp_ms DESC)
            """)
            self._conn.execute("""
                CREATE TABLE IF NOT EXISTS world_state (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_ms INTEGER NOT NULL
                )
            """)

    def _seed_system_tasks(self) -> None:
        defaults = [
            ("sys_health", "Monitor system health (local model, memory, connections)", "read"),
            ("sys_memory", "Review new memory updates for actionable items", "read"),
            ("sys_goals",  "Advance long-term goals", "write"),
            ("sys_briefing", "Generate morning briefing", "write"),
        ]
        with self._lock, self._conn:
            for tid, title, intent in defaults:
                self._conn.execute(
                    """INSERT OR IGNORE INTO tasks
                       (id, title, intent, enabled, system)
                       VALUES (?, ?, ?, 1, 1)""",
                    (tid, title, intent),
                )

    # ── Tasks ─────────────────────────────────────────────────────────────

    def list_tasks(self, only_enabled: bool = False) -> list[SubconsciousTask]:
        q = "SELECT * FROM tasks"
        if only_enabled:
            q += " WHERE enabled=1"
        q += " ORDER BY system DESC, id ASC"
        return [self._row_to_task(r) for r in self._conn.execute(q)]

    def add_task(self, tid: str, title: str, intent: Literal["read", "write"]) -> SubconsciousTask:
        with self._lock, self._conn:
            self._conn.execute(
                """INSERT OR REPLACE INTO tasks
                   (id, title, intent, enabled, system)
                   VALUES (?, ?, ?, 1, 0)""",
                (tid, title, intent),
            )
        return SubconsciousTask(id=tid, title=title, intent=intent)

    def delete_task(self, tid: str) -> None:
        with self._lock, self._conn:
            self._conn.execute("DELETE FROM tasks WHERE id=? AND system=0", (tid,))

    def toggle_task(self, tid: str, enabled: bool) -> None:
        with self._lock, self._conn:
            self._conn.execute("UPDATE tasks SET enabled=? WHERE id=?", (1 if enabled else 0, tid))

    def update_task_result(self, tid: str, decision: Decision, result: str) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                """UPDATE tasks SET last_evaluated_ms=?, last_decision=?, last_result=?
                   WHERE id=?""",
                (int(time.time() * 1000), decision, result[:500], tid),
            )

    # ── Activity log ─────────────────────────────────────────────────────

    def log_activity(self, entry: ActivityEntry) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                """INSERT INTO activity
                   (timestamp_ms, task_id, task_title, decision, state,
                    result, tainted)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (entry.timestamp_ms, entry.task_id, entry.task_title,
                 entry.decision, entry.state, entry.result[:500],
                 1 if entry.tainted else 0),
            )

    def recent_activity(self, k: int = 50) -> list[dict[str, Any]]:
        rows = self._conn.execute(
            "SELECT * FROM activity ORDER BY timestamp_ms DESC LIMIT ?", (k,),
        )
        return [dict(r) for r in rows]

    # ── World state (diff bookmarks) ─────────────────────────────────────

    def get_state(self, key: str, default: str = "") -> str:
        r = self._conn.execute(
            "SELECT value FROM world_state WHERE key=?", (key,),
        ).fetchone()
        return r["value"] if r else default

    def set_state(self, key: str, value: str) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                """INSERT OR REPLACE INTO world_state (key, value, updated_ms)
                   VALUES (?, ?, ?)""",
                (key, value, int(time.time() * 1000)),
            )

    def _row_to_task(self, r: sqlite3.Row) -> SubconsciousTask:
        return SubconsciousTask(
            id=r["id"], title=r["title"],
            intent=r["intent"],  # type: ignore[arg-type]
            enabled=bool(r["enabled"]), system=bool(r["system"]),
            last_evaluated_ms=r["last_evaluated_ms"],
            last_decision=r["last_decision"],  # type: ignore[arg-type]
            last_result=r["last_result"],
        )

    def close(self) -> None:
        with self._lock:
            try:
                self._conn.close()
            except Exception:
                pass


# Late import for Path typing.
from pathlib import Path  # noqa: E402


# ──────────────────────────────────────────────────────────────────────────────
# Engine
# ──────────────────────────────────────────────────────────────────────────────


class SubconsciousEngine:
    """Background loop that evaluates due tasks against the world diff.

    The engine is *passive* by default: it never contacts anyone and
    never takes external actions.  Tasks that want to escalate to the
    deep reasoning core must go through the configured bridge callback
    (which the runtime wires to `ADONAI.run_background()`).
    """

    def __init__(
        self,
        config: SubconsciousConfig,
        *,
        llm: Any = None,
        memory_tree: Any = None,
        goals: Any = None,
        bridge: Callable[[str, dict[str, Any]], Any] | None = None,
    ) -> None:
        self.config = config
        self.llm = llm
        self.memory_tree = memory_tree
        self.goals = goals
        self.bridge = bridge
        self.store = SubconsciousStore()
        self._task: asyncio.Task | None = None
        self._running = False
        self._failure_count = 0

    async def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._loop())
        log.info("SubconsciousEngine started (tick every %.0fs)",
                 self.config.tick_interval_s)

    async def stop(self) -> None:
        self._running = False
        if self._task is not None:
            try:
                self._task.cancel()
                await asyncio.wait_for(self._task, timeout=1.0)
            except (asyncio.CancelledError, asyncio.TimeoutError, Exception):
                pass
            self._task = None
        self.store.close()

    # ── Tick loop ─────────────────────────────────────────────────────────

    async def _loop(self) -> None:
        while self._running:
            try:
                await self._tick()
                self._failure_count = 0
            except asyncio.CancelledError:
                raise
            except Exception as e:
                self._failure_count += 1
                log.warning("Subconscious tick failed (#%d): %s",
                            self._failure_count, e)
            await asyncio.sleep(self.config.tick_interval_s)

    async def _tick(self) -> None:
        """Run one heartbeat tick."""
        now_ms = int(time.time() * 1000)
        situation, tainted = self._build_situation_report(now_ms)
        tasks = self.store.list_tasks(only_enabled=True)
        if not tasks:
            return

        for task in tasks:
            decision, result = await self._evaluate(task, situation)
            entry = ActivityEntry(
                timestamp_ms=now_ms, task_id=task.id, task_title=task.title,
                decision=decision,
                state={"skip": "skipped", "act": "acted", "escalate": "escalated"}[decision],
                result=result, tainted=tainted,
            )
            self.store.log_activity(entry)
            self.store.update_task_result(task.id, decision, result)

            # Execute the decision.
            if decision == "act":
                await self._act(task, situation, tainted)
            elif decision == "escalate":
                await self._escalate(task, situation, tainted)

        # Morning briefing check.
        await self._maybe_morning_briefing(now_ms, situation)

    # ── Situation report ──────────────────────────────────────────────────

    def _build_situation_report(self, now_ms: int) -> tuple[str, bool]:
        """Build a compact text report of what changed since the last tick.

        Returns (report, tainted).  ``tainted`` is True if any diff
        source returned external changes (i.e. the subconscious reacted
        to something other than its own writes).
        """
        last_ms = int(self.store.get_state("last_tick_ms", "0") or "0")
        self.store.set_state("last_tick_ms", str(now_ms))

        parts: list[str] = []
        tainted = False

        if "memory_tree" in self.config.diff_sources and self.memory_tree is not None:
            try:
                sources = self.memory_tree.list_sources()
                new_sources = [
                    s for s in sources
                    if s.get("last_activity_ms", 0) > last_ms
                ]
                if new_sources:
                    tainted = True
                    parts.append(
                        f"Memory Tree: {len(new_sources)} source(s) updated since last tick."
                    )
            except Exception as e:
                log.debug("memory_tree diff failed: %s", e)

        if "git" in self.config.diff_sources:
            try:
                import subprocess
                out = subprocess.run(
                    ["git", "log", "--oneline", "--since=5 minutes ago"],
                    capture_output=True, text=True, timeout=5,
                )
                if out.stdout.strip():
                    tainted = True
                    parts.append("Git: new commits:\n" + out.stdout.strip())
            except Exception:
                pass

        if "calendar" in self.config.diff_sources:
            # Stub: real implementation reads the calendar provider.
            pass

        report = "\n\n".join(parts) if parts else "(no changes since last tick)"
        return report, tainted

    # ── Evaluation ────────────────────────────────────────────────────────

    async def _evaluate(self, task: SubconsciousTask, situation: str) -> tuple[Decision, str]:
        """Ask the LLM what to do about ``task`` given the ``situation``."""
        if self.llm is None:
            # No LLM — always skip (no cost, no risk).
            return "skip", "no LLM configured"

        prompt = (
            f"You are the subconscious of an AI assistant.  Evaluate whether the "
            f"following task should run right now.\n\n"
            f"Task: {task.title}\n"
            f"Intent: {task.intent}\n\n"
            f"Current situation (world diff since last tick):\n{situation}\n\n"
            f"Reply with one word on the first line — skip, act, or escalate — "
            f"followed by a one-sentence reason on the second line."
        )
        try:
            messages = [
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt},
            ]
            resp = await self.llm.complete(
                messages,
                max_tokens=80,
                temperature=0.1,
            )
            text = (resp.text if hasattr(resp, "text") else str(resp)).strip()
            first = text.split("\n", 1)[0].strip().lower()
            reason = text.split("\n", 1)[1].strip() if "\n" in text else ""
            if first.startswith("act"):
                return "act", reason or "act"
            if first.startswith("esc"):
                return "escalate", reason or "escalate"
            return "skip", reason or "nothing new"
        except Exception as e:
            log.warning("Subconscious evaluate failed for %s: %s", task.id, e)
            return "skip", f"eval error: {e}"

    # ── Execution ─────────────────────────────────────────────────────────

    async def _act(self, task: SubconsciousTask, situation: str, tainted: bool) -> None:
        """Execute a task locally (read-only or write)."""
        if self.llm is None:
            return
        # Tainted tasks may only do read-only work.
        if tainted and task.intent == "write":
            log.info("Subconscious refusing tainted write task %s", task.id)
            return
        try:
            prompt = (
                f"Execute this task with the situation below.  Be brief.\n\n"
                f"Task: {task.title}\n"
                f"Situation:\n{situation}\n\n"
                f"Result:"
            )
            messages = [
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt},
            ]
            resp = await self.llm.complete(
                messages,
                max_tokens=200,
                temperature=0.3,
            )
            text = resp.text if hasattr(resp, "text") else str(resp)
            log.info("Subconscious acted on %s: %s", task.id, text[:120])
        except Exception as e:
            log.warning("Subconscious act failed for %s: %s", task.id, e)

    async def _escalate(self, task: SubconsciousTask, situation: str, tainted: bool) -> None:
        """Hand the task to the deep reasoning core via the bridge."""
        if self.bridge is None:
            log.info("Subconscious has no bridge — cannot escalate %s", task.id)
            return
        goal = f"[subconscious:{task.id}] {task.title}\n\nContext:\n{situation}"
        try:
            result = self.bridge(goal, {"tainted": tainted, "source": "subconscious"})
            if asyncio.iscoroutine(result):
                result = await result
            log.info("Subconscious escalated %s → %s", task.id, result)
        except Exception as e:
            log.warning("Subconscious escalate failed for %s: %s", task.id, e)

    # ── Morning briefing ──────────────────────────────────────────────────

    async def _maybe_morning_briefing(self, now_ms: int, situation: str) -> None:
        hour = self.config.morning_briefing_hour
        if hour is None:
            return
        local = datetime.now().astimezone()
        if local.hour != hour:
            return
        # Only generate once per day.
        today_key = f"briefing_{local.strftime('%Y-%m-%d')}"
        if self.store.get_state(today_key) == "done":
            return
        self.store.set_state(today_key, "done")
        await self._generate_briefing()

    async def _generate_briefing(self) -> str:
        """Generate the morning briefing: Highlights / Action items / Mentions / FYI."""
        if self.llm is None or self.memory_tree is None:
            return "(briefing skipped: no LLM or memory tree)"
        try:
            sources = self.memory_tree.list_sources()[:10]
            entities = self.memory_tree.top_entities(10)
            prompt = (
                "You are the subconscious of an AI assistant.  Generate a morning "
                "briefing for the user.  Use four sections:\n"
                "## Highlights\n## Action items\n## Mentions\n## FYI\n\n"
                "If nothing pressing happened, collapse the whole briefing to a single "
                "line: 'Nothing pressing.'\n\n"
                f"Recent sources:\n{json.dumps(sources, indent=2)}\n\n"
                f"Top entities:\n{', '.join(e for e, _ in entities)}\n"
            )
            messages = [
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt},
            ]
            resp = await self.llm.complete(
                messages,
                max_tokens=400,
                temperature=0.4,
            )
            text = resp.text if hasattr(resp, "text") else str(resp)
            self.store.set_state("last_briefing", text)
            log.info("Morning briefing generated (%d chars)", len(text))
            return text
        except Exception as e:
            log.warning("Morning briefing failed: %s", e)
            return f"(briefing error: {e})"

    # ── Manual trigger ────────────────────────────────────────────────────

    async def run_now(self) -> dict[str, Any]:
        """Manually trigger a tick.  Returns a summary."""
        await self._tick()
        return {
            "activity": self.store.recent_activity(10),
            "failure_count": self._failure_count,
        }

    def get_briefing(self) -> str:
        return self.store.get_state("last_briefing", "")
