"""v6 — Split brain.

A fast reflex agent triages inbound traffic while a deep reasoning
core delegates to worker fleets, steered by the subconscious.

Design (ported from OpenHuman's split-brain always-on layer):

  * Inbound traffic hits a **fast reflex agent** that triages in
    seconds.  It either:
        - replies immediately (simple Q&A, acknowledgements), or
        - hands the deep core a concise brief (a *what*, never a *how*).

  * A **deep reasoning core** does the multi-step work, delegating to
    parallel sub-agent workers, with a hard superstep cap guaranteeing
    termination.

  * Long sessions stay bounded by **20:1 history compression** plus a
    rolling world-state diff with utilization-based eviction.

  * The subconscious reviews compressed history + world diff and
    injects a short, dense **steering directive** (capped at ~900
    characters, expiring after ~20 reasoning cycles) into the
    reasoning core's system prompt.

This module provides the SplitBrain class — the runtime wires it into
`ADONAI.chat()` so that every inbound message goes through reflex
triage first.
"""
from __future__ import annotations

import asyncio
import hashlib
import logging
import time
from dataclasses import dataclass, field
from typing import Any, Literal

from adonai.config.settings import SplitBrainConfig

log = logging.getLogger(__name__)

TriageVerdict = Literal["reply_now", "hand_to_deep", "drop"]


@dataclass
class TriageResult:
    """The reflex agent's verdict on an inbound message."""
    verdict: TriageVerdict
    reply: str = ""           # when verdict == "reply_now"
    brief: str = ""           # when verdict == "hand_to_deep" — a *what*, never a *how*
    confidence: float = 0.0
    latency_ms: float = 0.0


@dataclass
class SteeringDirective:
    """A short, dense directive injected into the deep core's system prompt."""
    text: str
    created_at: int
    expires_after_cycles: int = 20
    cycles_remaining: int = 20

    def expired(self) -> bool:
        return self.cycles_remaining <= 0

    def tick(self) -> None:
        self.cycles_remaining -= 1


class HistoryCompressor:
    """20:1 history compression with rolling world-state diff.

    Keeps a rolling window of recent turns verbatim, then compresses
    older turns into a single summary.  Eviction is utilization-based:
    turns that were never referenced by the model get evicted first.
    """

    def __init__(self, ratio: int = 20) -> None:
        self.ratio = ratio
        self._verbatim: list[dict[str, Any]] = []
        self._compressed_summary: str = ""
        self._utilization: dict[int, int] = {}  # index → reference count

    def add(self, turn: dict[str, Any]) -> None:
        idx = len(self._verbatim)
        self._verbatim.append(turn)
        self._utilization[idx] = 0
        # When verbatim exceeds ratio × compressed_size, compress the oldest half.
        if len(self._verbatim) > self.ratio * max(1, len(self._compressed_summary) // 100):
            self._compress_oldest()

    def _compress_oldest(self) -> None:
        if len(self._verbatim) < 4:
            return
        # Sort by utilization ascending — evict least-referenced first.
        n_to_compress = len(self._verbatim) // 2
        idxs = sorted(range(len(self._verbatim)),
                      key=lambda i: self._utilization.get(i, 0))
        to_compress = sorted(idxs[:n_to_compress])
        kept = [i for i in range(len(self._verbatim)) if i not in to_compress]
        # Build a compressed summary of the evicted turns.
        evicted = [self._verbatim[i] for i in to_compress]
        summary_parts = [
            f"[{t.get('role', '?')}] {str(t.get('content', ''))[:80]}"
            for t in evicted
        ]
        self._compressed_summary = (self._compressed_summary + "\n" + "\n".join(summary_parts)).strip()
        # Re-index verbatim + utilization.
        new_verbatim = [self._verbatim[i] for i in kept]
        new_util = {i: self._utilization.get(kept[i], 0) for i in range(len(kept))}
        self._verbatim = new_verbatim
        self._utilization = new_util

    def get_context(self, max_tokens: int = 4096) -> str:
        parts: list[str] = []
        if self._compressed_summary:
            parts.append(f"[Compressed history]\n{self._compressed_summary}")
        for i, t in enumerate(self._verbatim):
            self._utilization[i] = self._utilization.get(i, 0) + 1
            parts.append(f"[{t.get('role', '?')}] {t.get('content', '')}")
        text = "\n\n".join(parts)
        # Truncate to max_tokens (4 chars/token).
        return text[: max_tokens * 4]


class SplitBrain:
    """Reflex triage + deep reasoning core + steering directives."""

    def __init__(
        self,
        config: SplitBrainConfig,
        *,
        reflex_llm: Any = None,
        deep_llm: Any = None,
        deep_runtime: Any = None,
    ) -> None:
        self.config = config
        self.reflex_llm = reflex_llm
        self.deep_llm = deep_llm
        self.deep_runtime = deep_runtime
        self.history = HistoryCompressor(config.history_compression_ratio)
        self._directive: SteeringDirective | None = None
        self._superstep_count = 0

    def set_directive(self, text: str) -> None:
        """Inject a steering directive (from the subconscious)."""
        self._directive = SteeringDirective(
            text=text[:900],  # capped at ~900 chars
            created_at=int(time.time() * 1000),
            expires_after_cycles=20,
            cycles_remaining=20,
        )
        log.info("Steering directive set: %s...", text[:80])

    # ── Reflex triage ─────────────────────────────────────────────────────

    async def triage(self, message: str) -> TriageResult:
        """Fast triage: reply_now | hand_to_deep | drop."""
        start = time.time()
        if self.reflex_llm is None:
            # No reflex LLM — everything goes to deep.
            return TriageResult(
                verdict="hand_to_deep", brief=message,
                confidence=0.0, latency_ms=0.0,
            )
        prompt = (
            "You are the reflex triage layer of an AI assistant.  Classify the "
            "inbound message into one of three categories:\n"
            "  reply_now      — simple Q&A, acknowledgements, greetings. Reply directly.\n"
            "  hand_to_deep   — needs multi-step reasoning, tool use, or research.\n"
            "  drop           — spam, empty, or noise.\n\n"
            "Reply with the category on the first line, then either the reply "
            "(if reply_now) or a one-sentence brief (if hand_to_deep) on the "
            "second line.\n\n"
            f"Message: {message}"
        )
        try:
            messages = [
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt},
            ]
            resp = await asyncio.wait_for(
                self.reflex_llm.complete(
                    messages,
                    max_tokens=200,
                    temperature=0.1,
                ),
                timeout=self.config.reflex_target_s * 2,
            )
            text = resp.text if hasattr(resp, "text") else str(resp)
            lines = text.strip().split("\n", 1)
            cat = lines[0].strip().lower()
            rest = lines[1].strip() if len(lines) > 1 else ""
            latency_ms = (time.time() - start) * 1000
            if cat.startswith("reply"):
                return TriageResult(verdict="reply_now", reply=rest, confidence=0.8, latency_ms=latency_ms)
            if cat.startswith("drop"):
                return TriageResult(verdict="drop", confidence=0.9, latency_ms=latency_ms)
            return TriageResult(verdict="hand_to_deep", brief=rest or message, confidence=0.7, latency_ms=latency_ms)
        except asyncio.TimeoutError:
            log.warning("Reflex triage timed out — handing to deep")
            return TriageResult(verdict="hand_to_deep", brief=message, confidence=0.0, latency_ms=(time.time() - start) * 1000)
        except Exception as e:
            log.warning("Reflex triage failed: %s — handing to deep", e)
            return TriageResult(verdict="hand_to_deep", brief=message, confidence=0.0, latency_ms=(time.time() - start) * 1000)

    # ── Deep reasoning ────────────────────────────────────────────────────

    async def deep_reason(self, brief: str, *, session_id: str | None = None) -> str:
        """Run the deep reasoning core on a brief."""
        # Tick the directive.
        if self._directive is not None:
            if self._directive.expired():
                self._directive = None
            else:
                self._directive.tick()

        # Build the system prompt with the directive + compressed history.
        sys_parts: list[str] = []
        if self._directive is not None:
            sys_parts.append(f"[Steering directive]\n{self._directive.text}")
        compressed = self.history.get_context(max_tokens=2048)
        if compressed:
            sys_parts.append(f"[History]\n{compressed}")
        system_prompt = "\n\n".join(sys_parts)

        # Delegate to the deep runtime (which has tools, agents, etc.).
        self._superstep_count += 1
        if self._superstep_count > self.config.max_supersteps:
            log.warning("Deep reasoning hit superstep cap (%d) — forcing return", self.config.max_supersteps)
            return "(deep reasoning capped by superstep limit)"

        if self.deep_runtime is not None:
            try:
                # Use the runtime's chat() — it has tools + agents.
                # Prepend the system prompt as context.
                full = f"{system_prompt}\n\n[Brief]\n{brief}" if system_prompt else brief
                result = await self.deep_runtime.chat(full, session_id=session_id)
                # Record the turn in history.
                self.history.add({"role": "user", "content": brief})
                self.history.add({"role": "assistant", "content": result})
                return result
            except Exception as e:
                log.exception("Deep reasoning failed: %s", e)
                return f"(deep reasoning error: {e})"

        # Fallback: direct LLM call.
        if self.deep_llm is not None:
            try:
                resp = await self.deep_llm.complete(
                    f"{system_prompt}\n\n{brief}" if system_prompt else brief,
                    max_tokens=1024, temperature=0.4,
                )
                out = resp.text if hasattr(resp, "text") else str(resp)
                self.history.add({"role": "user", "content": brief})
                self.history.add({"role": "assistant", "content": out})
                return out
            except Exception as e:
                return f"(deep LLM error: {e})"

        return "(no deep reasoning core available)"

    # ── Full turn ─────────────────────────────────────────────────────────

    async def handle(self, message: str, *, session_id: str | None = None) -> str:
        """Handle an inbound message end-to-end: triage → reply or deep."""
        triage = await self.triage(message)
        if triage.verdict == "drop":
            return "(dropped)"
        if triage.verdict == "reply_now":
            self.history.add({"role": "user", "content": message})
            self.history.add({"role": "assistant", "content": triage.reply})
            return triage.reply
        # hand_to_deep
        return await self.deep_reason(triage.brief or message, session_id=session_id)
