"""Ollama HTTP client — async, with retries + streaming + embeddings + tool calling."""
from __future__ import annotations

import json
import logging
import re
import time as _time
import urllib.parse
from typing import Any, AsyncIterator

import httpx

from adonai.config.settings import LLMConfig
from adonai.core.exceptions import LLMError
from adonai.core.interfaces import LLMClient, LLMResponse
from adonai.core.models import ToolCall

log = logging.getLogger(__name__)


class OllamaLLMClient(LLMClient):
    """Async client for Ollama's /api/chat + /api/embeddings endpoints.

    Supports native tool calling via the `tools` field on /api/chat
    (Ollama >= 0.3.0, required for qwen3 / llama3.1 / mistral tool models).
    """

    def __init__(self, config: LLMConfig) -> None:
        self.config = config
        api_key = config.api_key.get_secret_value() if config.api_key else ""
        self._headers = {"Authorization": f"Bearer {api_key}"} if api_key else {}
        self._http = httpx.AsyncClient(
            base_url=config.base_url.rstrip("/"),
            timeout=httpx.Timeout(config.request_timeout, connect=10.0),
            headers=self._headers,
        )
        # ── Proactive broken-template cache ─────────────────────────────
        # Some Ollama Modelfiles (notably Qwen3-family) ship a chat template
        # that uses Jinja2 `raise_exception(...)` — a Qwen-specific extension
        # Ollama's stock Jinja2 engine doesn't support. Every /api/chat call
        # to such a model dies with HTTP 400 "Unable to generate parser for
        # this template" *before* the model is invoked, flooding the logs.
        #
        # We probe the model once with /api/show; if the Modelfile's template
        # contains `raise_exception`, we mark it broken and skip /api/chat
        # entirely on every subsequent call, going straight to /api/generate.
        # This eliminates the repeated 400 errors and the noisy warnings.
        self._broken_template_models: set[str] = set()
        self._template_probe_done: set[str] = set()

    # ── Template-probe payload ────────────────────────────────────────
    # Pre-built once (not per-call) to avoid rebuilding on every probe.
    # This 8-message, 2-round tool conversation matches the shape that
    # triggers CallExpression failures in adonai-3.5 and similar
    # Modelfiles whose Jinja2 templates only exercise the broken code
    # path after multiple tool-calling rounds.
    _PROBE_PAYLOAD: dict = {
        "stream": False,
        "think": False,
        "tools": [{
            "type": "function",
            "function": {
                "name": "web_search",
                "description": "Search the web.",
                "parameters": {
                    "type": "object",
                    "properties": {"query": {"type": "string"}},
                    "required": ["query"],
                },
            },
        }],
        "messages": [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "Search for the latest AI news."},
            {
                "role": "assistant",
                "content": "",
                "tool_calls": [{
                    "id": "tc_1",
                    "type": "function",
                    "function": {
                        "name": "web_search",
                        "arguments": {"query": "latest AI news 2026"},
                    },
                }],
            },
            {
                "role": "tool",
                "tool_call_id": "tc_1",
                "content": "Result 1: Google IO 2026 announced new AI tools.",
            },
            {
                "role": "assistant",
                "content": "Let me fetch more details from that article.",
                "tool_calls": [{
                    "id": "tc_2",
                    "type": "function",
                    "function": {
                        "name": "web_search",
                        "arguments": {"query": "Google IO 2026 AI tools details"},
                    },
                }],
            },
            {
                "role": "tool",
                "tool_call_id": "tc_2",
                "content": "Result 2: Google released Gemini 3.0 with new capabilities.",
            },
            {
                "role": "assistant",
                "content": "Here is what I found so far. Let me get one more source.",
                "tool_calls": [{
                    "id": "tc_3",
                    "type": "function",
                    "function": {
                        "name": "web_search",
                        "arguments": {"query": "Gemini 3.0 capabilities benchmark"},
                    },
                }],
            },
            {
                "role": "tool",
                "tool_call_id": "tc_3",
                "content": "Result 3: Error 401 - access denied.",
            },
        ],
        "options": {"num_predict": 5},
    }

    async def _probe_template(self, model_name: str) -> None:
        """Probe the model's chat template for parser-breaking bugs.

        Two-phase detection:
          1. **Static scan** — checks the Modelfile text for known-bad
             Jinja2 markers (``raise_exception``, ``tojson_includes``).
          2. **Live multi-turn test** — sends an 8-message, 3-round
             tool-calling conversation to ``/api/chat`` (with ``tools``
             and ``think: false``, matching the exact payload shape the
             real agent uses).  This catches ANY template parser failure
             (e.g. unsupported ``CallExpression`` at a specific line/col)
             that the static scan misses.

        If either phase flags the model, all subsequent calls bypass
        ``/api/chat`` and go straight to ``/api/generate``.
        """
        self._template_probe_done.add(model_name)

        # ── Phase 1: static Modelfile scan ────────────────────────────
        try:
            resp = await self._http.post(
                "/api/show",
                json={"name": model_name},
            )
            if resp.status_code == 200:
                data = resp.json()
                modelfile = data.get("modelfile") or ""
                if isinstance(modelfile, str) and modelfile:
                    bad_markers = (
                        "raise_exception",
                        "raise_exception(",
                        "tojson_includes",
                    )
                    modelfile_lower = modelfile.lower()
                    for marker in bad_markers:
                        if marker.lower() in modelfile_lower:
                            self._broken_template_models.add(model_name)
                            log.info(
                                "Ollama: detected broken chat template for %s "
                                "(marker %r in Modelfile) — using /api/generate",
                                model_name, marker,
                            )
                            return  # already flagged — skip live test
        except Exception as e:
            log.debug("Ollama /api/show probe failed for %s: %s", model_name, e)

        # ── Phase 2: live multi-turn test ─────────────────────────────
        # Send a realistic 8-message, 3-round tool conversation that
        # exercises the full Jinja2 template tree — including multiple
        # assistant→tool→assistant cycles.  Templates that parse fine
        # for a bare {"role":"user"} ping or a single tool round often
        # crash only when the conversation grows (CallExpression
        # failures at specific template line/col positions).
        try:
            payload = dict(self._PROBE_PAYLOAD, model=model_name)
            test_resp = await self._http.post("/api/chat", json=payload)
            if test_resp.status_code == 400:
                body = (test_resp.text or "").lower()
                # Match ALL known template-parser error patterns.
                if (
                    "unable to generate parser" in body
                    or "automatic parser generation failed" in body
                    or ("call" in body and "failed" in body)
                    or "parser" in body and "error" in body
                ):
                    self._broken_template_models.add(model_name)
                    log.info(
                        "Ollama: live template probe FAILED for %s "
                        "(HTTP 400 on 8-msg tool conversation) — "
                        "using /api/generate directly",
                        model_name,
                    )
                    return
            # Any other status → template not provably broken; the
            # reactive fallback in _complete_impl will handle edge
            # cases if they appear at runtime.
        except Exception as e:
            log.debug(
                "Ollama live template probe errored for %s: %s",
                model_name, e,
            )

    async def complete(
        self,
        messages: list[dict[str, str]],
        tools: list[dict] | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> "LLMResponse":  # forward ref
        """Complete a chat. Wraps _complete_impl in llm_retry for resilience.

        The retry policy handles transient failures (network blips, rate
        limits, Ollama restarts). Permanent errors (auth, bad request) are
        re-raised immediately.
        """
        from adonai.llm.retry import standard_llm_retry
        return await standard_llm_retry(self._complete_impl)(
            messages, tools=tools, temperature=temperature, max_tokens=max_tokens,
            stop=stop, **kwargs,
        )

    async def _complete_impl(
        self,
        messages: list[dict[str, str]],
        tools: list[dict] | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        start = _time.time()
        # Convert OpenAI-style multimodal messages to Ollama's native format.
        # Ollama's /api/chat endpoint defines `content` as a string in its Go
        # struct, so an array value triggers:
        #   "json: cannot unmarshal array into Go struct field
        #    ChatRequest.messages.content of type string"
        # We pull image parts out into a top-level `images: [b64, ...]` field
        # on the message (Ollama's native multimodal shape) and concatenate
        # all text parts into a single `content` string.
        messages = [_to_ollama_message(m) for m in messages]

        # ── Proactive broken-template check ─────────────────────────────
        # Probe the model ONCE via /api/show. If the Modelfile's chat
        # template contains `raise_exception` (Qwen3-family marker), skip
        # /api/chat entirely and go straight to /api/generate. This avoids
        # the repeated HTTP 400 "Unable to generate parser for this template"
        # errors that flood the log on every turn for affected models.
        model_name = self.config.model_name
        if model_name not in self._template_probe_done:
            await self._probe_template(model_name)
        if model_name in self._broken_template_models:
            log.debug(
                "Ollama: model %s has a broken chat template — "
                "using /api/generate directly (skipping /api/chat)",
                model_name,
            )
            return await self._generate_fallback(
                messages, tools=tools, temperature=temperature,
                max_tokens=max_tokens, stop=stop,
                original_payload=None, start=start,
            )
        # IMPORTANT: we explicitly override `presence_penalty`, `frequency_penalty`,
        # and `top_k` here because Ollama Modelfiles often ship with aggressive
        # defaults (qwen3.5:4b ships with presence_penalty=1.5, which makes the
        # model jump wildly between unrelated topics and causes hallucinations
        # like responding to "search for AI news" with Facebook CSS variables).
        # Without this override, the Modelfile's baked-in values win and the
        # agent becomes unusable for tool calling.
        payload: dict = {
            "model": self.config.model_name,
            "messages": messages,
            "stream": False,
            "options": {
                "temperature": temperature,
                "top_p": self.config.top_p,
                "top_k": getattr(self.config, "top_k", 20),
                # Zero out penalties — tool-calling needs deterministic,
                # focused output.  High presence_penalty (which qwen3.5:4b's
                # Modelfile ships with at 1.5) causes the model to avoid
                # repeating ANY token (including common words in the user's
                # question), pushing it toward off-topic rambling.
                "presence_penalty": getattr(self.config, "presence_penalty", 0.0),
                "frequency_penalty": getattr(self.config, "frequency_penalty", 0.0),
                "num_predict": max_tokens,
                "num_ctx": self.config.context_window,
            },
        }
        # CRITICAL: disable thinking mode for tool-calling turns.
        #
        # qwen3.5:4b (and other qwen3 variants) ship with "thinking" mode
        # enabled by default.  When the model receives tool results, it
        # enters a long `<think>...</think>` block that consumes the
        # ENTIRE max_tokens budget (e.g. 512 tokens), leaving
        # `message.content` empty.  The agent then sees "no tool calls +
        # empty text" and has to retry.
        #
        # Setting `think: false` at the top level of the payload tells
        # Ollama to skip the thinking phase.  The model puts all its
        # tokens into the actual response instead, which is what we want
        # for tool-calling (the external tool loop IS the reasoning).
        #
        # Allow override via config for users who explicitly want thinking.
        if not getattr(self.config, "enable_thinking", False):
            payload["think"] = False
        if stop:
            payload["options"]["stop"] = stop
        # Native tool calling — Ollama accepts OpenAI-style tool schemas.
        # Strip the outer {"type": "function", "function": {...}} wrapper
        # because Ollama expects the bare function dict.
        if tools:
            payload["tools"] = [_unwrap_tool_schema(t) for t in tools]

        try:
            resp = await self._http.post("/api/chat", json=payload)
            resp.raise_for_status()
        except httpx.HTTPStatusError as e:
            if 400 <= e.response.status_code < 500:
                body = e.response.text[:600] if e.response.text else ""
                low = body.lower()
                # ── Chat-template parser failure fallback ──────────────────
                # Some Qwen3-family Modelfiles ship a chat template that
                # uses `raise_exception(...)` (a Qwen-specific Jinja
                # extension).  Ollama's stock Jinja2 engine doesn't
                # support it and rejects the whole request with HTTP 400
                # "Unable to generate parser for this template" before
                # the model ever sees the messages.  Retrying won't help
                # — but /api/generate (raw prompt, no chat template) does
                # work.  Fall back to it so the agent keeps working
                # instead of returning a hard 400 to the user.
                if (
                    "unable to generate parser" in low
                    or "raise_exception" in low
                    or "automatic parser generation failed" in low
                    or "no user query found in messages" in low
                ):
                    # Cache this model as broken-template so subsequent calls
                    # skip /api/chat entirely (avoids repeated 400s).
                    self._broken_template_models.add(self.config.model_name)
                    self._template_probe_done.add(self.config.model_name)
                    log.info(
                        "Ollama /api/chat template error for %s — "
                        "falling back to /api/generate (cached for future calls)",
                        self.config.model_name,
                    )
                    return await self._generate_fallback(
                        messages, tools=tools, temperature=temperature,
                        max_tokens=max_tokens, stop=stop,
                        original_payload=payload, start=start,
                    )
                # Include "bad request" in the message so the retry
                # decorator's _is_permanent() classifier catches it
                # immediately and skips the wasted 2nd/3rd attempts.
                raise LLMError(
                    f"Ollama HTTP {e.response.status_code} (bad request, "
                    f"not retryable): {body[:300]}"
                ) from e
            # 5xx errors are transient — re-raise as-is so the outer
            # @standard_llm_retry decorator can handle backoff + retry.
            raise

        data = resp.json()
        msg = data.get("message", {}) or {}
        text = msg.get("content", "") or ""
        # Ollama >= 0.5 puts qwen3 thinking content in a separate
        # `message.thinking` field.  Some models also leak thinking tags
        # inline in `content` when `think: false` is set but
        # the model wasn't trained to honour it.  Strip both so
        # the agent never sees raw thinking content as the user-
        # facing answer.
        thinking = msg.get("thinking", "") or ""
        # Strip any inline thinking blocks from content.
        if "🧠" in text or "<thinking>" in text:
            text = _strip_think_tags(text)
        tool_calls = _parse_tool_calls(msg.get("tool_calls"))

        # ── Auto-recovery: "thinking but no content" ──────────────
        # qwen3.5:4b frequently burns its ENTIRE max_tokens budget
        # on the (discarded) thinking phase when `think: false` is
        # set but the Modelfile's chat template doesn't honour it.
        # The result: 200 OK, empty `content`, no `tool_calls`,
        # and a multi-hundred-megabyte `thinking` field that we
        # just throw away.  Without this recovery the
        # ToolCallingAgent sees an empty response, logs a warning,
        # and only recovers after a 240-second nudge retry —
        # unacceptable UX.
        #
        # Fix: detect the failure here and do ONE internal retry
        # with a stronger directive appended to the messages.
        # The retry tells the model explicitly to respond in
        # plain text without thinking.  This makes the FIRST
        # user-visible call succeed instead of requiring a nudge.
        if thinking and not text and not tool_calls:
            log.info(
                "Ollama returned %d chars of thinking but empty "
                "content — doing internal recovery retry with "
                "explicit 'respond now' directive",
                len(thinking),
            )
            try:
                recovery_payload = dict(payload)
                recovery_payload["messages"] = list(messages) + [{
                    "role": "user",
                    "content": (
                        "Respond now. Do NOT think, do NOT return "
                        "an empty message. Either call a tool from "
                        "the available tools, or write your answer "
                        "as plain text. Output visible content "
                        "immediately."
                    ),
                }]
                # Tighten the recovery retry: smaller max_tokens
                # so the model can't burn another 1024 on thinking.
                recovery_payload["options"] = dict(
                    recovery_payload.get("options") or {}
                )
                recovery_payload["options"]["num_predict"] = min(
                    max_tokens, 768,
                )
                rec_resp = await self._http.post(
                    "/api/chat", json=recovery_payload,
                )
                rec_resp.raise_for_status()
                rec_data = rec_resp.json()
                rec_msg = rec_data.get("message", {}) or {}
                rec_text = rec_msg.get("content", "") or ""
                rec_thinking = rec_msg.get("thinking", "") or ""
                if "🧠" in rec_text or "<thinking>" in rec_text:
                    rec_text = _strip_think_tags(rec_text)
                rec_tool_calls = _parse_tool_calls(
                    rec_msg.get("tool_calls"),
                )
                if rec_text or rec_tool_calls:
                    # Recovery succeeded — use its response.
                    log.info(
                        "Ollama recovery retry succeeded (got %d "
                        "chars text, %d tool calls)",
                        len(rec_text),
                        len(rec_tool_calls or []),
                    )
                    msg = rec_msg
                    text = rec_text
                    thinking = rec_thinking
                    tool_calls = rec_tool_calls
                    data = rec_data
                else:
                    log.warning(
                        "Ollama recovery retry also returned empty "
                        "(%d chars thinking) — returning empty to "
                        "caller; agent's nudge loop will handle it",
                        len(rec_thinking),
                    )
            except Exception as rec_e:
                log.warning(
                    "Ollama recovery retry failed: %s — returning "
                    "original empty response",
                    rec_e,
                )
        elif thinking and not text:
            log.info(
                "Ollama returned %d chars of thinking but empty "
                "content (tool_calls=%d) — not retrying because "
                "tool calls are present",
                len(thinking), len(tool_calls or []),
            )
        return LLMResponse(
            text=text,
            tool_calls=tool_calls or None,
            finish_reason="tool_calls" if tool_calls else "stop",
            tokens_in=int(data.get("prompt_eval_count", 0) or 0),
            tokens_out=int(data.get("eval_count", 0) or 0),
            model=self.config.model_name,
            duration_s=_time.time() - start,
            raw=data,
            # Pass the raw assistant message dict through so the
            # ToolCallingAgent can append it verbatim to the next
            # request — avoids format mismatch (Ollama wants
            # `arguments` as an object, OpenAI wants a string).
            message=msg,
        )

    async def _generate_fallback(
        self,
        messages: list[dict[str, Any]],
        *,
        tools: list[dict] | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        stop: list[str] | None = None,
        original_payload: dict | None = None,
        start: float = 0.0,
    ) -> "LLMResponse":
        """Fallback to Ollama's /api/generate endpoint when /api/chat's
        Jinja2 chat-template parser rejects the request.

        This handles the well-known Qwen3 `raise_exception('No user
        query found in messages.')` failure mode — the Qwen3 chat
        template uses a Jinja `raise_exception(...)` macro that stock
        Ollama doesn't support, so the whole /api/chat call dies with
        HTTP 400 *before* the model is even invoked.  Falling back to
        /api/generate bypasses the chat template entirely — we flatten
        the conversation into a single text prompt and let the model
        answer natively.

        Tool-calling is also handled here by reformatting a serialised
        tool-call from the raw text output (best-effort JSON extraction).
        Native Ollama tool-calling isn't supported on /api/generate, so
        we ask the model to emit JSON in a known shape and parse it.
        """
        # Flatten the conversation into a single prompt.  System prompt
        # first, then alternating user/assistant turns, then a final
        # "assistant:" cue so the model continues.
        flat_parts: list[str] = []
        sys_prompts: list[str] = []
        for m in messages:
            role = m.get("role", "user")
            content = m.get("content", "")
            if not isinstance(content, str):
                # Multimodal content (list of parts) — join text parts.
                if isinstance(content, list):
                    content = "\n".join(
                        p.get("text", "") for p in content
                        if isinstance(p, dict) and p.get("type") == "text"
                    )
                else:
                    content = str(content)
            content = (content or "").strip()
            if not content:
                continue
            if role == "system":
                sys_prompts.append(content)
            elif role == "user":
                flat_parts.append(f"User: {content}")
            elif role == "assistant":
                flat_parts.append(f"Assistant: {content}")
            elif role == "tool":
                flat_parts.append(f"Tool result: {content}")
        if sys_prompts:
            sys_block = "\n\n".join(sys_prompts)
            flat_parts.insert(0, f"System: {sys_block}")
        if tools:
            tool_list = "\n".join(
                f"- {t.get('function', t).get('name', '?')}: "
                f"{t.get('function', t).get('description', '')[:160]}"
                for t in tools
            )
            flat_parts.append(
                "Available tools (call by emitting a single JSON object on "
                "its own line, e.g. "
                '{"tool":"web_search","parameters":{"query":"..."}}):\n'
                f"{tool_list}"
            )
        prompt = "\n\n".join(flat_parts) + "\n\nAssistant:"

        gen_payload: dict = {
            "model": self.config.model_name,
            "prompt": prompt,
            "stream": False,
            "options": {
                "temperature": temperature,
                "top_p": self.config.top_p,
                "top_k": getattr(self.config, "top_k", 20),
                "presence_penalty": getattr(self.config, "presence_penalty", 0.0),
                "frequency_penalty": getattr(self.config, "frequency_penalty", 0.0),
                "num_predict": max_tokens,
                "num_ctx": self.config.context_window,
            },
        }
        if not getattr(self.config, "enable_thinking", False):
            gen_payload["think"] = False
        if stop:
            gen_payload["options"]["stop"] = stop

        try:
            resp = await self._http.post("/api/generate", json=gen_payload)
            resp.raise_for_status()
        except httpx.HTTPStatusError as e:
            body = e.response.text[:300] if e.response.text else ""
            raise LLMError(
                f"Ollama /api/generate fallback also failed HTTP "
                f"{e.response.status_code} (bad request, not retryable): {body}"
            ) from e
        except Exception as e:
            raise LLMError(f"Ollama /api/generate fallback failed: {e}") from e

        data = resp.json()
        text = data.get("response", "") or ""
        thinking = data.get("thinking", "") or ""
        if "🧠" in text or "<thinking>" in text:
            text = _strip_think_tags(text)
        tool_calls: list[ToolCall] | None = None
        if tools and text:
            parsed = _parse_inline_tool_call(text)
            if parsed:
                tool_calls = parsed
                # Leave the text intact so the caller can see the model's
                # reasoning, but the agent loop will prefer the tool call.
        msg: dict[str, Any] = {"role": "assistant", "content": text}
        if tool_calls:
            msg["tool_calls"] = [
                {
                    "id": tc.id,
                    "type": "function",
                    "function": {
                        "name": tc.tool,
                        "arguments": tc.parameters,
                    },
                }
                for tc in tool_calls
            ]
        return LLMResponse(
            text=text,
            tool_calls=tool_calls,
            finish_reason="tool_calls" if tool_calls else "stop",
            tokens_in=int(data.get("prompt_eval_count", 0) or 0),
            tokens_out=int(data.get("eval_count", 0) or 0),
            model=self.config.model_name,
            duration_s=_time.time() - start,
            raw=data,
            message=msg,
        )

    async def stream(
        self,
        messages: list[dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ) -> AsyncIterator[str]:
        # Same multimodal → Ollama-native conversion as _complete_impl.
        messages = [_to_ollama_message(m) for m in messages]
        payload = {
            "model": self.config.model_name,
            "messages": messages,
            "stream": True,
            "options": {
                "temperature": temperature,
                "top_p": self.config.top_p,
                "num_predict": max_tokens,
                "num_ctx": self.config.context_window,
            },
        }
        async with self._http.stream("POST", "/api/chat", json=payload) as resp:
            resp.raise_for_status()
            async for line in resp.aiter_lines():
                if not line.strip():
                    continue
                try:
                    chunk = json.loads(line)
                except json.JSONDecodeError:
                    continue
                piece = chunk.get("message", {}).get("content", "")
                if piece:
                    yield piece
                if chunk.get("done"):
                    return

    async def check_vision_capable(self) -> bool | None:
        """Authoritatively check whether the configured model is vision-capable.

        Calls Ollama's ``POST /api/show`` endpoint with the model name and
        inspects the response for vision-projector artifacts.  This is the
        ground-truth check — far more reliable than the name-based
        :func:`is_vision_model` heuristic, which can't see custom
        Modelfiles published under user namespaces (e.g. ``frob/...``).

        Returns:
            * ``True``  — model has a vision projector attached, OR the
                          Modelfile explicitly references a vision template.
            * ``False`` — model loaded successfully but has no projector.
            * ``None``  — couldn't determine (network error, model not
                          pulled, Ollama server down).  Callers should
                          fall back to the heuristic in this case.

        Detection signals (any one of these → True):
            * ``projector_info`` non-empty in the response
            * ``model_info`` contains entries with keys like
              ``vision.*`` or ``*.vision``
            * Modelfile contains a ``PROJECTOR`` directive
        """
        payload = {"name": self.config.model_name}
        try:
            resp = await self._http.post("/api/show", json=payload)
            if resp.status_code == 404:
                # Model not pulled locally — can't tell.  Fall back to
                # the heuristic rather than falsely claiming True/False.
                log.info(
                    "Ollama /api/show returned 404 for %r — model not "
                    "pulled; falling back to heuristic",
                    self.config.model_name,
                )
                return None
            resp.raise_for_status()
            data = resp.json()
        except httpx.HTTPError as e:
            log.warning(
                "Ollama /api/show failed for %r: %s — falling back to "
                "heuristic vision detection",
                self.config.model_name, e,
            )
            return None
        except Exception as e:
            log.warning(
                "Ollama /api/show unexpected error for %r: %s — falling "
                "back to heuristic",
                self.config.model_name, e,
            )
            return None

        # Signal 1: explicit projector_info block (Ollama >= 0.5).
        projector_info = data.get("projector_info") or {}
        if projector_info:
            log.info(
                "Ollama /api/show: %s has projector_info (%s) — "
                "vision-capable",
                self.config.model_name,
                projector_info.get("type", "unknown"),
            )
            return True

        # Signal 2: model_info entries with vision-related keys.
        model_info = data.get("model_info") or {}
        if isinstance(model_info, dict):
            for key in model_info:
                kl = key.lower()
                if "vision" in kl or "projector" in kl or "visual" in kl:
                    log.info(
                        "Ollama /api/show: %s has vision-related "
                        "model_info key %r — vision-capable",
                        self.config.model_name, key,
                    )
                    return True

        # Signal 3: Modelfile contains a PROJECTOR directive or a
        # vision-oriented chat template.
        modelfile = data.get("modelfile") or ""
        if isinstance(modelfile, str):
            for line in modelfile.splitlines():
                stripped = line.strip()
                if stripped.upper().startswith("PROJECTOR"):
                    log.info(
                        "Ollama /api/show: %s Modelfile has PROJECTOR "
                        "directive — vision-capable",
                        self.config.model_name,
                    )
                    return True
            # Some vision models declare it in the template.
            if "image" in modelfile.lower() and "<image>" in modelfile:
                log.info(
                    "Ollama /api/show: %s Modelfile references <image> "
                    "token — vision-capable",
                    self.config.model_name,
                )
                return True

        log.info(
            "Ollama /api/show: %s has no vision artifacts — text-only",
            self.config.model_name,
        )
        return False

    async def embed(self, text: str | list[str]) -> list[list[float]]:
        """Embed text(s) via the Ollama /api/embeddings endpoint.

        v4 hardening:
          * Raises LLMError on failure instead of returning [0.0]*dim. The
            previous silent-zero-vector behavior corrupted memory search,
            knowledge graph, and semantic dedup — callers couldn't tell a
            real embedding from a failed one.
          * Validates the returned vector dimension; raises if the backend
            returns a degenerate (empty) embedding.

        v4.1 batched:
          * Multiple texts are embedded concurrently via ``asyncio.gather``
            instead of sequentially.  For a batch of 10 texts this cuts
            wall-clock from ~10 × RTT to ~1 × RTT (Ollama serialises
            internally but the HTTP round-trips overlap).
          * Per-text failures are collected; the method raises at the end
            if any text failed, but still returns the successful embeddings.
        """
        import asyncio as _aio
        texts = [text] if isinstance(text, str) else text
        if not texts:
            return []

        async def _embed_one(t: str) -> list[float]:
            payload = {"model": self.config.embedding_model, "prompt": t}
            resp = await self._http.post("/api/embeddings", json=payload)
            resp.raise_for_status()
            emb = resp.json().get("embedding", [])
            if not emb:
                raise LLMError(
                    f"Ollama returned empty embedding for model "
                    f"{self.config.embedding_model!r}"
                )
            if len(emb) < self.config.embedding_dim:
                emb = emb + [0.0] * (self.config.embedding_dim - len(emb))
            elif len(emb) > self.config.embedding_dim:
                emb = emb[: self.config.embedding_dim]
            return emb

        # Embed all texts concurrently.  return_exceptions=True so one
        # failure doesn't lose the successful embeddings.
        raw_results = await _aio.gather(
            *(_embed_one(t) for t in texts),
            return_exceptions=True,
        )
        results: list[list[float]] = []
        errors: list[str] = []
        for t, res in zip(texts, raw_results):
            if isinstance(res, Exception):
                errors.append(f"{type(res).__name__}: {res}")
                log.warning(
                    "Ollama embedding failed for text (preview=%r): %s",
                    t[:80], res,
                )
            else:
                results.append(res)
        if errors and len(results) < len(texts):
            raise LLMError(
                f"Ollama embedding batch failed "
                f"({len(results)}/{len(texts)} succeeded): "
                f"{errors[0]}"
            )
        return results

    async def close(self) -> None:
        await self._http.aclose()


# ──────────────────────────────────────────────────────────────────────────────
# Tool-schema helpers
# ──────────────────────────────────────────────────────────────────────────────

def _unwrap_tool_schema(schema: dict) -> dict:
    """Ollama expects the bare function dict, not the OpenAI wrapper.

    Input (OpenAI style):
        {"type": "function", "function": {"name": ..., "description": ..., "parameters": ...}}
    Output (Ollama style):
        {"type": "function", "function": {"name": ..., "description": ..., "parameters": ...}}

    Actually Ollama accepts the same shape — but be defensive: if someone
    passes a bare {"name": ..., "parameters": ...} dict, wrap it.
    """
    if "function" in schema:
        return schema
    if "name" in schema:
        return {
            "type": "function",
            "function": {
                "name": schema["name"],
                "description": schema.get("description", ""),
                "parameters": schema.get("parameters", {}),
            },
        }
    return schema


# Best-effort inline tool-call parser for the /api/generate fallback.
# Looks for the first JSON object matching {"tool": "...", "parameters": {...}}
# or {"name": "...", "arguments": {...}} anywhere in the raw text.
_INLINE_TOOL_CALL_RE = re.compile(
    r'\{\s*"(?:tool|name|function)"\s*:\s*"([^"]+)".*?"(?:parameters|arguments|args)"\s*:\s*(\{[^{}]*(?:\{[^{}]*\}[^{}]*)*\})\s*\}',
    re.DOTALL,
)


def _parse_inline_tool_call(text: str) -> list[ToolCall] | None:
    """Extract a tool call from raw model text (used by /api/generate fallback).

    Returns a list with one ToolCall, or None if no parseable tool call is
    found.  Multiple calls in a single response are not supported — only
    the first is parsed (sufficient for the fallback path).
    """
    if not text:
        return None
    # Quick reject so we don't run the regex on every response.
    if '"tool"' not in text and '"name"' not in text and '"function"' not in text:
        return None
    m = _INLINE_TOOL_CALL_RE.search(text)
    if not m:
        return None
    name = m.group(1)
    if not name:
        return None
    args_raw = m.group(2) or "{}"
    try:
        args = json.loads(args_raw)
    except json.JSONDecodeError:
        args = {"_raw": args_raw}
    if not isinstance(args, dict):
        args = {"_raw": args}
    return [ToolCall(tool=name, parameters=args)]


def _parse_tool_calls(raw: Any) -> list[ToolCall]:
    """Parse Ollama's tool_calls response field into ToolCall objects.

    Ollama returns:
        "tool_calls": [
            {"function": {"name": "web_search", "arguments": {"query": "..."}}}
        ]

    Preserves the LLM's tool-call ID when present so the `role=tool`
    response can reference it (OpenAI strict mode rejects mismatches).
    Generates a fallback ID if the LLM didn't provide one.
    """
    if not raw or not isinstance(raw, list):
        return []
    calls: list[ToolCall] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        # Ollama format doesn't usually include an `id`, but OpenAI does.
        call_id = item.get("id")
        func = item.get("function") or item
        name = func.get("name")
        if not name:
            continue
        args = func.get("arguments")
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except json.JSONDecodeError:
                args = {"_raw": args}
        if args is None:
            args = {}
        if not isinstance(args, dict):
            args = {"_raw": args}
        # Build the ToolCall, preserving the LLM-provided id if any.
        if call_id:
            calls.append(ToolCall(id=call_id, tool=name, parameters=args))
        else:
            calls.append(ToolCall(tool=name, parameters=args))
    return calls


# ──────────────────────────────────────────────────────────────────────────────
# Thinking-tag stripping
# ──────────────────────────────────────────────────────────────────────────────

_THINK_TAG_RE = re.compile(
    r"<(?:think|thinking|reasoning)>([\s\S]*?)</(?:think|thinking|reasoning)>",
    re.IGNORECASE,
)
# Some models emit an unclosed `<think>` tag that runs to end-of-string —
# treat that as "the whole rest is thinking" and discard it.
_UNCLOSED_THINK_RE = re.compile(
    r"<(?:think|thinking|reasoning)>[\s\S]*$",
    re.IGNORECASE,
)


def _strip_think_tags(text: str) -> str:
    """Remove `<think>...</think>` blocks from a model response.

    Qwen3-series models (and others with "thinking" capability) sometimes
    leak thinking content inline in `message.content` even when `think: false`
    is set — either because the Modelfile's chat template doesn't honour
    that flag, or because the model wasn't trained to.  When that happens
    the thinking content dominates the response and the actual answer is
    either missing or buried at the end.

    This helper:
      - Removes closed `<think>...</think>` blocks entirely.
      - If there's an unclosed `<think>` running to end-of-string, drops
        everything from that tag onward (the model ran out of tokens
        mid-think and never produced a real answer).
      - Collapses the whitespace left behind.
    """
    text = _THINK_TAG_RE.sub("", text)
    text = _UNCLOSED_THINK_RE.sub("", text)
    # Collapse runs of whitespace that the removal may have left.
    text = re.sub(r"\n\s*\n\s*\n+", "\n\n", text)
    return text.strip()


# ──────────────────────────────────────────────────────────────────────────────
# Multimodal message conversion (OpenAI-style → Ollama-native)
# ──────────────────────────────────────────────────────────────────────────────

# Known Ollama vision-capable model families.  Used by callers (e.g. the
# file analyst) to decide whether to even attempt a vision call.
VISION_MODEL_PATTERNS: tuple[str, ...] = (
    "llava", "llama3.2-vision", "llama3-vision", "minicpm-v",
    "moondream", "bakllava", "qwen2-vl", "qwen2.5-vl", "qwen-vl",
    "gemma3", "pixtral", "phi-3-vision", "phi3-vision", "InternVL",
    "granite-vision", "magpie", "aya-vision",
)


def is_vision_model(model_name: str) -> bool:
    """Heuristic: does *model_name* look like a vision-capable Ollama model?

    Matches case-insensitively against known vision model family prefixes.
    Callers should treat a `False` result as "definitely not vision" and
    skip the vision call entirely rather than burning a doomed HTTP round-trip.
    """
    if not model_name:
        return False
    name = model_name.lower()
    return any(pat.lower() in name for pat in VISION_MODEL_PATTERNS)


def _to_ollama_message(msg: dict[str, Any]) -> dict[str, Any]:
    """Convert one chat message to Ollama's native /api/chat shape.

    Accepts both:
      * Plain text:   {"role": "user", "content": "hello"}
      * OpenAI multimodal:
          {"role": "user", "content": [
              {"type": "text",  "text": "what is this?"},
              {"type": "image_url", "image_url": {"url": "data:image/jpeg;base64,..."}},
          ]}

    Produces Ollama-native:
      * Plain text:   {"role": "user", "content": "hello"}
      * Multimodal:   {"role": "user", "content": "what is this?",
                       "images": ["<base64-bytes>"]}

    Ollama's Go struct for `ChatRequest.messages[].content` is a `string`,
    not an array — sending the OpenAI form triggers HTTP 400 with
    "json: cannot unmarshal array into Go struct field
    ChatRequest.messages.content of type string".  This helper is the
    single fix-point for that bug.

    Image URLs can be:
      * `data:<mime>;base64,<b64>`  — decoded inline (most common case)
      * `http(s)://...`             — passed through verbatim (Ollama will
                                      fetch; we don't async-fetch here to
                                      keep this function sync + pure)

    Non-recognized content parts are skipped with a debug log so a future
    OpenAI extension doesn't break the request.
    """
    if not isinstance(msg, dict):
        # Be permissive — let Ollama's own validation reject malformed input.
        return msg  # type: ignore[return-value]

    content = msg.get("content")

    # Fast path: plain string content (the overwhelmingly common case).
    if isinstance(content, str) or content is None:
        return msg

    # If content is anything other than a list, leave it alone — Ollama
    # will reject it, but at least the error message will be informative.
    if not isinstance(content, list):
        return msg

    text_parts: list[str] = []
    image_blobs: list[str] = []

    for part in content:
        if not isinstance(part, dict):
            continue
        ptype = part.get("type")

        if ptype == "text":
            t = part.get("text", "")
            if isinstance(t, str) and t:
                text_parts.append(t)

        elif ptype == "image_url":
            url_obj = part.get("image_url") or {}
            url = url_obj.get("url") if isinstance(url_obj, dict) else None
            if not url:
                continue
            blob = _extract_image_blob(url)
            if blob:
                image_blobs.append(blob)

        elif ptype == "image":
            # Some clients use {"type": "image", "image": "<b64>"} directly.
            img = part.get("image") or part.get("data")
            if isinstance(img, str) and img:
                image_blobs.append(img)

        else:
            log.debug("Skipping unknown content part type %r in message", ptype)

    # Build the Ollama-native message.  Preserve any other fields the
    # caller set (role, tool_calls, name, etc.) — we only rewrite content
    # and add `images` when needed.
    out = {k: v for k, v in msg.items() if k != "content"}
    out["content"] = "\n".join(text_parts).strip()
    if image_blobs:
        out["images"] = image_blobs
    return out


def _extract_image_blob(url: str) -> str | None:
    """Extract a raw base64 image blob from an OpenAI-style image URL.

    Supports:
      * `data:<mime>;base64,<b64>`  → returns <b64>
      * `data:<mime>;base64,<b64>` with URL-encoded payload → decodes
      * plain base64 string (no scheme) → returned as-is
      * `http(s)://...` URLs          → returned verbatim (Ollama can fetch)
    """
    if not isinstance(url, str) or not url:
        return None

    # Data URI form: data:image/jpeg;base64,<payload>
    if url.startswith("data:"):
        # Split headers from payload.
        comma_idx = url.find(",")
        if comma_idx < 0:
            return None
        payload = url[comma_idx + 1:]
        # Some clients URL-encode the base64 payload; unquote if it looks
        # encoded.  base64 never contains '%' so this is safe.
        if "%" in payload:
            try:
                payload = urllib.parse.unquote(payload)
            except Exception:
                pass
        return payload or None

    # Plain base64 blob (no scheme).  Validate loosely: base64 alphabet only.
    # We don't decode here — Ollama wants the base64 string, not raw bytes.
    if re.fullmatch(r"[A-Za-z0-9+/=\s]+", url) and len(url) > 32:
        return url.replace("\n", "").replace(" ", "").strip()

    # http(s):// or other URL — pass through; Ollama will fetch it itself.
    if url.startswith("http://") or url.startswith("https://"):
        return url

    # Unknown form — return as-is and let Ollama decide.  Better to send
    # something than to silently drop the image.
    return url


# Re-export so callers can `from adonai.llm.ollama import is_vision_model`.
__all__ = [
    "OllamaLLMClient",
    "is_vision_model",
    "VISION_MODEL_PATTERNS",
]

