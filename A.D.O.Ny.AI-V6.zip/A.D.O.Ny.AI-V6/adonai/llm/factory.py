"""Factory: pick the right LLM client for the configured backend."""
from __future__ import annotations

import logging

from adonai.config.settings import LLMConfig
from adonai.core.interfaces import LLMClient

log = logging.getLogger(__name__)


def build_llm_client(config: LLMConfig, *, cache=None) -> LLMClient:
    """Build a concrete :class:`LLMClient` for *config.backend*.

    Wraps the underlying client in a cache layer when ``config.enable_cache``
    is true.  Falls back to a stub when the requested backend's SDK is not
    installed (so the rest of the framework still imports cleanly).
    """
    backend = (config.backend or "ollama").lower()
    client: LLMClient

    if backend == "ollama":
        from adonai.llm.ollama import OllamaLLMClient
        client = OllamaLLMClient(config)
    elif backend in ("vllm", "openai_compat", "openai", "llama_cpp"):
        from adonai.llm.openai_compat import OpenAICompatLLMClient
        client = OpenAICompatLLMClient(config)
    else:
        raise ValueError(f"unknown LLM backend: {backend!r}")

    if config.enable_cache and cache is not None:
        from adonai.llm.cache import CachedLLMClient
        return CachedLLMClient(client, cache)
    elif config.enable_cache:
        from adonai.llm.cache import CachedLLMClient, ResponseCache
        return CachedLLMClient(client, ResponseCache(max_entries=config.cache_max_entries))

    return client
