"""OpenAI-compatible LLM client (works with vLLM, llama.cpp, OpenAI, LM Studio)."""
from __future__ import annotations

import json
import logging
from typing import AsyncIterator

from adonai.config.settings import LLMConfig
from adonai.core.exceptions import LLMError
from adonai.core.interfaces import LLMClient, LLMResponse
from adonai.core.models import ToolCall

log = logging.getLogger(__name__)


class OpenAICompatLLMClient(LLMClient):
    """Async client for any OpenAI-compatible /v1/chat/completions endpoint."""

    def __init__(self, config: LLMConfig) -> None:
        self.config = config
        try:
            from openai import AsyncOpenAI
        except ImportError as e:
            raise ImportError(
                "the `openai` package is required for the openai_compat / vLLM / "
                "llama_cpp backends.  Install it via `pip install openai`."
            ) from e
        api_key = config.api_key.get_secret_value() if config.api_key else "sk-no-key-required"
        self._client = AsyncOpenAI(
            base_url=config.base_url.rstrip("/"),
            api_key=api_key,
            timeout=config.request_timeout,
            max_retries=config.max_retries,
        )

    async def complete(
        self,
        messages: list[dict[str, str]],
        tools: list[dict] | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        stop: list[str] | None = None,
        **kwargs: object,
    ) -> LLMResponse:
        """Complete a chat. Wraps _complete_impl in llm_retry for resilience."""
        from adonai.llm.retry import standard_llm_retry
        return await standard_llm_retry(self._complete_impl)(
            messages, tools=tools, temperature=temperature, max_tokens=max_tokens,
            stop=stop, **kwargs,
        )

    async def _complete_impl(
        self,
        messages: list[dict[str, str]],
        tools: list[dict] | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        stop: list[str] | None = None,
        **kwargs: object,
    ) -> LLMResponse:
        import time as _time
        start = _time.time()
        try:
            req_kwargs: dict = {
                "model": self.config.model_name,
                "messages": messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
            }
            if tools:
                req_kwargs["tools"] = tools
            if stop:
                req_kwargs["stop"] = stop
            resp = await self._client.chat.completions.create(**req_kwargs)
        except Exception as e:
            raise LLMError(f"OpenAI-compatible request failed: {type(e).__name__}: {e}") from e

        choice = resp.choices[0]
        text = choice.message.content or ""
        tool_calls = None
        if getattr(choice.message, "tool_calls", None):
            parsed = []
            for tc in choice.message.tool_calls:
                kwargs = {
                    "tool": tc.function.name,
                    "parameters": _safe_json(tc.function.arguments),
                }
                # Preserve the LLM-provided id when present so the
                # role=tool response can reference it (OpenAI strict
                # mode rejects mismatches).  If absent, let the
                # default_factory generate one.
                if getattr(tc, "id", None):
                    kwargs["id"] = tc.id
                parsed.append(ToolCall(**kwargs))
            tool_calls = parsed or None
        usage = resp.usage
        # Pass the raw assistant message dict through so the
        # ToolCallingAgent can append it verbatim to the next request —
        # avoids format mismatch between OpenAI (stringified arguments)
        # and Ollama (object arguments).
        raw_msg = choice.message.model_dump() if hasattr(choice.message, "model_dump") else {
            "role": "assistant", "content": text,
        }
        return LLMResponse(
            text=text,
            tool_calls=tool_calls,
            finish_reason=choice.finish_reason or "stop",
            tokens_in=int(usage.prompt_tokens) if usage else 0,
            tokens_out=int(usage.completion_tokens) if usage else 0,
            model=self.config.model_name,
            duration_s=_time.time() - start,
            raw=resp.model_dump() if hasattr(resp, "model_dump") else None,
            message=raw_msg,
        )

    async def stream(
        self,
        messages: list[dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ) -> AsyncIterator[str]:
        try:
            stream = await self._client.chat.completions.create(
                model=self.config.model_name,
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens,
                stream=True,
            )
            async for chunk in stream:
                if not chunk.choices:
                    continue
                delta = chunk.choices[0].delta
                if delta and delta.content:
                    yield delta.content
        except Exception as e:
            raise LLMError(f"OpenAI-compatible stream failed: {type(e).__name__}: {e}") from e

    async def embed(self, text: str | list[str]) -> list[list[float]]:
        """Embed text(s) via the OpenAI-compatible /v1/embeddings endpoint.

        v4 hardening: raises LLMError on failure instead of returning
        [0.0]*dim, which previously caused silent data corruption in memory
        search and semantic dedup.
        """
        texts = [text] if isinstance(text, str) else text
        if not texts:
            return []
        try:
            resp = await self._client.embeddings.create(
                model=self.config.embedding_model, input=texts,
            )
            embs = [list(d.embedding) for d in resp.data]
            if not embs or any(len(e) == 0 for e in embs):
                raise LLMError(f"OpenAI-compatible backend returned empty embedding(s) for model {self.config.embedding_model!r}")
            return embs
        except LLMError:
            raise
        except Exception as e:
            log.warning("OpenAI-compatible embedding failed: %s", e)
            raise LLMError(f"OpenAI-compatible embedding failed: {e}") from e

    async def close(self) -> None:
        await self._client.close()


def _safe_json(s: str | None) -> dict:
    if not s:
        return {}
    try:
        return json.loads(s)
    except json.JSONDecodeError:
        return {"_raw": s}
