"""LLM client base class — re-exports from core.interfaces for convenience."""
from __future__ import annotations

from adonai.core.interfaces import LLMClient, LLMResponse

__all__ = ["LLMClient", "LLMResponse"]
