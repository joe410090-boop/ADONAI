"""Upgrade 9 — Resource Intelligence Layer (Model Router).

Chooses the best LLM for a task dynamically based on:

* task complexity
* capability required (vision, embedding, reasoning)
* latency history (EMA per model)
* token cost awareness
* quality scoring (recent success rate)

Routing logic::

    Simple Tasks   → Small model
    Coding         → Medium model
    Research       → Large model

The router is a thin layer that owns a pool of
:class:`~adonai.core.interfaces.LLMClient` instances (one per tier) and
returns a :class:`~adonai.core.models.ModelRoute` describing the choice.
Callers can either use ``router.route(...)`` to get a route and then
``router.get_client(route)`` to get the LLM, or use the convenience
``router.complete(...)`` which does both in one call.

Latency and quality are tracked in-process (no external storage) using
an exponentially-weighted moving average.
"""
from __future__ import annotations

import asyncio
import logging
import time
from collections import defaultdict, deque
from typing import Any

from adonai.core.exceptions import ModelRouterError
from adonai.core.interfaces import LLMClient, LLMResponse, ModelRouter
from adonai.core.models import ModelRoute, ModelTier, Task, TaskComplexity

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# DefaultModelRouter
# ──────────────────────────────────────────────────────────────────────────────


class DefaultModelRouter(ModelRouter):
    """Default router that maps task complexity → model tier → LLM client.

    The router is constructed with a dict of pre-built
    :class:`LLMClient` instances, one per :class:`ModelTier`.  If a tier
    is missing, the router falls back to the next available tier.
    """

    def __init__(
        self,
        clients: dict[ModelTier, LLMClient],
        *,
        config: Any = None,
    ) -> None:
        if not clients:
            raise ModelRouterError("ModelRouter requires at least one client")
        self.clients = dict(clients)
        self.config = config
        # Latency EMA per model name.
        self._latency_ema: dict[str, float] = defaultdict(float)
        # Quality score per model name (rolling mean of success/failure).
        self._quality_history: dict[str, deque[float]] = defaultdict(
            lambda: deque(maxlen=self._quality_window())
        )
        # Token cost accumulator per model name.
        self._token_cost: dict[str, int] = defaultdict(int)
        # Periodic reset to prevent unbounded growth.
        self._cost_reset_time: float = time.monotonic()
        self._cost_reset_interval: float = 3600.0  # 1 hour
        # Concurrency semaphores per tier (so we don't overload one model).
        self._semaphores: dict[ModelTier, asyncio.Semaphore] = {
            tier: asyncio.Semaphore(self._max_concurrent(tier))
            for tier in self.clients
        }
        # Cache the route used for each in-flight request so
        # record_latency can be called without re-resolving.
        self._route_index: dict[str, ModelRoute] = {}

    # ── ModelRouter interface ────────────────────────────────────────────

    async def route(
        self,
        *,
        task: Task | None = None,
        prompt: str | None = None,
        complexity: str | None = None,
        capability: str | None = None,
    ) -> ModelRoute:
        """Pick the best model for the request."""
        # 1. Capability override (e.g. "vision", "embedding").
        if capability:
            tier = self._capability_to_tier(capability)
            if tier in self.clients:
                return self._build_route(tier, rationale=f"capability={capability}")

        # 2. Complexity from task or explicit kwarg.
        comp = complexity or (
            task.complexity.value if task else TaskComplexity.SIMPLE.value
        )
        tier_name = self._complexity_to_tier_name(comp)
        tier = ModelTier(tier_name)

        # 3. If the chosen tier is unavailable, fall back.
        if tier not in self.clients:
            tier = self._fallback_tier(tier)

        # 4. If latency on the chosen tier is bad AND a cheaper tier is
        #    available, consider downgrading.
        if self._should_downgrade(tier):
            cheaper = self._cheaper_tier(tier)
            if cheaper is not None:
                tier = cheaper
                log.debug("Router downgrading to %s due to latency", tier.value)

        return self._build_route(
            tier,
            rationale=f"complexity={comp}, capability={capability or 'default'}",
        )

    def get_client(self, route: ModelRoute) -> LLMClient:
        client = self.clients.get(route.model_tier)
        if client is None:
            raise ModelRouterError(
                f"no client registered for tier {route.model_tier}"
            )
        return client

    async def record_latency(
        self, route: ModelRoute, latency_s: float, success: bool,
    ) -> None:
        """Feed observed latency + success back into routing decisions."""
        name = route.model_name
        alpha = self._latency_ema_alpha()
        if self._latency_ema[name] == 0.0:
            self._latency_ema[name] = latency_s
        else:
            self._latency_ema[name] = (
                alpha * latency_s + (1.0 - alpha) * self._latency_ema[name]
            )
        # Quality rolling average.
        self._quality_history[name].append(1.0 if success else 0.0)

    # ── Convenience: route + complete in one call ────────────────────────

    async def complete(
        self,
        messages: list[dict[str, str]],
        *,
        task: Task | None = None,
        complexity: str | None = None,
        capability: str | None = None,
        **llm_kwargs: Any,
    ) -> tuple[LLMResponse, ModelRoute]:
        """Route + call complete() in one shot.  Returns (response, route)."""
        route = await self.route(
            task=task, complexity=complexity, capability=capability,
        )
        client = self.get_client(route)
        sem = self._semaphores[route.model_tier]
        start = time.time()
        success = True
        try:
            async with sem:
                resp = await client.complete(messages=messages, **llm_kwargs)
        except Exception:
            success = False
            raise
        finally:
            latency = time.time() - start
            try:
                await self.record_latency(route, latency, success)
            except Exception as e:
                log.debug("record_latency failed: %s", e)
        # Track token cost.
        if time.monotonic() - self._cost_reset_time > self._cost_reset_interval:
            self._token_cost.clear()
            self._cost_reset_time = time.monotonic()
        if resp.tokens_in + resp.tokens_out > 0:
            self._token_cost[route.model_name] += resp.tokens_in + resp.tokens_out
        return resp, route

    # ── Introspection ────────────────────────────────────────────────────

    def stats(self) -> dict[str, Any]:
        """Return a snapshot of router telemetry."""
        return {
            "latency_ema_s": dict(self._latency_ema),
            "quality": {
                name: (sum(h) / len(h)) if h else 0.0
                for name, h in self._quality_history.items()
            },
            "token_cost": dict(self._token_cost),
            "tiers": [t.value for t in self.clients],
        }

    # ── Tier resolution helpers ──────────────────────────────────────────

    def _complexity_to_tier_name(self, complexity: str) -> str:
        cfg_map = (
            getattr(getattr(self.config, "model_router", None),
                    "complexity_to_tier", None)
            if self.config else None
        )
        mapping = cfg_map or {
            "trivial": "small",
            "simple": "small",
            "moderate": "medium",
            "complex": "large",
            "open_ended": "large",
        }
        return mapping.get(complexity, "medium")

    def _capability_to_tier(self, capability: str) -> ModelTier:
        cap = capability.lower().strip()
        if cap in ("vision", "image", "multimodal"):
            return ModelTier.VISION
        if cap in ("embedding", "embed", "vector"):
            return ModelTier.EMBEDDING
        if cap in ("reasoning", "research", "planning"):
            return ModelTier.LARGE
        if cap in ("coding", "code"):
            return ModelTier.MEDIUM
        return ModelTier.MEDIUM

    def _fallback_tier(self, preferred: ModelTier) -> ModelTier:
        """Find an available tier, falling back from large → medium → small."""
        order = [preferred, ModelTier.LARGE, ModelTier.MEDIUM, ModelTier.SMALL]
        for t in order:
            if t in self.clients:
                return t
        # Should be impossible (constructor guarantees at least one client).
        raise ModelRouterError("no fallback client available")

    def _cheaper_tier(self, tier: ModelTier) -> ModelTier | None:
        order = [ModelTier.LARGE, ModelTier.MEDIUM, ModelTier.SMALL]
        try:
            idx = order.index(tier)
        except ValueError:
            return None
        for cheaper in order[idx + 1:]:
            if cheaper in self.clients:
                return cheaper
        return None

    def _should_downgrade(self, tier: ModelTier) -> bool:
        cfg = getattr(self.config, "model_router", None) if self.config else None
        if cfg and not getattr(cfg, "fallback_to_cheaper_on_timeout", True):
            return False
        # Downgrade if the EMA latency exceeds 30s.
        name = self._tier_to_model_name(tier)
        latency = self._latency_ema.get(name, 0.0)
        return latency > 30.0

    def _build_route(self, tier: ModelTier, *, rationale: str) -> ModelRoute:
        name = self._tier_to_model_name(tier)
        backend = self._tier_to_backend(tier)
        latency = self._latency_ema.get(name)
        quality = self._quality_score(name)
        # Confidence is a blend of quality and latency.
        confidence = 0.5 * quality + 0.5 * max(0.0, 1.0 - (latency or 0.0) / 60.0)
        return ModelRoute(
            model_tier=tier,
            model_name=name,
            backend=backend,
            rationale=rationale,
            estimated_latency_s=latency,
            estimated_cost_tokens=self._token_cost.get(name, 0),
            confidence=round(confidence, 3),
        )

    def _tier_to_model_name(self, tier: ModelTier) -> str:
        cfg_tiers = (
            getattr(getattr(self.config, "model_router", None), "tiers", None)
            if self.config else None
        ) or {}
        tier_cfg = cfg_tiers.get(tier.value, {})
        # Try to read from the client itself as a fallback.
        if not tier_cfg:
            client = self.clients.get(tier)
            model_attr = getattr(client, "model_name", None) or getattr(
                client, "model", None
            )
            return str(model_attr or tier.value)
        return str(tier_cfg.get("model_name", tier.value))

    def _tier_to_backend(self, tier: ModelTier) -> str:
        cfg_tiers = (
            getattr(getattr(self.config, "model_router", None), "tiers", None)
            if self.config else None
        ) or {}
        return str(cfg_tiers.get(tier.value, {}).get("backend", "unknown"))

    def _quality_score(self, model_name: str) -> float:
        h = self._quality_history.get(model_name)
        if not h:
            return 0.5
        return sum(h) / len(h)

    def _quality_window(self) -> int:
        return (
            getattr(getattr(self.config, "model_router", None), "quality_window", 20)
            if self.config else 20
        )

    def _latency_ema_alpha(self) -> float:
        return (
            getattr(getattr(self.config, "model_router", None),
                    "latency_ema_alpha", 0.3)
            if self.config else 0.3
        )

    def _max_concurrent(self, tier: ModelTier) -> int:
        # Allow more concurrency on cheaper tiers (they're faster).
        if tier == ModelTier.SMALL:
            return 8
        if tier == ModelTier.MEDIUM:
            return 4
        return 2


# ──────────────────────────────────────────────────────────────────────────────
# PassthroughRouter — single-model router for backward compat
# ──────────────────────────────────────────────────────────────────────────────


class PassthroughRouter(DefaultModelRouter):
    """Router that always returns the same client (no real routing).

    Useful for backward compatibility when a deployment has only one
    model configured.  Behaves identically to a single-client
    DefaultModelRouter.
    """

    def __init__(self, client: LLMClient, *, config: Any = None) -> None:
        # Determine which tier the client "feels like" — default to MEDIUM.
        tier = ModelTier.MEDIUM
        super().__init__({tier: client}, config=config)

    async def route(
        self,
        *,
        task: Task | None = None,
        prompt: str | None = None,
        complexity: str | None = None,
        capability: str | None = None,
    ) -> ModelRoute:
        # Always return the same tier.
        tier = next(iter(self.clients))
        return self._build_route(
            tier,
            rationale="passthrough (single-model deployment)",
        )


__all__ = ["DefaultModelRouter", "PassthroughRouter"]
