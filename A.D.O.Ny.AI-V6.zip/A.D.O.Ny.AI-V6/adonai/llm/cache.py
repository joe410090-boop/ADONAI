"""Response cache — avoids re-calling the LLM for identical prompts.

Especially valuable for small models where each call is precious.
Keyed on (model, messages_hash, temperature, max_tokens).
"""
from __future__ import annotations

import hashlib
import json
import logging
import time
from collections import OrderedDict
from typing import Any

from adonai.core.interfaces import LLMClient, LLMResponse

log = logging.getLogger(__name__)


class ResponseCache:
    """LRU cache for LLM responses."""

    def __init__(self, max_entries: int = 500, ttl_s: float = 3600.0) -> None:
        self._cache: OrderedDict[str, tuple[LLMResponse, float]] = OrderedDict()
        self._max = max_entries
        self._ttl = ttl_s
        self._hits = 0
        self._misses = 0

    def _key(
        self,
        model: str,
        messages: list[dict[str, str]],
        temperature: float,
        max_tokens: int,
        tools_schema_hash: str | None = None,
    ) -> str:
        blob = json.dumps({
            "m": model,
            "msg": messages,
            "t": round(temperature, 3),
            "mt": max_tokens,
            # v9 fix: include the tools-schema hash in the cache key so
            # tool-calling responses can be cached safely. Different tool
            # sets (or different schema versions of the same tool) get
            # different cache entries — preventing a response cached for
            # one tool set from being served for a different one. None
            # preserves the original behaviour for the no-tools path.
            "tsh": tools_schema_hash,
        }, sort_keys=True, default=str)
        return hashlib.sha256(blob.encode()).hexdigest()

    def get(
        self,
        model: str,
        messages: list[dict[str, str]],
        temperature: float,
        max_tokens: int,
        tools_schema_hash: str | None = None,
    ) -> LLMResponse | None:
        k = self._key(model, messages, temperature, max_tokens, tools_schema_hash)
        entry = self._cache.get(k)
        if entry is None:
            self._misses += 1
            return None
        resp, ts = entry
        if (time.time() - ts) > self._ttl:
            del self._cache[k]
            self._misses += 1
            return None
        self._hits += 1
        self._cache.move_to_end(k)
        return resp

    def put(
        self,
        model: str,
        messages: list[dict[str, str]],
        temperature: float,
        max_tokens: int,
        response: LLMResponse,
        tools_schema_hash: str | None = None,
    ) -> None:
        k = self._key(model, messages, temperature, max_tokens, tools_schema_hash)
        self._cache[k] = (response, time.time())
        self._cache.move_to_end(k)
        while len(self._cache) > self._max:
            self._cache.popitem(last=False)

    def stats(self) -> dict[str, int]:
        return {
            "hits": self._hits,
            "misses": self._misses,
            "size": len(self._cache),
            "hit_rate": (self._hits / max(1, self._hits + self._misses)),
        }

    def clear(self) -> None:
        self._cache.clear()
        self._hits = 0
        self._misses = 0


class CachedLLMClient(LLMClient):
    """Wraps an :class:`LLMClient` with a :class:`ResponseCache` and an embedding cache.

    v5: added an LRU cache for ``embed()`` calls. Previously every
    ``MemoryStore.search(query)`` re-embedded the query string via
    ``llm.embed()``, and ``MemoryManager.recall()`` searches 3-4 tiers
    (episodic/semantic/procedural/working) — so 3-4 redundant embedding
    calls per recall. The planner calls recall_similar + recall on every
    task. On a 4B embedding model that's ~400ms of avoidable latency
    per task. The embedding cache eliminates this.
    """

    def __init__(self, inner: LLMClient, cache: ResponseCache) -> None:
        self._inner = inner
        self._cache = cache
        # Embedding cache: text_hash → (embedding_vector, timestamp).
        # LRU with TTL. Keyed on the SHA256 of the text so identical text
        # across different callers hits the cache.
        self._embed_cache: OrderedDict[str, tuple[Any, float]] = OrderedDict()
        self._embed_max = 1000
        self._embed_ttl = 7200.0  # 2 hours
        self._embed_hits = 0
        self._embed_misses = 0

    async def complete(
        self,
        messages: list[dict[str, str]],
        tools: list[dict] | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        # v9 fix: previously the cache was gated on `tools is None`, which
        # meant the chat/tool-calling path (the dominant interactive path)
        # NEVER hit cache — every ToolCallingAgent iteration re-called the
        # LLM even for identical prompts + tool sets. We now cache both
        # paths:
        #
        #  * tools is None → cache as before (no tools_schema_hash).
        #  * tools is not None → hash the schema and include it in the key.
        #
        # Side-effecting tools (web_search, terminal, file_write) opt out
        # via either:
        #   (a) the caller passing `cacheable=False` in kwargs (the
        #       ToolCallingAgent sets this when any tool in its set has
        #       `Tool.cacheable == False`); or
        #   (b) the response being stream/non-cacheable for other reasons.
        cacheable = bool(kwargs.pop("cacheable", True))
        tools_schema_hash: str | None = None
        if tools is not None:
            if not cacheable:
                # Skip cache entirely for side-effecting tool sets.
                return await self._inner.complete(
                    messages, tools=tools, temperature=temperature,
                    max_tokens=max_tokens, stop=stop, **kwargs,
                )
            try:
                tools_blob = json.dumps(tools, sort_keys=True, default=str)
                tools_schema_hash = hashlib.sha256(
                    tools_blob.encode("utf-8", errors="replace")
                ).hexdigest()
            except Exception:
                # If we can't hash the schema (unlikely — it's a list of
                # dicts), fall back to skipping cache to be safe.
                return await self._inner.complete(
                    messages, tools=tools, temperature=temperature,
                    max_tokens=max_tokens, stop=stop, **kwargs,
                )
        cached = self._cache.get(
            self._inner.__class__.__name__, messages, temperature, max_tokens,
            tools_schema_hash,
        )
        if cached is not None:
            return cached
        resp = await self._inner.complete(
            messages, tools=tools, temperature=temperature,
            max_tokens=max_tokens, stop=stop, **kwargs,
        )
        self._cache.put(
            self._inner.__class__.__name__, messages, temperature, max_tokens,
            resp, tools_schema_hash,
        )
        return resp

    async def stream(self, messages, temperature=0.7, max_tokens=2048):
        async for chunk in self._inner.stream(messages, temperature=temperature, max_tokens=max_tokens):
            yield chunk

    async def embed(self, text):
        """Embed text, with LRU caching.

        v5: previously every MemoryStore.search() re-embedded the query
        string. MemoryManager.recall() searches 3-4 tiers, so 3-4
        redundant embedding calls per recall. Now cached.
        """
        if not text:
            return await self._inner.embed(text)
        # Hash the text for the cache key — handles arbitrary-length text.
        key = hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()
        entry = self._embed_cache.get(key)
        if entry is not None:
            vec, ts = entry
            if (time.time() - ts) <= self._embed_ttl:
                self._embed_hits += 1
                self._embed_cache.move_to_end(key)
                return vec
            else:
                del self._embed_cache[key]
        self._embed_misses += 1
        vec = await self._inner.embed(text)
        if vec is not None:
            self._embed_cache[key] = (vec, time.time())
            self._embed_cache.move_to_end(key)
            while len(self._embed_cache) > self._embed_max:
                self._embed_cache.popitem(last=False)
        return vec

    async def check_vision_capable(self):
        """Delegate vision-capability check to the inner client.

        Not all backends implement this (only OllamaLLMClient does), so
        fall back to None when the inner client doesn't expose it.
        """
        fn = getattr(self._inner, "check_vision_capable", None)
        if fn is None:
            return None
        return await fn()

    async def close(self) -> None:
        await self._inner.close()

    @property
    def cache_stats(self) -> dict[str, int]:
        stats = self._cache.stats()
        stats["embed_hits"] = self._embed_hits
        stats["embed_misses"] = self._embed_misses
        stats["embed_size"] = len(self._embed_cache)
        stats["embed_hit_rate"] = (
            self._embed_hits / max(1, self._embed_hits + self._embed_misses)
        )
        return stats

    # ── Pass-through properties for downstream introspection ────────────
    # Without these, callers that do `getattr(llm, "config", None)` (e.g.
    # the FileAnalysisAgent's vision-model detection) get None when the
    # LLM is wrapped in a cache, which causes the model name to show up
    # as "unknown" in user-facing messages.  Expose the inner client's
    # `config` and `model_name` so wrappers are transparent.

    @property
    def config(self):
        """Delegate to the inner client's config (if any)."""
        return getattr(self._inner, "config", None)

    @property
    def inner(self):
        """The wrapped :class:`LLMClient` instance."""
        return self._inner

    @property
    def model_name(self) -> str:
        """The configured model name (delegated to the inner client)."""
        cfg = getattr(self._inner, "config", None)
        if cfg is not None:
            return getattr(cfg, "model_name", "") or ""
        return getattr(self._inner, "model_name", "") or ""
