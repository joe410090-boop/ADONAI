"""Circuit breaker for LLM calls and tool execution.

Prevents cascading failures by temporarily stopping calls to
a failing endpoint after a threshold of consecutive failures.
"""

from __future__ import annotations

import asyncio
import time
import logging
from enum import Enum
from dataclasses import dataclass, field

log = logging.getLogger(__name__)


class CircuitState(Enum):
    CLOSED = "closed"       # Normal operation — calls go through
    OPEN = "open"           # Failing — calls are rejected immediately
    HALF_OPEN = "half_open" # Probing — allow one call to test recovery


@dataclass
class CircuitBreaker:
    """A per-key circuit breaker with configurable thresholds."""

    key: str
    failure_threshold: int = 5
    recovery_timeout: float = 60.0      # seconds to wait before half-open probe
    half_open_max_calls: int = 1         # calls allowed in half-open state

    _state: CircuitState = field(default=CircuitState.CLOSED, init=False)
    _failure_count: int = field(default=0, init=False)
    _success_count: int = field(default=0, init=False)
    _last_failure_time: float = field(default=0.0, init=False)
    _half_open_calls: int = field(default=0, init=False)
    _lock: asyncio.Lock = field(default_factory=asyncio.Lock, init=False)

    @property
    def state(self) -> CircuitState:
        """Return current state, transitioning OPEN→HALF_OPEN if timeout elapsed."""
        if self._state == CircuitState.OPEN:
            if time.monotonic() - self._last_failure_time >= self.recovery_timeout:
                self._state = CircuitState.HALF_OPEN
                self._half_open_calls = 0
                log.info("Circuit breaker [%s]: OPEN → HALF_OPEN", self.key)
        return self._state

    def _record_failure(self) -> None:
        self._failure_count += 1
        self._success_count = 0
        self._last_failure_time = time.monotonic()
        if self._failure_count >= self.failure_threshold:
            old = self._state
            self._state = CircuitState.OPEN
            if old != CircuitState.OPEN:
                log.warning(
                    "Circuit breaker [%s]: → OPEN after %d consecutive failures",
                    self.key, self._failure_count,
                )

    def _record_success(self) -> None:
        self._failure_count = 0
        self._success_count += 1
        if self._state == CircuitState.HALF_OPEN:
            self._half_open_calls += 1
            if self._half_open_calls >= self.half_open_max_calls:
                self._state = CircuitState.CLOSED
                log.info("Circuit breaker [%s]: HALF_OPEN → CLOSED", self.key)

    async def allow_request(self) -> bool:
        """Check if a request is allowed. If HALF_OPEN, counts toward probe limit."""
        async with self._lock:
            state = self.state
            if state == CircuitState.CLOSED:
                return True
            elif state == CircuitState.OPEN:
                return False
            else:  # HALF_OPEN
                if self._half_open_calls < self.half_open_max_calls:
                    return True
                return False

    async def record_success(self) -> None:
        async with self._lock:
            self._record_success()

    async def record_failure(self) -> None:
        async with self._lock:
            self._record_failure()

    def reset(self) -> None:
        self._state = CircuitState.CLOSED
        self._failure_count = 0
        self._success_count = 0
        self._half_open_calls = 0


class CircuitBreakerRegistry:
    """Manages per-key circuit breakers."""

    def __init__(
        self,
        failure_threshold: int = 5,
        recovery_timeout: float = 60.0,
    ) -> None:
        self._breakers: dict[str, CircuitBreaker] = {}
        self._failure_threshold = failure_threshold
        self._recovery_timeout = recovery_timeout

    def get(self, key: str) -> CircuitBreaker:
        if key not in self._breakers:
            self._breakers[key] = CircuitBreaker(
                key=key,
                failure_threshold=self._failure_threshold,
                recovery_timeout=self._recovery_timeout,
            )
        return self._breakers[key]

    async def allow_request(self, key: str) -> bool:
        return await self.get(key).allow_request()

    async def record_success(self, key: str) -> None:
        await self.get(key).record_success()

    async def record_failure(self, key: str) -> None:
        await self.get(key).record_failure()

    def reset_all(self) -> None:
        for cb in self._breakers.values():
            cb.reset()

    def status(self) -> dict[str, str]:
        return {k: v.state.value for k, v in self._breakers.items()}