"""Retry decorators for LLM calls and other transient-failure-prone operations.

Centralizes the retry/backoff policy so every LLM call site doesn't have to
re-implement it. Uses exponential backoff with jitter, classifies transient
vs. permanent errors, and respects a deadline so retries don't run forever.

Usage::

    from adonai.llm.retry import llm_retry

    @llm_retry
    async def complete(self, ...): ...

    # Or with custom params:
    @llm_retry(max_attempts=5, base_delay=2.0, max_delay=30.0)
    async def embed(self, ...): ...
"""
from __future__ import annotations

import asyncio
import functools
import logging
import random
from typing import Any, Awaitable, Callable, ParamSpec, TypeVar

from adonai.llm.circuit_breaker import CircuitBreakerRegistry

log = logging.getLogger(__name__)

P = ParamSpec("P")
T = TypeVar("T")


class CircuitOpenError(Exception):
    """Raised when the circuit breaker is OPEN and rejects a request."""
    pass


# Module-level circuit breaker registry.
_circuit_breaker = CircuitBreakerRegistry(failure_threshold=5, recovery_timeout=60.0)


def get_circuit_breaker() -> CircuitBreakerRegistry:
    """Return the module-level circuit breaker registry."""
    return _circuit_breaker


# Exception types that are NOT worth retrying — they'll fail the same way
# every time. Everything else is treated as transient.
_PERMANENT_ERROR_FRAGMENTS = (
    "authentication",
    "invalid api key",
    "model not found",
    "context length exceeded",
    "maximum context length",
    "rate limit",  # debatable — some rate limits are worth retrying after backoff
    "quota",
    "billing",
    "permission denied",
    "not authorized",
    "invalid_request",
    "bad request",
    "syntax error",
    # HTTP 4xx status-code markers.  LLMError messages from the Ollama and
    # OpenAI-compat clients include "HTTP <code>" — these are permanent
    # client errors that no amount of retrying will fix.
    "http 400",
    "http 401",
    "http 402",
    "http 403",
    "http 404",
    "http 405",
    "http 406",
    "http 409",
    "http 410",
    "http 411",
    "http 412",
    "http 413",
    "http 414",
    "http 415",
    "http 416",
    "http 421",
    "http 422",
    "http 423",
    "http 424",
    "http 425",
    "http 426",
    "http 428",
    # NOTE: "http 429" intentionally omitted — rate-limit responses should
    # be retried after a backoff (the original code deliberately treats
    # "rate limit" and "quota" as retryable; we preserve that behaviour).
    "http 431",
    "http 451",
    # Ollama-specific unmarshalling error — this is the exact bug that
    # triggered when sending OpenAI-style multimodal content to Ollama's
    # /api/chat endpoint.  It's a permanent client-side error: the request
    # shape is wrong, retrying won't help.
    "cannot unmarshal",
    "image decoding",
    "no vision model",
)


def _is_permanent(exc: BaseException) -> bool:
    """Return True if *exc* is a permanent error that won't succeed on retry."""
    msg = str(exc).lower()
    # Rate-limit and quota ARE retryable — remove them from the permanent set.
    for frag in _PERMANENT_ERROR_FRAGMENTS:
        if frag == "rate limit" or frag == "quota":
            continue  # retryable
        if frag in msg:
            return True
    return False


def llm_retry(
    max_attempts: int = 3,
    base_delay: float = 1.0,
    max_delay: float = 30.0,
    deadline: float | None = 300.0,
) -> Callable[[Callable[P, Awaitable[T]]], Callable[P, Awaitable[T]]]:
    """Retry an async callable with exponential backoff + jitter.

    Args:
        max_attempts: Total attempts (including the first). 3 = 1 try + 2 retries.
        base_delay: First retry delay in seconds.
        max_delay: Cap on per-retry delay.
        deadline: Overall deadline in seconds (None = no cap). Default 120s.
    """
    def decorator(func: Callable[P, Awaitable[T]]) -> Callable[P, Awaitable[T]]:
        @functools.wraps(func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> T:
            import time as _time
            start = _time.monotonic()
            last_exc: BaseException | None = None
            for attempt in range(1, max_attempts + 1):
                # Circuit breaker check — before each attempt
                if not await _circuit_breaker.allow_request("llm"):
                    raise CircuitOpenError("LLM circuit breaker is OPEN")
                try:
                    result = await func(*args, **kwargs)
                    await _circuit_breaker.record_success("llm")
                    return result
                except asyncio.CancelledError:
                    raise  # never retry cancellation
                except BaseException as exc:
                    last_exc = exc
                    if _is_permanent(exc):
                        log.debug("llm_retry: permanent error on attempt %d/%d: %s",
                                  attempt, max_attempts, exc)
                        await _circuit_breaker.record_failure("llm")
                        raise
                    if attempt >= max_attempts:
                        log.warning("llm_retry: exhausted %d attempts: %s", max_attempts, exc)
                        await _circuit_breaker.record_failure("llm")
                        raise
                    elapsed = _time.monotonic() - start
                    if deadline is not None and elapsed >= deadline:
                        log.warning("llm_retry: deadline %.1fs exceeded after %d attempts: %s",
                                    deadline, attempt, exc)
                        await _circuit_breaker.record_failure("llm")
                        raise
                    # Exponential backoff with jitter.
                    delay = min(max_delay, base_delay * (2 ** (attempt - 1)))
                    delay = delay * (0.5 + random.random() * 0.5)  # 50-100% jitter
                    # Don't sleep past the deadline.
                    if deadline is not None:
                        remaining = deadline - elapsed
                        delay = min(delay, max(0.0, remaining))
                    if delay <= 0:
                        await _circuit_breaker.record_failure("llm")
                        raise
                    log.info("llm_retry: attempt %d/%d failed (%s); retrying in %.2fs",
                             attempt, max_attempts, type(exc).__name__, delay)
                    await asyncio.sleep(delay)
            # Shouldn't reach here, but just in case:
            if last_exc is not None:
                await _circuit_breaker.record_failure("llm")
                raise last_exc
            raise RuntimeError("llm_retry: unreachable")
        return wrapper
    return decorator


# Convenience: a pre-configured decorator for the standard 3-attempt policy.
standard_llm_retry = llm_retry(max_attempts=3, base_delay=1.0, max_delay=30.0, deadline=300.0)
