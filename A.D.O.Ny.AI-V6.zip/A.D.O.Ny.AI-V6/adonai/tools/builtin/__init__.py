"""Built-in tools: filesystem, terminal, python_exec, git, web, http, browser, platform integrations."""
from pathlib import Path
from typing import Any

from adonai.tools.builtin.filesystem import FileReadTool, FileWriteTool, FileListTool
from adonai.tools.builtin.terminal import TerminalTool
from adonai.tools.builtin.python_exec import PythonExecTool
from adonai.tools.builtin.git import GitTool
from adonai.tools.builtin.web import WebSearchTool, WebFetchTool
from adonai.tools.builtin.http import HTTPRequestTool
from adonai.tools.builtin.browser import BrowserTool
from adonai.tools.builtin.todo import TodoWriteTool, TodoListTool
from adonai.tools.builtin.agent_reach import (
    TwitterReadTool, TwitterSearchTool,
    YouTubeSubtitlesTool,
    RedditSearchTool, RedditReadTool,
    BilibiliSearchTool,
    XiaoHongShuSearchTool,
    RSSReadTool,
    GitHubSearchTool, GitHubRepoReadTool,
    PlatformDiagnosticsTool,
    all_agent_reach_tools,
)
# Pentest tools (ported from Strix — see adonai/pentest/).
from adonai.tools.builtin.pentest_recon import PentestReconTool
from adonai.tools.builtin.pentest_code_analysis import PentestCodeAnalysisTool
from adonai.tools.builtin.pentest_browser import PentestBrowserTool
from adonai.tools.builtin.pentest_proxy import PentestProxyTool
from adonai.tools.builtin.pentest_shell import PentestSandboxTool
from adonai.tools.builtin.pentest_reporting import PentestReportingTool
from adonai.tools.builtin.pentest_agents_graph import PentestAgentsGraphTool


def all_pentest_tools() -> list[Any]:
    """Return a fresh list of all pentest tool instances.

    These are registered alongside the built-in tools so they're
    available to the PentesterAgent via the ToolRegistry. They are
    safe to register even when no pentest scan is active — each tool
    returns a clear error if invoked outside a scan.
    """
    return [
        PentestReconTool(),
        PentestCodeAnalysisTool(),
        PentestBrowserTool(),
        PentestProxyTool(),
        PentestSandboxTool(),
        PentestReportingTool(),
        PentestAgentsGraphTool(),
    ]


def all_builtin_tools(workspace_root: str | Path | None = None):
    """Return a fresh list of all built-in tool instances.

    Includes native platform integrations (Twitter, YouTube, Reddit,
    Bilibili, RSS, GitHub) — all implemented natively via HTTP, no
    external CLI tools required.

    Args:
        workspace_root: Optional path to use as the terminal cwd sandbox
            root.  When provided, the ``TerminalTool`` will reject any
            ``cwd`` parameter that escapes this directory.  v6: also
            propagated to filesystem tools (FileReadTool/FileWriteTool/
            FileListTool) via set_workspace_root() so all tools respect
            the same sandbox. Previously filesystem tools hardcoded
            <project>/workspace and ignored this parameter.
    """
    # v6: propagate workspace_root to filesystem tools so file.read/
    # file.write/file.list use the same sandbox as terminal.
    if workspace_root is not None:
        from adonai.tools.builtin.filesystem import set_workspace_root
        set_workspace_root(workspace_root)
    tools = [
        FileReadTool(), FileWriteTool(), FileListTool(),
        TerminalTool(workspace_root=workspace_root),
        PythonExecTool(workspace_root=workspace_root),  # v6: python_exec temp files in workspace
        GitTool(),
        WebSearchTool(), WebFetchTool(), HTTPRequestTool(),
        BrowserTool(),
        # Planning tools — referenced by the system prompt as the primary
        # planning directive for any 3+ step task. Must be registered so
        # the LLM's todo.write calls don't fail with "unknown tool".
        TodoWriteTool(), TodoListTool(),
    ]
    # Native platform integration tools — always registered, always
    # available (they use direct HTTP calls, no external dependencies).
    tools.extend(all_agent_reach_tools())
    # Pentest tools — registered always so the PentesterAgent can use
    # them via the ToolRegistry. They no-op outside a pentest scan.
    tools.extend(all_pentest_tools())
    return tools


__all__ = [
    "FileReadTool", "FileWriteTool", "FileListTool",
    "TerminalTool", "PythonExecTool", "GitTool",
    "WebSearchTool", "WebFetchTool", "HTTPRequestTool",
    "BrowserTool",
    "TodoWriteTool", "TodoListTool",
    # Native platform integrations
    "TwitterReadTool", "TwitterSearchTool",
    "YouTubeSubtitlesTool",
    "RedditSearchTool", "RedditReadTool",
    "BilibiliSearchTool",
    "XiaoHongShuSearchTool",
    "RSSReadTool",
    "GitHubSearchTool", "GitHubRepoReadTool",
    "PlatformDiagnosticsTool",
    "all_agent_reach_tools",
    # Pentest tools
    "PentestReconTool", "PentestCodeAnalysisTool", "PentestBrowserTool",
    "PentestProxyTool", "PentestSandboxTool", "PentestReportingTool",
    "PentestAgentsGraphTool", "all_pentest_tools",
    "all_builtin_tools",
]
