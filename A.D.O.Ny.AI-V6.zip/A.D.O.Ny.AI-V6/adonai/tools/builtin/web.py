"""Web tools — search via DuckDuckGo + fetch URL contents."""
from __future__ import annotations

import re
import time
from typing import Any
from urllib.parse import unquote

import httpx

from adonai.core.interfaces import Tool
from adonai.core.models import ToolResult


# v9 fix: A realistic browser-like User-Agent. Many CDNs and WAFs (Reddit,
# Bilibili, Cloudflare-protected sites) return 403 Blocked or 412
# Precondition Failed to clients that identify as bots, httpx, or have a
# sparse UA. We default to a recent Chrome-on-Windows UA.
_BROWSER_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

# Default browser-like headers used for web_fetch.
_BROWSER_HEADERS = {
    "User-Agent": _BROWSER_UA,
    "Accept": (
        "text/html,application/xhtml+xml,application/xml;q=0.9,"
        "application/json;q=0.8,*/*;q=0.7"
    ),
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
}


def _looks_like_ddg_challenge(html: str) -> bool:
    """DuckDuckGo returns a bot challenge page instead of results."""
    lowered = html.lower()
    markers = (
        "duckduckgo too",
        "complete the following challenge",
        "anomaly-modal",
        "challenge-form",
        "anomaly.js",
        "botnet",
        "bot challenge",
        "captcha",
    )
    return any(marker in lowered for marker in markers)


def _strip_tags(value: str) -> str:
    return re.sub(r"<[^>]+>", " ", value, flags=re.DOTALL).strip()


def _parse_duckduckgo_results(html: str, max_results: int) -> list[dict[str, Any]]:
    link_re = re.compile(
        r'<a[^>]+class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>', re.DOTALL,
    )
    link_re_fallback = re.compile(
        r'<a[^>]+href="([^"]+)"[^>]*class="[^"]*result[^"]*"[^>]*>(.*?)</a>',
        re.DOTALL,
    )
    snippet_re = re.compile(
        r'<a[^>]+class="result__snippet"[^>]*>(.*?)</a>', re.DOTALL,
    )
    snippet_re_fallback = re.compile(
        r'<(?:a|div|p)[^>]+class="[^"]*snippet[^"]*"[^>]*>(.*?)</(?:a|div|p)>',
        re.DOTALL,
    )
    links = link_re.findall(html)
    if not links:
        links = link_re_fallback.findall(html)
    snippets = snippet_re.findall(html)
    if not snippets:
        snippets = snippet_re_fallback.findall(html)
    results = []
    for i, (href, title) in enumerate(links[:max_results]):
        clean_title = _strip_tags(title)
        snippet = _strip_tags(snippets[i]) if i < len(snippets) else ""
        m = re.search(r"uddg=([^&]+)", href)
        actual_url = unquote(m.group(1)) if m else href
        credibility = _score_source_credibility(actual_url)
        results.append({
            "title": clean_title,
            "url": actual_url,
            "snippet": snippet,
            "source": _extract_domain(actual_url),
            "credibility": credibility["level"],
            "credibility_score": credibility["score"],
        })
    results.sort(key=lambda r: (-r["credibility_score"],))
    return results


def _parse_bing_results(html: str, max_results: int) -> list[dict[str, Any]]:
    results = []
    for block in re.findall(r'<li[^>]+class="b_algo"[^>]*>(.*?)</li>', html, re.DOTALL | re.IGNORECASE):
        anchor_match = re.search(r'<a[^>]+href="([^"]+)"[^>]*>(.*?)</a>', block, re.DOTALL | re.IGNORECASE)
        if not anchor_match:
            continue
        href = anchor_match.group(1)
        title = _strip_tags(anchor_match.group(2))
        snippet_match = re.search(r'<div[^>]*>(.*?)</div>', block, re.DOTALL | re.IGNORECASE)
        snippet = _strip_tags(snippet_match.group(1)) if snippet_match else ""
        if not href or not title:
            continue
        actual_url = href.split("&url=")[-1] if "&url=" in href else href
        actual_url = actual_url.replace("http://www.bing.com/ck/a?", "")
        actual_url = actual_url.split("&")[0]
        credibility = _score_source_credibility(actual_url)
        results.append({
            "title": title,
            "url": actual_url,
            "snippet": snippet,
            "source": _extract_domain(actual_url),
            "credibility": credibility["level"],
            "credibility_score": credibility["score"],
        })
        if len(results) >= max_results:
            break
    return results


class WebSearchTool(Tool):
    name = "web_search"
    description = (
        "Search the public web via DuckDuckGo (no API key required). "
        "Returns up to `max_results` results, each with title/url/snippet."
    )
    parameters = {
        "type": "object",
        "properties": {
            "query": {"type": "string"},
            "max_results": {"type": "integer", "default": 5, "minimum": 1, "maximum": 20},
        },
        "required": ["query"],
    }
    risk_level = "low"
    tags = ["web", "search"]
    category = "web"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        query = (params.get("query") or "").strip()
        max_results = max(1, min(20, int(params.get("max_results", 5))))
        if not query:
            return ToolResult(
                call_id=f"ws_{int(start*1000)}", tool=self.name,
                success=False, error="query is required", duration_s=time.time() - start,
            )

        search_requests: list[tuple[str, dict[str, str], str]] = [
            (
                "https://html.duckduckgo.com/html/",
                {"q": query},
                "duckduckgo",
            ),
            (
                "https://www.bing.com/search",
                {"q": query},
                "bing",
            ),
        ]

        last_error = None
        html = ""
        try:
            async with httpx.AsyncClient(timeout=20.0, follow_redirects=True) as client:
                for url, params_dict, provider in search_requests:
                    try:
                        resp = await client.get(
                            url,
                            params=params_dict,
                            headers={
                                **_BROWSER_HEADERS,
                                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                            },
                        )
                        html = resp.text
                        if provider == "duckduckgo":
                            if resp.status_code >= 400:
                                raise RuntimeError(f"HTTP {resp.status_code}")
                            if _looks_like_ddg_challenge(html):
                                last_error = "DuckDuckGo returned an anti-bot challenge page"
                                continue
                            results = _parse_duckduckgo_results(html, max_results)
                            if results:
                                return ToolResult(
                                    call_id=f"ws_{int(start*1000)}", tool=self.name,
                                    success=True,
                                    output={
                                        "query": query,
                                        "results": results,
                                        "count": len(results),
                                        "provider": "duckduckgo",
                                    },
                                    duration_s=time.time() - start,
                                )
                            last_error = "DuckDuckGo returned 0 parseable results"
                            continue

                        results = _parse_bing_results(html, max_results)
                        if results:
                            return ToolResult(
                                call_id=f"ws_{int(start*1000)}", tool=self.name,
                                success=True,
                                output={
                                    "query": query,
                                    "results": results,
                                    "count": len(results),
                                    "provider": "bing",
                                },
                                duration_s=time.time() - start,
                            )
                        last_error = "Bing returned 0 parseable results"
                    except Exception as e:
                        last_error = f"{provider} search request failed: {type(e).__name__}: {e}"
        except Exception as e:
            last_error = f"search request failed: {type(e).__name__}: {e}"

        return ToolResult(
            call_id=f"ws_{int(start*1000)}", tool=self.name,
            success=False,
            error=(
                last_error
                or "No public search results were available from the configured providers."
            ),
            output={"query": query, "results": [], "count": 0, "html_preview": html[:500]},
            duration_s=time.time() - start,
        )


class WebFetchTool(Tool):
    name = "web_fetch"
    description = (
        "Fetch a URL and return the main article text (HTML cleaned, scripts "
        "and styles removed, navigation/sidebar boilerplate stripped, ≤16 KB). "
        "Use for reading a specific article AFTER web_search gave you its URL."
    )
    parameters = {
        "type": "object",
        "properties": {
            "url": {"type": "string"},
            "max_bytes": {"type": "integer", "default": 16384},
        },
        "required": ["url"],
    }
    risk_level = "low"
    tags = ["web", "fetch"]
    category = "web"

    def __init__(self, policy: "UrlSafetyPolicy | None" = None) -> None:
        from adonai.tools.url_safety import UrlSafetyPolicy, DEFAULT_POLICY
        self._policy = policy or DEFAULT_POLICY

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        call_id = f"wf_{int(start*1000)}"
        url = (params.get("url") or "").strip()
        if not url:
            return ToolResult(call_id=call_id, tool=self.name, success=False,
                              error="url is required", duration_s=0.0)

        # SSRF check — block loopback / link-local (cloud metadata) / private.
        ok, reason = self._policy.validate(url)
        if not ok:
            return ToolResult(call_id=call_id, tool=self.name, success=False,
                              error=f"URL rejected by safety policy: {reason}",
                              duration_s=time.time() - start)

        max_bytes = int(params.get("max_bytes", 16_384))
        try:
            # ── SSRF-via-redirect defense ──────────────────────────────
            # Validate every redirect hop — a public URL that 302s to
            # 169.254.169.254 must be caught here, not after following.
            current_url = url
            resp = None
            for _hop in range(6):
                async with httpx.AsyncClient(
                    timeout=20.0, follow_redirects=False,
                ) as client:
                    resp = await client.get(
                        current_url,
                        headers=_BROWSER_HEADERS,
                    )
                if not (300 <= resp.status_code < 400):
                    break
                location = resp.headers.get("location")
                if not location:
                    break
                current_url = str(httpx.URL(current_url).join(location))
                ok_r, reason_r = self._policy.validate(current_url)
                if not ok_r:
                    return ToolResult(
                        call_id=call_id, tool=self.name, success=False,
                        error=(
                            f"Redirect target rejected by safety policy: "
                            f"{reason_r} (redirected to {current_url[:120]})"
                        ),
                        duration_s=time.time() - start,
                    )
            if resp is None:
                return ToolResult(
                    call_id=call_id, tool=self.name, success=False,
                    error="no response received",
                    duration_s=time.time() - start,
                )
            resp.raise_for_status()
            content_type = resp.headers.get("content-type", "")
            body = resp.text
        except Exception as e:
            return ToolResult(call_id=call_id, tool=self.name, success=False,
                              error=f"fetch failed: {type(e).__name__}: {e}",
                              duration_s=time.time() - start)

        # For HTML responses, extract readable article text instead of
        # dumping the raw page.  Modern news sites are full of inline CSS,
        # JSON-LD blocks, class-name lists, and navigation boilerplate that
        # small models confuse for "the answer" — they then hallucinate
        # that the user asked for CSS (which actually happened: user asked
        # for "latest AI news" and the agent replied with WordPress CSS).
        if "html" in content_type:
            body = _extract_article_text(body, url=url, max_bytes=max_bytes)
        else:
            # Non-HTML (JSON, plain text, etc.) — truncate directly.
            body = body[:max_bytes]
        return ToolResult(
            call_id=f"wf_{int(start*1000)}", tool=self.name,
            success=True,
            output={"url": url, "content": body, "content_type": content_type,
                    "bytes": len(body)},
            duration_s=time.time() - start,
        )


# ──────────────────────────────────────────────────────────────────────────────
# Article extraction — pull main readable text out of a web page
# ──────────────────────────────────────────────────────────────────────────────

# Tags whose entire contents we drop (boilerplate / non-article).
_DROP_TAGS_RE = re.compile(
    r"<(script|style|noscript|iframe|svg|nav|footer|header|aside|form|button|"
    r"link|meta|svg|template|figure|figcaption|picture|source|"
    r"svg|canvas|video|audio|map|area|object|embed|param)[\s\S]*?</\1\s*>",
    re.IGNORECASE,
)
# Self-closing variants of the same tags.
_DROP_VOID_RE = re.compile(
    r"<(link|meta|source|input|br|hr|img)\b[^>]*/?>",
    re.IGNORECASE,
)
# JSON-LD and other inline script-like data leaks.
_JSON_LD_RE = re.compile(
    r'<script[^>]+type=["\']application/(?:ld\+json|json)["\'][^>]*>[\s\S]*?</script>',
    re.IGNORECASE,
)
# HTML comments (often contain boilerplate / conditional CSS).
_COMMENT_RE = re.compile(r"<!--[\s\S]*?-->", re.IGNORECASE)
# Inline style/class/id attributes — they leak CSS class names that small
# models confuse for actual content.
#
# IMPORTANT: the value alternation MUST be wrapped in (?:...) — otherwise
# the | operator's low precedence turns the regex into
#   \s+(...)\s*=\s*"[^"]*"   OR   '[^']*'   OR   [^\s>]+
# and the bare `[^\s>]+` matches almost anything, eating the article text.
_ATTR_RE = re.compile(
    r"\s+(?:style|class|id|data-[a-zA-Z0-9_-]+|aria-[a-zA-Z0-9_-]+|"
    r"on[a-zA-Z]+|tabindex|role|hidden|contenteditable|draggable|"
    r"spellcheck|translate|loading|decoding|crossorigin|integrity|"
    r"referrer|srcset|sizes|width|height|alt|title|rel|target|href|src|"
    r"action|method|enctype|name|value|placeholder|type|required|disabled|"
    r"checked|selected|multiple|autocomplete|min|max|step|pattern|"
    r"maxlength|minlength)\s*=\s*"
    r"(?:\"[^\"]*\"|'[^']*'|[^\s>]+)",
    re.IGNORECASE,
)
# Anything that looks like a raw CSS rule (selector { ... }) that slipped
# through.  Helps with `<style>` blocks inside `<pre>` or escaped in JSON.
_CSS_RULE_RE = re.compile(
    r"[.#]?[a-zA-Z][\w-]*(?:\s*[>+~]\s*[.#]?[a-zA-Z][\w-]*)*\s*\{[^}]*\}",
)
# Block tags that should become paragraph breaks.
_BLOCK_RE = re.compile(
    r"</?(?:p|div|section|article|h[1-6]|li|ul|ol|tr|table|tbody|thead|"
    r"br|hr|blockquote|pre|code|main|figure|figcaption)\b[^>]*>",
    re.IGNORECASE,
)
# Any remaining tag.
_TAG_RE = re.compile(r"<[^>]+>")


def _extract_article_text(html: str, *, url: str = "", max_bytes: int = 16_384) -> str:
    """Pull the readable article text out of an HTML page.

    Strategy:
      1. Drop boilerplate tags entirely (script, style, nav, footer, …).
      2. Drop JSON-LD blocks (often huge, never user-facing text).
      3. Drop HTML comments.
      4. Strip ALL attributes — inline `style="..."` and `class="..."` leak
         CSS class names that small models confuse for content.
      5. Convert block-level tags to paragraph breaks.
      6. Strip remaining tags.
      7. Collapse whitespace.
      8. Drop any stray CSS-rule-looking fragments that slipped through.
      9. Truncate to max_bytes.
    """
    # 1-3: drop boilerplate blocks (JSON-LD first because it's inside <script>).
    text = _JSON_LD_RE.sub(" ", html)
    text = _COMMENT_RE.sub(" ", text)
    text = _DROP_TAGS_RE.sub(" ", text)
    text = _DROP_VOID_RE.sub(" ", text)

    # 4: strip attributes (style/class/id/data-*/on*/etc.).
    # Run a few passes because regex matching of attribute values can leave
    # trailing junk on the same line.
    for _ in range(3):
        new = _ATTR_RE.sub(" ", text)
        if new == text:
            break
        text = new

    # 5: block tags → newline.
    text = _BLOCK_RE.sub("\n", text)

    # 6: strip remaining tags.
    text = _TAG_RE.sub(" ", text)

    # Decode the most common HTML entities.
    import html as _html
    text = _html.unescape(text)

    # 7: collapse whitespace per line, drop empty lines.
    lines = [re.sub(r"\s+", " ", ln).strip() for ln in text.splitlines()]
    lines = [ln for ln in lines if ln]

    # 8: drop stray CSS-rule fragments.
    lines = [ln for ln in lines if not _looks_like_css(ln)]
    # Also drop lines that are pure punctuation / symbols.
    lines = [ln for ln in lines if len(ln) > 2 and any(c.isalpha() for c in ln)]

    text = "\n".join(lines)

    # 9: truncate to max_bytes, on a paragraph boundary if possible.
    if len(text) > max_bytes:
        # Try to cut at a newline near the limit.
        cut = text.rfind("\n", 0, max_bytes)
        if cut < max_bytes // 2:
            cut = max_bytes
        text = text[:cut].rstrip() + "\n…(truncated)"
    return text


def _looks_like_css(line: str) -> bool:
    """Heuristic: does this line look like a CSS rule or selector?"""
    s = line.strip()
    if not s:
        return False
    # `.foo { ... }` or `#bar { ... }` or `tag { ... }`.
    if _CSS_RULE_RE.search(s):
        return True
    # Lines that are nothing but CSS selectors (no trailing block) — common
    # after our attribute-stripping mangles a multi-line rule.
    if re.match(r"^[.#]?[a-zA-Z][\w-]*(?:\s*[>+~]\s*[.#]?[a-zA-Z][\w-]*)*\s*,?\s*$", s):
        return True
    # Lines dominated by `{`, `}`, `;` and property names.
    if ";" in s and ":" in s and re.search(r"\b[a-z-]+\s*:", s) and "{" not in s:
        # Could be a long CSS property list that lost its braces.
        if re.search(r"(font|color|background|border|margin|padding|width|height"
                     r"|display|position|flex|grid|line-height|letter-spacing"
                     r"|text-align|text-decoration)", s):
            return True
    # Lines that are just CSS variable definitions: --foo: ...;
    if re.match(r"^[a-zA-Z-]+\s*:\s*var\(--", s):
        return True
    return False


# ──────────────────────────────────────────────────────────────────────────────
# Source credibility scoring — used to rank search results so official
# company blogs and major tech publications appear above SEO spam.
# ──────────────────────────────────────────────────────────────────────────────

# Tier 1: official company blogs / primary sources.  These are the most
# credible for AI news because they're the actual announcements.
_TIER1_DOMAINS = frozenset({
    "openai.com", "blog.openai.com", "openai.com",
    "anthropic.com", "www.anthropic.com",
    "google.com", "blog.google", "deepmind.google", "ai.google",
    "meta.ai", "ai.meta.com", "about.fb.com",
    "microsoft.com", "blogs.microsoft.com", "azure.microsoft.com",
    "nvidia.com", "blogs.nvidia.com",
    "apple.com", "www.apple.com",
    "x.ai", "xai.com",
    "mistral.ai", "www.mistral.ai",
    "cohere.com", "docs.cohere.com",
    "stability.ai", "www.stability.ai",
    "huggingface.co", "blog.huggingface.co",
    "ai.gov", "nist.gov",
})

# Tier 2: major tech publications with editorial standards.
_TIER2_DOMAINS = frozenset({
    "techcrunch.com", "www.techcrunch.com",
    "theverge.com", "www.theverge.com",
    "arstechnica.com", "www.arstechnica.com",
    "wired.com", "www.wired.com",
    "reuters.com", "www.reuters.com",
    "bloomberg.com", "www.bloomberg.com",
    "wsj.com", "www.wsj.com",
    "nytimes.com", "www.nytimes.com",
    "ft.com", "www.ft.com",
    "cnet.com", "www.cnet.com",
    "engadget.com", "www.engadget.com",
    "venturebeat.com", "www.venturebeat.com",
    "theinformation.com", "www.theinformation.com",
    "semianalysis.com", "www.semianalysis.com",
    "stratechery.com", "www.stratechery.com",
    "hai.stanford.edu", "ai.stanford.edu",
    "mit.edu", "www.mit.edu",
    "nature.com", "www.nature.com",
    "arxiv.org",
})

# Tier 3: known aggregators / community discussion — useful but not
# primary sources.
_TIER3_DOMAINS = frozenset({
    "news.ycombinator.com", "hn.algolia.com",
    "reddit.com", "www.reddit.com",
    "github.com", "github.blog",
    "stackoverflow.com",
    "medium.com",
    "substack.com",
    "the-decoder.com", "www.the-decoder.com",
    "artificialintelligence-news.com",
})


def _extract_domain(url: str) -> str:
    """Extract the registrable domain from a URL."""
    try:
        from urllib.parse import urlparse
        host = urlparse(url).netloc.lower()
        # Strip leading www.
        if host.startswith("www."):
            host = host[4:]
        return host
    except Exception:
        return ""


def _score_source_credibility(url: str) -> dict:
    """Score a URL's source credibility on a 0-100 scale.

    Returns a dict with:
        - "score": int 0-100 (higher = more credible)
        - "level": str ("official" | "major-publication" | "aggregator" | "unknown")
    """
    domain = _extract_domain(url)
    if not domain:
        return {"score": 10, "level": "unknown"}
    if domain in _TIER1_DOMAINS:
        return {"score": 100, "level": "official"}
    if domain in _TIER2_DOMAINS:
        return {"score": 80, "level": "major-publication"}
    if domain in _TIER3_DOMAINS:
        return {"score": 50, "level": "aggregator"}
    # Heuristic: domains with very long names or lots of hyphens are
    # often SEO spam (e.g. "best-ai-news-2026-update.blogspot.com").
    if len(domain) > 30 or domain.count("-") > 3:
        return {"score": 15, "level": "unknown"}
    if any(spam in domain for spam in (
        "blogspot", "wordpress", "medium", "tumblr", "weebly",
        "imfounder", "ai-updates", "latest-ai", "ai-news",
    )):
        return {"score": 15, "level": "unknown"}
    # Default: unknown blog/site — low but not zero.
    return {"score": 25, "level": "unknown"}
