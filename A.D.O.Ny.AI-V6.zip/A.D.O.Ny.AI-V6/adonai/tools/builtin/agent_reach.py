"""Native platform integrations — Twitter, YouTube, Reddit, Bilibili, RSS, GitHub.

All integrations are implemented natively using direct HTTP calls — no
external CLI tools (Agent Reach, yt-dlp, gh, rdt-cli, etc.) required.
Everything runs inside ADONAI's own process via httpx.

Feasibility by platform:
  ✅ RSS          — XML parsing, no dependencies
  ✅ YouTube      — scrape caption tracks from video page HTML
  ✅ GitHub       — REST API (api.github.com), no auth for public repos
  ✅ Reddit       — JSON endpoints (append .json to any Reddit URL)
  ✅ Bilibili     — public search API (api.bilibili.com)
  ⚠️ Twitter/X    — nitter mirror fallback (unreliable; official API needs auth)
  ❌ XiaoHongShu  — requires browser login, not feasible natively
  ❌ Facebook     — requires browser login
  ❌ Instagram    — requires browser login
  ❌ LinkedIn     — requires browser login

For platforms marked ❌, the tools return a clear error explaining that
browser-based login is required and suggesting the user paste content
manually or use a browser automation tool.
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import time
import xml.etree.ElementTree as ET
from typing import Any
from urllib.parse import quote_plus, urlparse, unquote

import httpx

from adonai.core.interfaces import Tool
from adonai.core.models import ToolResult
from adonai.tools.builtin.web import _score_source_credibility, _extract_domain
from adonai.tools.url_safety import DEFAULT_POLICY as _DEFAULT_URL_POLICY

log = logging.getLogger(__name__)

# Shared HTTP client — reused across all tools for connection pooling.
# Lazy-initialized on first use to avoid creating it at import time.
_http_client: httpx.AsyncClient | None = None

_DEFAULT_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
}


async def _get_client() -> httpx.AsyncClient:
    """Get or create the shared HTTP client.

    v6 fix: follow_redirects is now False. Previously it was True, which
    meant SSRF-via-redirect was open on ALL 11 agent_reach tools — a public
    URL that 302s to http://169.254.169.254/... would be followed and return
    cloud metadata credentials. Tools that need redirect-following should
    use adonai.tools.url_safety.safe_fetch() instead, which re-validates
    every redirect hop against the SSRF policy.
    """
    global _http_client
    if _http_client is None or _http_client.is_closed:
        _http_client = httpx.AsyncClient(
            timeout=httpx.Timeout(20.0, connect=10.0),
            headers=_DEFAULT_HEADERS,
            follow_redirects=False,  # v6: SSRF defense — use safe_fetch for redirects
        )
    return _http_client


async def _safe_get(
    url: str,
    *,
    extra_headers: dict[str, str] | None = None,
    timeout: float = 20.0,
) -> httpx.Response:
    """Fetch a URL with per-hop SSRF re-validation.

    v6: replaces direct _get_client().get(url) calls in agent_reach tools
    that fetch user-supplied URLs (RSS, Twitter, YouTube, Reddit). Tools
    that hit fixed API endpoints (GitHub, Bilibili search) don't need this
    because the endpoints are hardcoded and trusted.
    """
    from adonai.tools.url_safety import safe_fetch
    headers = dict(_DEFAULT_HEADERS)
    if extra_headers:
        headers.update(extra_headers)
    status, resp_headers, content, final_url = await safe_fetch(
        url, method="GET", headers=headers, timeout=timeout,
    )
    # Build a minimal httpx.Response-like object so callers can use the
    # same .status_code / .text / .headers / .url interface.
    req = httpx.Request("GET", url)
    resp = httpx.Response(
        status_code=status,
        headers=resp_headers,
        content=content,
        request=req,
    )
    # httpx.Response.url is read-only; set via private attr.
    resp._url = httpx.URL(final_url)
    return resp


def _truncate(text: str, max_chars: int = 8000) -> str:
    """Truncate text to max_chars, adding a marker if cut."""
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + "\n... (truncated)"


def _validate_url_safe(url: str, call_id: str, tool_name: str, start: float) -> ToolResult | None:
    """Validate a URL against the SSRF safety policy.

    Returns None if the URL is safe, or a failure ToolResult if it's blocked.
    All URL-fetching tools in this module MUST call this before making HTTP
    requests — previously only web_fetch/http_request/browser(Playwright)
    validated URLs, leaving RSS/Twitter/YouTube/Reddit/Bilibili/GitHub tools
    as SSRF vectors (e.g. fetching http://169.254.169.254/... for cloud
    metadata credentials).
    """
    if not url or not isinstance(url, str):
        return ToolResult(
            call_id=call_id, tool=tool_name,
            success=False, error="url is required",
            duration_s=time.time() - start,
        )
    ok, reason = _DEFAULT_URL_POLICY.validate(url)
    if not ok:
        log.warning("URL safety policy rejected url %r for tool %s: %s", url, tool_name, reason)
        return ToolResult(
            call_id=call_id, tool=tool_name,
            success=False, error=f"URL rejected by safety policy: {reason}",
            duration_s=time.time() - start,
        )
    return None


# ════════════════════════════════════════════════════════════════════════════
# RSS / Atom Feeds — native XML parsing, no feedparser dependency
# ════════════════════════════════════════════════════════════════════════════


class RSSReadTool(Tool):
    """Read an RSS or Atom feed natively (no external dependencies)."""

    name = "rss_read"
    description = (
        "Read an RSS or Atom feed and return the latest entries.  "
        "Returns entry titles, URLs, publication dates, and summaries.  "
        "Parses XML natively — no external libraries needed."
    )
    parameters = {
        "type": "object",
        "properties": {
            "url": {"type": "string", "description": "RSS/Atom feed URL"},
            "max_entries": {
                "type": "integer", "default": 10, "minimum": 1, "maximum": 50,
            },
        },
        "required": ["url"],
    }
    risk_level = "low"
    tags = ["rss", "feed", "web"]
    category = "web"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        url = (params.get("url") or "").strip()
        call_id = f"rss_{int(start*1000)}"
        # v5: validate URL against SSRF safety policy before fetching.
        failure = _validate_url_safe(url, call_id, self.name, start)
        if failure is not None:
            return failure
        max_entries = max(1, min(50, int(params.get("max_entries", 10))))
        # v6: use _safe_get for per-hop redirect re-validation (SSRF defense).
        try:
            resp = await _safe_get(url, timeout=15.0)
            resp.raise_for_status()
            xml_text = resp.text
        except ValueError as e:
            return ToolResult(
                call_id=call_id, tool=self.name,
                success=False, error=f"URL rejected by safety policy: {e}",
                duration_s=time.time() - start,
            )
        except Exception as e:
            return ToolResult(
                call_id=call_id, tool=self.name,
                success=False, error=f"fetch failed: {type(e).__name__}: {e}",
                duration_s=time.time() - start,
            )
        try:
            entries, feed_title = _parse_rss_atom(xml_text, max_entries)
        except Exception as e:
            return ToolResult(
                call_id=call_id, tool=self.name,
                success=False, error=f"parse failed: {type(e).__name__}: {e}",
                duration_s=time.time() - start,
            )
        return ToolResult(
            call_id=call_id, tool=self.name,
            success=True,
            output={"title": feed_title, "url": url,
                    "entries": entries, "count": len(entries)},
            duration_s=time.time() - start,
        )


def _parse_rss_atom(xml_text: str, max_entries: int) -> tuple[list[dict], str]:
    """Parse RSS 2.0 or Atom 1.0 XML into a list of entry dicts."""
    root = ET.fromstring(xml_text)
    entries: list[dict] = []
    feed_title = ""

    # Detect format: RSS has <rss><channel>, Atom has <feed>
    if root.tag == "rss":
        channel = root.find("channel")
        if channel is None:
            return [], ""
        feed_title = (channel.findtext("title") or "").strip()
        for item in channel.findall("item")[:max_entries]:
            entries.append({
                "title": (item.findtext("title") or "").strip(),
                "url": (item.findtext("link") or "").strip(),
                "published": (item.findtext("pubDate") or "").strip(),
                "summary": _truncate(
                    re.sub(r"<[^>]+>", "",
                           item.findtext("description") or ""), 500),
            })
    elif root.tag.endswith("feed"):  # Atom: {http://www.w3.org/2005/Atom}feed
        feed_title = (root.findtext("title") or
                       root.findtext("{*}title") or "").strip()
        # Atom entries — handle both bare and namespaced tags
        for entry in root.findall("entry")[:max_entries] or \
                      root.findall("{*}entry")[:max_entries]:
            title = (entry.findtext("title") or
                     entry.findtext("{*}title") or "").strip()
            # Atom links use href attribute
            link = ""
            link_el = entry.find("link") or entry.find("{*}link")
            if link_el is not None:
                link = link_el.get("href", "") or link_el.text or ""
            published = (entry.findtext("published") or
                         entry.findtext("{*}published") or
                         entry.findtext("updated") or
                         entry.findtext("{*}updated") or "").strip()
            summary = (entry.findtext("summary") or
                       entry.findtext("{*}summary") or
                       entry.findtext("content") or
                       entry.findtext("{*}content") or "").strip()
            entries.append({
                "title": title, "url": link,
                "published": published,
                "summary": _truncate(re.sub(r"<[^>]+>", "", summary), 500),
            })
    else:
        raise ValueError(f"Unknown feed format: root tag = {root.tag}")

    return entries, feed_title


# ════════════════════════════════════════════════════════════════════════════
# YouTube — native subtitle extraction (no yt-dlp)
# ════════════════════════════════════════════════════════════════════════════


class YouTubeSubtitlesTool(Tool):
    """Extract YouTube video subtitles natively (no yt-dlp)."""

    name = "youtube_subtitles"
    description = (
        "Extract subtitles or transcript from a YouTube video.  Fetches "
        "the video page, extracts caption track URLs, downloads the VTT "
        "file, and parses it to plain text.  No external tools needed."
    )
    parameters = {
        "type": "object",
        "properties": {
            "url": {"type": "string", "description": "YouTube video URL"},
            "lang": {
                "type": "string", "default": "en",
                "description": "Preferred subtitle language code (en, zh, ja, etc.)",
            },
        },
        "required": ["url"],
    }
    risk_level = "low"
    tags = ["youtube", "video", "media"]
    category = "media"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        url = (params.get("url") or "").strip()
        call_id = f"yt_{int(start*1000)}"
        # v5: validate URL against SSRF safety policy.
        failure = _validate_url_safe(url, call_id, self.name, start)
        if failure is not None:
            return failure
        lang = params.get("lang", "en")
        # Extract video ID from various YouTube URL formats.
        video_id = _extract_youtube_id(url)
        if not video_id:
            return ToolResult(
                call_id=call_id, tool=self.name,
                success=False, error=f"Could not extract video ID from URL: {url}",
                duration_s=time.time() - start,
            )
        client = await _get_client()
        # Fetch the video page and extract caption track URLs from the
        # embedded ytInitialPlayerResponse JSON.
        # v6: use _safe_get for per-hop redirect re-validation (SSRF defense).
        try:
            resp = await _safe_get(
                f"https://www.youtube.com/watch?v={video_id}",
                timeout=15.0,
            )
            resp.raise_for_status()
            page_html = resp.text
        except ValueError as e:
            return ToolResult(
                call_id=call_id, tool=self.name,
                success=False, error=f"URL rejected by safety policy: {e}",
                duration_s=time.time() - start,
            )
        except Exception as e:
            return ToolResult(
                call_id=call_id, tool=self.name,
                success=False, error=f"Failed to fetch video page: {e}",
                duration_s=time.time() - start,
            )
        # Find captionTracks in the embedded JSON.
        caption_tracks = _extract_caption_tracks(page_html)
        if not caption_tracks:
            return ToolResult(
                call_id=f"yt_{int(start*1000)}", tool=self.name,
                success=False,
                error="No captions found for this video (it may not have subtitles)",
                duration_s=time.time() - start,
            )
        # Pick the best matching track (preferred lang, else first).
        chosen = None
        for track in caption_tracks:
            if track.get("languageCode", "").startswith(lang):
                chosen = track
                break
        if not chosen:
            chosen = caption_tracks[0]
        # Download the caption file.
        caption_url = chosen.get("baseUrl", "")
        if not caption_url:
            return ToolResult(
                call_id=f"yt_{int(start*1000)}", tool=self.name,
                success=False, error="Caption track found but no URL available",
                duration_s=time.time() - start,
            )
        try:
            resp = await client.get(caption_url, timeout=15.0)
            resp.raise_for_status()
            caption_raw = resp.text
        except Exception as e:
            return ToolResult(
                call_id=f"yt_{int(start*1000)}", tool=self.name,
                success=False, error=f"Failed to download captions: {e}",
                duration_s=time.time() - start,
            )
        # Parse VTT/XML to plain text.
        transcript = _parse_youtube_captions(caption_raw)
        return ToolResult(
            call_id=f"yt_{int(start*1000)}", tool=self.name,
            success=True,
            output={"url": url, "video_id": video_id,
                    "lang": chosen.get("languageCode", lang),
                    "transcript": _truncate(transcript, 12000)},
            duration_s=time.time() - start,
        )


def _extract_youtube_id(url: str) -> str:
    """Extract the 11-char video ID from a YouTube URL."""
    patterns = [
        r"(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/|youtube\.com/shorts/)([A-Za-z0-9_-]{11})",
        r"youtube\.com/watch.*[?&]v=([A-Za-z0-9_-]{11})",
    ]
    for pat in patterns:
        m = re.search(pat, url)
        if m:
            return m.group(1)
    return ""


def _extract_caption_tracks(html: str) -> list[dict]:
    """Extract captionTracks from the embedded ytInitialPlayerResponse."""
    # The caption tracks are in a JSON blob like:
    # "captionTracks":[{"baseUrl":"https://...","name":{"runs":[{"text":"English"}]},"vssId":".en","languageCode":"en",...}]
    m = re.search(r'"captionTracks":(\[.*?\])', html)
    if not m:
        return []
    try:
        tracks = json.loads(m.group(1))
        return tracks if isinstance(tracks, list) else []
    except json.JSONDecodeError:
        return []


def _parse_youtube_captions(raw: str) -> str:
    """Parse YouTube caption output (VTT, XML, or JSON3) to plain text."""
    # JSON3 format (most common now): {"events":[{"segs":[{"utf8":"text"}]},...]}
    if raw.strip().startswith("{"):
        try:
            data = json.loads(raw)
            lines: list[str] = []
            for event in data.get("events", []):
                segs = event.get("segs", [])
                text = "".join(s.get("utf8", "") for s in segs)
                if text.strip():
                    lines.append(text.strip())
            return " ".join(lines)
        except json.JSONDecodeError:
            pass
    # XML format: <transcript><text start="0" dur="1.0">Hello</text>...</transcript>
    if "<transcript>" in raw or "<text " in raw:
        try:
            root = ET.fromstring(raw)
            texts = [el.text or "" for el in root.iter("text")]
            return " ".join(t.strip() for t in texts if t.strip())
        except ET.ParseError:
            pass
    # VTT format — strip timestamps and tags.
    return _strip_vtt(raw)


def _strip_vtt(raw: str) -> str:
    """Strip VTT formatting to plain text."""
    raw = re.sub(r"^WEBVTT.*?\n\n", "", raw, flags=re.DOTALL)
    raw = re.sub(
        r"\d{2}:\d{2}:\d{2}[.,]\d{3}\s*-->\s*\d{2}:\d{2}:\d{2}[.,]\d{3}.*\n",
        "", raw,
    )
    raw = re.sub(r"^\d+\s*\n", "", raw, flags=re.MULTILINE)
    raw = re.sub(r"<[^>]+>", "", raw)
    lines = raw.splitlines()
    seen: set[str] = set()
    unique: list[str] = []
    for line in lines:
        s = line.strip()
        if s and s not in seen:
            seen.add(s)
            unique.append(s)
    return " ".join(unique)


# ════════════════════════════════════════════════════════════════════════════
# GitHub — native REST API (no gh CLI)
# ════════════════════════════════════════════════════════════════════════════


class GitHubSearchTool(Tool):
    """Search GitHub via REST API (no gh CLI needed)."""

    name = "github_search"
    description = (
        "Search GitHub for repositories, issues, or code via the REST "
        "API.  Returns names, URLs, descriptions, and stars.  No "
        "authentication required for public repos (rate-limited to 60 "
        "req/hour without a token)."
    )
    parameters = {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Search query"},
            "type": {
                "type": "string", "default": "repositories",
                "enum": ["repositories", "issues", "code"],
            },
            "max_results": {
                "type": "integer", "default": 10, "minimum": 1, "maximum": 30,
            },
        },
        "required": ["query"],
    }
    risk_level = "low"
    tags = ["github", "code", "search"]
    category = "developer"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        query = (params.get("query") or "").strip()
        if not query:
            return ToolResult(
                call_id=f"gh_{int(start*1000)}", tool=self.name,
                success=False, error="query is required",
                duration_s=time.time() - start,
            )
        search_type = params.get("type", "repositories")
        max_results = max(1, min(30, int(params.get("max_results", 10))))
        client = await _get_client()
        endpoint = f"https://api.github.com/search/{search_type}"
        try:
            resp = await client.get(
                endpoint,
                params={"q": query, "per_page": max_results},
                headers={"Accept": "application/vnd.github.v3+json"},
                timeout=15.0,
            )
            if resp.status_code == 403:
                return ToolResult(
                    call_id=f"gh_{int(start*1000)}", tool=self.name,
                    success=False,
                    error="GitHub API rate limit exceeded (60 req/hour without auth). "
                          "Set GITHUB_TOKEN env var for higher limits.",
                    duration_s=time.time() - start,
                )
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            return ToolResult(
                call_id=f"gh_{int(start*1000)}", tool=self.name,
                success=False, error=f"GitHub API failed: {type(e).__name__}: {e}",
                duration_s=time.time() - start,
            )
        # Normalize results based on type.
        items = data.get("items", [])
        results = []
        for item in items[:max_results]:
            if search_type == "repositories":
                results.append({
                    "name": item.get("full_name", ""),
                    "url": item.get("html_url", ""),
                    "description": item.get("description", ""),
                    "stars": item.get("stargazers_count", 0),
                    "language": item.get("language", ""),
                })
            elif search_type == "issues":
                results.append({
                    "title": item.get("title", ""),
                    "url": item.get("html_url", ""),
                    "state": item.get("state", ""),
                    "repository": item.get("repository_url", "").split("/")[-1],
                })
            elif search_type == "code":
                results.append({
                    "name": item.get("name", ""),
                    "url": item.get("html_url", ""),
                    "repository": item.get("repository", {}).get("full_name", ""),
                    "path": item.get("path", ""),
                })
        return ToolResult(
            call_id=f"gh_{int(start*1000)}", tool=self.name,
            success=True,
            output={"query": query, "type": search_type,
                    "results": results, "count": len(results),
                    "total": data.get("total_count", 0)},
            duration_s=time.time() - start,
        )


class GitHubRepoReadTool(Tool):
    """Read a GitHub repo's README and metadata via REST API."""

    name = "github_repo_read"
    description = (
        "Read a GitHub repository's README, description, stars, and "
        "metadata via the REST API.  Returns the full README text.  "
        "No authentication required for public repos."
    )
    parameters = {
        "type": "object",
        "properties": {
            "repo": {
                "type": "string",
                "description": "Repository in owner/name format (e.g. 'Panniantong/Agent-Reach')",
            },
        },
        "required": ["repo"],
    }
    risk_level = "low"
    tags = ["github", "code"]
    category = "developer"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        repo = (params.get("repo") or "").strip()
        if not repo or "/" not in repo:
            return ToolResult(
                call_id=f"gr_{int(start*1000)}", tool=self.name,
                success=False, error="repo is required (format: owner/name)",
                duration_s=time.time() - start,
            )
        client = await _get_client()
        # Fetch repo metadata.
        try:
            resp = await client.get(
                f"https://api.github.com/repos/{repo}",
                headers={"Accept": "application/vnd.github.v3+json"},
                timeout=15.0,
            )
            if resp.status_code == 404:
                return ToolResult(
                    call_id=f"gr_{int(start*1000)}", tool=self.name,
                    success=False, error=f"Repository not found: {repo}",
                    duration_s=time.time() - start,
                )
            resp.raise_for_status()
            meta = resp.json()
        except Exception as e:
            return ToolResult(
                call_id=f"gr_{int(start*1000)}", tool=self.name,
                success=False, error=f"GitHub API failed: {type(e).__name__}: {e}",
                duration_s=time.time() - start,
            )
        # Fetch README.
        readme_text = ""
        try:
            resp = await client.get(
                f"https://api.github.com/repos/{repo}/readme",
                headers={"Accept": "application/vnd.github.v3.raw"},
                timeout=15.0,
            )
            if resp.status_code == 200:
                readme_text = resp.text
        except Exception:
            pass  # README fetch is best-effort
        # Strip code fences for readability.
        readme_clean = re.sub(r"```[^\n]*\n", "", readme_text)
        readme_clean = re.sub(r"```", "", readme_clean)
        return ToolResult(
            call_id=f"gr_{int(start*1000)}", tool=self.name,
            success=True,
            output={
                "repo": repo,
                "metadata": {
                    "name": meta.get("full_name", ""),
                    "url": meta.get("html_url", ""),
                    "description": meta.get("description", ""),
                    "stars": meta.get("stargazers_count", 0),
                    "language": meta.get("language", ""),
                    "license": (meta.get("license") or {}).get("name", ""),
                    "topics": meta.get("topics", []),
                },
                "readme": _truncate(readme_clean, 12000),
            },
            duration_s=time.time() - start,
        )


# ════════════════════════════════════════════════════════════════════════════
# Reddit — native JSON endpoints (no rdt-cli / opencli)
# ════════════════════════════════════════════════════════════════════════════


class RedditSearchTool(Tool):
    """Search Reddit via JSON endpoints (no auth needed)."""

    name = "reddit_search"
    description = (
        "Search Reddit for posts matching a query.  Returns post titles, "
        "URLs, subreddits, scores, and snippet.  Uses Reddit's public "
        "JSON endpoints — no authentication required (rate-limited)."
    )
    parameters = {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Search query"},
            "subreddit": {
                "type": "string",
                "description": "Optional: limit search to a specific subreddit",
            },
            "max_results": {
                "type": "integer", "default": 10, "minimum": 1, "maximum": 25,
            },
        },
        "required": ["query"],
    }
    risk_level = "low"
    tags = ["reddit", "social", "search"]
    category = "social"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        query = (params.get("query") or "").strip()
        if not query:
            return ToolResult(
                call_id=f"rs_{int(start*1000)}", tool=self.name,
                success=False, error="query is required",
                duration_s=time.time() - start,
            )
        max_results = max(1, min(25, int(params.get("max_results", 10))))
        subreddit = (params.get("subreddit") or "").strip()
        client = await _get_client()
        # Build the search URL.  Reddit supports .json endpoint.
        if subreddit:
            url = f"https://www.reddit.com/r/{subreddit}/search.json"
            params_dict = {"q": query, "restrict_sr": "on", "limit": max_results,
                          "sort": "relevance"}
        else:
            url = "https://www.reddit.com/search.json"
            params_dict = {"q": query, "limit": max_results, "sort": "relevance"}
        # Reddit blocks generic user agents — use a realistic browser UA
        # and visit the main page first to establish a session cookie.
        reddit_headers = {
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "en-US,en;q=0.9",
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
        }
        try:
            # Visit the main page first to get session cookies.
            try:
                await client.get("https://www.reddit.com/", timeout=8.0,
                                headers=reddit_headers)
            except Exception:
                pass  # best-effort cookie warming
            resp = await client.get(url, params=params_dict, timeout=15.0,
                                    headers=reddit_headers)
            if resp.status_code == 429:
                return ToolResult(
                    call_id=f"rs_{int(start*1000)}", tool=self.name,
                    success=False,
                    error="Reddit rate limit exceeded. Please wait a moment and try again.",
                    duration_s=time.time() - start,
                )
            if resp.status_code == 403:
                # Reddit blocks server IPs aggressively.  Fall back to
                # DuckDuckGo site:reddit.com search — this actually works
                # and returns Reddit content.
                return await self._fallback_to_ddg(query, subreddit, max_results, start)
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            return ToolResult(
                call_id=f"rs_{int(start*1000)}", tool=self.name,
                success=False, error=f"Reddit search failed: {type(e).__name__}: {e}",
                duration_s=time.time() - start,
            )
        # Parse Reddit's JSON structure.
        results = []
        children = data.get("data", {}).get("children", [])
        for child in children[:max_results]:
            post = child.get("data", {})
            results.append({
                "title": post.get("title", ""),
                "url": post.get("url", ""),
                "permalink": f"https://www.reddit.com{post.get('permalink', '')}",
                "subreddit": post.get("subreddit_name_prefixed", ""),
                "score": post.get("score", 0),
                "num_comments": post.get("num_comments", 0),
                "author": post.get("author", ""),
                "created_utc": post.get("created_utc", 0),
                "selftext": _truncate(post.get("selftext", ""), 500),
            })
        return ToolResult(
            call_id=f"rs_{int(start*1000)}", tool=self.name,
            success=True,
            output={"query": query, "subreddit": subreddit or None,
                    "results": results, "count": len(results)},
            duration_s=time.time() - start,
        )

    async def _fallback_to_ddg(
        self, query: str, subreddit: str, max_results: int, start: float,
    ) -> ToolResult:
        """Fall back to DuckDuckGo site:reddit.com search when Reddit blocks us."""
        from adonai.tools.builtin.web import WebSearchTool
        ddg_query = f"site:reddit.com {query}"
        if subreddit:
            ddg_query = f"site:reddit.com/r/{subreddit} {query}"
        ddg = WebSearchTool()
        ddg_result = await ddg.execute(query=ddg_query, max_results=max_results)
        if ddg_result.success and isinstance(ddg_result.output, dict):
            results = []
            for r in ddg_result.output.get("results", [])[:max_results]:
                results.append({
                    "title": r.get("title", ""),
                    "url": r.get("url", ""),
                    "permalink": r.get("url", ""),
                    "subreddit": "",
                    "score": 0,
                    "num_comments": 0,
                    "author": "",
                    "selftext": r.get("snippet", ""),
                    "_source": "duckduckgo_fallback",
                })
            return ToolResult(
                call_id=f"rs_{int(start*1000)}", tool=self.name,
                success=True,
                output={"query": query, "subreddit": subreddit or None,
                        "results": results, "count": len(results),
                        "source": "duckduckgo_fallback (Reddit API blocked server IP)"},
                duration_s=time.time() - start,
            )
        return ToolResult(
            call_id=f"rs_{int(start*1000)}", tool=self.name,
            success=False,
            error="Reddit API blocked (403) and DuckDuckGo fallback also failed.",
            duration_s=time.time() - start,
        )


class RedditReadTool(Tool):
    """Read a Reddit post and its comments via JSON endpoint."""

    name = "reddit_read"
    description = (
        "Read a Reddit post and its comments.  Returns the post body "
        "and top comments.  Uses Reddit's public JSON endpoint — no "
        "authentication required."
    )
    parameters = {
        "type": "object",
        "properties": {
            "url": {"type": "string", "description": "Reddit post URL"},
            "max_comments": {
                "type": "integer", "default": 20, "minimum": 1, "maximum": 50,
            },
        },
        "required": ["url"],
    }
    risk_level = "low"
    tags = ["reddit", "social"]
    category = "social"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        url = (params.get("url") or "").strip()
        call_id = f"rr_{int(start*1000)}"
        # v5: validate URL against SSRF safety policy.
        failure = _validate_url_safe(url, call_id, self.name, start)
        if failure is not None:
            return failure
        max_comments = max(1, min(50, int(params.get("max_comments", 20))))
        # Append .json to the Reddit URL to get JSON output.
        json_url = url.rstrip("/") + "/.json"
        # v6: use _safe_get for per-hop redirect re-validation (SSRF defense).
        try:
            resp = await _safe_get(
                json_url, timeout=15.0,
                extra_headers={"Accept": "application/json"},
            )
            if resp.status_code == 429:
                return ToolResult(
                    call_id=call_id, tool=self.name,
                    success=False, error="Reddit rate limit exceeded.",
                    duration_s=time.time() - start,
                )
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            return ToolResult(
                call_id=call_id, tool=self.name,
                success=False, error=f"Reddit read failed: {type(e).__name__}: {e}",
                duration_s=time.time() - start,
            )
        # Reddit returns an array: [post_listing, comments_listing]
        if not isinstance(data, list) or len(data) < 2:
            return ToolResult(
                call_id=call_id, tool=self.name,
                success=False, error="Unexpected Reddit JSON structure",
                duration_s=time.time() - start,
            )
        # Extract post.
        post_data = data[0].get("data", {}).get("children", [])
        if not post_data:
            return ToolResult(
                call_id=call_id, tool=self.name,
                success=False, error="Post not found",
                duration_s=time.time() - start,
            )
        post = post_data[0].get("data", {})
        # Extract comments.
        comments = []
        comment_children = data[1].get("data", {}).get("children", [])
        for child in comment_children[:max_comments]:
            c = child.get("data", {})
            comments.append({
                "author": c.get("author", ""),
                "score": c.get("score", 0),
                "body": _truncate(c.get("body", ""), 1000),
            })
        return ToolResult(
            call_id=f"rr_{int(start*1000)}", tool=self.name,
            success=True,
            output={
                "url": url,
                "post": {
                    "title": post.get("title", ""),
                    "author": post.get("author", ""),
                    "subreddit": post.get("subreddit_name_prefixed", ""),
                    "score": post.get("score", 0),
                    "body": _truncate(post.get("selftext", ""), 5000),
                    "num_comments": post.get("num_comments", 0),
                },
                "comments": comments,
                "comment_count": len(comments),
            },
            duration_s=time.time() - start,
        )


# ════════════════════════════════════════════════════════════════════════════
# Bilibili — native public search API (no bili-cli)
# ════════════════════════════════════════════════════════════════════════════


class BilibiliSearchTool(Tool):
    """Search Bilibili via public API (no login needed)."""

    name = "bilibili_search"
    description = (
        "Search Bilibili (B站) for videos via the public search API.  "
        "Returns video titles, URLs, view counts, and uploaders.  No "
        "login required.  Uses api.bilibili.com directly."
    )
    parameters = {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Search query"},
            "max_results": {
                "type": "integer", "default": 10, "minimum": 1, "maximum": 20,
            },
        },
        "required": ["query"],
    }
    risk_level = "low"
    tags = ["bilibili", "video", "search"]
    category = "media"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        query = (params.get("query") or "").strip()
        if not query:
            return ToolResult(
                call_id=f"bs_{int(start*1000)}", tool=self.name,
                success=False, error="query is required",
                duration_s=time.time() - start,
            )
        max_results = max(1, min(20, int(params.get("max_results", 10))))
        client = await _get_client()
        # Bilibili's API requires cookies from the main page (buvid3 etc.)
        # to avoid 412 Precondition Failed.  Visit bilibili.com first to
        # establish a session, then call the API.
        bili_headers = {
            "Accept": "application/json, text/plain, */*",
            "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
            "Referer": "https://www.bilibili.com",
            "Origin": "https://www.bilibili.com",
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0.0.0 Safari/537.36"
            ),
        }
        try:
            # Warm up cookies by visiting the main page.
            try:
                await client.get("https://www.bilibili.com", timeout=8.0,
                                headers=bili_headers)
            except Exception:
                pass  # best-effort
            resp = await client.get(
                "https://api.bilibili.com/x/web-interface/search/type",
                params={
                    "search_type": "video",
                    "keyword": query,
                    "page": 1,
                    "page_size": max_results,
                },
                headers=bili_headers,
                timeout=15.0,
            )
            if resp.status_code == 412:
                # Bilibili anti-scraping — fall back to DuckDuckGo.
                return await self._fallback_to_ddg(query, max_results, start)
            resp.raise_for_status()
            # Check if we got HTML instead of JSON (anti-bot redirect).
            content_type = resp.headers.get("content-type", "")
            if "html" in content_type or not resp.text.strip().startswith("{"):
                return await self._fallback_to_ddg(query, max_results, start)
            data = resp.json()
        except Exception as e:
            # Any exception — try DDG fallback before giving up.
            return await self._fallback_to_ddg(query, max_results, start)
        if data.get("code") != 0:
            return await self._fallback_to_ddg(query, max_results, start)
        results = []
        for item in (data.get("data", {}).get("result") or [])[:max_results]:
            # Bilibili wraps keywords in <em class="keyword"> tags — strip them.
            title = re.sub(r"<[^>]+>", "", item.get("title", ""))
            results.append({
                "title": title,
                "url": item.get("arcurl", ""),
                "bvid": item.get("bvid", ""),
                "uploader": item.get("author", ""),
                "play_count": item.get("play", 0),
                "danmaku_count": item.get("video_review", 0),
                "duration": item.get("duration", ""),
                "description": _truncate(
                    re.sub(r"<[^>]+>", "", item.get("description", "")), 300),
            })
        return ToolResult(
            call_id=f"bs_{int(start*1000)}", tool=self.name,
            success=True,
            output={"query": query, "results": results, "count": len(results)},
            duration_s=time.time() - start,
        )

    async def _fallback_to_ddg(
        self, query: str, max_results: int, start: float,
    ) -> ToolResult:
        """Fall back to DuckDuckGo site:bilibili.com search when API blocks us."""
        from adonai.tools.builtin.web import WebSearchTool
        ddg = WebSearchTool()
        ddg_result = await ddg.execute(
            query=f"site:bilibili.com {query}", max_results=max_results,
        )
        if ddg_result.success and isinstance(ddg_result.output, dict):
            results = []
            for r in ddg_result.output.get("results", [])[:max_results]:
                results.append({
                    "title": r.get("title", ""),
                    "url": r.get("url", ""),
                    "bvid": "",
                    "uploader": "",
                    "play_count": 0,
                    "danmaku_count": 0,
                    "duration": "",
                    "description": r.get("snippet", ""),
                    "_source": "duckduckgo_fallback",
                })
            return ToolResult(
                call_id=f"bs_{int(start*1000)}", tool=self.name,
                success=True,
                output={"query": query, "results": results,
                        "count": len(results),
                        "source": "duckduckgo_fallback (Bilibili API blocked)"},
                duration_s=time.time() - start,
            )
        return ToolResult(
            call_id=f"bs_{int(start*1000)}", tool=self.name,
            success=False,
            error="Bilibili API blocked and DuckDuckGo fallback also failed.",
            duration_s=time.time() - start,
        )


# ════════════════════════════════════════════════════════════════════════════
# Twitter/X — nitter mirror fallback (no official auth)
# ════════════════════════════════════════════════════════════════════════════


# Public nitter instances — these are community-maintained Twitter mirrors.
# They're unreliable (go up and down frequently), so we try multiple ones.
_NITTER_INSTANCES = [
    "https://nitter.net",
    "https://nitter.privacydev.net",
    "https://nitter.poast.org",
    "https://nitter.cz",
]


class TwitterReadTool(Tool):
    """Read a single tweet via nitter mirrors (no official auth)."""

    name = "twitter_read"
    description = (
        "Read a single tweet by its URL.  Uses public nitter mirrors as "
        "a fallback since Twitter's official API requires authentication.  "
        "Returns the tweet text, author, and date.  Note: nitter mirrors "
        "can be unreliable — if all fail, the tool returns an error."
    )
    parameters = {
        "type": "object",
        "properties": {
            "tweet_url": {
                "type": "string",
                "description": "Tweet URL (https://x.com/user/status/123 or https://twitter.com/...)",
            },
        },
        "required": ["tweet_url"],
    }
    risk_level = "low"
    tags = ["twitter", "social"]
    category = "social"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        tweet_url = (params.get("tweet_url") or "").strip()
        call_id = f"tw_{int(start*1000)}"
        # v5: validate URL against SSRF safety policy.
        failure = _validate_url_safe(tweet_url, call_id, self.name, start)
        if failure is not None:
            return failure
        # Convert twitter.com/x.com URL to a nitter URL.
        status_match = re.search(
            r"(?:twitter\.com|x\.com)/([^/]+)/status/(\d+)", tweet_url,
        )
        if not status_match:
            return ToolResult(
                call_id=f"tw_{int(start*1000)}", tool=self.name,
                success=False, error=f"Could not parse tweet URL: {tweet_url}",
                duration_s=time.time() - start,
            )
        username, status_id = status_match.groups()
        client = await _get_client()
        # Try each nitter instance until one works.
        for instance in _NITTER_INSTANCES:
            nitter_url = f"{instance}/{username}/status/{status_id}"
            try:
                resp = await client.get(nitter_url, timeout=10.0)
                if resp.status_code != 200:
                    continue
                html = resp.text
                # Parse the tweet from nitter's HTML.
                tweet_data = _parse_nitter_tweet(html, username, status_id)
                if tweet_data:
                    tweet_data["url"] = tweet_url
                    tweet_data["source"] = f"nitter ({instance})"
                    return ToolResult(
                        call_id=f"tw_{int(start*1000)}", tool=self.name,
                        success=True, output=tweet_data,
                        duration_s=time.time() - start,
                    )
            except Exception:
                continue
        return ToolResult(
            call_id=f"tw_{int(start*1000)}", tool=self.name,
            success=False,
            error=(
                "All nitter mirrors failed or are unavailable.  Twitter's "
                "official API requires authentication.  To read tweets "
                "natively, you can: (1) try again later when mirrors are up, "
                "(2) paste the tweet text manually, or (3) set up a Twitter "
                "API bearer token in the TWITTER_BEARER_TOKEN env var."
            ),
            duration_s=time.time() - start,
        )


def _parse_nitter_tweet(html: str, username: str, status_id: str) -> dict | None:
    """Extract tweet text from a nitter page's HTML."""
    # Nitter tweets are in <div class="tweet-content">...</div>
    m = re.search(
        r'<div class="tweet-content[^"]*"[^>]*>(.*?)</div>',
        html, re.DOTALL,
    )
    if not m:
        return None
    text = re.sub(r"<[^>]+>", "", m.group(1)).strip()
    # Try to extract the date.
    date_match = re.search(
        r'<span class="tweet-date[^"]*"[^>]*><a[^>]*title="([^"]+)"',
        html,
    )
    date = date_match.group(1) if date_match else ""
    return {
        "username": username,
        "status_id": status_id,
        "text": _truncate(text, 2000),
        "date": date,
    }


class TwitterSearchTool(Tool):
    """Search Twitter via nitter (limited, unreliable)."""

    name = "twitter_search"
    description = (
        "Search Twitter/X for tweets.  Uses public nitter mirrors as a "
        "fallback.  WARNING: nitter search is unreliable and may not "
        "return results.  For reliable Twitter search, set the "
        "TWITTER_BEARER_TOKEN environment variable."
    )
    parameters = {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Search query"},
            "max_results": {
                "type": "integer", "default": 10, "minimum": 1, "maximum": 20,
            },
        },
        "required": ["query"],
    }
    risk_level = "low"
    tags = ["twitter", "social", "search"]
    category = "social"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        query = (params.get("query") or "").strip()
        if not query:
            return ToolResult(
                call_id=f"ts_{int(start*1000)}", tool=self.name,
                success=False, error="query is required",
                duration_s=time.time() - start,
            )
        max_results = max(1, min(20, int(params.get("max_results", 10))))
        # Check for Twitter API bearer token.
        import os
        bearer = os.environ.get("TWITTER_BEARER_TOKEN", "")
        if bearer:
            return await self._search_via_api(query, max_results, bearer, start)
        # Fall back to nitter.
        return await self._search_via_nitter(query, max_results, start)

    async def _search_via_api(
        self, query: str, max_results: int, bearer: str, start: float,
    ) -> ToolResult:
        """Search via official Twitter API v2 (requires bearer token)."""
        client = await _get_client()
        try:
            resp = await client.get(
                "https://api.twitter.com/2/tweets/search/recent",
                params={"query": query, "max_results": max_results,
                       "tweet.fields": "created_at,author_id,public_metrics"},
                headers={"Authorization": f"Bearer {bearer}"},
                timeout=15.0,
            )
            resp.raise_for_status()
            data = resp.json()
        except Exception as e:
            return ToolResult(
                call_id=f"ts_{int(start*1000)}", tool=self.name,
                success=False, error=f"Twitter API failed: {type(e).__name__}: {e}",
                duration_s=time.time() - start,
            )
        results = []
        for tweet in data.get("data", [])[:max_results]:
            results.append({
                "id": tweet.get("id", ""),
                "text": tweet.get("text", ""),
                "author_id": tweet.get("author_id", ""),
                "created_at": tweet.get("created_at", ""),
                "metrics": tweet.get("public_metrics", {}),
                "url": f"https://x.com/i/web/status/{tweet.get('id', '')}",
            })
        return ToolResult(
            call_id=f"ts_{int(start*1000)}", tool=self.name,
            success=True,
            output={"query": query, "results": results, "count": len(results),
                    "source": "twitter_api_v2"},
            duration_s=time.time() - start,
        )

    async def _search_via_nitter(
        self, query: str, max_results: int, start: float,
    ) -> ToolResult:
        """Search via nitter mirrors (unreliable fallback)."""
        client = await _get_client()
        for instance in _NITTER_INSTANCES:
            try:
                resp = await client.get(
                    f"{instance}/search",
                    params={"f": "tweets", "q": query},
                    timeout=10.0,
                )
                if resp.status_code != 200:
                    continue
                html = resp.text
                tweets = _parse_nitter_search(html, max_results)
                if tweets:
                    return ToolResult(
                        call_id=f"ts_{int(start*1000)}", tool=self.name,
                        success=True,
                        output={"query": query, "results": tweets,
                                "count": len(tweets),
                                "source": f"nitter ({instance})"},
                        duration_s=time.time() - start,
                    )
            except Exception:
                continue
        return ToolResult(
            call_id=f"ts_{int(start*1000)}", tool=self.name,
            success=False,
            error=(
                "Twitter search failed: all nitter mirrors are unavailable, "
                "and no TWITTER_BEARER_TOKEN env var is set.  For reliable "
                "search, set TWITTER_BEARER_TOKEN (see "
                "https://developer.twitter.com/en/portal/products)."
            ),
            duration_s=time.time() - start,
        )


def _parse_nitter_search(html: str, max_results: int) -> list[dict]:
    """Parse tweet results from a nitter search page."""
    # Each tweet is in a <div class="timeline-item">
    items = re.findall(
        r'<div class="timeline-item[^"]*"[^>]*>(.*?)</div>\s*</div>\s*</div>',
        html, re.DOTALL,
    )
    tweets = []
    for item in items[:max_results]:
        text_match = re.search(
            r'<div class="tweet-content[^"]*"[^>]*>(.*?)</div>',
            item, re.DOTALL,
        )
        if not text_match:
            continue
        text = re.sub(r"<[^>]+>", "", text_match.group(1)).strip()
        username_match = re.search(r'<a[^>]+class="username"[^>]*>@([^<]+)<', item)
        username = username_match.group(1) if username_match else ""
        tweets.append({
            "text": _truncate(text, 500),
            "username": username,
            "url": "",
        })
    return tweets


# ════════════════════════════════════════════════════════════════════════════
# XiaoHongShu — requires browser login (not feasible natively)
# ════════════════════════════════════════════════════════════════════════════


class XiaoHongShuSearchTool(Tool):
    """XiaoHongShu search — requires browser login (not natively feasible)."""

    name = "xiaohongshu_search"
    description = (
        "Search XiaoHongShu (小红书).  WARNING: XiaoHongShu requires "
        "browser-based login and has aggressive anti-scraping — it "
        "cannot be accessed natively via HTTP.  This tool will return "
        "an error explaining the limitation.  To search XiaoHongShu, "
        "either (1) use a browser automation tool, (2) paste the "
        "content manually, or (3) install the Agent Reach CLI which "
        "handles browser session reuse."
    )
    parameters = {
        "type": "object",
        "properties": {
            "query": {"type": "string", "description": "Search query"},
            "max_results": {
                "type": "integer", "default": 10, "minimum": 1, "maximum": 20,
            },
        },
        "required": ["query"],
    }
    risk_level = "low"
    tags = ["xiaohongshu", "social", "search"]
    category = "social"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        return ToolResult(
            call_id=f"xs_{int(start*1000)}", tool=self.name,
            success=False,
            error=(
                "XiaoHongShu requires browser-based login and cannot be "
                "accessed natively via HTTP (aggressive anti-scraping).  "
                "Options: (1) use the 'browser' tool to navigate and "
                "extract content manually, (2) paste the content you want "
                "analyzed, or (3) install Agent Reach CLI which handles "
                "browser session reuse: pipx install https://github.com/"
                "Panniantong/agent-reach/archive/main.zip"
            ),
            duration_s=time.time() - start,
        )


# ════════════════════════════════════════════════════════════════════════════
# Diagnostics
# ════════════════════════════════════════════════════════════════════════════


class PlatformDiagnosticsTool(Tool):
    """Check which native platform integrations are available."""

    name = "platform_diagnostics"
    description = (
        "Check which native platform integrations (Twitter, YouTube, "
        "Reddit, Bilibili, RSS, GitHub) are available and working.  "
        "Tests each platform with a lightweight request and reports "
        "status.  Use this to diagnose why a platform tool is failing."
    )
    parameters = {
        "type": "object",
        "properties": {},
    }
    risk_level = "low"
    tags = ["diagnostics"]
    category = "system"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        client = await _get_client()
        results = {}
        # Test each platform.
        tests = [
            ("github", "https://api.github.com/rate_limit", None),
            ("reddit", "https://www.reddit.com/.json", {"limit": 1}),
            ("bilibili", "https://api.bilibili.com/x/web-interface/search/type",
             {"search_type": "video", "keyword": "test", "page_size": 1}),
            ("youtube", "https://www.youtube.com", None),
            ("rss", None, None),  # no single endpoint to test
        ]
        for platform, url, params_dict in tests:
            if url is None:
                results[platform] = "✅ available (no endpoint test needed)"
                continue
            try:
                resp = await client.get(url, params=params_dict, timeout=8.0)
                if resp.status_code == 200:
                    results[platform] = "✅ working"
                elif resp.status_code == 429:
                    results[platform] = "⚠️ rate-limited"
                else:
                    results[platform] = f"❌ HTTP {resp.status_code}"
            except Exception as e:
                results[platform] = f"❌ {type(e).__name__}: {e}"
        # Twitter — check if nitter is reachable.
        import os
        if os.environ.get("TWITTER_BEARER_TOKEN"):
            results["twitter"] = "✅ working (official API with bearer token)"
        else:
            # Quick nitter check.
            for instance in _NITTER_INSTANCES:
                try:
                    resp = await client.get(instance, timeout=5.0)
                    if resp.status_code == 200:
                        results["twitter"] = f"⚠️ nitter fallback ({instance})"
                        break
                except Exception:
                    continue
            else:
                results["twitter"] = "❌ no nitter available, set TWITTER_BEARER_TOKEN"
        results["xiaohongshu"] = "❌ requires browser login (not natively available)"
        results["facebook"] = "❌ requires browser login"
        results["instagram"] = "❌ requires browser login"
        return ToolResult(
            call_id=f"diag_{int(start*1000)}", tool=self.name,
            success=True, output=results,
            duration_s=time.time() - start,
        )


# ════════════════════════════════════════════════════════════════════════════
# Tool registry
# ════════════════════════════════════════════════════════════════════════════


def all_agent_reach_tools():
    """Return a fresh list of all native platform integration tools."""
    return [
        TwitterReadTool(),
        TwitterSearchTool(),
        YouTubeSubtitlesTool(),
        RedditSearchTool(),
        RedditReadTool(),
        BilibiliSearchTool(),
        XiaoHongShuSearchTool(),
        RSSReadTool(),
        GitHubSearchTool(),
        GitHubRepoReadTool(),
        PlatformDiagnosticsTool(),
    ]


__all__ = [
    "TwitterReadTool", "TwitterSearchTool",
    "YouTubeSubtitlesTool",
    "RedditSearchTool", "RedditReadTool",
    "BilibiliSearchTool",
    "XiaoHongShuSearchTool",
    "RSSReadTool",
    "GitHubSearchTool", "GitHubRepoReadTool",
    "PlatformDiagnosticsTool",
    "all_agent_reach_tools",
]
