"""Filesystem tools — sandboxed to the workspace directory.

v6 fix: the workspace root is now configurable at runtime via
set_workspace_root(). Previously it was hardcoded to <project>/workspace
and ignored config.workspace — so if an operator set
config.workspace=/var/lib/adonai/sandbox, terminal cwd was constrained
to that path but filesystem tools still read/wrote <project>/workspace.
Two tools, two different sandboxes. Now all builtin tools respect the
same workspace root.
"""
from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Any
import tempfile
from adonai.core.interfaces import Tool
from adonai.core.models import ToolResult

_DEFAULT_WORKSPACE = Path(__file__).resolve().parents[3] / "workspace"
# v6: runtime-configurable workspace root. Set by all_builtin_tools()
# from config.workspace so filesystem tools respect the same sandbox
# as terminal.
_workspace_override: Path | None = None


def set_workspace_root(path: str | Path | None) -> None:
    """v6: set the workspace root for all filesystem tools.

    Called by all_builtin_tools() with config.workspace so that
    file.read/file.write/file.list respect the same sandbox as terminal.
    Pass None to reset to the default (<project>/workspace).
    """
    global _workspace_override
    if path is None:
        _workspace_override = None
    else:
        _workspace_override = Path(path).resolve()


def _workspace_root() -> Path:
    ws = _workspace_override or _DEFAULT_WORKSPACE
    ws.mkdir(parents=True, exist_ok=True)
    return ws




def _resolve_safely(path: str) -> Path:
    """Resolve *path* against the workspace sandbox, rejecting escapes.

    Security model (v4 hardening):
      * Use Path.is_relative_to() instead of str.startswith() — the latter
        has a classic bug where ws="/foo/bar" matches p="/foo/bar2/x".
      * Reject symlinks that escape the workspace via a realpath check.
      * Reject absolute paths that don't already live inside the workspace
        (prevents /etc/passwd, /root/.ssh, etc.).
      * The system tempdir is allowed for backwards compat but is logged
        at WARNING because multi-tenant systems share /tmp.
    """
    ws = _workspace_root().resolve()
    tmp = Path(tempfile.gettempdir()).resolve()
    raw = Path(path)
    if raw.is_absolute():
        # Absolute paths must already be inside ws or tmp.
        p = raw.resolve()
    else:
        p = (ws / path).resolve()
    # is_relative_to is the correct containment check (Py3.9+).
    in_ws = _is_relative_to(p, ws)
    in_tmp = _is_relative_to(p, tmp)
    if not (in_ws or in_tmp):
        raise PermissionError(
            f"path {path!r} (resolved: {p}) escapes workspace sandbox "
            f"(allowed: {ws}, {tmp})"
        )
    if in_tmp and not in_ws:
        # Accessing /tmp — allowed but suspicious. Log for audit.
        import logging as _logging
        _logging.getLogger(__name__).warning(
            "filesystem access outside workspace, in system tempdir: %r", p
        )
    # Reject symlinks whose target escapes ws (TOCTOU defense).
    try:
        if p.is_symlink():
            real = Path(os.path.realpath(p))
            if not (_is_relative_to(real, ws) or _is_relative_to(real, tmp)):
                raise PermissionError(
                    f"symlink {path!r} targets outside workspace: {real}"
                )
    except OSError:
        pass  # broken symlink — let the subsequent open() surface the error
    return p


def _is_relative_to(p: Path, base: Path) -> bool:
    """Py3.9+ has Path.is_relative_to; this is a backport for safety."""
    try:
        p.relative_to(base)
        return True
    except ValueError:
        return False


def _ok(tool, output, start):
    return ToolResult(call_id=f"{tool}_{int(start*1000)}", tool=tool,
                      success=True, output=output, duration_s=time.time() - start)


def _err(tool, error, start):
    return ToolResult(call_id=f"{tool}_{int(start*1000)}", tool=tool,
                      success=False, error=error, duration_s=time.time() - start)


class FileReadTool(Tool):
    name = "file.read"
    description = "Read text contents of a file inside the workspace sandbox (≤1 MB)."
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "max_bytes": {"type": "integer", "default": 1048576},
        },
        "required": ["path"],
    }
    risk_level = "low"
    tags = ["file", "io"]
    category = "filesystem"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        try:
            p = _resolve_safely(params["path"])
        except PermissionError as e:
            return _err(self.name, str(e), start)
        if not p.exists() or not p.is_file():
            return _err(self.name, f"file not found: {p}", start)
        max_bytes = int(params.get("max_bytes", 1_048_576))
        try:
            data = p.read_bytes()[:max_bytes]
            try:
                text = data.decode("utf-8")
                return _ok(self.name, {"path": str(p), "content": text, "bytes": len(data)}, start)
            except UnicodeDecodeError:
                return _ok(self.name, {"path": str(p), "bytes": len(data), "binary": True}, start)
        except Exception as e:
            return _err(self.name, f"read failed: {type(e).__name__}: {e}", start)


class FileWriteTool(Tool):
    name = "file.write"
    description = "Write text to a file inside the workspace sandbox. Overwrites by default."
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "content": {"type": "string"},
            "append": {"type": "boolean", "default": False},
        },
        "required": ["path", "content"],
    }
    risk_level = "medium"
    tags = ["file", "io"]
    category = "filesystem"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        try:
            p = _resolve_safely(params["path"])
        except PermissionError as e:
            return _err(self.name, str(e), start)
        content = params.get("content", "")
        append = bool(params.get("append", False))
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            mode = "a" if append else "w"
            with open(p, mode, encoding="utf-8") as f:
                f.write(content)
            return _ok(self.name, {"path": str(p), "bytes": len(content), "appended": append}, start)
        except Exception as e:
            return _err(self.name, f"write failed: {type(e).__name__}: {e}", start)


class FileListTool(Tool):
    name = "file.list"
    description = "List files/subdirs inside a workspace path."
    parameters = {
        "type": "object",
        "properties": {
            "path": {"type": "string", "default": "."},
            "recursive": {"type": "boolean", "default": False},
        },
    }
    risk_level = "low"
    tags = ["file", "io"]
    category = "filesystem"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        try:
            p = _resolve_safely(params.get("path", "."))
        except PermissionError as e:
            return _err(self.name, str(e), start)
        if not p.exists():
            return _err(self.name, f"path not found: {p}", start)
        recursive = bool(params.get("recursive", False))
        try:
            entries = []
            if recursive:
                for root, dirs, files in os.walk(p):
                    for name in dirs + files:
                        full = Path(root) / name
                        entries.append({
                            "path": str(full.relative_to(_workspace_root())),
                            "type": "dir" if full.is_dir() else "file",
                            "size": full.stat().st_size if full.is_file() else 0,
                        })
            else:
                for full in sorted(p.iterdir()):
                    entries.append({
                        "path": str(full.relative_to(_workspace_root())),
                        "type": "dir" if full.is_dir() else "file",
                        "size": full.stat().st_size if full.is_file() else 0,
                    })
            return _ok(self.name, {"path": str(p), "entries": entries}, start)
        except Exception as e:
            return _err(self.name, f"list failed: {type(e).__name__}: {e}", start)
