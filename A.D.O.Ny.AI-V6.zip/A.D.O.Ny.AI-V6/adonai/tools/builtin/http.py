"""HTTP request tool — generic JSON/HTTP client for API integrations.

SSRF protection: all URLs are validated against UrlSafetyPolicy before
fetch. Loopback, link-local (incl. cloud metadata 169.254.169.254),
private, and multicast addresses are blocked. Sites that need internal
access must pass an explicit allowlist.

v9 fix: Many sites (Reddit, Bilibili, Twitter, etc.) block requests with
the default httpx/Python user agent, returning 403 Blocked or 412
Precondition Failed. We now inject a browser-like User-Agent by default
plus a set of common Accept headers. Callers can still override via the
`headers` parameter.
"""
from __future__ import annotations

import json
import time
from typing import Any

import httpx

from adonai.core.interfaces import Tool
from adonai.core.models import ToolResult
from adonai.tools.url_safety import UrlSafetyPolicy


# A realistic browser-like User-Agent. Many CDNs and WAFs (Cloudflare,
# Reddit's edge, Bilibili's anti-bot) return 403/412 to any client that
# identifies as httpx, python-requests, or has an empty UA. We default
# to a recent Chrome-on-Windows UA; callers can override per-request.
_DEFAULT_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/124.0.0.0 Safari/537.36"
)

# Default browser-like headers that suppress 412 Precondition Failed
# (Bilibili) and 403 Blocked (Reddit) responses. Caller-supplied headers
# override these per-key.
_DEFAULT_HEADERS = {
    "User-Agent": _DEFAULT_UA,
    "Accept": (
        "text/html,application/xhtml+xml,application/xml;q=0.9,"
        "application/json;q=0.8,*/*;q=0.7"
    ),
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
}


class HTTPRequestTool(Tool):
    name = "http_request"
    description = (
        "Make an HTTP request to any URL.  Supports GET/POST/PUT/DELETE. "
        "Returns status code + headers + body (≤64 KB)."
    )
    parameters = {
        "type": "object",
        "properties": {
            "url": {"type": "string"},
            "method": {"type": "string", "default": "GET", "enum": ["GET", "POST", "PUT", "DELETE", "PATCH"]},
            "headers": {"type": "object", "default": {}},
            "body": {"type": "string", "default": ""},
            "timeout": {"type": "integer", "default": 30},
        },
        "required": ["url"],
    }
    risk_level = "medium"
    tags = ["http", "api"]
    category = "network"

    def __init__(self, policy: UrlSafetyPolicy | None = None) -> None:
        self._policy = policy or UrlSafetyPolicy()

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        call_id = f"http_{int(start*1000)}"
        url = (params.get("url") or "").strip()
        if not url:
            return ToolResult(call_id=call_id, tool=self.name, success=False,
                              error="url is required", duration_s=0.0)

        # SSRF check — reject loopback/link-local/private/multicast.
        ok, reason = self._policy.validate(url)
        if not ok:
            return ToolResult(call_id=call_id, tool=self.name, success=False,
                              error=f"URL rejected by safety policy: {reason}",
                              duration_s=time.time() - start)

        method = (params.get("method") or "GET").upper()
        # Merge default browser-like headers with caller-supplied headers.
        # Caller headers win per-key (case-insensitive).
        caller_headers = params.get("headers") or {}
        headers = dict(_DEFAULT_HEADERS)
        if isinstance(caller_headers, dict):
            # Drop any case-variant keys that the caller is overriding.
            caller_lower = {k.lower(): k for k in caller_headers}
            for default_key in list(headers.keys()):
                if default_key.lower() in caller_lower:
                    del headers[default_key]
            headers.update(caller_headers)
        body = params.get("body") or ""
        try:
            timeout = max(1, min(120, int(params.get("timeout", 30))))
        except (TypeError, ValueError):
            timeout = 30

        # Filter sensitive response headers before returning to the LLM.
        _SENSITIVE_RESP_HEADERS = {"set-cookie", "authorization", "cookie", "x-api-key"}

        # Build request kwargs (headers + optional body) once — reused
        # across redirect hops with POST→GET downgrade on redirect.
        req_kwargs: dict = {"headers": headers}
        if body and method in ("POST", "PUT", "PATCH"):
            if "content-type" in {k.lower() for k in headers}:
                req_kwargs["content"] = body
            else:
                try:
                    req_kwargs["json"] = json.loads(body)
                except json.JSONDecodeError:
                    req_kwargs["content"] = body

        try:
            # ── SSRF-via-redirect defense ──────────────────────────────
            # The previous code validated the URL once before the request
            # but then followed redirects with follow_redirects=True.
            # A public URL that returns 302 Location: http://169.254.169.254/
            # would be followed WITHOUT re-validation — textbook SSRF
            # bypass.  We now use follow_redirects=False and manually
            # re-validate every redirect Location before following it.
            # This costs us a few extra HTTP round-trips on redirect
            # chains but closes the bypass completely.
            max_redirects = 5
            current_url = url
            current_method = method
            current_kwargs = dict(req_kwargs)
            resp = None
            for _hop in range(max_redirects + 1):
                async with httpx.AsyncClient(
                    timeout=timeout, follow_redirects=False,
                ) as client:
                    resp = await client.request(
                        current_method, current_url, **current_kwargs,
                    )
                # If not a redirect, we're done.
                if not (300 <= resp.status_code < 400):
                    break
                location = resp.headers.get("location")
                if not location:
                    break  # redirect with no Location — bail
                # Resolve relative redirects against the current URL.
                current_url = str(httpx.URL(current_url).join(location))
                # ── Re-validate the redirect target ──
                ok, reason = self._policy.validate(current_url)
                if not ok:
                    return ToolResult(
                        call_id=call_id, tool=self.name, success=False,
                        error=(
                            f"Redirect target rejected by safety policy: "
                            f"{reason} (redirected to {current_url[:120]})"
                        ),
                        duration_s=time.time() - start,
                    )
                # Redirects after POST/PUT/PATCH should typically be GET.
                if current_method in ("POST", "PUT", "PATCH"):
                    current_method = "GET"
                    current_kwargs.pop("content", None)
                    current_kwargs.pop("json", None)
            if resp is None:
                return ToolResult(
                    call_id=call_id, tool=self.name, success=False,
                    error="no response received",
                    duration_s=time.time() - start,
                )
            text = resp.text[:65_536]
            safe_headers = {k: v for k, v in resp.headers.items()
                            if k.lower() not in _SENSITIVE_RESP_HEADERS}
            return ToolResult(
                call_id=call_id, tool=self.name,
                success=(200 <= resp.status_code < 400),
                output={
                    "status_code": resp.status_code,
                    "headers": safe_headers,
                    "body": text,
                    "url": str(resp.url),
                },
                error=None if 200 <= resp.status_code < 400 else f"HTTP {resp.status_code}",
                duration_s=time.time() - start,
            )
        except Exception as e:
            return ToolResult(call_id=call_id, tool=self.name, success=False,
                              error=f"{type(e).__name__}: {e}",
                              duration_s=time.time() - start)
