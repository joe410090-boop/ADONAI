"""Browser tool — Playwright-backed page automation with httpx fallback.

When Playwright is installed and browsers are downloaded, the tool can:
  - navigate to URLs
  - extract text / HTML / screenshots
  - click elements
  - fill forms
  - execute JavaScript

When Playwright is NOT installed, the tool gracefully degrades to a
fetch-only mode using httpx (text extraction only, no JS / clicks).

The tool is registered alongside the other built-in tools via
``all_builtin_tools()``.
"""
from __future__ import annotations

import asyncio
import base64
import logging
import time
from typing import Any

import httpx

from adonai.core.interfaces import Tool
from adonai.core.models import ToolResult

log = logging.getLogger(__name__)


# Try to import playwright at module load — but never fail.
try:
    from playwright.async_api import async_playwright, Browser as _PwBrowser
    _PLAYWRIGHT_AVAILABLE = True
except ImportError:  # pragma: no cover
    _PLAYWRIGHT_AVAILABLE = False
    _PwBrowser = None  # type: ignore[assignment,misc]


class BrowserTool(Tool):
    """Headless browser automation tool.

    Actions:
      - ``navigate`` — go to a URL, return page text + title
      - ``screenshot`` — go to a URL, return a base64 PNG screenshot
      - ``click``     — go to a URL, click a CSS selector, return text
      - ``fill``      — go to a URL, fill a form field, return text
      - ``evaluate``  — go to a URL, run JS, return result
      - ``fetch``     — httpx-only mode (always available)

    When Playwright is unavailable, only ``fetch`` is supported; the
    other actions fall back to ``fetch`` with a warning.
    """

    name = "browser"
    description = (
        "Headless browser automation.  Navigate, click, fill forms, "
        "extract text/HTML, take screenshots, and run JavaScript.  "
        "Degrades to httpx fetch when Playwright is not installed."
    )
    parameters = {
        "type": "object",
        "properties": {
            "action": {
                "type": "string",
                "enum": ["navigate", "screenshot", "click", "fill", "evaluate", "fetch"],
                "description": "The browser action to perform.",
            },
            "url": {"type": "string", "description": "Target URL."},
            "selector": {
                "type": "string",
                "description": "CSS selector (for click / fill).",
            },
            "value": {
                "type": "string",
                "description": "Value to fill (for fill) or JS to run (for evaluate).",
            },
            "wait_for": {
                "type": "string",
                "description": "CSS selector to wait for before extracting.",
            },
            "timeout": {
                "type": "integer", "default": 30, "minimum": 1, "maximum": 120,
                "description": "Per-action timeout in seconds.",
            },
            "user_agent": {
                "type": "string",
                "description": "Override the User-Agent string.",
            },
        },
        "required": ["action", "url"],
    }
    risk_level = "medium"
    tags = ["web", "browser", "automation"]
    category = "web"

    # Playwright browser instance is lazily initialised + reused across
    # calls.  The lock is created on first use (Python 3.12 + doesn't
    # allow asyncio.Lock() at class-definition time when no loop is
    # running).
    _pw_instance = None
    _pw_browser: Any = None
    _pw_lock: Any = None

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        action = (params.get("action") or "navigate").lower()
        url = (params.get("url") or "").strip()
        timeout = max(1, min(120, int(params.get("timeout", 30))))
        call_id = f"br_{int(start * 1000)}"

        if not url:
            return ToolResult(
                call_id=call_id, tool=self.name,
                success=False, error="url is required",
                duration_s=time.time() - start,
            )

        # Route to the appropriate handler.
        try:
            if action == "fetch":
                return await self._fetch(url, timeout, call_id, start)
            if not _PLAYWRIGHT_AVAILABLE:
                # Degrade to fetch with a warning in the output.
                result = await self._fetch(url, timeout, call_id, start)
                result.output = (
                    f"[playwright not installed — falling back to httpx fetch]\n\n"
                    f"{result.output}"
                ) if isinstance(result.output, str) else result.output
                return result
            # Playwright path.
            return await self._playwright_action(action, params, timeout, call_id, start)
        except Exception as e:
            log.warning("BrowserTool action '%s' failed: %s", action, e)
            return ToolResult(
                call_id=call_id, tool=self.name,
                success=False, error=f"{type(e).__name__}: {e}",
                duration_s=time.time() - start,
            )

    # ------------------------------------------------------------------ #
    # httpx fallback
    # ------------------------------------------------------------------ #

    async def _fetch(self, url: str, timeout: int, call_id: str, start: float) -> ToolResult:
        """Plain HTTP fetch — always available, no JS rendering.

        v6 fix: uses safe_fetch() with per-hop SSRF re-validation instead
        of httpx follow_redirects=True. Previously a public URL that 302s
        to http://169.254.169.254/... would be followed and return cloud
        metadata credentials.
        """
        from adonai.tools.url_safety import safe_fetch
        try:
            status, resp_headers, content, final_url = await safe_fetch(
                url,
                timeout=float(timeout),
                headers={"User-Agent": "Mozilla/5.0 (compatible; ADONAI/4.0)"},
            )
        except ValueError as e:
            # URL rejected by safety policy (initial or redirect target).
            log.warning("BrowserTool._fetch rejected url %r: %s", url, e)
            return ToolResult(
                call_id=call_id, tool=self.name,
                success=False, error=f"URL rejected by safety policy: {e}",
                duration_s=time.time() - start,
            )
        except Exception as e:
            return ToolResult(
                call_id=call_id, tool=self.name,
                success=False, error=f"fetch failed: {e}",
                duration_s=time.time() - start,
            )
        # Decode body.
        text = content.decode("utf-8", errors="replace")
        content_type = resp_headers.get("content-type", "")
        if len(text) > 50_000:
            text = text[:50_000] + "\n... [truncated]"
        return ToolResult(
            call_id=call_id, tool=self.name,
            success=True,
            output={
                "url": final_url,
                "status": status,
                "content_type": content_type,
                "text": text,
                "length": len(content),
            },
            duration_s=time.time() - start,
        )

    # ------------------------------------------------------------------ #
    # Playwright actions
    # ------------------------------------------------------------------ #

    async def _get_browser(self) -> Any:
        """Lazily start a single shared Playwright browser."""
        if self._pw_browser is not None:
            return self._pw_browser
        # Create the lock on first use (Python 3.12-safe).
        if BrowserTool._pw_lock is None:
            BrowserTool._pw_lock = asyncio.Lock()
        async with BrowserTool._pw_lock:
            if self._pw_browser is not None:
                return self._pw_browser
            self._pw_instance = await async_playwright().start()
            self._pw_browser = await self._pw_instance.chromium.launch(headless=True)
            return self._pw_browser

    async def _playwright_action(
        self, action: str, params: dict[str, Any],
        timeout: int, call_id: str, start: float,
    ) -> ToolResult:
        from adonai.tools.url_safety import DEFAULT_POLICY as _DEFAULT_URL_POLICY
        browser = await self._get_browser()
        context = await browser.new_context(
            user_agent=params.get("user_agent") or "Mozilla/5.0 (compatible; ADONAI/4.0)",
            viewport={"width": 1280, "height": 720},
        )
        page = await context.new_page()
        try:
            url = params["url"]
            # SSRF check — block file://, loopback, link-local, private.
            ok, reason = _DEFAULT_URL_POLICY.validate(url)
            if not ok:
                return ToolResult(call_id=call_id, tool=self.name, success=False,
                                  error=f"URL rejected by safety policy: {reason}",
                                  duration_s=time.time() - start)
            await page.goto(url, timeout=timeout * 1000, wait_until="domcontentloaded")
            wait_for = params.get("wait_for")
            if wait_for:
                try:
                    await page.wait_for_selector(wait_for, timeout=timeout * 1000)
                except Exception as e:
                    log.debug("wait_for %s failed (non-fatal): %s", wait_for, e)

            if action == "navigate":
                title = await page.title()
                text = await page.inner_text("body")
                if len(text) > 50_000:
                    text = text[:50_000] + "\n... [truncated]"
                return ToolResult(
                    call_id=call_id, tool=self.name, success=True,
                    output={
                        "url": page.url, "title": title,
                        "text": text, "length": len(text),
                    },
                    duration_s=time.time() - start,
                )

            if action == "screenshot":
                png = await page.screenshot(full_page=True)
                b64 = base64.b64encode(png).decode("ascii")
                return ToolResult(
                    call_id=call_id, tool=self.name, success=True,
                    output={
                        "url": page.url,
                        "screenshot_base64": b64,
                        "length": len(png),
                    },
                    duration_s=time.time() - start,
                )

            if action == "click":
                selector = params.get("selector")
                if not selector:
                    return ToolResult(
                        call_id=call_id, tool=self.name,
                        success=False, error="selector is required for click",
                        duration_s=time.time() - start,
                    )
                await page.click(selector, timeout=timeout * 1000)
                text = await page.inner_text("body")
                if len(text) > 50_000:
                    text = text[:50_000] + "\n... [truncated]"
                return ToolResult(
                    call_id=call_id, tool=self.name, success=True,
                    output={"url": page.url, "text": text, "clicked": selector},
                    duration_s=time.time() - start,
                )

            if action == "fill":
                selector = params.get("selector")
                value = params.get("value", "")
                if not selector:
                    return ToolResult(
                        call_id=call_id, tool=self.name,
                        success=False, error="selector is required for fill",
                        duration_s=time.time() - start,
                    )
                await page.fill(selector, value, timeout=timeout * 1000)
                return ToolResult(
                    call_id=call_id, tool=self.name, success=True,
                    output={"url": page.url, "filled": selector, "value": value},
                    duration_s=time.time() - start,
                )

            if action == "evaluate":
                js = params.get("value") or params.get("script") or ""
                if not js:
                    return ToolResult(
                        call_id=call_id, tool=self.name,
                        success=False, error="value (JS source) is required for evaluate",
                        duration_s=time.time() - start,
                    )
                # SECURITY: page.evaluate runs arbitrary JS in the page's origin.
                # If the page is attacker-controlled, this enables cookie theft,
                # CSRF, etc. We log at WARNING so operators can audit, and we
                # cap the JS source size to prevent DoS. For full isolation,
                # use page.add_init_script with a sandboxed helper instead.
                if len(js) > 10_000:
                    return ToolResult(call_id=call_id, tool=self.name, success=False,
                                      error="JS source exceeds 10KB limit",
                                      duration_s=time.time() - start)
                log.warning("BrowserTool evaluate() on %s (JS size=%d)", url, len(js))
                result = await page.evaluate(js)
                return ToolResult(
                    call_id=call_id, tool=self.name, success=True,
                    output={"url": page.url, "result": result},
                    duration_s=time.time() - start,
                )

            return ToolResult(
                call_id=call_id, tool=self.name,
                success=False, error=f"unknown action: {action}",
                duration_s=time.time() - start,
            )
        finally:
            await context.close()

    # ------------------------------------------------------------------ #
    # Lifecycle
    # ------------------------------------------------------------------ #

    @classmethod
    async def shutdown(cls) -> None:
        """Close the shared Playwright browser if it was started."""
        if cls._pw_browser is not None:
            try:
                await cls._pw_browser.close()
            except Exception:
                pass
            cls._pw_browser = None
        if cls._pw_instance is not None:
            try:
                await cls._pw_instance.stop()
            except Exception:
                pass
            cls._pw_instance = None
