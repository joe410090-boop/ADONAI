"""Todo-list tool — lets the LLM plan with a visible checklist and mark items done.

This mirrors the `TodoWrite` pattern used by assistant-style agents: the LLM
calls `todo.write` with the *entire* desired list, and the tool replaces the
session's list atomically.  Each call publishes a `todo.updated` event on the
EventBus so UIs (web, SSE, CLI) can render live progress.

Semantics — full-replace, not incremental:
  - The LLM doesn't have to track item IDs; it just rewrites the whole list.
  - Status transitions are inferred by diffing against the previous list
    (matched on `content`), so "marking done" = rewrite the list with the
    same items but `status="completed"` on the finished one.

Per-session storage:
  - Todos are scoped to a `session_id` (defaulting to "default").
  - In-memory only — todos are ephemeral working state, not long-term memory.
  - If you want persistence, hook the `todo.updated` event and write to SQLite.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
import uuid
from typing import Any

from adonai.core.interfaces import Tool
from adonai.core.models import ToolResult

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Session-scoped store (module-level singleton — one per process)
# ──────────────────────────────────────────────────────────────────────────────

class _TodoStore:
    """In-memory, session-scoped todo store.

    A "todo" is a dict: {id, content, status, priority}.
    status ∈ {"pending", "in_progress", "completed"}.
    priority ∈ {"low", "medium", "high"}.
    """

    _instance: "_TodoStore | None" = None
    _lock = asyncio.Lock()

    def __init__(self) -> None:
        self._by_session: dict[str, list[dict[str, Any]]] = {}
        # Subscribers — called with (session_id, todos) on every write.
        self._subscribers: list = []

    @classmethod
    def instance(cls) -> "_TodoStore":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def get(self, session_id: str) -> list[dict[str, Any]]:
        return list(self._by_session.get(session_id, []))

    def replace(self, session_id: str, items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Atomically replace the session's todo list.

        Each input item may be a plain string (treated as content, status=pending)
        or a dict with {content, status?, priority?}.  IDs are stable across
        replacements when content matches (so the LLM can mark items done
        without knowing IDs).
        """
        prev = self._by_session.get(session_id, [])
        prev_by_content = {it["content"]: it["id"] for it in prev if "content" in it}

        new_list: list[dict[str, Any]] = []
        for raw in items:
            if isinstance(raw, str):
                item = {"content": raw, "status": "pending", "priority": "medium"}
            elif isinstance(raw, dict):
                content = str(raw.get("content", "")).strip()
                if not content:
                    continue
                item = {
                    "content": content,
                    "status": str(raw.get("status", "pending")).lower(),
                    "priority": str(raw.get("priority", "medium")).lower(),
                }
            else:
                continue
            if item["status"] not in ("pending", "in_progress", "completed"):
                item["status"] = "pending"
            if item["priority"] not in ("low", "medium", "high"):
                item["priority"] = "medium"
            # Preserve ID if content matches an existing item (stable identity).
            item["id"] = prev_by_content.get(item["content"], f"todo_{uuid.uuid4().hex[:8]}")
            new_list.append(item)

        self._by_session[session_id] = new_list
        return new_list

    def clear(self, session_id: str) -> None:
        self._by_session.pop(session_id, None)


def get_todos(session_id: str) -> list[dict[str, Any]]:
    """Module-level accessor — used by API routes and CLI to read current state."""
    return _TodoStore.instance().get(session_id)


# ──────────────────────────────────────────────────────────────────────────────
# Tool
# ──────────────────────────────────────────────────────────────────────────────

class TodoWriteTool(Tool):
    """`todo.write` — replace the session's todo list.

    The LLM passes the *entire* desired list each call.  This makes
    "mark done" trivial: rewrite the list with the same items but flip
    one item's `status` to `completed`.

    Why full-replace instead of incremental updates?
      - The LLM doesn't have to track item IDs (which it gets wrong often).
      - The list is the single source of truth — no hidden state.
      - Diffing against the previous list lets us preserve stable IDs
        (matched on content) so a UI can animate status transitions.
    """

    name = "todo.write"
    description = (
        "Plan your work as a visible checklist, then mark items done as you complete them. "
        "Pass the ENTIRE list every call — items are matched by content so IDs stay stable. "
        "Use this at the start of any multi-step task (3+ steps) and update it after each step. "
        "Status must be one of: pending, in_progress, completed. "
        "Only ONE item should be in_progress at a time."
    )
    parameters = {
        "type": "object",
        "properties": {
            "session_id": {
                "type": "string",
                "description": "Session identifier. Use the one from your context if available, else 'default'.",
                "default": "default",
            },
            "todos": {
                "type": "array",
                "description": "The complete todo list — replaces any previous list for this session.",
                "items": {
                    "type": "object",
                    "properties": {
                        "content": {"type": "string", "description": "What needs to be done (imperative, e.g. 'Fetch the API docs')."},
                        "status": {"type": "string", "enum": ["pending", "in_progress", "completed"], "default": "pending"},
                        "priority": {"type": "string", "enum": ["low", "medium", "high"], "default": "medium"},
                    },
                    "required": ["content"],
                },
            },
        },
        "required": ["todos"],
    }
    risk_level = "low"
    requires_approval = False
    tags = ["planning", "todo", "productivity"]
    category = "planning"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        session_id = str(params.get("session_id") or "default")
        todos = _coerce_todos(params)
        if todos is None:
            return ToolResult(
                call_id=f"todo_{int(start*1000)}", tool=self.name,
                success=False,
                error=(
                    "'todos' must be an array of items (each item may be a "
                    "string or {content, status, priority} object).  Got: "
                    f"{type(params.get('todos')).__name__}"
                ),
                duration_s=time.time() - start,
            )

        store = _TodoStore.instance()
        # Replace under the store's lock to avoid races with concurrent reads.
        async with store._lock:
            new_list = store.replace(session_id, todos)

        # Publish a `todo.updated` event on the EventBus (if one is registered).
        try:
            from adonai.core.events import EventPublisher, Event, EventBus
            bus = EventPublisher._event_bus  # process-wide bus
            if bus is not None:
                await bus.publish(Event(
                    type="todo.updated",
                    payload={
                        "session_id": session_id,
                        "todos": new_list,
                        "counts": {
                            "pending": sum(1 for t in new_list if t["status"] == "pending"),
                            "in_progress": sum(1 for t in new_list if t["status"] == "in_progress"),
                            "completed": sum(1 for t in new_list if t["status"] == "completed"),
                        },
                    },
                    source="TodoWriteTool",
                ))
        except Exception as e:
            log.debug("todo.updated event publish failed (non-fatal): %s", e)

        # Return a compact summary so the LLM sees the result.
        counts = {
            "total": len(new_list),
            "pending": sum(1 for t in new_list if t["status"] == "pending"),
            "in_progress": sum(1 for t in new_list if t["status"] == "in_progress"),
            "completed": sum(1 for t in new_list if t["status"] == "completed"),
        }
        return ToolResult(
            call_id=f"todo_{int(start*1000)}", tool=self.name,
            success=True,
            output={"todos": new_list, "counts": counts},
            duration_s=time.time() - start,
        )


class TodoListTool(Tool):
    """`todo.list` — read the current todo list for a session.

    Mostly useful for debugging / UI rendering; the LLM doesn't usually
    need to call this because `todo.write` echoes the full list back.
    """

    name = "todo.list"
    description = "Read the current todo list for a session. Returns the full list with statuses."
    parameters = {
        "type": "object",
        "properties": {
            "session_id": {
                "type": "string",
                "default": "default",
                "description": "Session identifier to read todos for.",
            },
        },
        "required": [],
    }
    risk_level = "low"
    tags = ["planning", "todo"]
    category = "planning"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        session_id = str(params.get("session_id") or "default")
        todos = _TodoStore.instance().get(session_id)
        return ToolResult(
            call_id=f"todo_{int(start*1000)}", tool=self.name,
            success=True,
            output={"todos": todos, "count": len(todos)},
            duration_s=time.time() - start,
        )


__all__ = ["TodoWriteTool", "TodoListTool", "get_todos", "_TodoStore"]


# ──────────────────────────────────────────────────────────────────────────────
# Argument coercion — tolerate the various shapes small LLMs emit
# ──────────────────────────────────────────────────────────────────────────────

def _coerce_todos(params: dict[str, Any]) -> list[Any] | None:
    """Normalise the `todos` argument into a Python list.

    Small Ollama models (qwen3-4b etc.) frequently emit arguments in shapes
    that don't match the schema.  Without this coercion the tool rejected
    every such call with `success=False (0.00s)`, which looked to the LLM
    (and the user) like the tool was broken.  Acceptable shapes:

    - ``{"todos": [...]}``                    — schema-correct
    - ``{"todos": "[{...}]"}``                — stringified JSON list
    - ``{"items": [...]}``                    — wrong key but obvious intent
    - ``{"list": [...]}``, ``{"tasks": [...]}`` — same
    - ``[...]``                               — list passed as the whole args
    - ``"[...]"``                             — list stringified as the whole args
    - ``{"_raw": [...]}``                     — fallback shape from the Ollama
                                                parser when JSON didn't decode
                                                to a dict

    Returns the list on success, or ``None`` if no usable list was found.
    """
    raw = params.get("todos")
    if raw is None:
        # Try common alternative keys the LLM might use.
        for alt in ("items", "list", "tasks", "_raw"):
            if alt in params:
                raw = params[alt]
                break
    # Stringify-and-parse: handles both "[]" wrapped strings and JSON lists
    # that the LLM emitted as a single argument value.
    if isinstance(raw, str):
        s = raw.strip()
        if not s:
            return None
        try:
            parsed = json.loads(s)
        except json.JSONDecodeError:
            # Last-ditch: maybe it was Python-literalised (single quotes).
            try:
                import ast
                parsed = ast.literal_eval(s)
            except (ValueError, SyntaxError):
                return None
        if isinstance(parsed, list):
            return parsed
        return None
    if isinstance(raw, list):
        return raw
    return None
