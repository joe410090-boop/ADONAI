"""Git tool — wraps git CLI for repo operations."""
from __future__ import annotations

import asyncio
import os
import signal
import time
from typing import Any

from adonai.core.interfaces import Tool
from adonai.core.models import ToolResult

log = __import__("logging").getLogger(__name__)


class GitTool(Tool):
    name = "git"
    description = (
        "Run a git command in a workspace repo.  Returns stdout+stderr (≤64 KB) "
        "and exit code.  Allowed: status, log, diff, add, commit, branch, "
        "checkout, merge, pull, push (when authenticated)."
    )
    parameters = {
        "type": "object",
        "properties": {
            "command": {"type": "string", "description": "git subcommand + args (e.g. 'status')."},
            "repo_path": {"type": "string", "default": ".", "description": "Repo path inside workspace."},
        },
        "required": ["command"],
    }
    risk_level = "medium"
    tags = ["git", "vcs"]
    category = "vcs"

    # Block destructive ops unless explicitly approved.
    _BLOCKED = ["push --force", "reset --hard", "clean -fd"]

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        subcmd = (params.get("command") or "").strip()
        if not subcmd:
            return ToolResult(
                call_id=f"git_{int(start*1000)}", tool=self.name,
                success=False, error="command is required", duration_s=time.time() - start,
            )
        for bad in self._BLOCKED:
            if bad in subcmd:
                return ToolResult(
                    call_id=f"git_{int(start*1000)}", tool=self.name,
                    success=False, error=f"blocked git operation: {bad!r}",
                    duration_s=time.time() - start,
                )
        repo_path = params.get("repo_path", ".")
        # Resolve repo path inside workspace.
        from adonai.tools.builtin.filesystem import _resolve_safely
        try:
            cwd = _resolve_safely(repo_path)
        except PermissionError as e:
            return ToolResult(
                call_id=f"git_{int(start*1000)}", tool=self.name,
                success=False, error=str(e), duration_s=time.time() - start,
            )
        try:
            proc = await asyncio.create_subprocess_exec(
                "git", *subcmd.split(),
                cwd=str(cwd),
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                start_new_session=True,  # v8: create process group for clean kill
            )
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=30)
            text = (stdout or b"").decode("utf-8", errors="replace")
            if len(text) > 65_536:
                text = text[:65_536] + "\n…(truncated)"
            return ToolResult(
                call_id=f"git_{int(start*1000)}", tool=self.name,
                success=(proc.returncode == 0),
                output={"stdout": text, "exit_code": proc.returncode, "command": f"git {subcmd}"},
                error=None if proc.returncode == 0 else f"exit code {proc.returncode}",
                duration_s=time.time() - start,
            )
        except asyncio.TimeoutError:
            # v8: Kill the entire process group (git + any hooks/children).
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            except (ProcessLookupError, OSError):
                try:
                    proc.kill()
                except Exception:
                    pass
            return ToolResult(
                call_id=f"git_{int(start*1000)}", tool=self.name,
                success=False, error="git command timed out (30s) — process group killed",
                duration_s=time.time() - start,
            )
        except Exception as e:
            return ToolResult(
                call_id=f"git_{int(start*1000)}", tool=self.name,
                success=False, error=f"git failed: {type(e).__name__}: {e}",
                duration_s=time.time() - start,
            )
