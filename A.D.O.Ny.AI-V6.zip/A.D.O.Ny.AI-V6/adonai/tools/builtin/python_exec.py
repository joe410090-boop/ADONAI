"""Python execution tool — runs Python code in a sandboxed subprocess.

Security model (v4 hardening):
  * Code is inspected via AST before execution. Imports of dangerous modules
    (subprocess, os.system, ctypes, etc.) and calls to exec/eval/compile
    are rejected. This is NOT a complete sandbox — determined attackers can
    bypass AST inspection via dynamic dispatch — but it stops the trivial
    prompt-injection cases. For full sandboxing, run ADONAI inside a
    container with seccomp/landlock.
  * The subprocess gets a minimal env: only PATH, LANG, LC_ALL, HOME,
    PYTHONDONTWRITEBYTECODE, PYTHONUNBUFFERED. Secrets (OPENAI_API_KEY,
    TWITTER_BEARER_TOKEN, DB credentials) are stripped.
  * Resource limits: RLIMIT_CPU (10s), RLIMIT_AS (512 MB), RLIMIT_FSIZE
    (50 MB), RLIMIT_NPROC (64). Prevents infinite loops and OOM.
  * Timeouts clamped to [1, 120] seconds.
  * Temp files written with mode 0o600 inside the workspace sandbox.
  * Process group kill on timeout (start_new_session=True + os.killpg).
"""
from __future__ import annotations

import ast
import asyncio
import logging
import os
import resource
import tempfile
import time
from pathlib import Path
from typing import Any

from adonai.core.interfaces import Tool
from adonai.core.models import ToolResult

log = logging.getLogger(__name__)

# Modules whose import implies intent to escape the sandbox.
# v9: removed `pathlib` from the blocklist — it's a pure-Python path
# manipulation library, not a filesystem escape. Blocking it forced the
# LLM to use string concatenation for paths, which is less safe. Kept
# `tempfile` blocked because it can write outside the workspace if `dir=`
# is absolute.
_DANGEROUS_MODULES = {
    "subprocess", "os", "shutil", "ctypes", "cffi", "pty", "ptyprocess",
    "multiprocessing", "asyncio.subprocess", "socket", "socketserver",
    "http", "http.server", "http.client", "urllib", "urllib.request",
    "ftplib", "smtplib", "telnetlib", "paramiko", "fabric",
    "pickle", "shelve", "marshal", "code", "codeop", "pdb", "bdb",
    "importlib", "importlib.util", "imp", "builtins",
    "secrets", "keyring", "getpass", "crypt",
    "tempfile",  # can write outside workspace if dir= is absolute
}

# Calls that imply dynamic code execution or sandbox escape.
_DANGEROUS_CALLS = {
    "exec", "eval", "compile", "__import__", "globals", "locals",
    "vars", "dir", "getattr", "setattr", "delattr", "type", "super",
    "open",  # file I/O — use file.* tools
}

# Attributes that imply builtins manipulation or dynamic dispatch escape.
# v6 fix: added __self__, __dict__, __doc__, __name__, __qualname__, __module__
# to close the print.__self__.__dict__["__import__"]("os") bypass gadget.
_DANGEROUS_ATTRS = {
    "__builtins__", "__import__", "__subclasses__", "__bases__",
    "__mro__", "__class__", "__globals__",
    # v6: attributes that enable reflection-based sandbox escape
    "__self__", "__dict__", "__doc__", "__name__", "__qualname__", "__module__",
    "__wrapped__", "__func__", "__code__", "__defaults__", "__closure__",
}

# String literals that, when used as a subscript key, indicate sandbox escape
# (e.g. obj["__import__"], obj["__builtins__"], obj["__subclasses__"]).
# v6: closes the print.__self__.__dict__["__import__"]("os") bypass gadget.
_DANGEROUS_SUBSCRIPT_KEYS = {
    "__import__", "__builtins__", "__subclasses__", "__bases__", "__mro__",
    "__class__", "__globals__", "__self__", "__dict__", "__code__",
    "__wrapped__", "__func__", "__closure__", "__name__", "__qualname__",
}


def _extract_subscript_key(node: ast.Subscript) -> str | None:
    """Extract the string-literal key from a Subscript node, if it is one.

    Handles both Python <3.9 (slice=ast.Index) and >=3.9 (slice=expr directly).
    Returns None for non-string-literal subscripts (e.g. obj[i], obj[0]).
    """
    sl = node.slice
    # Python 3.8 wraps the expression in ast.Index
    if isinstance(sl, ast.Index):  # pragma: no cover
        sl = sl.value  # type: ignore[attr-defined]
    if isinstance(sl, ast.Constant) and isinstance(sl.value, str):
        return sl.value
    return None


class _SandboxInspector(ast.NodeVisitor):
    """Walks the AST and collects violations (does not modify code)."""

    def __init__(self) -> None:
        self.violations: list[str] = []

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            mod = alias.name.split(".")[0]
            if mod in _DANGEROUS_MODULES or alias.name in _DANGEROUS_MODULES:
                self.violations.append(f"import of {alias.name!r} is forbidden")
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        mod = node.module or ""
        top = mod.split(".")[0]
        if mod in _DANGEROUS_MODULES or top in _DANGEROUS_MODULES:
            self.violations.append(f"from-import of {mod!r} is forbidden")
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        # Direct name call: exec(...), eval(...), open(...)
        if isinstance(node.func, ast.Name) and node.func.id in _DANGEROUS_CALLS:
            self.violations.append(f"call to {node.func.id}() is forbidden")
        # Attribute access: os.system, subprocess.run, __import__
        elif isinstance(node.func, ast.Attribute):
            if node.func.attr in _DANGEROUS_CALLS:
                self.violations.append(f"call to .{node.func.attr}() is forbidden")
        # v6: Subscript-call gadget: obj["__import__"]("os")
        # Block calls whose func is a Subscript with a dangerous string-literal key.
        elif isinstance(node.func, ast.Subscript):
            key = _extract_subscript_key(node.func)
            if key is not None and key in _DANGEROUS_SUBSCRIPT_KEYS:
                self.violations.append(
                    f"call via subscript ['{key}'] is forbidden (sandbox escape gadget)"
                )
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> None:
        if node.attr in _DANGEROUS_ATTRS:
            self.violations.append(f"access to .{node.attr} is forbidden")
        self.generic_visit(node)

    def visit_Subscript(self, node: ast.Subscript) -> None:
        # v6: Block obj["__import__"], obj["__builtins__"], etc.
        # This closes the print.__self__.__dict__["__import__"]("os") bypass.
        key = _extract_subscript_key(node)
        if key is not None and key in _DANGEROUS_SUBSCRIPT_KEYS:
            self.violations.append(
                f"subscript access ['{key}'] is forbidden (sandbox escape gadget)"
            )
        self.generic_visit(node)


def _inspect_code(code: str) -> list[str]:
    """Return a list of violation strings; empty list = code passed inspection."""
    try:
        tree = ast.parse(code)
    except SyntaxError as e:
        return [f"syntax error: {e}"]
    inspector = _SandboxInspector()
    inspector.visit(tree)
    return inspector.violations


def _apply_rlimits() -> None:
    """Pre-exec resource limits (called in the child process via start_new_session)."""
    # CPU: 10 seconds
    resource.setrlimit(resource.RLIMIT_CPU, (10, 10))
    # Address space: 512 MB
    try:
        resource.setrlimit(resource.RLIMIT_AS, (512 * 1024 * 1024, 512 * 1024 * 1024))
    except (ValueError, OSError):
        pass  # RLIMIT_AS not supported on all platforms
    # File size: 50 MB
    resource.setrlimit(resource.RLIMIT_FSIZE, (50 * 1024 * 1024, 50 * 1024 * 1024))
    # Number of processes: 64
    try:
        resource.setrlimit(resource.RLIMIT_NPROC, (64, 64))
    except (ValueError, OSError):
        pass


def _minimal_env() -> dict[str, str]:
    """Return a minimal env for the subprocess — secrets stripped."""
    keep = {"PATH", "LANG", "LC_ALL", "HOME", "PYTHONDONTWRITEBYTECODE", "PYTHONUNBUFFERED"}
    return {k: v for k, v in os.environ.items() if k in keep}


class PythonExecTool(Tool):
    name = "python_exec"
    description = (
        "Execute Python code in a subprocess with AST inspection, resource "
        "limits (10s CPU, 512MB RAM, 50MB file), and a stripped environment. "
        "Returns stdout+stderr (≤64 KB) and exit code. Imports of os, "
        "subprocess, socket, ctypes, etc. are rejected by the AST inspector. "
        "For file I/O use the file.* tools; for shell use the terminal tool."
    )
    parameters = {
        "type": "object",
        "properties": {
            "code": {"type": "string", "description": "Python source code to execute."},
            "timeout": {"type": "integer", "default": 30, "description": "Max seconds (1-120)."},
        },
        "required": ["code"],
    }
    risk_level = "high"
    requires_approval = True
    tags = ["python", "execution"]
    category = "system"

    def __init__(self, workspace_root: str | None = None) -> None:
        self._workspace_root = Path(workspace_root).resolve() if workspace_root else None

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        call_id = f"py_{int(start * 1000)}"
        code = (params.get("code") or "").strip()
        if not code:
            return ToolResult(call_id=call_id, tool=self.name, success=False,
                              error="code is required", duration_s=0.0)

        # AST inspection — reject dangerous imports/calls/attrs.
        violations = _inspect_code(code)
        if violations:
            log.warning("PythonExecTool rejected code with %d violation(s): %s",
                        len(violations), "; ".join(violations[:5]))
            return ToolResult(call_id=call_id, tool=self.name, success=False,
                              error="code rejected by sandbox inspector: " + "; ".join(violations[:5]),
                              duration_s=time.time() - start)

        # Clamp timeout.
        try:
            timeout = max(1, min(120, int(params.get("timeout", 30))))
        except (TypeError, ValueError):
            timeout = 30

        # Write temp file with mode 0o600 inside workspace (or system temp).
        tmp_dir = str(self._workspace_root / ".tmp") if self._workspace_root else None
        if tmp_dir:
            Path(tmp_dir).mkdir(parents=True, exist_ok=True)
        try:
            fd, tmp_path = tempfile.mkstemp(suffix=".py", dir=tmp_dir)
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "w") as f:
                f.write(code)
        except Exception as e:
            return ToolResult(call_id=call_id, tool=self.name, success=False,
                              error=f"temp file creation failed: {e}",
                              duration_s=time.time() - start)

        try:
            proc = await asyncio.create_subprocess_exec(
                "python3", tmp_path,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                env=_minimal_env(),
                start_new_session=True,  # so we can killpg on timeout
                preexec_fn=_apply_rlimits,
            )
            try:
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
            except asyncio.TimeoutError:
                try:
                    os.killpg(os.getpgid(proc.pid), 9)
                except (ProcessLookupError, PermissionError, OSError):
                    try:
                        proc.kill()
                    except ProcessLookupError:
                        pass
                return ToolResult(call_id=call_id, tool=self.name, success=False,
                                  error=f"timeout after {timeout}s (process group killed)",
                                  duration_s=time.time() - start)
            text = (stdout or b"").decode("utf-8", errors="replace")
            if len(text) > 65_536:
                text = text[:65_536] + "\n…(truncated)"
            return ToolResult(
                call_id=call_id, tool=self.name,
                success=(proc.returncode == 0),
                output={"stdout": text, "exit_code": proc.returncode},
                error=None if proc.returncode == 0 else f"exit code {proc.returncode}",
                duration_s=time.time() - start,
            )
        except Exception as e:
            return ToolResult(call_id=call_id, tool=self.name, success=False,
                              error=f"execution failed: {type(e).__name__}: {e}",
                              duration_s=time.time() - start)
        finally:
            try:
                Path(tmp_path).unlink(missing_ok=True)
            except Exception as e:
                log.debug("temp file cleanup failed: %s", e)
