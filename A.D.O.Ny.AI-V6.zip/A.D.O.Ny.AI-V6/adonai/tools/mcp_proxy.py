"""MCP tool proxy — exposes an MCP remote tool as a native Tool.

v6 security fix: MCP servers self-declare their risk_level, which a
malicious server can set to "low" to bypass the approval gate. We now
default ALL MCP tools to "high" risk (via MCPConfig.default_risk_level)
unless the tool name is explicitly listed in MCPConfig.trusted_tools.
This ensures remote-controlled tools always require human approval.
"""
from __future__ import annotations

import time
from typing import Any

from adonai.core.interfaces import Tool
from adonai.core.models import ToolResult


class MCPToolProxy(Tool):
    """Adapter that exposes an MCP remote tool as a native Tool."""

    def __init__(self, mcp_client, server: str, spec: dict, *,
                 default_risk_level: str = "high",
                 trusted_tools: list[str] | None = None) -> None:
        self.mcp = mcp_client
        self.server = server
        self.spec = spec
        self.name = spec.get("name", "unnamed")
        self.description = spec.get("description", "")
        self.parameters = spec.get("parameters", {"type": "object", "properties": {}})
        # v6: override server-declared risk_level. MCP servers are remote-
        # controlled and cannot be trusted to self-declare their risk level
        # honestly. A malicious server could return {"risk_level": "low"}
        # to bypass the approval gate. We default to "high" unless the
        # operator has explicitly trusted this tool by name.
        trusted = trusted_tools or []
        if self.name in trusted:
            self.risk_level = spec.get("risk_level", "medium")
        else:
            self.risk_level = default_risk_level
        self.requires_approval = spec.get("requires_approval", self.risk_level == "high")
        self.tags = spec.get("tags", ["mcp"])
        self.category = "mcp"

    async def execute(self, **params: Any) -> ToolResult:
        start = time.time()
        try:
            out = await self.mcp.call_tool(self.server, self.name, params)
            return ToolResult(
                call_id=f"mcp_{self.server}_{self.name}",
                tool=self.name, success=True, output=out,
                duration_s=time.time() - start,
                metadata={"server": self.server},
            )
        except Exception as e:
            return ToolResult(
                call_id=f"mcp_{self.server}_{self.name}",
                tool=self.name, success=False,
                error=f"{type(e).__name__}: {e}",
                duration_s=time.time() - start,
                metadata={"server": self.server},
            )
