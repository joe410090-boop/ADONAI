"""URL safety utilities — SSRF protection for all URL-fetching tools.

Blocks:
  * Non-http(s) schemes (file://, ftp://, gopher://, dict://, etc.)
  * Loopback (127.0.0.0/8, ::1)
  * Link-local (169.254.0.0/16) — includes cloud metadata endpoints
  * Private ranges (10/8, 172.16/12, 192.168/16, fc00::/7)
  * Multicast / broadcast
  * Hostnames that resolve to any of the above (DNS rebinding defense —
    resolved at fetch time, not at validate time, to catch TOCTOU)

Sites that need to fetch internal services must add them to an explicit
allowlist via UrlSafetyPolicy(allow_hosts={"internal-api.local"}).

v6: added safe_fetch() helper for per-hop redirect re-validation (closes
the SSRF-via-redirect gap identified in audit Q6 Finding 6.2).
"""
from __future__ import annotations

import ipaddress
import socket
from dataclasses import dataclass, field
from urllib.parse import urlparse


@dataclass
class UrlSafetyPolicy:
    """Policy for validating URLs before fetch."""

    allow_hosts: set[str] = field(default_factory=set)
    allow_schemes: set[str] = field(default_factory=lambda: {"http", "https"})
    block_loopback: bool = True
    block_link_local: bool = True
    block_private: bool = True
    block_multicast: bool = True
    max_redirects: int = 5

    def validate(self, url: str) -> tuple[bool, str]:
        """Return (ok, reason). reason is "" when ok."""
        if not url or not isinstance(url, str):
            return False, "empty url"
        try:
            parsed = urlparse(url)
        except Exception as e:
            return False, f"url parse error: {e}"

        if parsed.scheme.lower() not in self.allow_schemes:
            return False, f"scheme {parsed.scheme!r} not allowed (allowed: {sorted(self.allow_schemes)})"

        host = parsed.hostname or ""
        if not host:
            return False, "no hostname in url"

        # Explicit allowlist bypasses IP checks (for internal services).
        if host.lower() in {h.lower() for h in self.allow_hosts}:
            return True, ""

        # If host is an IP literal, check it directly.
        try:
            ip = ipaddress.ip_address(host)
            if self.block_loopback and ip.is_loopback:
                return False, f"loopback address blocked: {ip}"
            if self.block_link_local and ip.is_link_local:
                return False, f"link-local address blocked: {ip} (includes cloud metadata)"
            if self.block_private and ip.is_private:
                return False, f"private address blocked: {ip}"
            if self.block_multicast and ip.is_multicast:
                return False, f"multicast address blocked: {ip}"
            return True, ""
        except ValueError:
            pass  # hostname, not IP — resolve and check below

        # Resolve hostname and check ALL A/AAAA records.
        try:
            infos = socket.getaddrinfo(host, None)
        except socket.gaierror as e:
            return False, f"DNS resolution failed for {host!r}: {e}"
        for family, _, _, _, sockaddr in infos:
            ip_str = sockaddr[0]
            try:
                ip = ipaddress.ip_address(ip_str)
            except ValueError:
                continue
            if self.block_loopback and ip.is_loopback:
                return False, f"{host!r} resolves to loopback {ip}"
            if self.block_link_local and ip.is_link_local:
                return False, f"{host!r} resolves to link-local {ip} (cloud metadata?)"
            if self.block_private and ip.is_private:
                return False, f"{host!r} resolves to private {ip}"
            if self.block_multicast and ip.is_multicast:
                return False, f"{host!r} resolves to multicast {ip}"
        return True, ""


# Default policy — blocks all internal/private/link-local.
DEFAULT_POLICY = UrlSafetyPolicy()


# ── v6: redirect-safe fetch helper ──────────────────────────────────────
# Closes the SSRF-via-redirect gap identified in the audit (Q6 Finding 6.2):
# browser._fetch and agent_reach tools used httpx with follow_redirects=True
# and did NOT re-validate redirect targets — so a public URL that 302s to
# http://169.254.169.254/... would be followed and return cloud metadata
# credentials. This helper manually follows redirects, re-validating every
# Location: header against the safety policy.


async def safe_fetch(
    url: str,
    *,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    timeout: float = 30.0,
    policy: UrlSafetyPolicy | None = None,
    max_redirects: int = 5,
) -> tuple[int, dict[str, str], bytes, str]:
    """Fetch a URL with per-hop SSRF re-validation.

    Returns (status_code, headers, body_bytes, final_url).
    Raises ValueError if any URL (initial or redirect target) is rejected
    by the safety policy.

    This is the v6 fix for the SSRF-via-redirect vulnerability. Tools that
    previously used ``httpx.AsyncClient(follow_redirects=True)`` should use
    this helper instead to ensure every redirect hop is re-validated.
    """
    import httpx

    pol = policy or DEFAULT_POLICY
    current_url = url
    current_method = method.upper()
    current_headers = dict(headers) if headers else {}
    final_url = url

    for _hop in range(max_redirects + 1):
        # Re-validate the URL on EVERY hop (initial + each redirect target).
        ok, reason = pol.validate(current_url)
        if not ok:
            raise ValueError(f"URL rejected by safety policy: {reason}")

        async with httpx.AsyncClient(
            timeout=timeout,
            follow_redirects=False,  # we handle redirects manually
        ) as client:
            resp = await client.request(
                current_method, current_url, headers=current_headers,
            )

        final_url = str(resp.url)

        # Non-redirect response — return it.
        if not (300 <= resp.status_code < 400):
            return resp.status_code, dict(resp.headers), resp.content, final_url

        # Redirect — extract Location and re-validate on next hop.
        location = resp.headers.get("location")
        if not location:
            return resp.status_code, dict(resp.headers), resp.content, final_url

        # Resolve relative redirects against the current URL.
        current_url = str(httpx.URL(current_url).join(location))
        # Per RFC 7231 §6.4, redirects other than 307/308 should use GET.
        if resp.status_code not in (307, 308):
            current_method = "GET"

    raise ValueError(f"too many redirects (>{max_redirects})")
