"""Tool scoring — track + rank tool effectiveness over time."""
from __future__ import annotations

import asyncio
from typing import Any


class ToolScorer:
    """Rank tools by recent effectiveness — used by the planner to pick good tools."""

    def __init__(self, registry) -> None:
        self._registry = registry

    def rank_for_goal(self, goal: str, top_k: int = 5) -> list[tuple[str, float]]:
        """Return [(tool_name, score)] for tools likely useful for *goal*.

        Synchronous wrapper that runs the async implementation in the
        current event loop (or creates one if none is running).
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop is not None and loop.is_running():
            # We're inside an already-running event loop (e.g. inside
            # an async function that called this sync method).  Create
            # a *new* thread to run the async version so we don't
            # deadlock the existing loop.
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(
                    asyncio.run,
                    self.rank_for_goal_async(goal, top_k=top_k),
                )
                return future.result(timeout=30.0)
        else:
            return asyncio.run(self.rank_for_goal_async(goal, top_k=top_k))

    async def rank_for_goal_async(self, goal: str, top_k: int = 5) -> list[tuple[str, float]]:
        goal_lower = goal.lower()
        scored: list[tuple[str, float]] = []
        tools = await self._registry.list_user_facing()
        for t in tools:
            score = 0.5  # base
            # Boost if description matches goal keywords.
            desc = (t.description or "").lower()
            for word in goal_lower.split():
                if len(word) > 3 and word in desc:
                    score += 0.1
            # Boost by historical effectiveness.
            score += self._registry.effectiveness(t.name) * 0.3
            # Cap.
            score = min(1.0, score)
            scored.append((t.name, score))
        scored.sort(key=lambda t: t[1], reverse=True)
        return scored[:top_k]
