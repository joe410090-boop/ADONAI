"""Tool registry — central catalog of all tools available to the agent."""
from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
import time
from collections import defaultdict
from pathlib import Path
from typing import Any

from adonai.core.interfaces import Tool
from adonai.core.models import ToolResult
from adonai.tools.permissions import PermissionPolicy

log = logging.getLogger(__name__)


class ToolRegistry:
    """Central registry of all tools (native + MCP).

    Fixes vs. legacy:
      - register() does NOT mutate Tool.name — uses internal alias map.
      - register_many() is sequential (deterministic order).
      - Statistics tracked per registered name (call/success/fail/duration).
      - v9: Statistics persisted to SQLite so SelfImprovementEngine.
        observe_bottlenecks() sees historical data across restarts.
        Previously _stats was in-memory only, so after every restart
        all_stats() returned zeros and the self-improvement pipeline
        essentially never fired.
    """

    def __init__(
        self,
        permission_policy: PermissionPolicy | None = None,
        *,
        stats_db_path: str | Path | None = None,
    ) -> None:
        self._tools: dict[str, Tool] = {}
        self._aliases: dict[str, str] = {}  # registered_name → original tool.name
        self._stats: dict[str, dict[str, Any]] = defaultdict(
            lambda: {"calls": 0, "success": 0, "fail": 0, "total_s": 0.0,
                     "last_used": 0.0}
        )
        self._namespaces: dict[str, str] = {}
        self._permissions = permission_policy or PermissionPolicy()
        # v9: SQLite-backed stats persistence. If stats_db_path is None,
        # stats stay in-memory only (legacy behavior, useful for tests).
        self._stats_db_path: Path | None = (
            Path(stats_db_path) if stats_db_path else None
        )
        self._stats_conn: sqlite3.Connection | None = None
        if self._stats_db_path is not None:
            self._init_stats_db()
            self._load_stats_from_db()

    async def register(self, tool: Tool, namespace: str | None = None) -> None:
        if not tool.name:
            raise ValueError("Tool.name must be non-empty")
        key = f"{namespace}.{tool.name}" if namespace else tool.name
        self._tools[key] = tool
        self._aliases[key] = tool.name
        self._namespaces[key] = namespace or "native"
        log.info("Registered tool '%s' (source=%s)", key, self._namespaces[key])

    async def register_many(self, tools: list[Tool], namespace: str | None = None) -> None:
        for t in tools:
            await self.register(t, namespace=namespace)

    async def unregister(self, name: str) -> bool:
        if name in self._tools:
            del self._tools[name]
            self._aliases.pop(name, None)
            self._namespaces.pop(name, None)
            return True
        return False

    async def get_tool(self, name: str) -> Tool | None:
        if name in self._tools:
            return self._tools[name]
        # Fallback: caller passed the bare tool.name — match any alias.
        for key, bare in self._aliases.items():
            if bare == name:
                return self._tools[key]
        return None

    async def list_tools(self, tag: str | None = None, namespace: str | None = None) -> list[Tool]:
        tools = list(self._tools.values())
        if tag:
            tools = [t for t in tools if tag in (t.tags or [])]
        if namespace:
            keys = [k for k, ns in self._namespaces.items() if ns == namespace]
            tools = [self._tools[k] for k in keys if k in self._tools]
        return tools

    async def list_user_facing(self) -> list[Tool]:
        """Tools the planner should see — excludes debug/test-tagged."""
        return [t for t in self._tools.values()
                if "debug" not in (t.tags or []) and "test" not in (t.tags or [])]

    async def schemas(self) -> list[dict]:
        return [
            {
                "type": "function",
                "function": {
                    "name": key,
                    "description": tool.description,
                    "parameters": tool.parameters,
                },
            }
            for key, tool in self._tools.items()
        ]

    async def execute(self, name: str, **params: Any) -> ToolResult:
        """Execute a tool by name with parameter validation + permission check.

        v6: adds generic retry-with-backoff for transient-failure tools.
        Previously only python_exec and terminal had retry (via the
        executor's _self_heal_step). All other tools (web_search,
        web_fetch, http.*, etc.) failed the step immediately with no
        retry. Now transient failures (network errors, timeouts, 5xx)
        are retried up to 2 times with exponential backoff.
        """
        tool = await self.get_tool(name)
        if tool is None:
            return ToolResult(
                call_id=f"err_{int(time.time()*1000)}", tool=name,
                success=False, error=f"tool '{name}' not registered",
            )
        # Permission check — use the async variant so high-risk tools
        # can trigger the human-approval callback when require_approval
        # is enabled.
        if hasattr(self._permissions, "check_async"):
            allowed, reason = await self._permissions.check_async(name, tool, params)
        else:
            allowed, reason = self._permissions.check(name, tool, params)
        if not allowed:
            return ToolResult(
                call_id=f"perm_{int(time.time()*1000)}", tool=name,
                success=False, error=f"permission denied: {reason}",
            )
        start = time.time()
        # v6: retry transient failures for non-high-risk tools.
        max_retries = 2 if getattr(tool, "risk_level", "medium") != "high" else 0
        last_result: ToolResult | None = None
        for attempt in range(max_retries + 1):
            try:
                out = await tool.execute(**params)
                if not isinstance(out, ToolResult):
                    out = ToolResult(
                        call_id=f"{name}_{int(start*1000)}", tool=name,
                        success=True, output=out, duration_s=time.time() - start,
                    )
                # Success — record and return.
                if out.success:
                    self._record(name, True, time.time() - start)
                    return out
                # Failure — check if it's transient (worth retrying).
                last_result = out
                if attempt < max_retries and self._is_transient_failure(out):
                    import asyncio as _aio
                    backoff = 0.5 * (2 ** attempt)  # 0.5s, 1.0s
                    log.debug(
                        "Tool '%s' transient failure (attempt %d/%d): %s — retrying in %.1fs",
                        name, attempt + 1, max_retries + 1,
                        (out.error or "")[:120], backoff,
                    )
                    await _aio.sleep(backoff)
                    continue
                # Non-transient failure or out of retries — record and return.
                self._record(name, False, time.time() - start)
                return out
            except Exception as e:
                self._record(name, False, time.time() - start)
                # Check if the exception is transient.
                if attempt < max_retries and self._is_transient_exception(e):
                    import asyncio as _aio
                    backoff = 0.5 * (2 ** attempt)
                    log.debug(
                        "Tool '%s' transient exception (attempt %d/%d): %s — retrying",
                        name, attempt + 1, max_retries + 1, e,
                    )
                    await _aio.sleep(backoff)
                    continue
                return ToolResult(
                    call_id=f"{name}_{int(start*1000)}", tool=name,
                    success=False, error=f"{type(e).__name__}: {e}",
                    duration_s=time.time() - start,
                )
        # Should not reach here, but return last result as fallback.
        if last_result:
            return last_result
        return ToolResult(
            call_id=f"{name}_{int(start*1000)}", tool=name,
            success=False, error="exhausted retries",
            duration_s=time.time() - start,
        )

    @staticmethod
    def _is_transient_failure(result: ToolResult) -> bool:
        """Check if a ToolResult failure is transient (worth retrying)."""
        err = (result.error or "").lower()
        transient_markers = (
            "timeout", "timed out", "connection", "network", "unreachable",
            "reset by peer", "broken pipe", "temporary failure",
            "service unavailable", "gateway", "bad gateway", "503", "502",
            "rate limit", "429", "too many requests",
        )
        return any(m in err for m in transient_markers)

    @staticmethod
    def _is_transient_exception(exc: Exception) -> bool:
        """Check if an exception is transient (worth retrying)."""
        exc_name = type(exc).__name__.lower()
        transient_names = (
            "timeout", "timeouterror", "connectionerror", "connectionreset",
            "connectionaborted", "connectionrefused", "clientdisconnect",
        )
        if any(n in exc_name for n in transient_names):
            return True
        # Check for httpx/aiohttp transient exceptions by name.
        if "timeout" in exc_name or "connect" in exc_name:
            return True
        return False

    def _record(self, name: str, success: bool, duration_s: float) -> None:
        s = self._stats[name]
        s["calls"] += 1
        s["success" if success else "fail"] += 1
        s["total_s"] += duration_s
        s["last_used"] = time.time()
        # v9: persist to SQLite so stats survive restarts.
        if self._stats_db_path is not None:
            try:
                self._persist_stats(name, s)
            except Exception as e:
                log.debug("Tool stats persist failed for %s (non-fatal): %s", name, e)

    # ── v9: SQLite stats persistence ──────────────────────────────────

    def _init_stats_db(self) -> None:
        """Create the tool_stats table if it doesn't exist."""
        assert self._stats_db_path is not None
        self._stats_db_path.parent.mkdir(parents=True, exist_ok=True)
        self._stats_conn = sqlite3.connect(
            str(self._stats_db_path), check_same_thread=False,
        )
        self._stats_conn.row_factory = sqlite3.Row
        with self._stats_conn:
            self._stats_conn.execute("""CREATE TABLE IF NOT EXISTS tool_stats (
                name TEXT PRIMARY KEY,
                calls INTEGER NOT NULL DEFAULT 0,
                success INTEGER NOT NULL DEFAULT 0,
                fail INTEGER NOT NULL DEFAULT 0,
                total_s REAL NOT NULL DEFAULT 0.0,
                last_used REAL NOT NULL DEFAULT 0.0
            )""")

    def _load_stats_from_db(self) -> None:
        """Load stats from SQLite into the in-memory dict on startup."""
        if self._stats_conn is None:
            return
        try:
            rows = self._stats_conn.execute(
                "SELECT name, calls, success, fail, total_s, last_used FROM tool_stats"
            ).fetchall()
            for row in rows:
                self._stats[row["name"]] = {
                    "calls": row["calls"],
                    "success": row["success"],
                    "fail": row["fail"],
                    "total_s": row["total_s"],
                    "last_used": row["last_used"],
                }
            if rows:
                log.info("v9: Loaded tool stats for %d tools from SQLite", len(rows))
        except Exception as e:
            log.warning("Tool stats load failed (non-fatal): %s", e)

    def _persist_stats(self, name: str, stats: dict[str, Any]) -> None:
        """Upsert a single tool's stats into SQLite."""
        if self._stats_conn is None:
            return
        with self._stats_conn:
            self._stats_conn.execute(
                """INSERT OR REPLACE INTO tool_stats
                   (name, calls, success, fail, total_s, last_used)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (name, int(stats["calls"]), int(stats["success"]),
                 int(stats["fail"]), float(stats["total_s"]),
                 float(stats["last_used"])),
            )

    def effectiveness(self, name: str) -> float:
        s = self._stats[name]
        if s["calls"] == 0:
            return 0.5
        return s["success"] / s["calls"]

    def all_stats(self) -> dict[str, dict[str, Any]]:
        return dict(self._stats)

    async def load_mcp_tools(self, mcp_client) -> int:
        """Discover + register tools from all connected MCP servers.

        v6: enforces MCPConfig.deny_tools (previously declared but never
        checked) and passes default_risk_level + trusted_tools to
        MCPToolProxy so MCP tools default to "high" risk.
        """
        if not mcp_client:
            return 0
        # Load MCP config for deny_tools / default_risk_level / trusted_tools.
        deny_list: list[str] = []
        default_risk = "high"
        trusted: list[str] = []
        try:
            from adonai.config.settings import Config
            cfg = Config()
            deny_list = list(getattr(cfg.mcp, "deny_tools", []))
            default_risk = getattr(cfg.mcp, "default_risk_level", "high")
            trusted = list(getattr(cfg.mcp, "trusted_tools", []))
        except Exception:
            pass
        count = 0
        try:
            servers = await mcp_client.list_servers()
        except Exception as e:
            log.warning("MCP list_servers failed: %s", e)
            return 0
        for srv in servers:
            try:
                tools = await mcp_client.discover_tools(srv)
            except Exception as e:
                log.warning("MCP discover_tools(%s) failed: %s", srv, e)
                continue
            for spec in tools:
                tool_name = spec.get("name", "unnamed")
                # v6: enforce deny_tools — previously dead config.
                if tool_name in deny_list:
                    log.warning("MCP tool %r denied by config.deny_tools", tool_name)
                    continue
                from adonai.tools.mcp_proxy import MCPToolProxy
                tool = MCPToolProxy(
                    mcp_client, srv, spec,
                    default_risk_level=default_risk,
                    trusted_tools=trusted,
                )
                await self.register(tool, namespace=f"mcp.{srv}")
                count += 1
        log.info("Loaded %d MCP tools from %d server(s)", count, len(servers))
        return count
