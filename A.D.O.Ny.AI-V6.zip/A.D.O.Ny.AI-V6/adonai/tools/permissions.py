"""Permission policy — gate tool execution based on risk level + forbidden paths/commands.

Supports a human-in-the-loop approval gate for high-risk tools (terminal,
python_exec, file.write).  When ``config.safety.require_approval`` is True
and an approval callback is registered via ``set_approval_callback()``,
high-risk tool calls block until the callback returns True.  Without a
callback, high-risk tools are rejected outright (fail-closed).
"""
from __future__ import annotations

import asyncio
import re
from typing import Any, Awaitable, Callable

from adonai.core.interfaces import Tool
from adonai.config.settings import SafetyConfig


# Patterns that indicate destructive / escape-prone Python code.
# Used by the python_exec code inspection branch below.
#
# NOTE: keep this list narrow.  Blocking `open(..., 'w')` (the previous
# behaviour) rejected every script that saved output to a file — including
# the system-prompt example workflow "save output to file" — and was the
# single most common cause of `python_exec success=False (0.00s)` with no
# output.  We now only block patterns that actually escape the sandbox or
# destroy data outside the working directory.
_DANGEROUS_PYTHON_PATTERNS: tuple[str, ...] = (
    r"\bos\.system\b",
    r"\bos\.popen\b",
    r"\bsubprocess\.",
    r"\bshutil\.rmtree\b",
    r"\b__import__\s*\(",
    r"\beval\s*\(",
    r"\bexec\s*\(",          # bare exec() of arbitrary strings — not the function def
    r"\bcompile\s*\(",
    # Recursive / system-wide deletes — single-file unlink is fine.
    r"\bshutil\.rmtree\b",
    r"\bos\.removedirs\b",
    r"\bos\.unlink\s*\(\s*['\"]/['\"]",
    r"\bPath\s*\(\s*['\"]\s*/\s*['\"]\s*\)\.unlink",
    r"\bPath\s*\(\s*['\"]\s*/\s*['\"]\s*\)\.rmdir",
)
_DANGEROUS_PYTHON_RE = re.compile("|".join(_DANGEROUS_PYTHON_PATTERNS))


# Approval callback type: (tool_name, params) → (approved, reason).
ApprovalCallback = Callable[
    [str, dict[str, Any]],
    Awaitable[tuple[bool, str]],
]


class PermissionPolicy:
    """Gate tool execution.

    When ``config.safety.require_approval`` is True, high-risk tools
    (``tool.risk_level == "high"``) require approval.  If an approval
    callback is registered via :meth:`set_approval_callback`, the policy
    awaits it and returns its verdict.  If no callback is registered,
    high-risk tools are rejected outright (fail-closed).
    """

    def __init__(self, config: SafetyConfig | None = None) -> None:
        self.config = config or SafetyConfig()
        self._require_approval = self.config.require_approval
        self._approval_callback: ApprovalCallback | None = None

    def set_approval_callback(self, cb: ApprovalCallback) -> None:
        """Register a human-in-the-loop approval callback.

        The callback receives ``(tool_name, params)`` and must return
        ``(approved: bool, reason: str)``.  It will be called for every
        high-risk tool execution when ``require_approval`` is True.
        """
        self._approval_callback = cb

    async def check_async(
        self, name: str, tool: Tool, params: dict[str, Any],
    ) -> tuple[bool, str]:
        """Async permission check — awaits the approval callback when
        a high-risk tool requires approval.

        Use this instead of :meth:`check` when the tool registry is in
        an async context (which is always, since ``execute()`` is async).
        """
        # High-risk tools require approval (when enabled).
        if self._require_approval and tool.risk_level == "high":
            if self._approval_callback is not None:
                try:
                    approved, reason = await self._approval_callback(name, params)
                    if not approved:
                        return False, f"high-risk tool rejected by approval gate: {reason}"
                    # Approved — fall through to the rest of the checks.
                except Exception as e:
                    return False, f"approval callback raised: {e}"
            else:
                # No callback registered → fail-closed.
                return False, (
                    "high-risk tool requires approval but no approval "
                    "callback is registered (set PermissionPolicy."
                    "set_approval_callback to enable interactive approval)"
                )
        # Delegate the remaining checks to the sync method.
        return self.check(name, tool, params)

    def check(self, name: str, tool: Tool, params: dict[str, Any]) -> tuple[bool, str]:
        """Returns (allowed, reason).  reason is empty when allowed.

        Synchronous check — does NOT invoke the approval callback.  Use
        :meth:`check_async` for the full async approval flow.
        """
        # Path-based guard for file tools.
        # v7 fix: previously used path.startswith(forbidden) which has the
        # classic containment bug (ws="/foo/bar" matches p="/foo/bar2/x").
        # Now uses Path.is_relative_to() with a realpath fallback, matching
        # the fix already applied in tools/builtin/filesystem.py.
        if name.startswith("file.") or "path" in params:
            path = str(params.get("path", ""))
            if path:
                try:
                    from pathlib import Path
                    p = Path(path).resolve()
                    for forbidden in self.config.forbidden_paths:
                        fp = Path(forbidden).resolve()
                        try:
                            # is_relative_to was added in Python 3.9.
                            if hasattr(p, "is_relative_to"):
                                if p.is_relative_to(fp):
                                    return False, f"path {path!r} is forbidden (under {forbidden!r})"
                            else:
                                # Fallback for <3.9: compare common path.
                                import os.path as _osp
                                if _osp.commonpath([str(p), str(fp)]) == str(fp):
                                    return False, f"path {path!r} is forbidden (under {forbidden!r})"
                        except (ValueError, OSError):
                            # v9 SECURITY FIX: paths on different drives (Windows)
                            # or non-existent paths previously fell back to a
                            # buggy substring check (`path.startswith(forbidden)`)
                            # which produced false positives (`/etc` matches
                            # `/etc2/foo`) AND false negatives (`./etc/passwd`
                            # resolved against workspace slips through).
                            # Now we FAIL CLOSED: deny the request and let the
                            # caller retry with a valid path. This is the only
                            # safe default for path containment.
                            return False, (
                                f"path {path!r} could not be resolved against "
                                f"forbidden path {forbidden!r} — denied (fail-closed)"
                            )
                except Exception:
                    # v9 SECURITY FIX: If path resolution fails (malformed path,
                    # permission denied on parent, etc.), FAIL CLOSED instead of
                    # falling back to a substring check that has known bypasses.
                    return False, (
                        f"path {path!r} could not be resolved — denied (fail-closed)"
                    )
        # Command-based guard for shell / terminal / git.
        if name in ("shell", "terminal", "git") or "command" in params:
            cmd = str(params.get("command", ""))
            # v9: parse the command into tokens and check the binary (tokens[0])
            # against forbidden_commands, instead of doing a fragile substring
            # match against the raw command string. The substring match would
            # block `echo shutdown` (printing the word) — false positive.
            import shlex
            try:
                tokens = shlex.split(cmd)
            except ValueError:
                tokens = cmd.split()
            if tokens:
                binary = tokens[0]
                # Check the binary itself against forbidden commands.
                for forbidden in self.config.forbidden_commands:
                    # If the forbidden entry is a single word (like "shutdown",
                    # "reboot", "mkfs"), match against the binary only.
                    if " " not in forbidden.strip() and binary.endswith(forbidden):
                        return False, f"command binary matches forbidden pattern {forbidden!r}"
                    # If the forbidden entry is a multi-token pattern (like
                    # "rm -rf /"), check it against the joined tokens.
                    if " " in forbidden.strip() and forbidden in " ".join(tokens):
                        return False, f"command matches forbidden pattern {forbidden!r}"
        # Code inspection for python_exec — scan for destructive patterns.
        if name == "python_exec" and "code" in params:
            code = str(params.get("code", ""))
            match = _DANGEROUS_PYTHON_RE.search(code)
            if match:
                return False, (
                    f"python_exec code matches forbidden pattern "
                    f"{match.group()!r}"
                )
        return True, ""
