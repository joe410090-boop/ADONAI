"""Coder agent — code generation + refactoring + debugging + testing.

Clean version: uses the real ToolCallingAgent loop so the LLM decides
when to call python_exec, file.read, file.write, web_search, etc.
No more broken `tools.execute(...)` positional-arg bug, no more
hard-coded pre-code research injection.
"""
from __future__ import annotations

import logging
from typing import Any

from adonai.agents.base import BaseAgent
from adonai.agents.tool_calling_agent import ToolCallingAgent
from adonai.core.models import Task, TaskResult, TaskStatus
from adonai.llm.prompt import SystemPrompts

log = logging.getLogger(__name__)


class CoderAgent(BaseAgent):
    name = "coder"
    role = "coding"
    capabilities = ["code", "write", "implement", "build", "function",
                    "class", "refactor", "debug", "test", "script", "program"]
    preferred_tools = ["python_exec", "file.read", "file.write", "file.list",
                       "terminal", "web_search"]
    system_prompt = SystemPrompts.CODER

    def can_handle(self, goal: str) -> float:
        g = goal.lower()
        code_indicators = [
            "write code", "write a script", "write a function",
            "write a python", "write a program", "implement a function",
            "implement a class", "write a class", "code to:",
            "write code to:", "python code", "javascript code",
            "debug", "refactor", "write a test",
        ]
        for indicator in code_indicators:
            if indicator in g:
                return 0.9
        for cap in self.capabilities:
            if cap in g:
                return 0.7
        return 0.0

    async def run(self, task: Task) -> TaskResult:
        """Run the real tool-calling loop for coding tasks.

        The LLM is given the tool schemas (python_exec, file.read,
        file.write, terminal, web_search, etc.) and decides for itself
        when and how to call them.  It can search the web for current
        API docs, write code, execute it, see the output, and iterate
        — all through native tool calling.
        """
        if self.llm is None or self.tools is None:
            return TaskResult(
                task_id=task.id, status=TaskStatus.FAILED,
                error="CoderAgent requires an LLM and tool registry",
            )

        # Build conversation history from the parent executor (if any).
        history: list[dict[str, str]] = []
        if self.parent is not None and hasattr(self.parent, "executor"):
            executor = getattr(self.parent, "executor", None)
            if executor is not None and task.session_id:
                history = executor._get_history(task.session_id)

        agent = ToolCallingAgent(
            llm=self.llm,
            tools=self.tools,
            max_iterations=10,  # coding tasks often need multiple iterations
            temperature=0.2,
            max_tokens=2048,
        )

        try:
            reply = await agent.run(
                user_message=task.goal,
                system_prompt=self.system_prompt,
                history=history,
                session_id=task.session_id,
            )
            return TaskResult(
                task_id=task.id, status=TaskStatus.COMPLETED,
                output=reply, steps_executed=1,
            )
        except Exception as e:
            return TaskResult(
                task_id=task.id, status=TaskStatus.FAILED,
                error=f"{type(e).__name__}: {e}",
            )
