"""Upgrade 1 — Dedicated Critic Agent.

Pipeline change::

    Planner → Executor → Critic → Verifier

The Critic runs *between* the Executor and the Verifier.  It:

* challenges assumptions
* searches for weaknesses
* proposes alternative plans
* detects hallucinations
* evaluates efficiency
* detects premature conclusions

Outputs a :class:`~adonai.core.models.CritiqueReport` with confidence,
weaknesses, alternatives, and risk_score.

The Critic is intentionally **stateless and model-agnostic** — it can be
subclassed to use any LLM backend, or wrapped around a heuristic rule
engine for offline evaluation.
"""
from __future__ import annotations

import json
import logging
import re
from typing import Any
from uuid import uuid4

from adonai.core.exceptions import CritiqueError
from adonai.core.events import EventPublisher, EventTypes
from adonai.core.interfaces import Critic, LLMClient
from adonai.core.json_utils import JSONExtractionError, extract_json
from adonai.core.models import (
    CritiqueReport, Plan, PlanStep, Task, TaskResult, TaskStatus,
)

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Heuristic hallucination / weakness detectors
# ──────────────────────────────────────────────────────────────────────────────

_HALLUCINATION_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    (
        re.compile(r"\b(as an ai language model|i am an ai|i'm just an? ai)\b", re.I),
        "AI self-identification leaked into output — possible RLHF hallucination.",
    ),
    (
        re.compile(r"\b(i cannot|i can't|i am unable to) (access|browse|fetch|search)\b", re.I),
        "Claims inability to use tools — verify the tool was actually invoked.",
    ),
    (
        re.compile(r"\b(simulated|hypothetical|imaginary) (results?|data|output)\b", re.I),
        "Output references simulated/hypothetical data — may be fabricated.",
    ),
    (
        re.compile(r"\bhttps?://[^\s]+example\.com\b", re.I),
        "URL points to example.com — likely a placeholder, not a real source.",
    ),
    (
        re.compile(r"\b\d{4}-\d{2}-\d{2}\b.*\b(future|upcoming|scheduled)\b", re.I),
        "Future-dated event described as fact — possible fabrication.",
    ),
]

_PREMATURE_CONCLUSION_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\b(in conclusion|to summarize|in summary)\b", re.I),
    re.compile(r"\b(the answer is|therefore,?\s+the)\b", re.I),
]


def _heuristic_hallucination_flags(text: str) -> list[str]:
    flags: list[str] = []
    if not text:
        return flags
    for pat, msg in _HALLUCINATION_PATTERNS:
        if pat.search(text):
            flags.append(msg)
    return flags


def _heuristic_premature_conclusion(
    text: str, steps_executed: int, max_steps: int,
) -> bool:
    """Flag if the model concluded in <30% of allowed steps."""
    if not text or max_steps <= 0:
        return False
    if steps_executed / max_steps > 0.5:
        return False
    return any(p.search(text) for p in _PREMATURE_CONCLUSION_PATTERNS)


def _heuristic_efficiency(plan: Plan, result: TaskResult) -> list[str]:
    notes: list[str] = []
    if not plan or not plan.steps:
        return notes
    # Redundant tool calls (same tool invoked 3+ times).
    tool_counts: dict[str, int] = {}
    for step in plan.steps:
        if step.tool:
            tool_counts[step.tool] = tool_counts.get(step.tool, 0) + 1
    for tool, count in tool_counts.items():
        if count >= 3:
            notes.append(
                f"Tool '{tool}' invoked {count} times — possible redundant work."
            )
    # Steps with no verification gate.
    unverified = sum(
        1 for s in plan.steps
        if s.verification_type.value == "unverified"
    )
    if unverified > len(plan.steps) / 2:
        notes.append(
            f"{unverified}/{len(plan.steps)} steps have no verification gate."
        )
    # Empty output despite execution.
    if (
        result.status == TaskStatus.COMPLETED
        and (result.output is None or str(result.output).strip() == "")
    ):
        notes.append("Task marked completed but produced empty output.")
    return notes


# ──────────────────────────────────────────────────────────────────────────────
# Critic Agent
# ──────────────────────────────────────────────────────────────────────────────


_CRITIC_SYSTEM_PROMPT = (
    "You are the CRITIC agent in an autonomous AI research platform.\n"
    "Your job is to find problems with the proposed plan/step/result before\n"
    "it reaches the verifier.  Be skeptical, concrete, and specific.\n\n"
    "For each target, you MUST output JSON with EXACTLY these fields:\n"
    "{\n"
    '  "confidence": 0.0-1.0,        // your confidence in the target\n'
    '  "weaknesses": [str],           // concrete weaknesses\n'
    '  "alternatives": [str],         // alternative approaches\n'
    '  "hallucination_flags": [str],  // unsupported or fabricated claims\n'
    '  "efficiency_notes": [str],     // wasted steps / slow paths\n'
    '  "premature_conclusion": bool,  // did the agent conclude too early?\n'
    '  "risk_score": 0.0-1.0,         // aggregate risk of executing\n'
    '  "recommendation": "accept" | "revise" | "reject" | "escalate",\n'
    '  "rationale": str               // one-paragraph justification\n'
    "}\n\n"
    "Return ONLY the JSON object.  No prose, no markdown fences."
)


class CriticAgent(Critic, EventPublisher):
    """Default LLM-backed critic with heuristic pre-filtering.

    The critic is intentionally cheap to call: it receives the target
    (plan / step / result) and the task, and returns a
    :class:`CritiqueReport`.  Heuristic checks run first so we can short-
    circuit obvious problems without spending an LLM call.
    """

    name: str = "critic"

    def __init__(
        self,
        llm: LLMClient | None = None,
        *,
        config: Any = None,
    ) -> None:
        self.llm = llm
        self.config = config

    # ── Public API ────────────────────────────────────────────────────────

    async def critique(
        self,
        task: Task,
        target: Any,
        *,
        target_kind: str = "result",
        context: dict[str, Any] | None = None,
    ) -> CritiqueReport:
        """Critique a plan / step / result / hypothesis / experiment.

        Falls back to a heuristic-only report when no LLM is configured.
        """
        context = context or {}
        # 1. Heuristic pass — always runs (cheap, deterministic).
        heuristic = self._heuristic_pass(task, target, target_kind, context)

        # 2. LLM pass — only if LLM is available.  (We could short-circuit
        #    when heuristics already flagged severe hallucination, but
        #    running the LLM in addition gives us extra signal.)
        report: CritiqueReport
        if self.llm is not None:
            try:
                llm_report = await self._llm_pass(
                    task, target, target_kind, context, heuristic,
                )
                # Merge LLM findings into the heuristic baseline.
                report = self._merge(heuristic, llm_report, task, target_kind)
            except Exception as e:
                log.warning("Critic LLM pass failed: %s — using heuristic only", e)
                report = heuristic
        else:
            report = heuristic

        # Emit critique.completed event for subscribers.
        await self._emit(EventTypes.CRITIQUE_COMPLETED, {
            "task_id": task.id,
            "target_kind": target_kind,
            "confidence": report.confidence,
            "risk_score": report.risk_score,
            "weakness_count": len(report.weaknesses),
        })

        return report

    # ── Heuristic pass ────────────────────────────────────────────────────

    def _heuristic_pass(
        self,
        task: Task,
        target: Any,
        target_kind: str,
        context: dict[str, Any],
    ) -> CritiqueReport:
        weaknesses: list[str] = []
        alternatives: list[str] = []
        hallucination_flags: list[str] = []
        efficiency_notes: list[str] = []
        premature = False
        risk_score = 0.2  # baseline

        if target_kind == "plan" and isinstance(target, Plan):
            weaknesses.extend(self._heuristic_plan_weaknesses(target))
            efficiency_notes.extend(self._heuristic_plan_efficiency(target))
            risk_score = self._heuristic_plan_risk(target)
        elif target_kind == "step" and isinstance(target, PlanStep):
            weaknesses.extend(self._heuristic_step_weaknesses(target))
            risk_score = 0.4 if target.risk_level == "high" else 0.2
        elif target_kind == "result":
            output_text = self._extract_text(target)
            hallucination_flags.extend(_heuristic_hallucination_flags(output_text))
            premature = _heuristic_premature_conclusion(
                output_text,
                getattr(target, "steps_executed", 0) if isinstance(target, TaskResult) else 0,
                task.max_steps,
            )
            if isinstance(target, TaskResult) and context.get("plan"):
                efficiency_notes.extend(_heuristic_efficiency(context["plan"], target))
            risk_score = 0.6 if hallucination_flags else 0.3
            if premature:
                risk_score = max(risk_score, 0.5)

        confidence = max(0.05, 1.0 - risk_score - 0.1 * len(weaknesses))
        recommendation = self._recommend(confidence, risk_score, hallucination_flags)

        return CritiqueReport(
            task_id=task.id,
            target_kind=target_kind,  # type: ignore[arg-type]
            target_ref=getattr(target, "id", None),
            confidence=round(confidence, 3),
            weaknesses=weaknesses,
            alternatives=alternatives,
            hallucination_flags=hallucination_flags,
            efficiency_notes=efficiency_notes,
            premature_conclusion=premature,
            risk_score=round(risk_score, 3),
            recommendation=recommendation,  # type: ignore[arg-type]
            rationale="heuristic-only critique (no LLM call)",
            metadata={"engine": "heuristic"},
        )

    def _heuristic_plan_weaknesses(self, plan: Plan) -> list[str]:
        weaknesses: list[str] = []
        if not plan.steps:
            weaknesses.append("Plan has zero steps.")
            return weaknesses
        # Step with no description.
        if any(not s.description.strip() for s in plan.steps):
            weaknesses.append("One or more steps have empty descriptions.")
        # Step referencing an unknown tool.
        # (We can't validate against the registry here without injecting it;
        #  leave that to the executor.)
        # Cycle in dependencies.
        if self._has_cycle(plan):
            weaknesses.append("Plan dependency graph has a cycle.")
        # Steps with high risk and no verification.
        for s in plan.steps:
            if s.risk_level == "high" and s.verification_type.value == "unverified":
                weaknesses.append(
                    f"High-risk step '{s.description[:60]}…' has no verification gate."
                )
        # Plan confidence too low.
        if plan.confidence < 0.3:
            weaknesses.append(
                f"Plan self-reported confidence is low ({plan.confidence:.2f})."
            )
        return weaknesses

    def _heuristic_plan_efficiency(self, plan: Plan) -> list[str]:
        notes: list[str] = []
        # Sequential-only plan when parallelism is possible.
        ready_first = [
            s for s in plan.steps
            if not s.dependencies
        ]
        if len(ready_first) >= 3:
            notes.append(
                f"{len(ready_first)} steps have no dependencies — could run in parallel."
            )
        # Long plan.
        if len(plan.steps) > 12:
            notes.append(
                f"Plan has {len(plan.steps)} steps — consider decomposing into sub-tasks."
            )
        return notes

    def _heuristic_plan_risk(self, plan: Plan) -> float:
        if not plan.steps:
            return 0.8
        high = sum(1 for s in plan.steps if s.risk_level == "high")
        medium = sum(1 for s in plan.steps if s.risk_level == "medium")
        risk = (high * 0.2) + (medium * 0.05)
        return min(1.0, risk + (1.0 - plan.confidence) * 0.3)

    def _heuristic_step_weaknesses(self, step: PlanStep) -> list[str]:
        weaknesses: list[str] = []
        if not step.description.strip():
            weaknesses.append("Step description is empty.")
        if step.tool is None and step.verification_type.value == "unverified":
            weaknesses.append(
                "LLM-only step with no verification gate — output is unverifiable."
            )
        if step.risk_level == "high" and not step.expected_outcome:
            weaknesses.append("High-risk step has no expected_outcome.")
        return weaknesses

    def _has_cycle(self, plan: Plan) -> bool:
        """Simple DFS cycle detection on the plan's step dependency graph."""
        step_ids = {s.id for s in plan.steps}
        adj: dict[str, list[str]] = {s.id: list(s.dependencies) for s in plan.steps}
        # Filter deps to known step ids.
        adj = {k: [d for d in v if d in step_ids] for k, v in adj.items()}
        WHITE, GRAY, BLACK = 0, 1, 2
        color = {sid: WHITE for sid in step_ids}

        def visit(node: str) -> bool:
            color[node] = GRAY
            for nxt in adj.get(node, []):
                if color[nxt] == GRAY:
                    return True
                if color[nxt] == WHITE and visit(nxt):
                    return True
            color[node] = BLACK
            return False

        return any(color[sid] == WHITE and visit(sid) for sid in step_ids)

    # ── LLM pass ──────────────────────────────────────────────────────────

    async def _llm_pass(
        self,
        task: Task,
        target: Any,
        target_kind: str,
        context: dict[str, Any],
        heuristic: CritiqueReport,
    ) -> dict[str, Any]:
        """Call the LLM with a structured prompt; return parsed JSON dict."""
        if self.llm is None:
            return {}
        user_prompt = self._build_user_prompt(task, target, target_kind, heuristic)
        resp = await self.llm.complete(
            messages=[
                {"role": "system", "content": _CRITIC_SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
            temperature=0.2,
            max_tokens=1024,
        )
        text = resp.text or ""
        try:
            data = extract_json(text)
        except JSONExtractionError as e:
            log.warning("Critic LLM returned unparseable JSON: %s", e)
            raise CritiqueError(f"unparseable critic output: {e}") from e
        if not isinstance(data, dict):
            raise CritiqueError("critic LLM returned non-dict JSON")
        return data

    def _build_user_prompt(
        self,
        task: Task,
        target: Any,
        target_kind: str,
        heuristic: CritiqueReport,
    ) -> str:
        target_summary: str
        if isinstance(target, Plan):
            steps_str = "\n".join(
                f"  {i+1}. {s.description} [tool={s.tool}, risk={s.risk_level}, "
                f"verify={s.verification_type.value}]"
                for i, s in enumerate(target.steps)
            )
            target_summary = (
                f"PLAN (confidence={target.confidence:.2f}, {len(target.steps)} steps):\n{steps_str}"
            )
        elif isinstance(target, PlanStep):
            target_summary = (
                f"STEP: {target.description}\n"
                f"  tool={target.tool}, risk={target.risk_level}, "
                f"verify={target.verification_type.value}\n"
                f"  expected_outcome={target.expected_outcome}"
            )
        elif isinstance(target, TaskResult):
            output_str = str(target.output)[:2000] if target.output else "(empty)"
            target_summary = (
                f"RESULT (status={target.status.value}, "
                f"steps_executed={target.steps_executed}, "
                f"confidence={target.confidence:.2f}):\n{output_str}"
            )
            if target.error:
                target_summary += f"\n\nERROR: {target.error[:500]}"
        else:
            target_summary = f"TARGET ({target_kind}): {str(target)[:2000]}"

        heuristic_summary = (
            f"\n\nHeuristic pre-check (already detected):\n"
            f"  weaknesses: {heuristic.weaknesses}\n"
            f"  hallucination_flags: {heuristic.hallucination_flags}\n"
            f"  efficiency_notes: {heuristic.efficiency_notes}\n"
            f"  premature_conclusion: {heuristic.premature_conclusion}\n"
            f"  risk_score: {heuristic.risk_score:.2f}"
        )

        return (
            f"TASK GOAL: {task.goal}\n"
            f"TASK COMPLEXITY: {task.complexity.value}\n\n"
            f"{target_summary}"
            f"{heuristic_summary}\n\n"
            f"Produce your critique as JSON.  Do NOT repeat the heuristic "
            f"findings verbatim — add NEW information or confirm/refute them."
        )

    # ── Merge + recommendation ───────────────────────────────────────────

    def _merge(
        self,
        heuristic: CritiqueReport,
        llm_report: dict[str, Any],
        task: Task,
        target_kind: str,
    ) -> CritiqueReport:
        # Dedupe weaknesses/alternatives/flags while preserving order.
        def _merge_list(a: list[str], b: list[str]) -> list[str]:
            seen = set()
            out: list[str] = []
            for x in list(a) + list(b):
                key = x.strip().lower()
                if not key or key in seen:
                    continue
                seen.add(key)
                out.append(x)
            return out

        # LLM confidence takes precedence if provided; otherwise keep heuristic.
        try:
            confidence = float(llm_report.get("confidence", heuristic.confidence))
        except (TypeError, ValueError):
            confidence = heuristic.confidence
        confidence = max(0.0, min(1.0, confidence))

        try:
            risk_score = float(llm_report.get("risk_score", heuristic.risk_score))
        except (TypeError, ValueError):
            risk_score = heuristic.risk_score
        risk_score = max(0.0, min(1.0, risk_score))

        recommendation = self._recommend(
            confidence, risk_score,
            _merge_list(heuristic.hallucination_flags,
                        list(llm_report.get("hallucination_flags") or [])),
        )

        return CritiqueReport(
            id=heuristic.id,
            task_id=task.id,
            target_kind=target_kind,  # type: ignore[arg-type]
            target_ref=heuristic.target_ref,
            confidence=round(confidence, 3),
            weaknesses=_merge_list(
                heuristic.weaknesses, list(llm_report.get("weaknesses") or [])
            ),
            alternatives=_merge_list(
                heuristic.alternatives, list(llm_report.get("alternatives") or [])
            ),
            hallucination_flags=_merge_list(
                heuristic.hallucination_flags,
                list(llm_report.get("hallucination_flags") or []),
            ),
            efficiency_notes=_merge_list(
                heuristic.efficiency_notes,
                list(llm_report.get("efficiency_notes") or []),
            ),
            premature_conclusion=bool(
                llm_report.get("premature_conclusion", heuristic.premature_conclusion)
            ),
            risk_score=round(risk_score, 3),
            recommendation=recommendation,  # type: ignore[arg-type]
            rationale=str(llm_report.get("rationale") or heuristic.rationale),
            metadata={"engine": "hybrid", "llm_findings": len(llm_report)},
        )

    def _recommend(
        self,
        confidence: float,
        risk_score: float,
        hallucination_flags: list[str],
    ) -> str:
        """Apply thresholds from config (or defaults) to pick a recommendation."""
        cfg = getattr(self.config, "critic", None) if self.config else None
        revise_t = getattr(cfg, "revise_threshold", 0.45) if cfg else 0.45
        reject_t = getattr(cfg, "reject_threshold", 0.20) if cfg else 0.20
        risk_block_t = getattr(cfg, "risk_block_threshold", 0.80) if cfg else 0.80

        if risk_score >= risk_block_t or hallucination_flags:
            # Severe hallucination → always escalate so a human can review.
            if hallucination_flags:
                return "escalate"
            return "reject"
        if confidence < reject_t:
            return "reject"
        if confidence < revise_t:
            return "revise"
        return "accept"

    # ── Helpers ───────────────────────────────────────────────────────────

    @staticmethod
    def _extract_text(target: Any) -> str:
        if isinstance(target, TaskResult):
            return str(target.output or "") + " " + (target.error or "")
        if isinstance(target, str):
            return target
        return str(target)


# ──────────────────────────────────────────────────────────────────────────────
# Heuristic-only critic (no LLM required) — for offline / cheap use
# ──────────────────────────────────────────────────────────────────────────────

