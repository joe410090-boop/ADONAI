"""Executive agent — goal decomposition + task orchestration + delegation."""
from __future__ import annotations

import json
import logging
from typing import Any

from adonai.agents.base import BaseAgent
from adonai.core.json_utils import extract_json
from adonai.core.models import Task, TaskResult, TaskStatus, TaskComplexity
from adonai.llm.prompt import SystemPrompts

log = logging.getLogger(__name__)


class ExecutiveAgent(BaseAgent):
    """Top-level orchestrator — decomposes goals + delegates to specialists."""

    name = "executive"
    role = "orchestrator"
    capabilities = ["general"]
    preferred_tools: list[str] = []
    system_prompt = SystemPrompts.EXECUTIVE

    def can_handle(self, goal: str) -> float:
        # Executive handles everything by default; specialists override.
        return 0.5

    async def run(self, task: Task) -> TaskResult:
        """Decide whether to handle directly or delegate."""
        if self.parent is None:
            return TaskResult(
                task_id=task.id, status=TaskStatus.FAILED,
                error="executive agent has no parent runtime",
            )

        # If the goal is simple, run directly via the parent.
        if task.complexity in (TaskComplexity.TRIVIAL, TaskComplexity.SIMPLE):
            task.assigned_agent = self.name
            return await self.parent.run(task)

        # For complex goals, ask the LLM how to delegate.
        try:
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": f"Goal: {task.goal}\n\nProduce delegation JSON."},
                ],
                temperature=0.2, max_tokens=512,
            )
            data = extract_json(resp.text or "")
            strategy = data.get("strategy", "direct")
            if strategy == "direct":
                task.assigned_agent = self.name
                return await self.parent.run(task)
            # Delegate to the first sub-agent in the plan.
            delegations = data.get("delegations", [])
            if delegations:
                first = delegations[0]
                target_agent = first.get("agent", "executive")
                # Find the agent in the registry (set by runtime after build).
                if getattr(self.parent, "agent_registry", None) is not None:
                    agent = self.parent.agent_registry.get(target_agent)
                    if agent is not None:
                        task.assigned_agent = target_agent
                        task.description = first.get("task", task.goal)
                        return await agent.run(task)
            # Fallback: run directly.
            task.assigned_agent = self.name
            return await self.parent.run(task)
        except Exception as e:
            log.warning("Executive delegation failed (%s) — running directly", e)
            task.assigned_agent = self.name
            return await self.parent.run(task)
