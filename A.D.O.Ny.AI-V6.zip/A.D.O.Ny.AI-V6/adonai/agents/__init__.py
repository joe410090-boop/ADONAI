"""7-agent hierarchy: executive, planner, researcher, coder, memory, reflection, learning.

v10: adds ParallelToolCallingAgent for concurrent tool execution within a
single LLM turn — cuts multi-tool latency from sum(latencies) to max(latencies).
"""
from adonai.agents.base import BaseAgent
from adonai.agents.executive import ExecutiveAgent
from adonai.agents.researcher import ResearcherAgent
from adonai.agents.coder import CoderAgent
from adonai.agents.reflection import ReflectionAgent
from adonai.agents.learning import LearningAgent
from adonai.agents.memory_agent import MemoryAgent
from adonai.agents.pentester import PentesterAgent
from adonai.agents.registry import AgentRegistry, build_default_registry
from adonai.agents.parallel_tool_agent import (
    ParallelToolCallingAgent,
    execute_tools_parallel,
    analyze_tool_dependencies,
)

__all__ = [
    "BaseAgent", "ExecutiveAgent", "ResearcherAgent", "CoderAgent",
    "ReflectionAgent", "LearningAgent", "MemoryAgent",
    "PentesterAgent",
    "AgentRegistry", "build_default_registry",
    "ParallelToolCallingAgent",
    "execute_tools_parallel",
    "analyze_tool_dependencies",
]
