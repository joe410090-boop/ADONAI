"""Executive autonomy layer — continuous execution loop + world model.

Implements Phases 3, 4, 6, 8 of the production upgrade:
  * Phase 3 — Executive controller: long/medium/short-term goals, prioritization,
    scheduling, interrupt/resume/cancel, cost/risk/confidence estimation.
  * Phase 4 — Continuous autonomous loop: observe → think → reason → plan →
    execute → verify → reflect → learn → update memory → repeat.
  * Phase 6 — World model: current projects, active tasks, completed work,
    available tools, system resources, known constraints, deadlines,
    user preferences, environment state.
  * Phase 8 — Self-reflection: after every significant action, store lessons
    that future planning consults.

The ExecutiveController is designed to run perpetually as a background
asyncio task. It does NOT require user input — it picks the next-best
action from the goal hierarchy and works on it. Users can submit new goals
at any time; they're inserted into the hierarchy and prioritized.
"""
from __future__ import annotations

import asyncio
import json
import logging
import sqlite3
import time
import uuid
from dataclasses import dataclass, field, asdict
from enum import Enum
from pathlib import Path
from typing import Any, Awaitable, Callable

from adonai.core.models import Task, TaskResult, TaskStatus

log = logging.getLogger(__name__)


class GoalTier(str, Enum):
    """Phase 5 — hierarchical planning tiers."""
    GOAL = "goal"            # multi-month strategic objective
    MISSION = "mission"      # multi-week effort
    PROJECT = "project"      # multi-day deliverable
    MILESTONE = "milestone"  # multi-hour checkpoint
    TASK = "task"            # minutes-to-hours unit of work
    SUBTASK = "subtask"      # minutes
    ACTION = "action"        # seconds (single tool call)


class GoalStatus(str, Enum):
    PENDING = "pending"
    ACTIVE = "active"
    BLOCKED = "blocked"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    PAUSED = "paused"


@dataclass
class Goal:
    """A node in the hierarchical goal tree (Phase 5)."""
    id: str
    title: str
    description: str = ""
    tier: GoalTier = GoalTier.TASK
    status: GoalStatus = GoalStatus.PENDING
    parent_id: str | None = None
    children: list[str] = field(default_factory=list)  # child goal IDs
    dependencies: list[str] = field(default_factory=list)  # goal IDs that must complete first
    priority: int = 5  # 1 (highest) .. 10 (lowest)
    estimated_cost_usd: float = 0.0
    estimated_duration_s: float = 0.0
    risk_level: str = "low"  # low / medium / high / critical
    confidence: float = 0.5  # 0..1 — agent's confidence in success
    deadline: float | None = None  # unix timestamp
    created_at: float = field(default_factory=time.time)
    started_at: float | None = None
    completed_at: float | None = None
    assigned_agent: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)
    # Reflection (Phase 8) — lessons learned from this goal.
    lessons: list[str] = field(default_factory=list)
    failure_count: int = 0
    max_retries: int = 3


@dataclass
class WorldModel:
    """Phase 6 — the agent's internal model of its world.

    The executive consults this model when deciding "what should I do next?".
    It's updated continuously as goals are added/completed, tools are
    discovered/health-checked, and resources change.
    """
    goals: dict[str, Goal] = field(default_factory=dict)
    root_goal_ids: list[str] = field(default_factory=list)  # top-level goals
    available_tools: list[str] = field(default_factory=list)
    tool_health: dict[str, dict[str, Any]] = field(default_factory=dict)  # tool_name → {healthy, last_check, ...}
    system_resources: dict[str, Any] = field(default_factory=dict)  # cpu, mem, disk
    user_preferences: dict[str, Any] = field(default_factory=dict)
    environment: dict[str, Any] = field(default_factory=dict)  # env vars, hostname, etc.
    constraints: list[str] = field(default_factory=list)  # e.g. "no network after 18:00"
    recent_actions: list[dict[str, Any]] = field(default_factory=list)  # last N actions (episodic)
    recent_reflections: list[dict[str, Any]] = field(default_factory=list)  # last N lessons
    max_recent: int = 100

    def add_goal(self, goal: Goal) -> None:
        self.goals[goal.id] = goal
        if goal.parent_id is None:
            self.root_goal_ids.append(goal.id)
        elif goal.parent_id in self.goals:
            self.goals[goal.parent_id].children.append(goal.id)

    def active_goals(self) -> list[Goal]:
        return [g for g in self.goals.values() if g.status == GoalStatus.ACTIVE]

    def pending_goals(self) -> list[Goal]:
        return [g for g in self.goals.values() if g.status == GoalStatus.PENDING]

    def unblocked_pending(self) -> list[Goal]:
        """Pending goals whose dependencies are all COMPLETED."""
        out = []
        for g in self.pending_goals():
            if all(
                self.goals[d].status == GoalStatus.COMPLETED
                for d in g.dependencies if d in self.goals
            ):
                out.append(g)
        return out

    def record_action(self, action: dict[str, Any]) -> None:
        self.recent_actions.append(action)
        if len(self.recent_actions) > self.max_recent:
            self.recent_actions = self.recent_actions[-self.max_recent:]

    def record_reflection(self, reflection: dict[str, Any]) -> None:
        self.recent_reflections.append(reflection)
        if len(self.recent_reflections) > self.max_recent:
            self.recent_reflections = self.recent_reflections[-self.max_recent:]


# ──────────────────────────────────────────────────────────────────────────────
# Goal persistence — SQLite-backed goal store
# ──────────────────────────────────────────────────────────────────────────────

class GoalStore:
    """SQLite persistence layer for the ExecutiveController's goal tree.

    Goals survive process restarts: on ``save`` the full Goal dataclass is
    serialised to JSON and upserted; on ``load_all`` the entire tree is
    reconstructed and re-parented.  This is what makes the autonomous
    executive *long-running* — a crash or restart doesn't lose the goal
    hierarchy, deadlines, or accumulated lessons.

    The store uses a single table ``executive_goals`` with one row per
    goal.  The ``children`` and ``dependencies`` lists are JSON arrays;
    the ``lessons`` list is JSON; the ``metadata`` dict is JSON.
    """

    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        self._conn.execute("""
            CREATE TABLE IF NOT EXISTS executive_goals (
                id            TEXT PRIMARY KEY,
                title         TEXT NOT NULL,
                description   TEXT NOT NULL DEFAULT '',
                tier          TEXT NOT NULL,
                status        TEXT NOT NULL,
                parent_id     TEXT,
                children      TEXT NOT NULL DEFAULT '[]',
                dependencies  TEXT NOT NULL DEFAULT '[]',
                priority      INTEGER NOT NULL DEFAULT 5,
                estimated_cost_usd REAL NOT NULL DEFAULT 0,
                estimated_duration_s REAL NOT NULL DEFAULT 0,
                risk_level    TEXT NOT NULL DEFAULT 'low',
                confidence    REAL NOT NULL DEFAULT 0.5,
                deadline      REAL,
                created_at    REAL NOT NULL,
                started_at    REAL,
                completed_at  REAL,
                assigned_agent TEXT,
                metadata      TEXT NOT NULL DEFAULT '{}',
                lessons       TEXT NOT NULL DEFAULT '[]',
                failure_count INTEGER NOT NULL DEFAULT 0,
                max_retries   INTEGER NOT NULL DEFAULT 3
            )
        """)
        # Index for fast "find pending/active goals" queries.
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_exec_goals_status "
            "ON executive_goals(status)"
        )
        self._conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_exec_goals_parent "
            "ON executive_goals(parent_id)"
        )
        self._conn.commit()

    def save(self, goal: Goal) -> None:
        """Upsert a single goal into the store."""
        self._conn.execute(
            """INSERT OR REPLACE INTO executive_goals
               (id, title, description, tier, status, parent_id, children,
                dependencies, priority, estimated_cost_usd, estimated_duration_s,
                risk_level, confidence, deadline, created_at, started_at,
                completed_at, assigned_agent, metadata, lessons, failure_count,
                max_retries)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                goal.id, goal.title, goal.description, goal.tier.value,
                goal.status.value, goal.parent_id,
                json.dumps(goal.children), json.dumps(goal.dependencies),
                goal.priority, goal.estimated_cost_usd, goal.estimated_duration_s,
                goal.risk_level, goal.confidence, goal.deadline, goal.created_at,
                goal.started_at, goal.completed_at, goal.assigned_agent,
                json.dumps(goal.metadata), json.dumps(goal.lessons),
                goal.failure_count, goal.max_retries,
            ),
        )
        self._conn.commit()

    def load_all(self) -> list[Goal]:
        """Load all goals from the store and return them as Goal objects."""
        rows = self._conn.execute(
            "SELECT * FROM executive_goals"
        ).fetchall()
        goals: list[Goal] = []
        for row in rows:
            try:
                goals.append(Goal(
                    id=row["id"],
                    title=row["title"],
                    description=row["description"],
                    tier=GoalTier(row["tier"]),
                    status=GoalStatus(row["status"]),
                    parent_id=row["parent_id"],
                    children=json.loads(row["children"]),
                    dependencies=json.loads(row["dependencies"]),
                    priority=row["priority"],
                    estimated_cost_usd=row["estimated_cost_usd"],
                    estimated_duration_s=row["estimated_duration_s"],
                    risk_level=row["risk_level"],
                    confidence=row["confidence"],
                    deadline=row["deadline"],
                    created_at=row["created_at"],
                    started_at=row["started_at"],
                    completed_at=row["completed_at"],
                    assigned_agent=row["assigned_agent"],
                    metadata=json.loads(row["metadata"]),
                    lessons=json.loads(row["lessons"]),
                    failure_count=row["failure_count"],
                    max_retries=row["max_retries"],
                ))
            except Exception as e:
                log.warning("GoalStore: skipping corrupt goal %s: %s", row["id"], e)
        return goals

    def delete(self, goal_id: str) -> bool:
        cur = self._conn.execute(
            "DELETE FROM executive_goals WHERE id = ?", (goal_id,)
        )
        self._conn.commit()
        return cur.rowcount > 0

    def close(self) -> None:
        try:
            self._conn.close()
        except Exception:
            pass


class ExecutiveController:
    """Phase 3 + 4 — the perpetual autonomous executive.

    Lifecycle:
        ctrl = ExecutiveController(runtime=ai)
        await ctrl.start()         # spawns the background loop
        await ctrl.submit_goal("Build a TODO app")  # user-submitted
        ...
        await ctrl.stop()          # graceful shutdown

    The loop runs forever (until stop()), continuously:
        1. Observe: refresh the world model (tool health, resources).
        2. Prioritize: pick the highest-priority unblocked goal.
        3. Decompose: if the goal is high-tier, ask the LLM to break it down.
        4. Execute: run the goal via the runtime.
        5. Verify: check the result against the goal's acceptance criteria.
        6. Reflect: store lessons in the world model + memory.
        7. Repeat.
    """

    def __init__(
        self,
        runtime: Any,
        *,
        tick_interval_s: float = 1.0,
        max_concurrent_goals: int = 4,
        goal_store: GoalStore | None = None,
    ) -> None:
        self.runtime = runtime
        self.world = WorldModel()
        self._tick_interval = tick_interval_s
        self._semaphore = asyncio.Semaphore(max_concurrent_goals)
        self._task: asyncio.Task | None = None
        self._stop_event = asyncio.Event()
        self._running_goals: set[asyncio.Task] = set()
        # Injected dependencies (set in start()).
        self._llm = None
        self._tools = None
        self._memory = None
        # ── Goal persistence ──────────────────────────────────────────
        # When a GoalStore is provided, goals survive process restarts:
        # start() loads all goals from SQLite and re-parents them into
        # the WorldModel; submit_goal/cancel_goal/_execute_goal persist
        # mutations back to the store.  Without a store, the controller
        # is in-memory only (the previous behaviour).
        self._store = goal_store

    async def start(self) -> None:
        """Start the background executive loop."""
        if self._task is not None:
            return
        # Wire up dependencies from the runtime.
        self._llm = getattr(self.runtime, "llm", None)
        self._tools = getattr(self.runtime, "tools", None)
        self._memory = getattr(self.runtime, "memory", None)
        # Snapshot the available tools into the world model.
        if self._tools is not None:
            try:
                tools_list = await self._tools.list_tools()
                self.world.available_tools = [t["name"] if isinstance(t, dict) else t.name
                                              for t in tools_list]
            except Exception as e:
                log.warning("ExecutiveController: could not list tools: %s", e)
        # ── Load persisted goals ──────────────────────────────────────
        if self._store is not None:
            try:
                loaded = self._store.load_all()
                for g in loaded:
                    self.world.add_goal(g)
                if loaded:
                    log.info(
                        "ExecutiveController: recovered %d goal(s) from store",
                        len(loaded),
                    )
            except Exception as e:
                log.warning("ExecutiveController: goal load failed: %s", e)
        self._stop_event.clear()
        self._task = asyncio.create_task(self._loop(), name="executive-loop")
        log.info("ExecutiveController started (tick=%.1fs, max_concurrent=%d)",
                 self._tick_interval, self._semaphore._value)

    async def stop(self, timeout: float = 10.0) -> None:
        """Signal the loop to stop and wait for in-flight goals."""
        self._stop_event.set()
        if self._task is not None:
            try:
                await asyncio.wait_for(self._task, timeout=timeout)
            except asyncio.TimeoutError:
                self._task.cancel()
            self._task = None
        # Cancel any in-flight goal tasks.
        for t in list(self._running_goals):
            t.cancel()
        if self._running_goals:
            await asyncio.gather(*self._running_goals, return_exceptions=True)
        self._running_goals.clear()
        log.info("ExecutiveController stopped")

    async def submit_goal(
        self,
        title: str,
        description: str = "",
        tier: GoalTier = GoalTier.GOAL,
        priority: int = 5,
        deadline: float | None = None,
        parent_id: str | None = None,
    ) -> str:
        """Submit a new goal. Returns the goal ID."""
        goal = Goal(
            id=f"g_{uuid.uuid4().hex[:12]}",
            title=title, description=description, tier=tier,
            priority=priority, deadline=deadline, parent_id=parent_id,
        )
        self.world.add_goal(goal)
        # Persist so the goal survives restarts.
        if self._store is not None:
            try:
                self._store.save(goal)
            except Exception as e:
                log.warning("ExecutiveController: goal save failed: %s", e)
        log.info("ExecutiveController: submitted goal %s (%s, tier=%s, priority=%d)",
                 goal.id, title[:80], tier.value, priority)
        return goal.id

    async def cancel_goal(self, goal_id: str) -> bool:
        """Cancel a goal and all its descendants."""
        goal = self.world.goals.get(goal_id)
        if goal is None:
            return False
        goal.status = GoalStatus.CANCELLED
        goal.completed_at = time.time()
        # Persist the status change.
        if self._store is not None:
            try:
                self._store.save(goal)
            except Exception as e:
                log.warning("ExecutiveController: goal save failed: %s", e)
        # Recursively cancel children.
        for child_id in list(goal.children):
            await self.cancel_goal(child_id)
        log.info("ExecutiveController: cancelled goal %s", goal_id)
        return True

    async def _loop(self) -> None:
        """The perpetual observe→think→plan→execute→verify→reflect loop."""
        log.info("ExecutiveController loop running")
        while not self._stop_event.is_set():
            try:
                await self._tick()
            except asyncio.CancelledError:
                break
            except Exception as e:
                log.error("ExecutiveController tick failed: %s", e, exc_info=True)
            try:
                await asyncio.wait_for(self._stop_event.wait(), timeout=self._tick_interval)
            except asyncio.TimeoutError:
                pass  # normal — tick interval elapsed
        log.info("ExecutiveController loop exited")

    async def _tick(self) -> None:
        """One iteration of the autonomous loop."""
        # 1. Observe — refresh tool health + system resources.
        await self._observe()
        # 1b. v7: Auto-seed goals from recent reflections if the world is
        # empty. Previously the controller ran perpetually but found zero
        # goals unless a user manually submitted one via POST /executive/goals.
        # Now, if there are no pending goals AND we have recent reflections
        # indicating failures, we auto-create "investigate and fix X" goals
        # from the reflection lessons.
        candidates = self.world.unblocked_pending()
        if not candidates and not self._running_goals:
            seeded = await self._auto_seed_goals()
            if seeded:
                candidates = self.world.unblocked_pending()
        if not candidates:
            return  # nothing to do; wait for next tick
        # Sort by (priority asc, deadline asc, tier weight).
        _tier_weight = {GoalTier.GOAL: 0, GoalTier.MISSION: 1, GoalTier.PROJECT: 2,
                        GoalTier.MILESTONE: 3, GoalTier.TASK: 4, GoalTier.SUBTASK: 5,
                        GoalTier.ACTION: 6}
        candidates.sort(key=lambda g: (g.priority, g.deadline or float('inf'),
                                       _tier_weight.get(g.tier, 9)))
        # Don't exceed the concurrency limit.
        if len(self._running_goals) >= self._semaphore._value:
            return
        goal = candidates[0]
        goal.status = GoalStatus.ACTIVE
        goal.started_at = time.time()
        # 3. Decompose high-tier goals (Phase 5) — if it's a GOAL/MISSION/PROJECT
        # and has no children, ask the LLM to decompose it.
        if goal.tier in (GoalTier.GOAL, GoalTier.MISSION, GoalTier.PROJECT) and not goal.children:
            await self._decompose(goal)
            # After decomposition, mark the parent as completed (its children
            # are the actual work) and continue.
            if goal.children:
                goal.status = GoalStatus.COMPLETED
                goal.completed_at = time.time()
                return
        # 4. Execute — run the goal via the runtime.
        t = asyncio.create_task(self._execute_goal(goal))
        self._running_goals.add(t)
        t.add_done_callback(self._running_goals.discard)

    async def _auto_seed_goals(self) -> int:
        """v7: Auto-create goals from recent reflection lessons.

        When the executive loop finds no pending goals, it examines the
        world model's recent_reflections list. If any reflection indicates
        a failure (success=False), it creates a TASK-tier goal to
        "investigate and address the failure pattern" so the controller
        has work to do on the next tick.

        Returns the number of goals seeded.
        """
        if not self.world.recent_reflections:
            return 0
        # Only seed if we haven't recently (rate-limit to once per 5 minutes).
        last_seed = getattr(self, "_last_auto_seed_ts", 0.0)
        if time.time() - last_seed < 300.0:  # 5 minutes
            return 0
        # Find failures in recent reflections.
        failures = [r for r in self.world.recent_reflections if not r.get("success", True)]
        if not failures:
            return 0
        self._last_auto_seed_ts = time.time()
        seeded = 0
        # Deduplicate by title so we don't seed the same investigation twice.
        existing_titles = {g.title for g in self.world.goals.values()}
        for r in failures[:3]:  # cap at 3 per seeding round
            title = f"Investigate failure: {r.get('title', 'unknown')[:60]}"
            if title in existing_titles:
                continue
            existing_titles.add(title)
            description = (
                f"Auto-seeded from reflection (confidence={r.get('confidence', 0.5):.2f}, "
                f"duration={r.get('duration_s', 0):.1f}s). "
                f"Lessons: {'; '.join(r.get('lessons', [])[:3])}"
            )
            await self.submit_goal(
                title=title,
                description=description,
                tier=GoalTier.TASK,
                priority=8,  # low priority — only runs if nothing else is queued
            )
            seeded += 1
            log.info(
                "ExecutiveController: auto-seeded goal %r from reflection "
                "(failure on %r)",
                title, r.get("title", "unknown")[:60],
            )
        return seeded

    async def _observe(self) -> None:
        """Refresh the world model's view of tools + resources."""
        # Tool health (cheap — just check the registry is responsive).
        if self._tools is not None:
            try:
                tools_list = await self._tools.list_tools()
                self.world.available_tools = [t["name"] if isinstance(t, dict) else t.name
                                              for t in tools_list]
                for name in self.world.available_tools:
                    if name not in self.world.tool_health:
                        self.world.tool_health[name] = {"healthy": True, "last_check": time.time()}
            except Exception as e:
                log.debug("observe: tool list failed: %s", e)
        # System resources (cheap — read /proc).
        try:
            import os
            self.world.system_resources = {
                "cpu_count": os.cpu_count(),
                "load_avg": os.getloadavg() if hasattr(os, "getloadavg") else None,
                "pid": os.getpid(),
            }
        except Exception:
            pass
        # ── v7: Read recent blackboard entries ──────────────────────────
        # The Blackboard was previously write-only — runtime._run_multi_agent
        # posted results but nothing ever read them. The executive loop now
        # reads recent entries each tick so it can factor multi-agent
        # outcomes into its prioritization (e.g. detect recurring failures,
        # surface recent successes for goal selection).
        blackboard = getattr(self.runtime, "blackboard", None)
        if blackboard is not None:
            try:
                recent = await blackboard.read(limit=20)
                # Stash in the world model so _tick() / _prioritize() can consult.
                self.world.recent_blackboard = recent
                # If any recent entries indicate a multi-agent failure on a
                # goal we're tracking, bump that goal's failure_count so it
                # gets retried with a different agent next tick.
                for entry in recent:
                    val = entry.get("value") or {}
                    if not isinstance(val, dict):
                        continue
                    task_id = val.get("task_id")
                    if not task_id:
                        continue
                    # Find matching goal in the world model.
                    for g in self.world.goals.values():
                        if g.id == task_id or task_id in g.title:
                            conf = float(val.get("confidence", 0.5))
                            if conf < 0.3 and entry not in g.metadata.get("_seen_bb", []):
                                g.metadata.setdefault("_seen_bb", []).append(entry)
                                log.info(
                                    "ExecutiveController: blackboard flagged low-confidence "
                                    "result for goal %s (conf=%.2f) — will reprioritize",
                                    g.id, conf,
                                )
                            break
            except Exception as e:
                log.debug("observe: blackboard read failed: %s", e)

    async def _decompose(self, goal: Goal) -> None:
        """Ask the LLM to break a high-tier goal into sub-goals (Phase 5).

        v7: now prefers the wired StrategicReasoner (runtime.strategic_reasoner)
        when available — it produces a SQLite-persisted goal hierarchy with
        dependency edges and Bayesian probability updates. Falls back to the
        inline LLM decomposition if the StrategicReasoner is not enabled.
        """
        # ── v7: Prefer DefaultStrategicReasoner if wired ───────────────
        strategic = getattr(self.runtime, "strategic_reasoner", None)
        if strategic is not None:
            try:
                # The StrategicReasoner.decompose() returns a list of
                # StrategicGoal objects with parent/child/dependency edges.
                # We adapt them into the ExecutiveController's Goal model.
                mission = f"{goal.title}\n\n{goal.description}".strip()
                sub_goals = await strategic.decompose(mission, depth=2)
                for sg in sub_goals:
                    sg_tier = GoalTier.TASK
                    tier_str = getattr(sg, "tier", "task").lower()
                    try:
                        sg_tier = GoalTier(tier_str)
                    except ValueError:
                        pass
                    sub_goal = Goal(
                        id=f"g_{uuid.uuid4().hex[:12]}",
                        title=getattr(sg, "title", "untitled"),
                        description=getattr(sg, "description", ""),
                        tier=sg_tier,
                        priority=int(getattr(sg, "priority", goal.priority)),
                        parent_id=goal.id,
                        confidence=float(getattr(sg, "success_probability", 0.5)),
                    )
                    # Copy dependency edges if present.
                    deps = getattr(sg, "dependencies", []) or []
                    if isinstance(deps, list):
                        sub_goal.dependencies = [str(d) for d in deps]
                    self.world.add_goal(sub_goal)
                    if self._store is not None:
                        try:
                            self._store.save(sub_goal)
                        except Exception:
                            pass
                if self._store is not None:
                    try:
                        self._store.save(goal)
                    except Exception:
                        pass
                log.info(
                    "ExecutiveController: decomposed goal %s into %d sub-goals "
                    "via StrategicReasoner",
                    goal.id, len(goal.children),
                )
                return
            except Exception as e:
                log.warning(
                    "ExecutiveController: StrategicReasoner decompose failed "
                    "for %s (%s) — falling back to inline LLM decomposition",
                    goal.id, e,
                )
        # ── Fallback: inline LLM decomposition ─────────────────────────
        if self._llm is None:
            return
        try:
            resp = await self._llm.complete(
                messages=[
                    {"role": "system", "content": (
                        "You are the executive controller of an autonomous AI. "
                        "Decompose the given goal into 2-5 sub-goals. Output JSON: "
                        '{"subgoals":[{"title":"...","description":"...","tier":"mission|project|milestone|task","priority":1-10}]}'
                    )},
                    {"role": "user", "content": f"Goal: {goal.title}\n\nDescription: {goal.description}"},
                ],
                temperature=0.2, max_tokens=512,
            )
            from adonai.core.json_utils import extract_json
            data = extract_json(resp.text or "")
            for sub in data.get("subgoals", []):
                sub_goal = Goal(
                    id=f"g_{uuid.uuid4().hex[:12]}",
                    title=sub.get("title", "untitled"),
                    description=sub.get("description", ""),
                    tier=GoalTier(sub.get("tier", "task")),
                    priority=int(sub.get("priority", goal.priority)),
                    parent_id=goal.id,
                )
                self.world.add_goal(sub_goal)
                # Persist sub-goal so it survives restarts.
                if self._store is not None:
                    try:
                        self._store.save(sub_goal)
                    except Exception:
                        pass
            # Persist the parent goal too (its children list was updated).
            if self._store is not None:
                try:
                    self._store.save(goal)
                except Exception:
                    pass
            log.info("ExecutiveController: decomposed goal %s into %d sub-goals",
                     goal.id, len(goal.children))
        except Exception as e:
            log.warning("ExecutiveController: decompose failed for %s: %s", goal.id, e)

    async def _execute_goal(self, goal: Goal) -> None:
        """Execute a leaf goal via the runtime (Phase 4 — Execute)."""
        async with self._semaphore:
            try:
                task = Task(goal=goal.title, description=goal.description)
                task.assigned_agent = goal.assigned_agent or "executive"
                result = await self.runtime.run(goal.title)
                # 5. Verify — check the result.
                verified = self._verify_result(goal, result)
                # 6. Reflect — store lessons.
                await self._reflect(goal, result, verified)
                # Update goal status.
                if verified and result.status == TaskStatus.COMPLETED:
                    goal.status = GoalStatus.COMPLETED
                    goal.confidence = max(goal.confidence, 0.8)
                else:
                    goal.failure_count += 1
                    if goal.failure_count >= goal.max_retries:
                        goal.status = GoalStatus.FAILED
                    else:
                        goal.status = GoalStatus.PENDING  # retry on next tick
                goal.completed_at = time.time()
                # Persist status change so the goal tree survives restarts.
                if self._store is not None:
                    try:
                        self._store.save(goal)
                    except Exception as e:
                        log.warning("ExecutiveController: goal save failed: %s", e)
                # Record in world model.
                self.world.record_action({
                    "goal_id": goal.id, "title": goal.title,
                    "status": goal.status.value, "verified": verified,
                    "duration_s": goal.completed_at - (goal.started_at or goal.completed_at),
                    "ts": goal.completed_at,
                })
            except asyncio.CancelledError:
                goal.status = GoalStatus.PAUSED
                if self._store is not None:
                    try:
                        self._store.save(goal)
                    except Exception:
                        pass
                raise
            except Exception as e:
                log.error("ExecutiveController: goal %s failed: %s", goal.id, e, exc_info=True)
                goal.status = GoalStatus.FAILED
                goal.failure_count += 1
                goal.lessons.append(f"execution_error: {type(e).__name__}: {e}")
                if self._store is not None:
                    try:
                        self._store.save(goal)
                    except Exception:
                        pass

    def _verify_result(self, goal: Goal, result: TaskResult) -> bool:
        """Phase 11 — verify the result against the goal's acceptance criteria.

        This is a lightweight check — full verification runs in the
        VerificationGate at the executor level. Here we just sanity-check
        that the task succeeded and produced non-empty output.
        """
        if result.status != TaskStatus.COMPLETED:
            return False
        if not result.output:
            return False
        return True

    async def _reflect(self, goal: Goal, result: TaskResult, verified: bool) -> None:
        """Phase 8 — self-reflection after every significant action."""
        lesson = {
            "goal_id": goal.id,
            "title": goal.title,
            "tier": goal.tier.value,
            "success": verified and result.status == TaskStatus.COMPLETED,
            "confidence": result.confidence,
            "duration_s": result.duration_s,
            "ts": time.time(),
            "lessons": list(result.lessons or []),
            "tool_calls": len(result.tool_calls or []),
        }
        self.world.record_reflection(lesson)
        # Persist to memory if available.
        if self._memory is not None:
            try:
                from adonai.core.models import Memory, MemoryType
                mem = Memory(
                    type=MemoryType.EPISODIC,
                    content=f"Goal: {goal.title}\nSuccess: {lesson['success']}\n"
                            f"Confidence: {lesson['confidence']}\nLessons: {lesson['lessons']}",
                    importance=0.8 if verified else 0.6,
                    confidence=lesson["confidence"],
                    tags=["reflection", goal.tier.value, "success" if verified else "failure"],
                    source="executive_reflection",
                )
                await self._memory.add(mem)
            except Exception as e:
                log.debug("reflect: memory add failed: %s", e)
