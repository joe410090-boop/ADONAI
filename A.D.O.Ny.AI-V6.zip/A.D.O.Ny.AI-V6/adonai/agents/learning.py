"""Learning agent — extracts patterns + creates skills from successful executions."""
from __future__ import annotations

import logging
from typing import Any

from adonai.agents.base import BaseAgent
from adonai.core.models import Task, TaskResult, TaskStatus
from adonai.llm.prompt import SystemPrompts

log = logging.getLogger(__name__)


class LearningAgent(BaseAgent):
    name = "learning"
    role = "learning"
    capabilities = ["learn", "extract pattern", "skill", "teach", "improve"]
    preferred_tools: list[str] = []
    system_prompt = SystemPrompts.LEARNING

    def can_handle(self, goal: str) -> float:
        g = goal.lower()
        learning_indicators = [
            "learn from", "extract pattern", "create a skill",
            "teach me", "how can we improve", "what patterns",
            "skill from", "generalize this",
        ]
        for indicator in learning_indicators:
            if indicator in g:
                return 0.8
        for cap in self.capabilities:
            if cap in g:
                return 0.5
        return 0.1  # Background agent — rarely claims primary handling.

    async def run(self, task: Task) -> TaskResult:
        """Extract patterns or skills from the task context and prior results."""
        # The learning agent primarily operates via the LearningLoop
        # (background processing), but can also be directly invoked to
        # extract a skill from a specific task result.
        if self.llm is None:
            return TaskResult(
                task_id=task.id, status=TaskStatus.FAILED,
                error="LearningAgent requires an LLM",
            )

        # Check if the task context includes a prior result to learn from.
        prior_output = None
        if task.context:
            prior_output = task.context.get("output") or task.context.get("prior_output")

        if not prior_output:
            # No prior output — ask the LLM to extract general patterns.
            try:
                resp = await self.llm.complete(
                    messages=[
                        {"role": "system", "content": self.system_prompt},
                        {"role": "user", "content": (
                            f"Task goal: {task.goal}\n\n"
                            f"Extract any reusable patterns or skills from this request. "
                            f"If the request is too vague to extract a pattern, "
                            f"explain what additional context would help."
                        )},
                    ],
                    temperature=0.3, max_tokens=512,
                )
                return TaskResult(
                    task_id=task.id, status=TaskStatus.COMPLETED,
                    output=resp.text, steps_executed=1,
                )
            except Exception as e:
                return TaskResult(
                    task_id=task.id, status=TaskStatus.FAILED,
                    error=f"{type(e).__name__}: {e}",
                )

        # Extract a skill from the prior output.
        try:
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": (
                        f"Task goal: {task.goal}\n\n"
                        f"Prior execution output:\n{str(prior_output)[:2000]}\n\n"
                        f"Extract a reusable skill from this execution. "
                        f"Output JSON: {{\"name\": \"...\", \"description\": \"...\", "
                        f"\"steps\": [...], \"applicability\": \"...\"}}"
                    )},
                ],
                temperature=0.3, max_tokens=512,
            )
            skill_text = resp.text or ""

            # If a SkillManager is available, store the extracted skill.
            if self.parent is not None:
                skill_mgr = getattr(self.parent, "skills", None)
                if skill_mgr is not None and hasattr(skill_mgr, "create"):
                    try:
                        from adonai.core.json_utils import extract_json
                        data = extract_json(skill_text)
                        if isinstance(data, dict) and "name" in data:
                            await skill_mgr.create(
                                name=data["name"],
                                description=data.get("description", ""),
                                steps=data.get("steps", []),
                            )
                    except Exception as e:
                        log.debug("Skill storage failed: %s", e)

            return TaskResult(
                task_id=task.id, status=TaskStatus.COMPLETED,
                output=skill_text, steps_executed=1,
            )
        except Exception as e:
            return TaskResult(
                task_id=task.id, status=TaskStatus.FAILED,
                error=f"{type(e).__name__}: {e}",
            )
