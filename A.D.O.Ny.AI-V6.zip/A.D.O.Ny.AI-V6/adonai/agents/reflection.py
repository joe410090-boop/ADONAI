"""Reflection agent — critiques outputs + detects hallucinations + suggests improvements."""
from __future__ import annotations

import logging
from typing import Any

from adonai.agents.base import BaseAgent
from adonai.core.models import Task, TaskResult, TaskStatus
from adonai.llm.prompt import SystemPrompts

log = logging.getLogger(__name__)


class ReflectionAgent(BaseAgent):
    name = "reflection"
    role = "reflection"
    capabilities = ["critique", "review", "verify", "check"]
    preferred_tools: list[str] = []
    system_prompt = SystemPrompts.REFLECTION

    def can_handle(self, goal: str) -> float:
        g = goal.lower()
        for kw in self.capabilities:
            if kw in g:
                return 0.8
        return 0.1

    async def run(self, task: Task) -> TaskResult:
        """Critique the task's prior output (if any) and return improvements."""
        if self.llm is None:
            return await super().run(task)
        try:
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": f"Goal: {task.goal}\n\nOutput JSON with issues + improvements."},
                ],
                temperature=0.3, max_tokens=512,
            )
            return TaskResult(
                task_id=task.id, status=TaskStatus.COMPLETED,
                output=resp.text, steps_executed=1,
            )
        except Exception as e:
            return TaskResult(
                task_id=task.id, status=TaskStatus.FAILED,
                error=f"{type(e).__name__}: {e}",
            )
