"""Memory agent — recall + storage + consolidation + context assembly."""
from __future__ import annotations

import logging
from typing import Any

from adonai.agents.base import BaseAgent
from adonai.core.models import Task, TaskResult, TaskStatus
from adonai.llm.prompt import SystemPrompts

log = logging.getLogger(__name__)


class MemoryAgent(BaseAgent):
    name = "memory"
    role = "memory"
    capabilities = ["remember", "recall", "forget", "what did i", "memory"]
    preferred_tools: list[str] = []
    system_prompt = SystemPrompts.MEMORY

    def can_handle(self, goal: str) -> float:
        g = goal.lower()
        # Strong match for memory/recall-oriented goals.
        memory_indicators = [
            "remember", "recall", "what did i", "what was that",
            "do you remember", "have we discussed", "forget",
            "my memory", "earlier conversation",
        ]
        for indicator in memory_indicators:
            if indicator in g:
                return 0.9
        for cap in self.capabilities:
            if cap in g:
                return 0.7
        return 0.0

    async def run(self, task: Task) -> TaskResult:
        """Recall relevant memories and synthesize a response."""
        if self.memory is None:
            return TaskResult(
                task_id=task.id, status=TaskStatus.FAILED,
                error="MemoryAgent requires a memory manager",
            )

        # Recall relevant memories.
        try:
            memories = await self.memory.recall(task.goal, top_k=10)
        except Exception as e:
            log.warning("Memory recall failed: %s", e)
            memories = []

        if not memories:
            # No relevant memories found — let the LLM respond.
            if self.llm is not None:
                try:
                    resp = await self.llm.complete(
                        messages=[
                            {"role": "system", "content": self.system_prompt},
                            {"role": "user", "content": (
                                f"Query: {task.goal}\n\n"
                                f"No relevant memories were found. "
                                f"Let the user know and suggest they provide more context."
                            )},
                        ],
                        temperature=0.3, max_tokens=512,
                    )
                    return TaskResult(
                        task_id=task.id, status=TaskStatus.COMPLETED,
                        output=resp.text, steps_executed=1,
                    )
                except Exception as e:
                    return TaskResult(
                        task_id=task.id, status=TaskStatus.FAILED,
                        error=f"{type(e).__name__}: {e}",
                    )
            return TaskResult(
                task_id=task.id, status=TaskStatus.COMPLETED,
                output="No relevant memories found.", steps_executed=1,
            )

        # Synthesize the recalled memories with the LLM.
        # NOTE: the Memory model (adonai/core/models.py:163-178) defines the
        # field as `type`, not `memory_type`. The previous code referenced
        # `m.memory_type` and crashed with AttributeError whenever recall
        # returned non-empty results. Fixed to use `m.type` directly.
        memory_context = "\n".join(
            f"- [{m.type.value if hasattr(m.type, 'value') else m.type}] "
            f"{m.content[:300]} (importance={getattr(m, 'importance', 0.5):.2f})"
            for m in memories[:10]
        )

        if self.llm is not None:
            try:
                resp = await self.llm.complete(
                    messages=[
                        {"role": "system", "content": self.system_prompt},
                        {"role": "user", "content": (
                            f"Query: {task.goal}\n\n"
                            f"Recalled memories:\n{memory_context}\n\n"
                            f"Synthesize a response using these memories."
                        )},
                    ],
                    temperature=0.3, max_tokens=512,
                )
                return TaskResult(
                    task_id=task.id, status=TaskStatus.COMPLETED,
                    output=resp.text, steps_executed=1,
                )
            except Exception as e:
                # Fallback: return raw memory contents.
                return TaskResult(
                    task_id=task.id, status=TaskStatus.COMPLETED,
                    output=f"Recalled memories:\n{memory_context}", steps_executed=1,
                )

        # No LLM — return raw memory contents.
        return TaskResult(
            task_id=task.id, status=TaskStatus.COMPLETED,
            output=f"Recalled memories:\n{memory_context}", steps_executed=1,
        )
