"""Researcher agent — web research + source verification + synthesis.

Clean version: uses the real ToolCallingAgent loop so the LLM decides
when to call web_search, web_fetch, etc.  No more broken
`tools.execute("web_search", {...})` positional-arg bug, no more
"Note: web search was not available" apologetic fallback.
"""
from __future__ import annotations

import logging
from typing import Any

from adonai.agents.base import BaseAgent
from adonai.agents.tool_calling_agent import ToolCallingAgent
from adonai.core.models import Task, TaskResult, TaskStatus
from adonai.llm.prompt import SystemPrompts

log = logging.getLogger(__name__)


class ResearcherAgent(BaseAgent):
    name = "researcher"
    role = "research"
    capabilities = ["research", "search", "find", "look up", "investigate",
                    "news", "trending", "latest"]
    preferred_tools = ["web_search", "web_fetch"]
    system_prompt = SystemPrompts.RESEARCHER

    def can_handle(self, goal: str) -> float:
        g = goal.lower()
        research_indicators = [
            "research", "search for", "find information", "look up",
            "investigate", "what is the latest", "news about",
            "trending", "find out", "tell me about",
        ]
        for indicator in research_indicators:
            if indicator in g:
                return 0.9
        for cap in self.capabilities:
            if cap in g:
                return 0.7
        return 0.0

    async def run(self, task: Task) -> TaskResult:
        """Run the real tool-calling loop for research tasks.

        The LLM is given the tool schemas (web_search, web_fetch, etc.)
        and decides for itself when and how to call them.  Tool results
        are fed back to the LLM, which synthesizes a final answer.
        """
        if self.llm is None or self.tools is None:
            return TaskResult(
                task_id=task.id, status=TaskStatus.FAILED,
                error="ResearcherAgent requires an LLM and tool registry",
            )

        # Build conversation history from the parent executor (if any),
        # so the researcher has context from prior turns.
        history: list[dict[str, str]] = []
        if self.parent is not None and hasattr(self.parent, "executor"):
            executor = getattr(self.parent, "executor", None)
            if executor is not None and task.session_id:
                history = executor._get_history(task.session_id)

        agent = ToolCallingAgent(
            llm=self.llm,
            tools=self.tools,
            max_iterations=8,
            temperature=0.3,
            max_tokens=2048,
        )

        try:
            reply = await agent.run(
                user_message=task.goal,
                system_prompt=self.system_prompt,
                history=history,
                session_id=task.session_id,
            )
            return TaskResult(
                task_id=task.id, status=TaskStatus.COMPLETED,
                output=reply, steps_executed=1,
            )
        except Exception as e:
            return TaskResult(
                task_id=task.id, status=TaskStatus.FAILED,
                error=f"{type(e).__name__}: {e}",
            )
