"""File Analysis Agent — analyzes uploaded files of any type.

Supports: text, code, JSON, CSV, YAML, Markdown, PDF, Word, Excel,
images (via vision LLM), archives (zip/tar), binaries (hex preview).

Wires into the existing ADONAI v3 architecture as a new sub-agent.
"""
# NOTE: do NOT add `from __future__ import annotations` here.
# FastAPI / Pydantic use get_type_hints() to resolve the UploadFile
# parameter annotation in the /upload route, and the ForwardRef
# string produced by PEP 563 fails to resolve.  Keep this file
# importable under stock Python 3.11 annotation semantics.

import asyncio
import base64
import csv
import io
import json
import logging
import mimetypes
import os
import re
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any

# Import UploadFile + File at module level so Pydantic's get_type_hints()
# can resolve them inside the route handlers defined in
# register_file_upload_route().  With `from __future__ import annotations`,
# all annotations become strings — Pydantic can only resolve them if the
# names exist in the module's __globals__.
from fastapi import UploadFile as _FastAPIUploadFile, File as _FastAPIFile, HTTPException as _FastAPIHTTPException

from adonai.agents.base import BaseAgent
from adonai.core.models import Task, TaskResult, TaskStatus
from adonai.llm.prompt import SystemPrompts

log = logging.getLogger(__name__)

# Default upload directory.
UPLOAD_DIR = Path(__file__).resolve().parents[2] / "data" / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

# Max file size we'll read fully (10 MB).
MAX_FILE_SIZE = 10 * 1024 * 1024
# Max bytes to send to the LLM as text.
MAX_TEXT_FOR_LLM = 12_000


class FileAnalysisAgent(BaseAgent):
    """Analyzes uploaded files of any type and reports their contents."""

    name = "file_analyst"
    role = "analysis"
    capabilities = [
        "analyze file", "analyze", "upload", "file analysis",
        "what's in", "inspect", "examine file", "parse file",
        "read file", "summarize file",
    ]
    preferred_tools: list[str] = []
    system_prompt = (
        "You are the File Analysis Agent.  When a user uploads a file "
        "or asks you to analyze a file, examine its contents and "
        "report: file type, structure, key content, and any notable "
        "patterns.  For code, identify language + purpose.  For data "
        "(CSV/JSON), summarize columns + row count.  For documents, "
        "summarize key points.  For images, describe what you see."
    )

    def can_handle(self, goal: str) -> float:
        g = goal.lower()
        for kw in self.capabilities:
            if kw in g:
                return 1.0
        return 0.0

    async def run(self, task: Task) -> TaskResult:
        """Analyze a file.  Expects either:
          - task.context['file_path']  → path to a file on disk
          - task.context['file_name'] + task.context['file_content'] (bytes)
          - task.goal starting with 'analyze file:' followed by a path
        """
        if self.llm is None:
            return TaskResult(
                task_id=task.id, status=TaskStatus.FAILED,
                error="FileAnalysisAgent requires an LLM",
            )

        # Resolve the file to analyze.
        file_path, file_content, file_name = self._resolve_file(task)
        if file_path is None and file_content is None:
            return TaskResult(
                task_id=task.id, status=TaskStatus.FAILED,
                error=(
                    "No file found.  Either:  (1) upload a file via "
                    "POST /upload, then say 'analyze file <name>', or "
                    "(2) include file_content in the task context."
                ),
            )

        try:
            analysis = await self._analyze(file_path, file_content, file_name, task.goal)
            return TaskResult(
                task_id=task.id, status=TaskStatus.COMPLETED,
                output=analysis, steps_executed=1,
                confidence=0.85,
            )
        except Exception as e:
            log.exception("File analysis failed")
            return TaskResult(
                task_id=task.id, status=TaskStatus.FAILED,
                error=f"analysis failed: {type(e).__name__}: {e}",
            )

    # ------------------------------------------------------------------ #
    # File resolution
    # ------------------------------------------------------------------ #

    def _resolve_file(self, task: Task) -> tuple[Path | None, bytes | None, str]:
        """Return (file_path, file_content, file_name) — whichever is available."""
        ctx = task.context or {}

        # 1. Explicit file_content in context (e.g. from /upload endpoint).
        if ctx.get("file_content") and ctx.get("file_name"):
            return None, ctx["file_content"], ctx["file_name"]

        # 2. file_path in context.
        if ctx.get("file_path"):
            p = Path(ctx["file_path"])
            if p.exists() and p.is_file():
                return p, None, p.name

        # 3. Parse from goal: "analyze file <path>" or "analyze <path>".
        goal = task.goal.strip()
        m = re.match(r"(?:analyze\s+(?:file\s+)?)?(.+\.?\w+)", goal, re.IGNORECASE)
        if m:
            candidate = m.group(1).strip().strip('"\'')
            # Try as absolute path.
            p = Path(candidate)
            if p.exists() and p.is_file():
                return p, None, p.name
            # Try in uploads dir.
            p = UPLOAD_DIR / candidate
            if p.exists() and p.is_file():
                return p, None, p.name

        # 4. Just "analyze file" with no path — pick the most recent upload.
        if "file" in goal.lower() and UPLOAD_DIR.exists():
            files = sorted(UPLOAD_DIR.iterdir(), key=os.path.getmtime, reverse=True)
            if files:
                return files[0], None, files[0].name

        return None, None, ""

    # ------------------------------------------------------------------ #
    # Analysis dispatch
    # ------------------------------------------------------------------ #

    async def _analyze(
        self, file_path: Path | None, file_content: bytes | None,
        file_name: str, goal: str,
    ) -> str:
        """Dispatch to the right analyzer based on file type."""
        # Read content if we have a path.
        if file_content is None and file_path is not None:
            size = file_path.stat().st_size
            if size > MAX_FILE_SIZE:
                return f"❌ File too large: {file_name} is {size:,} bytes (max {MAX_FILE_SIZE:,})."
            file_content = file_path.read_bytes()

        if file_content is None:
            return "❌ No file content to analyze."

        size = len(file_content)
        mime, _ = mimetypes.guess_type(file_name)
        if mime is None:
            mime = self._sniff_mime(file_content)

        # Build the analysis header.
        header = (
            f"📊 **File Analysis: `{file_name}`**\n\n"
            f"- **Size:** {size:,} bytes ({size/1024:.1f} KB)\n"
            f"- **Type:** {mime or 'unknown'}\n"
        )
        if file_path:
            header += f"- **Path:** `{file_path}`\n"
        header += f"- **Analyzed:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"

        # Dispatch based on type.
        try:
            if mime and mime.startswith("text/"):
                body = await self._analyze_text(file_content, mime, goal)
            elif mime == "application/json":
                body = await self._analyze_json(file_content, goal)
            elif mime == "text/csv" or file_name.lower().endswith(".csv"):
                body = await self._analyze_csv(file_content, goal)
            elif mime in ("application/yaml", "application/x-yaml") or file_name.lower().endswith((".yaml", ".yml")):
                body = await self._analyze_yaml(file_content, goal)
            elif mime == "text/markdown" or file_name.lower().endswith((".md", ".markdown")):
                body = await self._analyze_markdown(file_content, goal)
            elif file_name.lower().endswith((".py", ".js", ".ts", ".java", ".go", ".rs", ".c", ".cpp", ".h", ".rb", ".php", ".swift", ".kt")):
                body = await self._analyze_code(file_content, file_name, goal)
            elif mime == "application/pdf":
                body = await self._analyze_pdf(file_content, goal)
            elif file_name.lower().endswith((".docx",)):
                body = await self._analyze_docx(file_content, goal)
            elif file_name.lower().endswith((".xlsx",)):
                body = await self._analyze_xlsx(file_content, goal)
            elif mime and mime.startswith("image/"):
                body = await self._analyze_image(file_content, mime, goal)
            elif file_name.lower().endswith((".zip",)):
                body = await self._analyze_zip(file_content, goal)
            elif mime and mime.startswith("audio/"):
                body = "🎵 Audio file detected. Audio transcription not yet implemented — use the `whisper` tool via shell."
            elif mime and mime.startswith("video/"):
                body = "🎬 Video file detected. Video analysis not yet implemented."
            else:
                body = await self._analyze_binary(file_content, goal)
        except Exception as e:
            body = f"⚠️ Analysis error: {type(e).__name__}: {e}"

        return header + body

    # ------------------------------------------------------------------ #
    # Per-type analyzers
    # ------------------------------------------------------------------ #

    async def _analyze_text(self, content: bytes, mime: str, goal: str) -> str:
        try:
            text = content.decode("utf-8", errors="replace")
        except Exception:
            text = content.decode("latin-1", errors="replace")
        lines = text.splitlines()
        preview = "\n".join(lines[:50])
        if len(lines) > 50:
            preview += f"\n... ({len(lines) - 50} more lines)"
        # Ask the LLM for a summary.
        llm_summary = await self._llm_summarize(
            f"Analyze this {mime} file.  Goal: {goal}\n\nContent (first {MAX_TEXT_FOR_LLM} chars):\n{text[:MAX_TEXT_FOR_LLM]}",
        )
        return f"**Lines:** {len(lines)}\n**Characters:** {len(text):,}\n\n**Preview:**\n```\n{preview[:2000]}\n```\n\n**Analysis:**\n{llm_summary}"

    async def _analyze_json(self, content: bytes, goal: str) -> str:
        try:
            data = json.loads(content)
        except json.JSONDecodeError as e:
            return f"❌ Invalid JSON: {e}"
        # Summarize structure.
        if isinstance(data, dict):
            keys = list(data.keys())[:20]
            structure = f"Object with {len(data)} keys: {keys}"
        elif isinstance(data, list):
            structure = f"Array with {len(data)} items"
            if data and isinstance(data[0], dict):
                structure += f"; first item keys: {list(data[0].keys())[:10]}"
        else:
            structure = f"Scalar: {type(data).__name__}"
        llm_summary = await self._llm_summarize(
            f"Analyze this JSON.  Goal: {goal}\n\nStructure: {structure}\n\nContent (first {MAX_TEXT_FOR_LLM} chars):\n{json.dumps(data, indent=2)[:MAX_TEXT_FOR_LLM]}",
        )
        return f"**Structure:** {structure}\n\n**Analysis:**\n{llm_summary}"

    async def _analyze_csv(self, content: bytes, goal: str) -> str:
        try:
            text = content.decode("utf-8", errors="replace")
        except Exception:
            text = content.decode("latin-1", errors="replace")
        reader = csv.reader(io.StringIO(text))
        rows = list(reader)
        if not rows:
            return "❌ Empty CSV."
        header = rows[0]
        sample = rows[1:4] if len(rows) > 1 else []
        llm_summary = await self._llm_summarize(
            f"Analyze this CSV.  Goal: {goal}\n\nColumns: {header}\nRow count: {len(rows) - 1}\nSample rows: {sample}",
        )
        return (
            f"**Columns ({len(header)}):** {header}\n"
            f"**Rows:** {len(rows) - 1}\n"
            f"**Sample:**\n```\n{header}\n" +
            "\n".join(",".join(r) for r in sample) + "\n```\n\n"
            f"**Analysis:**\n{llm_summary}"
        )

    async def _analyze_yaml(self, content: bytes, goal: str) -> str:
        try:
            import yaml
            data = yaml.safe_load(content)
        except ImportError:
            return "⚠️ PyYAML not installed.  Raw content:\n```\n" + content.decode("utf-8", errors="replace")[:2000] + "\n```"
        except Exception as e:
            return f"❌ Invalid YAML: {e}"
        llm_summary = await self._llm_summarize(
            f"Analyze this YAML.  Goal: {goal}\n\nParsed: {str(data)[:MAX_TEXT_FOR_LLM]}",
        )
        return f"**Parsed structure:** {type(data).__name__}\n\n**Analysis:**\n{llm_summary}"

    async def _analyze_markdown(self, content: bytes, goal: str) -> str:
        text = content.decode("utf-8", errors="replace")
        # Extract headings.
        headings = [l for l in text.splitlines() if l.strip().startswith("#")]
        llm_summary = await self._llm_summarize(
            f"Analyze this Markdown document.  Goal: {goal}\n\nContent (first {MAX_TEXT_FOR_LLM} chars):\n{text[:MAX_TEXT_FOR_LLM]}",
        )
        return f"**Headings ({len(headings)}):**\n" + "\n".join(headings[:15]) + f"\n\n**Analysis:**\n{llm_summary}"

    async def _analyze_code(self, content: bytes, file_name: str, goal: str) -> str:
        text = content.decode("utf-8", errors="replace")
        ext = Path(file_name).suffix
        lang_map = {".py": "python", ".js": "javascript", ".ts": "typescript",
                    ".java": "java", ".go": "go", ".rs": "rust", ".c": "c",
                    ".cpp": "cpp", ".h": "c", ".rb": "ruby", ".php": "php",
                    ".swift": "swift", ".kt": "kotlin"}
        lang = lang_map.get(ext, "unknown")
        lines = text.splitlines()
        # Count functions/classes (rough).
        funcs = len(re.findall(r"^\s*(?:def |function |func |public |private |protected )", text, re.MULTILINE))
        classes = len(re.findall(r"^\s*(?:class |struct |enum |interface )", text, re.MULTILINE))
        llm_summary = await self._llm_summarize(
            f"Analyze this {lang} source file.  Goal: {goal}\n\nFile: {file_name}\nLines: {len(lines)}\n\nContent:\n```{lang}\n{text[:MAX_TEXT_FOR_LLM]}\n```",
        )
        return (
            f"**Language:** {lang}\n"
            f"**Lines:** {len(lines)}\n"
            f"**Functions (approx):** {funcs}\n"
            f"**Classes (approx):** {classes}\n\n"
            f"**Analysis:**\n{llm_summary}"
        )

    async def _analyze_pdf(self, content: bytes, goal: str) -> str:
        try:
            # Try pdfplumber first (better text extraction).
            try:
                import pdfplumber
                with pdfplumber.open(io.BytesIO(content)) as pdf:
                    pages = len(pdf.pages)
                    text_parts = []
                    for i, page in enumerate(pdf.pages[:20]):  # first 20 pages
                        t = page.extract_text() or ""
                        text_parts.append(t)
                    full_text = "\n\n".join(text_parts)
                llm_summary = await self._llm_summarize(
                    f"Analyze this PDF ({pages} pages).  Goal: {goal}\n\nExtracted text (first {MAX_TEXT_FOR_LLM} chars):\n{full_text[:MAX_TEXT_FOR_LLM]}",
                )
                return f"**Pages:** {pages}\n\n**Analysis:**\n{llm_summary}"
            except ImportError:
                pass
            # Fall back to pypdf.
            try:
                from pypdf import PdfReader
                reader = PdfReader(io.BytesIO(content))
                pages = len(reader.pages)
                text_parts = []
                for page in reader.pages[:20]:
                    text_parts.append(page.extract_text() or "")
                full_text = "\n\n".join(text_parts)
                llm_summary = await self._llm_summarize(
                    f"Analyze this PDF ({pages} pages).  Goal: {goal}\n\nExtracted text (first {MAX_TEXT_FOR_LLM} chars):\n{full_text[:MAX_TEXT_FOR_LLM]}",
                )
                return f"**Pages:** {pages}\n\n**Analysis:**\n{llm_summary}"
            except ImportError:
                return (
                    "⚠️ No PDF library installed.  Install one with:\n"
                    "```\npip install pdfplumber\n# or\npip install pypdf\n```\n\n"
                    f"File size: {len(content):,} bytes."
                )
        except Exception as e:
            return f"❌ PDF analysis failed: {e}"

    async def _analyze_docx(self, content: bytes, goal: str) -> str:
        try:
            from docx import Document
            doc = Document(io.BytesIO(content))
            paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
            full_text = "\n".join(paragraphs)
            llm_summary = await self._llm_summarize(
                f"Analyze this Word document.  Goal: {goal}\n\nText (first {MAX_TEXT_FOR_LLM} chars):\n{full_text[:MAX_TEXT_FOR_LLM]}",
            )
            return f"**Paragraphs:** {len(paragraphs)}\n\n**Analysis:**\n{llm_summary}"
        except ImportError:
            return "⚠️ `python-docx` not installed.  Install with `pip install python-docx`."
        except Exception as e:
            return f"❌ DOCX analysis failed: {e}"

    async def _analyze_xlsx(self, content: bytes, goal: str) -> str:
        try:
            from openpyxl import load_workbook
            wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
            sheets = wb.sheetnames
            summary_parts = []
            for sheet_name in sheets[:5]:  # first 5 sheets
                ws = wb[sheet_name]
                rows = list(ws.iter_rows(max_row=5, values_only=True))
                summary_parts.append(f"**Sheet: {sheet_name}** — {ws.max_row} rows × {ws.max_column} cols\nFirst rows: {rows[:3]}")
            wb.close()
            llm_summary = await self._llm_summarize(
                f"Analyze this Excel workbook.  Goal: {goal}\n\nSheets: {sheets}\n\n{chr(10).join(summary_parts)}",
            )
            return f"**Sheets ({len(sheets)}):** {sheets}\n\n" + "\n\n".join(summary_parts) + f"\n\n**Analysis:**\n{llm_summary}"
        except ImportError:
            return "⚠️ `openpyxl` not installed.  Install with `pip install openpyxl`."
        except Exception as e:
            return f"❌ XLSX analysis failed: {e}"

    async def _analyze_image(self, content: bytes, mime: str, goal: str) -> str:
        # Try vision LLM (OpenAI-compatible gpt-4o, llama 3.2 vision, llava, etc.).
        #
        # Two-step strategy:
        #   1. If the configured model is recognizably a vision model, attempt
        #      the multimodal call directly.  The Ollama client now converts
        #      OpenAI-style `content: [...]` arrays into Ollama-native
        #      `content: str` + `images: [b64]` form, so this works against
        #      both Ollama and OpenAI-compatible backends.
        #   2. If the configured model is NOT a vision model (e.g. the default
        #      qwen3 / qwen2.5 instruct models), skip the doomed HTTP call
        #      entirely and fall straight through to the PIL metadata fallback.
        #      Previously this branch wasted ~5s on 3 retries × ~1s backoff
        #      before reaching the same fallback.

        # Read image dimensions up-front — we want them in BOTH the success
        # and the fallback paths, so do it once here.  Pillow is optional.
        img_format = mime.split("/")[-1].upper() if mime else "UNKNOWN"
        img_dims = f"{len(content):,} bytes"
        img_mode = "unknown"
        try:
            from PIL import Image
            img = Image.open(io.BytesIO(content))
            img_format = img.format or img_format
            img_dims = f"{img.size[0]}×{img.size[1]} pixels"
            img_mode = img.mode
        except ImportError:
            pil_available = False
        except Exception:
            # Corrupt image or unreadable — keep the byte-count fallback.
            pil_available = True  # PIL is installed, just couldn't read this file
        else:
            pil_available = True

        # Step 1: should we even try the vision LLM?
        #
        # Resolution chain (in priority order):
        #   a) Config override `llm.vision_capable` (True/False) — user wins.
        #   b) Runtime check via Ollama's /api/show — authoritative when the
        #      backend is Ollama.  Returns True/False/None; None means
        #      "couldn't tell" (network error, model not pulled).
        #   c) Name-based heuristic `is_vision_model()` — best-effort fallback
        #      when /api/show is unavailable (non-Ollama backend) or
        #      inconclusive.
        model_name = ""
        llm_cfg = None
        try:
            # Walk through possible wrappers (CachedLLMClient, router, etc.).
            # CachedLLMClient exposes .config as a property delegating to
            # the inner client; raw OllamaLLMClient exposes it directly.
            llm_cfg = getattr(self.llm, "config", None)
            if llm_cfg is not None:
                model_name = getattr(llm_cfg, "model_name", "") or ""
        except Exception:
            pass

        # (a) Config override — always wins.
        override = None
        if llm_cfg is not None:
            override = getattr(llm_cfg, "vision_capable", None)
        if override is True:
            model_supports_vision = True
            detection_source = "config override (vision_capable=true)"
        elif override is False:
            model_supports_vision = False
            detection_source = "config override (vision_capable=false)"
        else:
            # (b) Runtime check via /api/show — only for Ollama backends.
            runtime_result: bool | None = None
            inner_client = getattr(self.llm, "inner", None) or self.llm
            check_fn = getattr(inner_client, "check_vision_capable", None)
            if callable(check_fn):
                try:
                    runtime_result = await check_fn()
                except Exception as e:
                    log.debug(
                        "check_vision_capable() raised %s — falling back "
                        "to heuristic", e,
                    )
                    runtime_result = None

            if runtime_result is True:
                model_supports_vision = True
                detection_source = "Ollama /api/show (projector detected)"
            elif runtime_result is False:
                model_supports_vision = False
                detection_source = "Ollama /api/show (no projector)"
            else:
                # (c) Name-based heuristic fallback.
                try:
                    from adonai.llm.ollama import is_vision_model
                    model_supports_vision = bool(model_name) and is_vision_model(model_name)
                    detection_source = "name heuristic (fallback after /api/show inconclusive)"
                except ImportError:
                    _vision_hints = (
                        "gpt-4o", "gpt-4-vision", "gpt-4-turbo", "vision",
                        "llava", "claude-3", "gemini", "pixtral", "moondream",
                        "minicpm-v", "qwen2-vl", "qwen2.5-vl", "qwen-vl",
                        "llama3.2-vision", "llama3-vision", "gemma3",
                    )
                    ml = (model_name or "").lower()
                    model_supports_vision = any(h in ml for h in _vision_hints)
                    detection_source = "name heuristic (ollama module unavailable)"

        log.info(
            "FileAnalysisAgent vision detection: model=%r supports_vision=%s "
            "(source: %s)",
            model_name, model_supports_vision, detection_source,
        )

        if not model_supports_vision:
            # Skip the LLM call entirely — we know it will fail.
            hint_lines = [
                "  The configured LLM was detected as text-only.",
                f"  Detection method: {detection_source}.",
                "  To enable vision analysis, do ONE of:",
                "    1. Install a known vision model and switch to it:",
                "         ollama pull llava:7b           # ~4.7 GB",
                "         ollama pull llama3.2-vision:11b # ~6.7 GB",
                "         ollama pull minicpm-v:8b        # ~4.9 GB",
                "       then set llm.model_name in config/default.yaml.",
                "    2. If you're SURE this model is vision-capable (e.g. a",
                "       custom Modelfile with a PROJECTOR directive), force",
                "       it on by adding to config/default.yaml:",
                "         llm:",
                "           vision_capable: true",
                "       (Note: qwen3 / qwen3.5 -instruct variants are",
                "       text-only by Alibaba's official design — only the",
                "       -VL variants support vision. If your model genuinely",
                "       has a projector, option 2 will let it through.)",
            ]
            if not pil_available:
                hint_lines.append(
                    "  (Also install Pillow for image dimensions: "
                    "`pip install Pillow`)"
                )
            hint = "\n".join(hint_lines)
            return (
                f"**Format:** {img_format}\n"
                f"**Size:** {img_dims}\n"
                f"**Mode:** {img_mode}\n\n"
                f"⚠️ Vision analysis skipped — the configured LLM "
                f"({model_name or 'unknown'}) is not detected as "
                f"vision-capable.\n{hint}"
            )

        # Step 2: attempt the vision call.
        try:
            b64 = base64.b64encode(content).decode()
            # Build a vision request in OpenAI-style multimodal format.
            # The Ollama client transparently converts this to its native
            # `content: str + images: [b64]` shape; OpenAI-compatible
            # backends accept it as-is.
            messages = [
                {"role": "system", "content": "You are a vision model. Describe the image in detail."},
                {"role": "user", "content": [
                    {"type": "text", "text": f"Analyze this image.  Goal: {goal}"},
                    {"type": "image_url", "image_url": {"url": f"data:{mime};base64,{b64}"}},
                ]},
            ]
            resp = await self.llm.complete(messages=messages, max_tokens=512)
            vision_text = (resp.text or "").strip()
            if not vision_text:
                vision_text = "(vision model returned empty response)"
            return (
                f"**Format:** {img_format}\n"
                f"**Size:** {img_dims}\n"
                f"**Mode:** {img_mode}\n\n"
                f"**Vision analysis:**\n{vision_text}"
            )
        except Exception as e:
            # Fall back to image stats (dimensions already read above).
            err = str(e)[:300]
            return (
                f"**Format:** {img_format}\n"
                f"**Size:** {img_dims}\n"
                f"**Mode:** {img_mode}\n\n"
                f"⚠️ Vision LLM call failed ({err}).  The model "
                f"({model_name or 'unknown'}) was heuristically detected as "
                f"vision-capable but the backend rejected the request — "
                f"check that the model is actually pulled (`ollama list`) "
                f"and that the Ollama server is running."
            )

    async def _analyze_zip(self, content: bytes, goal: str) -> str:
        try:
            with zipfile.ZipFile(io.BytesIO(content)) as zf:
                names = zf.namelist()
                file_infos = [(n, zf.getinfo(n).file_size) for n in names[:50]]
            listing = "\n".join(f"  {n} ({s:,} bytes)" for n, s in file_infos)
            if len(names) > 50:
                listing += f"\n  ... ({len(names) - 50} more files)"
            llm_summary = await self._llm_summarize(
                f"Analyze this ZIP archive.  Goal: {goal}\n\nFile count: {len(names)}\nFiles:\n{listing}",
            )
            return f"**Files ({len(names)}):**\n```\n{listing}\n```\n\n**Analysis:**\n{llm_summary}"
        except zipfile.BadZipFile:
            return "❌ Invalid ZIP file."

    async def _analyze_binary(self, content: bytes, goal: str) -> str:
        # Hex dump of first 256 bytes.
        hex_preview = content[:256].hex(" ")
        ascii_preview = "".join(
            chr(b) if 32 <= b < 127 else "." for b in content[:256]
        )
        # Build the LLM prompt WITHOUT backslashes inside the f-string
        # expression (Python 3.11 forbids that).
        llm_prompt = (
            "What might this binary file be? Goal: " + goal
            + "\n\nHex: " + hex_preview[:500]
        )
        heuristic = await self._llm_summarize(llm_prompt)
        return (
            f"**Binary file** ({len(content):,} bytes)\n\n"
            f"**Hex preview (first 256 bytes):**\n```\n{hex_preview}\n```\n\n"
            f"**ASCII preview:**\n```\n{ascii_preview}\n```\n\n"
            f"⚠️ No specific analyzer for this file type.  Use the LLM summary below "
            f"or convert to a supported format.\n\n"
            f"**Heuristic analysis:**\n{heuristic}"
        )

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #

    async def _llm_summarize(self, prompt: str) -> str:
        """Call the LLM to produce a natural-language summary."""
        try:
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.3,
                max_tokens=1024,
            )
            return resp.text.strip() or "(no analysis produced)"
        except Exception as e:
            return f"(LLM summary failed: {e})"

    def _sniff_mime(self, content: bytes) -> str | None:
        """Guess MIME type from magic bytes."""
        if content.startswith(b"\xff\xd8\xff"):
            return "image/jpeg"
        if content.startswith(b"\x89PNG\r\n\x1a\n"):
            return "image/png"
        if content.startswith(b"GIF8"):
            return "image/gif"
        if content.startswith(b"%PDF"):
            return "application/pdf"
        if content.startswith(b"PK\x03\x04"):
            return "application/zip"
        if content.startswith(b"\x1f\x8b"):
            return "application/gzip"
        if content[:4] == b"RIFF" and content[8:12] == b"WEBP":
            return "image/webp"
        return None


# --------------------------------------------------------------------------- #
# FastAPI route handler — add this to your api/server.py to enable uploads
# --------------------------------------------------------------------------- #

def register_file_upload_route(app, ai) -> None:
    """Register POST /upload + GET /files endpoints on a FastAPI app.

    Usage in api/server.py::

        from adonai.agents.file_analyst import register_file_upload_route
        register_file_upload_route(app, ai)
    """
    # Use the module-level imports so Pydantic can resolve the type hints.
    UploadFile = _FastAPIUploadFile
    File = _FastAPIFile
    HTTPException = _FastAPIHTTPException

    @app.post("/upload")
    async def upload_file(file: _FastAPIUploadFile = _FastAPIFile(...)) -> dict:
        """Upload a file for analysis.  Returns the saved file name."""
        if not file.filename:
            raise HTTPException(400, "no filename")
        # Save to uploads dir.
        save_path = UPLOAD_DIR / file.filename
        content = await file.read()
        if len(content) > MAX_FILE_SIZE:
            raise HTTPException(413, f"file too large (max {MAX_FILE_SIZE} bytes)")
        save_path.write_bytes(content)
        return {
            "filename": file.filename,
            "size": len(content),
            "path": str(save_path),
            "message": f"Upload successful.  Ask the agent: 'analyze file {file.filename}'",
        }

    @app.get("/files")
    async def list_files() -> list[dict]:
        """List all uploaded files."""
        if not UPLOAD_DIR.exists():
            return []
        out = []
        for p in sorted(UPLOAD_DIR.iterdir(), key=os.path.getmtime, reverse=True):
            stat = p.stat()
            out.append({
                "name": p.name,
                "size": stat.st_size,
                "uploaded": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                "path": str(p),
            })
        return out

    @app.get("/files/{filename}")
    async def file_info(filename: str) -> dict:
        """Get info about a specific uploaded file."""
        p = UPLOAD_DIR / filename
        if not p.exists():
            raise HTTPException(404, "file not found")
        stat = p.stat()
        mime, _ = mimetypes.guess_type(filename)
        return {
            "name": p.name,
            "size": stat.st_size,
            "uploaded": datetime.fromtimestamp(stat.st_mtime).isoformat(),
            "path": str(p),
            "mime": mime,
        }

    @app.delete("/files/{filename}")
    async def delete_file(filename: str) -> dict:
        """Delete an uploaded file."""
        p = UPLOAD_DIR / filename
        if not p.exists():
            raise HTTPException(404, "file not found")
        p.unlink()
        return {"deleted": filename}

    @app.post("/analyze")
    async def analyze_uploaded_file(
        filename: str = "",
        session_id: str | None = None,
    ) -> dict:
        """Analyze an uploaded file directly.

        If *session_id* is provided, the analysis is recorded into the
        conversation history — so you can ask follow-up questions like
        "what was in that file?" and the agent remembers.
        """
        p = UPLOAD_DIR / filename
        if not p.exists():
            raise HTTPException(404, f"file {filename!r} not found.  Upload first via POST /upload.")
        # Build a task + run the FileAnalysisAgent.
        from adonai.core.models import Task
        task = Task(
            goal=f"analyze file {filename}",
            context={"file_path": str(p)},
            session_id=session_id or "default",
        )
        if ai.agents is None:
            raise HTTPException(503, "agent registry not initialized")
        agent = ai.agents.get("file_analyst")
        if agent is None:
            raise HTTPException(503, "file_analyst agent not registered")
        result = await agent.run(task)

        # Record the turn into conversation history so the agent
        # remembers the file analysis for follow-up questions.
        reply = result.output if result.output is not None else (
            f"[error] {result.error}" if result.error else "[no analysis]"
        )
        if ai.executor is not None and session_id:
            user_msg = f"📎 analyze file {filename}"
            ai.executor._record_turn(session_id, user_msg, str(reply))

        return {
            "filename": filename,
            "status": result.status.value,
            "analysis": result.output,
            "error": result.error,
            "session_id": session_id,
        }
