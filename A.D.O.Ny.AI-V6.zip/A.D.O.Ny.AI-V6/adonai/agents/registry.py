"""Agent registry — registers + routes between agents based on goal matching."""
from __future__ import annotations

import logging
from typing import Any

from adonai.agents.base import BaseAgent
from adonai.agents.executive import ExecutiveAgent
from adonai.agents.researcher import ResearcherAgent
from adonai.agents.coder import CoderAgent
from adonai.agents.reflection import ReflectionAgent
from adonai.agents.learning import LearningAgent
from adonai.agents.memory_agent import MemoryAgent
from adonai.agents.file_analyst import FileAnalysisAgent
from adonai.agents.scientist import ScientificDiscoveryAgent
from adonai.agents.pentester import PentesterAgent

log = logging.getLogger(__name__)


# v9 fix: ToolCallingAgent and CriticAgent are not BaseAgent subclasses
# (they have different constructors and don't expose attach()/can_handle
# in the BaseAgent shape). The two adapter classes below wrap them so
# they can be registered in the AgentRegistry alongside the other 8
# built-in agents, making the registry's route()/get() API work for
# callers that want to look up the critic or the tool-calling agent by
# name. The adapters construct the underlying agent lazily in attach()
# (once llm/tools are available from the parent) so build_default_registry
# can still create them with no args.


class _ToolCallingAgentAdapter(BaseAgent):
    """Adapter so ToolCallingAgent can live in the AgentRegistry.

    Defers construction of the underlying ToolCallingAgent until
    attach() gives us an llm + tools reference. ``run()`` falls back
    to the parent's run() (same as the default BaseAgent.run()).
    """

    name = "tool_calling"
    role = "tool_calling"
    capabilities = ["tool_calling", "chat", "conversation"]
    preferred_tools: list[str] = []
    system_prompt = ""

    def __init__(self) -> None:
        super().__init__()
        self._agent: Any = None

    def attach(self, parent_agent: Any) -> None:
        super().attach(parent_agent)
        # Lazily construct the ToolCallingAgent now that we have llm +
        # tools from the parent. If construction fails (e.g. parent has
        # no tools registered yet), we leave _agent=None and run() will
        # fall back to the parent's run() — same as any other sub-agent
        # without explicit run() logic.
        try:
            from adonai.agents.tool_calling_agent import ToolCallingAgent
            if self.llm is not None and self.tools is not None:
                self._agent = ToolCallingAgent(
                    llm=self.llm, tools=self.tools,
                )
        except Exception as e:
            log.debug("ToolCallingAgent adapter construction deferred: %s", e)

    def can_handle(self, goal: str) -> float:
        # The ToolCallingAgent is the chat path; it doesn't route via
        # the registry. Return 0 so the registry's route() never picks
        # it over a more specific agent. Callers can still fetch it
        # explicitly via agents.get("tool_calling").
        return 0.0


class _CriticAgentAdapter(BaseAgent):
    """Adapter so CriticAgent can live in the AgentRegistry.

    CriticAgent is normally invoked via POST /critique or by the
    executor's post-execution review (config.critic.run_on_result).
    Registering it here makes it discoverable via /agents and lets
    callers fetch it by name (agents.get("critic")) without holding
    a separate reference.
    """

    name = "critic"
    role = "critique"
    capabilities = ["critique", "review", "verification"]
    preferred_tools: list[str] = []
    system_prompt = ""

    def __init__(self) -> None:
        super().__init__()
        self._agent: Any = None

    def attach(self, parent_agent: Any) -> None:
        super().attach(parent_agent)
        try:
            from adonai.agents.critic import CriticAgent
            config = getattr(parent_agent, "config", None)
            self._agent = CriticAgent(llm=self.llm, config=config)
        except Exception as e:
            log.debug("CriticAgent adapter construction deferred: %s", e)

    def can_handle(self, goal: str) -> float:
        # Critic is invoked explicitly, not via route().
        return 0.0


class AgentRegistry:
    """Registers + routes between agents based on goal-matching."""

    def __init__(self) -> None:
        self._agents: dict[str, BaseAgent] = {}

    def register(self, agent: BaseAgent) -> None:
        self._agents[agent.name] = agent
        log.info("Registered agent '%s' (role=%s)", agent.name, agent.role)

    def get(self, name: str) -> BaseAgent | None:
        return self._agents.get(name)

    def list_agents(self) -> list[BaseAgent]:
        return list(self._agents.values())

    def route(self, goal: str) -> BaseAgent:
        """Pick the agent with the highest can_handle() score for *goal*."""
        best = None
        best_score = -1.0
        for agent in self._agents.values():
            try:
                score = agent.can_handle(goal)
            except Exception:
                score = 0.0
            if score > best_score:
                best_score = score
                best = agent
        return best or self._agents.get("executive")


def build_default_registry(parent: Any = None) -> AgentRegistry:
    """Build a registry with all 10 built-in agents attached to *parent*.

    v9 fix: registered ToolCallingAgent and CriticAgent via lightweight
    adapters so they're discoverable via /agents and fetchable by name
    (``agents.get("tool_calling")`` / ``agents.get("critic")``).
    Previously they existed as classes but were never registered, so
    /agents listed 8 agents while the codebase shipped 10. The
    adapters defer construction of the underlying agents until
    attach() is called (when llm + tools are available), preserving
    the no-arg constructor pattern of the other 8 agents.
    """
    registry = AgentRegistry()
    for agent_cls in [
        ExecutiveAgent, ResearcherAgent, CoderAgent,
        FileAnalysisAgent, ScientificDiscoveryAgent,
        ReflectionAgent, LearningAgent, MemoryAgent,
        PentesterAgent,
        _ToolCallingAgentAdapter, _CriticAgentAdapter,
    ]:
        agent = agent_cls()
        if parent is not None:
            agent.attach(parent)
        registry.register(agent)
    return registry
