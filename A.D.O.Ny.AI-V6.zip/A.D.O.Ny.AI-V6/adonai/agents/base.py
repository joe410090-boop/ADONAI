"""Base agent — shared behavior for all 7 agent types."""
from __future__ import annotations

import logging
from typing import Any

from adonai.core.interfaces import Agent
from adonai.core.models import AgentMessage, Task, TaskResult, TaskStatus

log = logging.getLogger(__name__)


class BaseAgent(Agent):
    """Common base for all agents.

    Subclasses set ``name``, ``role``, ``capabilities``, ``preferred_tools``,
    ``system_prompt`` and override :meth:`run` for custom delegation logic.
    """

    name: str = "base_agent"
    role: str = "generic"
    capabilities: list[str] = []
    preferred_tools: list[str] = []
    system_prompt: str = ""

    def __init__(self) -> None:
        self.parent: Any = None  # set by attach()
        self.llm: Any = None
        self.tools: Any = None
        self.memory: Any = None

    def attach(self, parent_agent: Any) -> None:
        """Bind this sub-agent to its parent AdonaiAgent (or runtime)."""
        self.parent = parent_agent
        self.llm = getattr(parent_agent, "llm", None)
        self.tools = getattr(parent_agent, "tools", None)
        self.memory = getattr(parent_agent, "memory", None)

    async def run(self, task: Task) -> TaskResult:
        """Default delegation: forward to the parent's run()."""
        if self.parent is None:
            return TaskResult(
                task_id=task.id, status=TaskStatus.FAILED,
                error=f"sub-agent {self.name!r} has no parent attached",
            )
        task.assigned_agent = self.name
        return await self.parent.run(task)

    def can_handle(self, goal: str) -> float:
        """Keyword-based confidence — subclasses override for smarter routing."""
        goal_lower = goal.lower()
        for cap in self.capabilities:
            if cap.lower() in goal_lower:
                return 1.0
        return 0.0
