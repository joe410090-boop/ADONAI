"""Scientific Discovery Agent — wraps the discovery_node for the agent hierarchy.

When the user asks the agent to "design", "optimize", "engineer", or
"discover" something with measurable constraints, this agent routes the
request to the discovery_node's ResearchDirector.

The main agent (executive) knows about this capability via the agent
registry — it will automatically delegate to this agent when the goal
matches.
"""
# NOTE: no `from __future__ import annotations` — breaks FastAPI type hints.

import logging
from typing import Any

from adonai.agents.base import BaseAgent
from adonai.core.models import Task, TaskResult, TaskStatus
from adonai.discovery.discovery_node import ResearchDirector

log = logging.getLogger(__name__)


class ScientificDiscoveryAgent(BaseAgent):
    """Routes engineering optimization goals to the discovery system."""

    name = "scientist"
    role = "discovery"
    capabilities = [
        "design", "optimize", "engineer", "discover",
        "nozzle", "turbine", "heat exchanger", "structural",
        "thermal efficiency", "parameter optimization",
        "evolutionary optimization", "research campaign",
    ]
    preferred_tools: list[str] = []
    system_prompt = (
        "You are the Scientific Discovery Agent.  You run autonomous "
        "multi-agent research campaigns that iteratively generate, simulate, "
        "critique, and evolve engineering designs until fitness targets "
        "are met.  You manage a population of candidate designs, run "
        "parallel simulations, and use evolutionary optimization to find "
        "the best solution."
    )

    def can_handle(self, goal: str) -> float:
        g = goal.lower()
        # Block: "write code" / "write a script" / "implement" / "program"
        # should go to the Coder agent, NOT the scientist.
        code_indicators = [
            "write code", "write a script", "write a function",
            "write a python", "write a program", "implement a function",
            "implement a class", "write a class", "code to:",
            "write code to:", "python code", "javascript code",
        ]
        for indicator in code_indicators:
            if indicator in g:
                return 0.0  # explicitly yield to the Coder agent

        # Strong match: engineering design + optimization goals.
        # Must have BOTH a design verb AND an engineering noun/metric
        # to avoid grabbing generic "optimize my code" requests.
        design_verbs = ["design", "engineer", "optimize", "discover"]
        engineering_nouns = [
            "nozzle", "turbine", "heat exchanger", "blade", "wing",
            "structural", "thermal", "stress", "efficiency", "mpa",
            "fitness", "evolutionary optimization", "research campaign",
            "parameter optimization", "material", "alloy", "composite",
        ]
        has_design_verb = any(v in g for v in design_verbs)
        has_eng_noun = any(n in g for n in engineering_nouns)

        if has_design_verb and has_eng_noun:
            return 1.0
        # Strong match on specific engineering objects alone.
        for kw in ["nozzle", "turbine", "heat exchanger", "research campaign"]:
            if kw in g:
                return 1.0
        return 0.0

    async def run(self, task: Task) -> TaskResult:
        """Run a discovery campaign for the task goal."""
        if self.llm is None:
            return TaskResult(
                task_id=task.id, status=TaskStatus.FAILED,
                error="ScientificDiscoveryAgent requires an LLM",
            )

        # Extract constraints from the task context or goal.
        constraints = self._extract_constraints(task)

        # Parse campaign parameters from the goal or use defaults.
        max_generations = task.context.get("max_generations", 12) if task.context else 12
        population_size = task.context.get("population_size", 8) if task.context else 8
        # Higher target = more generations needed = more evolution visible.
        target_fitness = task.context.get("target_fitness", 0.97) if task.context else 0.97

        # Determine DB path from config.
        db_path = "data/adonai.db"
        if hasattr(self, "parent") and self.parent is not None:
            cfg = getattr(self.parent, "config", None)
            if cfg is not None:
                db_path = str(cfg.memory.sqlite_path)

        log.info(
            "Starting discovery campaign: %s (gens=%d pop=%d target=%.2f)",
            task.goal[:80], max_generations, population_size, target_fitness,
        )

        # Run the campaign.
        director = ResearchDirector(
            llm=self.llm,
            db_path=db_path,
            max_generations=max_generations,
            population_size=population_size,
            target_fitness=target_fitness,
            constraints=constraints,
        )
        report = await director.run_campaign(task.goal)

        # Format the output as a readable summary.
        output = self._format_report(report)
        return TaskResult(
            task_id=task.id,
            status=TaskStatus.COMPLETED if report.get("status") == "complete" else TaskStatus.FAILED,
            output=output,
            steps_executed=report.get("generations_completed", 0),
            confidence=report.get("best_fitness", 0.0),
        )

    def _extract_constraints(self, task: Task) -> dict[str, float]:
        """Parse engineering constraints from the goal text or context."""
        constraints: dict[str, float] = {}
        goal = task.goal.lower()

        import re

        # Stress: "400 MPa" or "400 mpa"
        m = re.search(r"(\d+(?:\.\d+)?)\s*mpa", goal)
        if m:
            constraints["target_stress_mpa"] = float(m.group(1))

        # Efficiency: "95% efficiency" or "efficiency above 95%"
        m = re.search(r"(\d+(?:\.\d+)?)\s*%\s*(?:thermal\s+)?efficiency", goal)
        if m:
            constraints["target_efficiency"] = float(m.group(1))
        m = re.search(r"efficiency\s*(?:above|>|over|>=?)\s*(\d+(?:\.\d+)?)", goal)
        if m:
            constraints["target_efficiency"] = float(m.group(1))

        # Mass: "mass under 2 kg" or "weight under 2kg" or "under 2 kg"
        m = re.search(r"(?:mass|weight)?\s*(?:under|below|<|less than)\s*(\d+(?:\.\d+)?)\s*kg", goal)
        if m:
            constraints["max_mass_kg"] = float(m.group(1))

        # Cost: "cost under $3000" or "$3000" or "under $3000"
        m = re.search(r"(?:cost|budget)?\s*(?:under|below|<|less than)?\s*\$?(\d+(?:\.\d+)?)\s*(?:dollars?|usd)?", goal)
        if m and ("cost" in goal or "$" in goal or "budget" in goal):
            constraints["max_cost"] = float(m.group(1))
            constraints["reference_cost"] = float(m.group(1))

        # Override with explicit context.
        if task.context:
            for k, v in task.context.items():
                if k in ("target_stress_mpa", "target_efficiency", "reference_cost"):
                    try:
                        constraints[k] = float(v)
                    except (TypeError, ValueError):
                        pass

        return constraints

    def _format_report(self, report: dict) -> str:
        """Format the campaign report as readable Markdown."""
        lines = [
            f"🔬 **Scientific Discovery Campaign Complete**",
            f"",
            f"**Campaign ID:** `{report.get('campaign_id', '?')}`",
            f"**Objective:** {report.get('objective', '?')}",
            f"**Status:** {report.get('status', '?')}",
            f"**Generations:** {report.get('generations_completed', 0)}/{report.get('max_generations', '?')}",
            f"",
            f"### Results",
            f"- **Best Fitness:** {report.get('best_fitness', 0):.4f} / {report.get('target_fitness', 0):.2f}",
            f"- **Target Reached:** {'✅ Yes' if report.get('target_reached') else '❌ No'}",
            f"",
        ]

        best = report.get("best_design")
        if best:
            import json
            lines.append(f"### Best Design")
            lines.append(f"```json")
            lines.append(json.dumps(best, indent=2))
            lines.append(f"```")
            lines.append("")

        # Generation history.
        gens = report.get("generation_summaries", [])
        if gens:
            lines.append("### Evolution History")
            lines.append("")
            lines.append("| Gen | Best Fitness | Avg Fitness |")
            lines.append("|-----|-------------|-------------|")
            for g in gens:
                lines.append(
                    f"| {g['generation']} | {g['best_fitness']:.4f} | {g['average_fitness']:.4f} |"
                )
            lines.append("")

        # Learning insights.
        insights = report.get("learning_insights", {})
        if insights and isinstance(insights, dict):
            lines.append("### Learning Insights")
            lines.append(f"- **Average fitness:** {insights.get('average_fitness', 'N/A')}")
            lines.append(f"- **Best fitness:** {insights.get('best_fitness', 'N/A')}")
            lines.append(f"- **Trend:** {insights.get('trend', 'N/A')}")
            lines.append(f"- **Recommendation:** {insights.get('recommendation', 'N/A')}")
            corr = insights.get("parameter_correlations", {})
            if corr:
                lines.append(f"- **Parameter correlations:**")
                for param, score in corr.items():
                    lines.append(f"  - `{param}`: {score:+.3f}")
            lines.append("")

        lines.append("📄 Full report saved to `data/discovery/research_report.md`")
        lines.append("📄 Best design saved to `data/discovery/best_design.json`")
        return "\n".join(lines)
