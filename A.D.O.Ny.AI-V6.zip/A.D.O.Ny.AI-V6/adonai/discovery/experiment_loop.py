"""Upgrade 8 — Autonomous Experiment Loop.

Iterative research loop::

    Goal → Observe → Hypothesize → Experiment → Analyze → Learn → Repeat

The loop continues until any of:

* confidence threshold achieved
* resource limit reached (time or iterations)
* user intervention (via ``stop()``)

Composes the Hypothesis Generator (Upgrade 7) with the Simulator
Abstraction Layer (Upgrade 11) and the Reflection Engine (Upgrade 4)
to produce a self-improving research cycle.

Output: a dict with the final hypotheses, experiments, lessons, and
telemetry.
"""
from __future__ import annotations

import asyncio
import logging
import time
from datetime import datetime, timezone
from typing import Any

from adonai.core.exceptions import ExperimentLoopError
from adonai.core.events import EventPublisher, EventTypes
from adonai.core.interfaces import (
    ExperimentLoop, HypothesisGenerator, LLMClient, ReflectionEngine,
)
from adonai.core.models import (
    Experiment, ExperimentStatus, Hypothesis, HypothesisStatus,
    Task, TaskResult, TaskStatus,
)
from adonai.discovery.experiment_loop_store import (
    ExperimentLoopStore, make_loop_id,
)

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# DefaultExperimentLoop
# ──────────────────────────────────────────────────────────────────────────────


class DefaultExperimentLoop(ExperimentLoop, EventPublisher):
    """Default iterative research loop.

    Wires together:

    * an :class:`HypothesisGenerator` (Upgrade 7) — to propose hypotheses
    * a simulator registry (Upgrade 11) — to run experiments
    * a :class:`ReflectionEngine` (Upgrade 4) — to extract lessons
    * an optional :class:`LLMClient` — to make observation notes

    The loop's state machine is::

        observe → hypothesize → design → run → analyze → learn → observe → …

    Each iteration produces one or more hypotheses and one experiment
    per hypothesis.  The loop terminates when the top hypothesis's
    confidence exceeds ``confidence_threshold`` or when the resource
    budget is exhausted.
    """

    def __init__(
        self,
        hypothesis_generator: HypothesisGenerator,
        *,
        llm: LLMClient | None = None,
        reflection_engine: ReflectionEngine | None = None,
        simulator_registry: Any = None,
        config: Any = None,
        store: ExperimentLoopStore | None = None,
    ) -> None:
        self.generator = hypothesis_generator
        self.llm = llm
        self.reflection = reflection_engine
        self.simulators = simulator_registry
        self.config = config
        # Optional SQLite persistence — when None, loop state stays in-memory.
        self.store = store
        self._stop_requested = False
        self._running = False

    # ── ExperimentLoop interface ─────────────────────────────────────────

    async def run(
        self,
        goal: str,
        *,
        max_iterations: int = 10,
        confidence_threshold: float = 0.85,
        resource_budget_s: float | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Run the loop until convergence, resource limit, or interruption."""
        if self._running:
            raise ExperimentLoopError("loop already running")
        self._running = True
        self._stop_requested = False
        start_ts = time.time()
        context = context or {}

        # Defaults from config.
        cfg = getattr(self.config, "experiment_loop", None) if self.config else None
        if cfg is not None:
            max_iterations = max_iterations or cfg.default_max_iterations
            confidence_threshold = confidence_threshold or cfg.default_confidence_threshold
            if resource_budget_s is None:
                resource_budget_s = cfg.default_resource_budget_s
        max_iterations = max(1, max_iterations)

        state: dict[str, Any] = {
            "goal": goal,
            "iteration": 0,
            "observations": [await self._observe(goal, context)],
            "hypotheses": [],
            "experiments": [],
            "lessons": [],
            "converged": False,
            "stop_reason": None,
        }

        # When persistence is wired, derive a stable loop id and
        # save initial state.
        loop_id = make_loop_id(goal) if self.store is not None else None
        if self.store is not None:
            try:
                self.store.save_state(loop_id, goal, state, status="running")  # type: ignore[arg-type]
            except Exception as e:
                log.debug("Initial loop persist failed (non-fatal): %s", e)

        try:
            for iteration in range(1, max_iterations + 1):
                if self._stop_requested:
                    state["stop_reason"] = "user_intervention"
                    break
                if resource_budget_s and (time.time() - start_ts) > resource_budget_s:
                    state["stop_reason"] = "resource_budget_exceeded"
                    break
                state["iteration"] = iteration
                log.info(
                    "ExperimentLoop: iteration %d/%d (elapsed=%.1fs)",
                    iteration, max_iterations, time.time() - start_ts,
                )
                state = await self.step(state)

                # Emit iteration event for subscribers (progress tracking).
                await self._emit(EventTypes.EXPERIMENT_LOOP_ITERATION, {
                    "iteration": iteration,
                    "max_iterations": max_iterations,
                    "hypotheses_count": len(state["hypotheses"]),
                    "experiments_count": len(state["experiments"]),
                    "elapsed_s": time.time() - start_ts,
                })

                # Check convergence.
                if state["hypotheses"]:
                    top_hyp = max(state["hypotheses"], key=lambda h: h.confidence)
                    if top_hyp.confidence >= confidence_threshold:
                        state["converged"] = True
                        state["stop_reason"] = "confidence_threshold_achieved"
                        log.info(
                            "ExperimentLoop: converged (confidence=%.3f ≥ %.3f)",
                            top_hyp.confidence, confidence_threshold,
                        )
                        await self._emit(EventTypes.EXPERIMENT_LOOP_CONVERGED, {
                            "iteration": iteration,
                            "top_hypothesis": top_hyp.statement[:200],
                            "confidence": top_hyp.confidence,
                            "threshold": confidence_threshold,
                        })
                        break
            else:
                state["stop_reason"] = state["stop_reason"] or "max_iterations_reached"
        finally:
            self._running = False

        state["duration_s"] = time.time() - start_ts
        state["iterations_completed"] = state["iteration"]

        # Final persistence update — mark loop as completed/stopped.
        if self.store is not None and loop_id is not None:
            try:
                self.store.save_state(
                    loop_id, goal, state,
                    status="completed" if state.get("converged") else "stopped",
                    stop_reason=state.get("stop_reason"),
                )
            except Exception as e:
                log.debug("Final loop persist failed (non-fatal): %s", e)

        return state

    async def step(self, state: dict[str, Any]) -> dict[str, Any]:
        """Execute one iteration: observe → hypothesize → experiment → learn."""
        goal = state["goal"]
        # 1. Observe (produce an observation note from the latest state).
        observation = await self._observe(
            goal,
            {"previous_hypotheses": state["hypotheses"][-3:],
             "previous_experiments": state["experiments"][-3:]},
        )
        state["observations"].append(observation)

        # 2. Hypothesize (generate 1-3 fresh hypotheses).
        existing_statements = {h.statement for h in state["hypotheses"]}
        new_hyps = await self.generator.generate(
            observation,
            max_hypotheses=3,
            context={"iteration": state["iteration"]},
        )
        # Filter out duplicates.
        new_hyps = [
            h for h in new_hyps
            if h.statement not in existing_statements
        ]
        state["hypotheses"].extend(new_hyps)
        if not new_hyps:
            log.info("ExperimentLoop: no new hypotheses generated")
            return state

        # 3. Experiment: design + run for each new hypothesis.
        for hyp in new_hyps:
            try:
                experiment = await self.generator.design_experiment(hyp)
                experiment = await self.generator.verify(hyp, experiment)
                state["experiments"].append(experiment)
            except Exception as e:
                log.warning(
                    "ExperimentLoop: experiment for hypothesis %s failed: %s",
                    hyp.id, e,
                )

        # 4. Analyze: rank hypotheses by confidence.
        state["hypotheses"].sort(key=lambda h: h.confidence, reverse=True)

        # 5. Learn: invoke the Reflection Engine on a synthetic task.
        if self.reflection is not None:
            try:
                task = Task(
                    goal=f"Research loop iteration {state['iteration']}: {goal[:80]}",
                    complexity="open_ended",
                )
                result = TaskResult(
                    task_id=task.id,
                    status=TaskStatus.COMPLETED,
                    output=str({
                        "top_hypothesis": state["hypotheses"][0].statement
                            if state["hypotheses"] else None,
                        "experiments_run": len(state["experiments"]),
                    }),
                    steps_executed=len(state["experiments"]),
                    duration_s=0.0,
                    confidence=state["hypotheses"][0].confidence
                        if state["hypotheses"] else 0.0,
                )
                lessons = await self.reflection.reflect(task, None, result)
                state["lessons"].extend(lessons)
            except Exception as e:
                log.debug("ExperimentLoop: reflection failed: %s", e)

        return state

    async def stop(self) -> None:
        """Gracefully request the loop to stop after the current iteration."""
        self._stop_requested = True
        # Give the running step a chance to finish.
        for _ in range(60):
            if not self._running:
                return
            await asyncio.sleep(0.1)

    # ── Helpers ──────────────────────────────────────────────────────────

    async def _observe(
        self, goal: str, context: dict[str, Any],
    ) -> str:
        """Produce an observation note for this iteration.

        If an LLM is available, ask it to summarize what we know so far
        and what we should investigate next.  Otherwise produce a
        trivial observation.
        """
        if self.llm is None:
            return f"Observation for goal: {goal}"
        prior_hyps = context.get("previous_hypotheses") or []
        prior_exps = context.get("previous_experiments") or []
        prior_hyps_text = (
            "\n".join(f"- {h.statement} (confidence={h.confidence:.2f})"
                      for h in prior_hyps)
            or "(none)"
        )
        prior_exps_text = (
            "\n".join(f"- {e.name} (status={e.status.value})"
                      for e in prior_exps
                      if hasattr(e, "name") and hasattr(e, "status"))
            or "(none)"
        )
        user_prompt = (
            f"GOAL: {goal}\n\n"
            f"PRIOR HYPOTHESES:\n{prior_hyps_text}\n\n"
            f"PRIOR EXPERIMENTS:\n{prior_exps_text}\n\n"
            f"In 1-2 sentences, what should we investigate next?"
        )
        try:
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": (
                        "You are the OBSERVATION phase of an autonomous research loop. "
                        "Be specific and concrete."
                    )},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.4,
                max_tokens=200,
            )
            return (resp.text or "").strip() or f"Observation for goal: {goal}"
        except Exception as e:
            log.debug("Observe LLM failed: %s", e)
            return f"Observation for goal: {goal}"


__all__ = ["DefaultExperimentLoop"]
