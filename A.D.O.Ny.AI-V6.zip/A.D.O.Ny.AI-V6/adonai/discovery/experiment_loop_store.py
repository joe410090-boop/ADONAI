"""Experiment loop persistence — SQLite store for loop state.

Persists the in-memory state of a :class:`DefaultExperimentLoop` run
so loops can survive process restarts and be inspected later.

Schema (table ``experiment_loops``):

* ``id``              TEXT PRIMARY KEY   — loop run id (derived from goal hash)
* ``goal``            TEXT NOT NULL
* ``created_at``      REAL NOT NULL
* ``updated_at``      REAL NOT NULL
* ``status``          TEXT NOT NULL      — running | completed | stopped
* ``state_json``      TEXT NOT NULL      — full state dict (JSON-serialised)
* ``stop_reason``     TEXT

Table ``experiment_loop_hypotheses`` (1-to-many):
* ``loop_id``         TEXT
* ``hypothesis_id``   TEXT
* ``statement``       TEXT
* ``confidence``      REAL
* ``status``          TEXT
* ``added_at``        REAL
"""
from __future__ import annotations

import json
import logging
import sqlite3
import time
from pathlib import Path
from typing import Any
from uuid import uuid4

log = logging.getLogger(__name__)


_SCHEMA = """
CREATE TABLE IF NOT EXISTS experiment_loops (
    id           TEXT PRIMARY KEY,
    goal         TEXT NOT NULL,
    created_at   REAL NOT NULL,
    updated_at   REAL NOT NULL,
    status       TEXT NOT NULL,
    stop_reason  TEXT,
    state_json   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS experiment_loop_hypotheses (
    loop_id        TEXT NOT NULL,
    hypothesis_id  TEXT NOT NULL,
    statement      TEXT,
    confidence     REAL,
    status         TEXT,
    added_at       REAL NOT NULL,
    PRIMARY KEY (loop_id, hypothesis_id)
);

CREATE INDEX IF NOT EXISTS idx_loops_status ON experiment_loops(status);
CREATE INDEX IF NOT EXISTS idx_loop_hyps_loop ON experiment_loop_hypotheses(loop_id);
"""


class ExperimentLoopStore:
    """SQLite-backed persistence for experiment loop state."""

    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _init_schema(self) -> None:
        try:
            with self._connect() as conn:
                conn.executescript(_SCHEMA)
                conn.commit()
        except Exception as e:
            log.error("ExperimentLoopStore schema init failed: %s", e)
            raise

    # ------------------------------------------------------------------ #
    # Write
    # ------------------------------------------------------------------ #

    def save_state(
        self,
        loop_id: str,
        goal: str,
        state: dict[str, Any],
        *,
        status: str = "running",
        stop_reason: str | None = None,
    ) -> None:
        """Persist (or update) the state of a running/completed loop."""
        now = time.time()
        # Serialise state — Pydantic models → dicts.
        serialisable = _to_serialisable(state)
        state_json = json.dumps(serialisable, default=str)
        try:
            with self._connect() as conn:
                conn.execute(
                    """INSERT INTO experiment_loops
                       (id, goal, created_at, updated_at, status, stop_reason, state_json)
                       VALUES (?, ?, ?, ?, ?, ?, ?)
                       ON CONFLICT(id) DO UPDATE SET
                           updated_at = excluded.updated_at,
                           status = excluded.status,
                           stop_reason = excluded.stop_reason,
                           state_json = excluded.state_json""",
                    (loop_id, goal, now, now, status, stop_reason, state_json),
                )
                # Persist hypotheses (replace strategy).
                conn.execute(
                    "DELETE FROM experiment_loop_hypotheses WHERE loop_id = ?",
                    (loop_id,),
                )
                for hyp in state.get("hypotheses", []):
                    conn.execute(
                        """INSERT INTO experiment_loop_hypotheses
                           (loop_id, hypothesis_id, statement, confidence, status, added_at)
                           VALUES (?, ?, ?, ?, ?, ?)""",
                        (
                            loop_id,
                            hyp.get("id") if isinstance(hyp, dict) else getattr(hyp, "id", ""),
                            (hyp.get("statement") if isinstance(hyp, dict)
                             else getattr(hyp, "statement", ""))[:500],
                            (hyp.get("confidence") if isinstance(hyp, dict)
                             else getattr(hyp, "confidence", 0.0)),
                            (hyp.get("status") if isinstance(hyp, dict)
                             else getattr(hyp, "status", "")).value
                            if not isinstance(hyp, dict) and hasattr(hyp, "status")
                            else str(hyp.get("status", "") if isinstance(hyp, dict) else ""),
                            now,
                        ),
                    )
                conn.commit()
        except Exception as e:
            log.error("ExperimentLoopStore.save_state failed: %s", e)
            raise

    # ------------------------------------------------------------------ #
    # Read
    # ------------------------------------------------------------------ #

    def load_state(self, loop_id: str) -> dict[str, Any] | None:
        """Load the persisted state for a loop id."""
        try:
            with self._connect() as conn:
                row = conn.execute(
                    "SELECT * FROM experiment_loops WHERE id = ?",
                    (loop_id,),
                ).fetchone()
            if row is None:
                return None
            return {
                "id": row["id"],
                "goal": row["goal"],
                "created_at": row["created_at"],
                "updated_at": row["updated_at"],
                "status": row["status"],
                "stop_reason": row["stop_reason"],
                "state": json.loads(row["state_json"]),
            }
        except Exception as e:
            log.warning("ExperimentLoopStore.load_state failed: %s", e)
            return None

    def list_loops(self, status: str | None = None, limit: int = 50) -> list[dict[str, Any]]:
        """List loops, optionally filtered by status."""
        query = "SELECT id, goal, created_at, updated_at, status, stop_reason FROM experiment_loops"
        params: list[Any] = []
        if status is not None:
            query += " WHERE status = ?"
            params.append(status)
        query += " ORDER BY updated_at DESC LIMIT ?"
        params.append(limit)
        try:
            with self._connect() as conn:
                rows = conn.execute(query, params).fetchall()
            return [dict(r) for r in rows]
        except Exception as e:
            log.warning("ExperimentLoopStore.list_loops failed: %s", e)
            return []

    def list_hypotheses(self, loop_id: str) -> list[dict[str, Any]]:
        """List hypotheses for a loop."""
        try:
            with self._connect() as conn:
                rows = conn.execute(
                    "SELECT * FROM experiment_loop_hypotheses WHERE loop_id = ? ORDER BY added_at",
                    (loop_id,),
                ).fetchall()
            return [dict(r) for r in rows]
        except Exception as e:
            log.warning("ExperimentLoopStore.list_hypotheses failed: %s", e)
            return []

    def delete_loop(self, loop_id: str) -> bool:
        try:
            with self._connect() as conn:
                conn.execute(
                    "DELETE FROM experiment_loop_hypotheses WHERE loop_id = ?",
                    (loop_id,),
                )
                cur = conn.execute(
                    "DELETE FROM experiment_loops WHERE id = ?",
                    (loop_id,),
                )
                conn.commit()
                return cur.rowcount > 0
        except Exception as e:
            log.warning("ExperimentLoopStore.delete_loop failed: %s", e)
            return False


# --------------------------------------------------------------------------- #
# Helpers
# --------------------------------------------------------------------------- #

def _to_serialisable(obj: Any) -> Any:
    """Recursively convert Pydantic models + nested structures to JSON-safe dicts."""
    if hasattr(obj, "model_dump"):
        return obj.model_dump()
    if isinstance(obj, dict):
        return {k: _to_serialisable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_to_serialisable(item) for item in obj]
    if hasattr(obj, "value") and hasattr(obj, "name"):
        # Enum.
        return obj.value
    return obj


def make_loop_id(goal: str) -> str:
    """Derive a stable loop id from the goal text."""
    import hashlib
    return "loop_" + hashlib.sha1(goal.encode()).hexdigest()[:12]
