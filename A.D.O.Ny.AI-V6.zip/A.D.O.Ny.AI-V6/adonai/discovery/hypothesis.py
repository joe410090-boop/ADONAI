"""Upgrade 7 — Hypothesis Generator.

Dedicated discovery capability.  Pipeline::

    Observation → Hypothesis Generation → Experiment Design
                → Execution → Verification

Outputs a :class:`~adonai.core.models.Hypothesis` with statement,
confidence, and supporting_evidence.

The generator:

* Accepts free-text observations (from web search, files, agents, or
  experiments) and proposes N falsifiable hypotheses.
* Designs experiments to test each hypothesis (using the Simulation
  Abstraction Layer from Upgrade 11 when appropriate).
* Updates hypothesis confidence using a Bayesian update rule based on
  experiment outcomes.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from adonai.core.exceptions import HypothesisError
from adonai.core.events import EventPublisher, EventTypes
from adonai.core.interfaces import HypothesisGenerator, LLMClient
from adonai.core.json_utils import JSONExtractionError, extract_json
from adonai.core.models import (
    Experiment, ExperimentStatus, Hypothesis, HypothesisStatus,
    SimulationSpec,
)

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Prompts
# ──────────────────────────────────────────────────────────────────────────────


_HYPOTHESIS_PROMPT = (
    "You are the HYPOTHESIS GENERATOR for an autonomous research platform.\n"
    "Given an observation, propose FALSIFIABLE hypotheses that explain it.\n\n"
    "Output JSON array (max N items):\n"
    "[\n"
    "  {\n"
    '    "statement": str,              // falsifiable hypothesis\n'
    '    "predictions": [str],          // what we would observe if true\n'
    '    "falsification_criteria": str, // observation that would refute it\n'
    '    "prior": 0.0-1.0,              // prior probability\n'
    '    "domain": str?                 // e.g. "fluid_dynamics"\n'
    "  }\n"
    "]\n\n"
    "Rules:\n"
    "1. Each hypothesis MUST be falsifiable — there must be a concrete\n"
    "   observation that would prove it wrong.\n"
    "2. Avoid trivially-true hypotheses (\"X exists because it was made\").\n"
    "3. Prefer hypotheses with high information content.\n"
    "Return ONLY the JSON array.  No prose, no markdown fences."
)

_EXPERIMENT_DESIGN_PROMPT = (
    "You are the EXPERIMENT DESIGNER for an autonomous research platform.\n"
    "Given a hypothesis, design an experiment that tests it.\n\n"
    "Output JSON:\n"
    "{\n"
    '  "name": str,\n'
    '  "description": str,\n'
    '  "simulator": "mock"|"openfoam"|"pybullet"|"carla"|"isaac_sim"|null,\n'
    '  "design": {                       // simulator-specific config\n'
    '    "parameters": {},\n'
    '    "config": {},\n'
    '    "metrics": [str]\n'
    "  },\n"
    '  "expected_supporting": [str],    // outcomes that would support\n'
    '  "expected_contradicting": [str]   // outcomes that would refute\n'
    "}\n\n"
    "Return ONLY the JSON.  No prose, no markdown fences."
)


# ──────────────────────────────────────────────────────────────────────────────
# DefaultHypothesisGenerator
# ──────────────────────────────────────────────────────────────────────────────


class DefaultHypothesisGenerator(HypothesisGenerator, EventPublisher):
    """LLM-backed hypothesis generator with Bayesian update.

    Falls back to a trivial heuristic generator when no LLM is
    configured (useful for tests).
    """

    def __init__(
        self,
        llm: LLMClient | None = None,
        *,
        config: Any = None,
        simulator_registry: Any = None,
    ) -> None:
        self.llm = llm
        self.config = config
        self.simulators = simulator_registry

    # ── HypothesisGenerator interface ────────────────────────────────────

    async def generate(
        self,
        observation: str,
        *,
        domain: str | None = None,
        max_hypotheses: int = 3,
        context: dict[str, Any] | None = None,
    ) -> list[Hypothesis]:
        """Generate up to ``max_hypotheses`` falsifiable hypotheses."""
        if not observation or not observation.strip():
            return []
        if self.llm is None:
            return self._heuristic_generate(observation, domain, max_hypotheses)
        user_prompt = (
            f"OBSERVATION: {observation}\n"
            f"DOMAIN: {domain or 'general'}\n"
            f"MAX HYPOTHESES: {max_hypotheses}\n\n"
            f"Generate hypotheses as JSON."
        )
        try:
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": _HYPOTHESIS_PROMPT},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.4,
                max_tokens=1024,
            )
            data = extract_json(resp.text or "")
        except (JSONExtractionError, Exception) as e:
            log.warning("Hypothesis generation LLM failed: %s — using heuristic", e)
            return self._heuristic_generate(observation, domain, max_hypotheses)
        if not isinstance(data, list):
            data = [data] if isinstance(data, dict) else []
        # Filter by min falsifiability (heuristic — long falsification_criteria = good).
        min_falsif = (
            getattr(getattr(self.config, "hypothesis", None),
                    "min_falsifiability_score", 0.5)
            if self.config else 0.5
        )
        out: list[Hypothesis] = []
        for item in data[:max_hypotheses]:
            if not isinstance(item, dict):
                continue
            statement = str(item.get("statement", "")).strip()
            if not statement:
                continue
            falsification = str(item.get("falsification_criteria", "")).strip()
            # Heuristic falsifiability score: 1.0 if there's a falsification
            # criterion of >= 20 chars, else 0.3.
            falsif_score = 1.0 if len(falsification) >= 20 else 0.3
            if falsif_score < min_falsif:
                continue
            try:
                prior = float(item.get("prior", 0.5))
            except (TypeError, ValueError):
                prior = 0.5
            hyp = Hypothesis(
                statement=statement,
                confidence=prior,
                prior=prior,
                predictions=list(item.get("predictions") or []),
                falsification_criteria=falsification or None,
                domain=domain or item.get("domain"),
                status=HypothesisStatus.PROPOSED,
            )
            out.append(hyp)

        # Emit hypothesis.generated events for subscribers.
        for h in out:
            await self._emit(EventTypes.HYPOTHESIS_GENERATED, {
                "hypothesis_id": h.id,
                "statement": h.statement[:200],
                "confidence": h.confidence,
                "domain": h.domain,
            })

        return out

    async def design_experiment(
        self, hypothesis: Hypothesis,
    ) -> Experiment:
        """Design an experiment that tests ``hypothesis``.

        If the LLM suggests a simulator, the experiment's ``design``
        field will contain a :class:`SimulationSpec`-compatible dict.
        """
        if self.llm is None:
            return self._heuristic_design(hypothesis)
        user_prompt = (
            f"HYPOTHESIS: {hypothesis.statement}\n"
            f"PREDICTIONS: {hypothesis.predictions}\n"
            f"FALSIFICATION: {hypothesis.falsification_criteria}\n"
            f"DOMAIN: {hypothesis.domain or 'general'}\n\n"
            f"Design an experiment as JSON."
        )
        try:
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": _EXPERIMENT_DESIGN_PROMPT},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.2,
                max_tokens=1024,
            )
            data = extract_json(resp.text or "")
        except (JSONExtractionError, Exception) as e:
            log.warning("Experiment design LLM failed: %s — using heuristic", e)
            return self._heuristic_design(hypothesis)
        if not isinstance(data, dict):
            return self._heuristic_design(hypothesis)
        return Experiment(
            hypothesis_id=hypothesis.id,
            name=str(data.get("name", "untitled_experiment")),
            description=str(data.get("description", "")),
            simulator=data.get("simulator"),
            design=data.get("design") or {},
            metadata={
                "expected_supporting": data.get("expected_supporting") or [],
                "expected_contradicting": data.get("expected_contradicting") or [],
            },
        )

    async def verify(
        self, hypothesis: Hypothesis, experiment: Experiment,
    ) -> Hypothesis:
        """Run the experiment and update the hypothesis confidence.

        Uses the SimulatorRegistry if the experiment has a simulator;
        otherwise runs the LLM-suggested analysis heuristically.
        """
        if experiment.status != ExperimentStatus.COMPLETED:
            # Need to run it first.
            experiment = await self._run_experiment(experiment)
        # Compute confidence delta.
        delta = self._compute_confidence_delta(hypothesis, experiment)
        new_conf = max(0.01, min(0.99, hypothesis.confidence + delta))
        hypothesis.confidence = new_confidence = round(new_conf, 4)
        hypothesis.posterior = new_confidence
        hypothesis.experiment_ids.append(experiment.id)
        # Update status.
        if new_confidence >= self._supported_threshold():
            hypothesis.status = HypothesisStatus.SUPPORTED
            hypothesis.supporting_evidence.append(experiment.id)
            await self._emit(EventTypes.HYPOTHESIS_SUPPORTED, {
                "hypothesis_id": hypothesis.id,
                "confidence": new_confidence,
                "experiment_id": experiment.id,
            })
        elif new_confidence <= self._refuted_threshold():
            hypothesis.status = HypothesisStatus.REFUTED
            hypothesis.contradicting_evidence.append(experiment.id)
            await self._emit(EventTypes.HYPOTHESIS_REFUTED, {
                "hypothesis_id": hypothesis.id,
                "confidence": new_confidence,
                "experiment_id": experiment.id,
            })
        else:
            hypothesis.status = HypothesisStatus.INCONCLUSIVE
        return hypothesis

    # ── Helpers ──────────────────────────────────────────────────────────

    async def _run_experiment(self, experiment: Experiment) -> Experiment:
        """Execute the experiment via the SimulatorRegistry."""
        experiment.status = ExperimentStatus.RUNNING
        from datetime import datetime, timezone
        experiment.started_at = datetime.now(timezone.utc)
        if (
            self.simulators is not None
            and experiment.simulator
            and experiment.simulator != "none"
        ):
            try:
                spec = SimulationSpec(
                    simulator=experiment.simulator,
                    parameters=experiment.design.get("parameters") or {},
                    config=experiment.design.get("config") or {},
                    metrics=experiment.design.get("metrics") or [],
                )
                result = await self.simulators.run(spec)
                experiment.result = {
                    "metrics": result.metrics,
                    "log": result.log,
                    "error": result.error,
                    "duration_s": result.duration_s,
                }
                experiment.metrics = dict(result.metrics)
                if result.status.value == "completed":
                    experiment.status = ExperimentStatus.COMPLETED
                else:
                    experiment.status = ExperimentStatus.FAILED
                    experiment.error = result.error or "simulation failed"
            except Exception as e:
                experiment.status = ExperimentStatus.FAILED
                experiment.error = f"simulator_error: {e}"
        else:
            # No simulator — heuristic pass/fail based on design.
            experiment.status = ExperimentStatus.COMPLETED
            experiment.result = {"heuristic": True}
            experiment.metrics = {"plausibility": 0.6}
        experiment.completed_at = datetime.now(timezone.utc)
        return experiment

    def _compute_confidence_delta(
        self, hypothesis: Hypothesis, experiment: Experiment,
    ) -> float:
        """Compute the confidence delta from the experiment outcome.

        Heuristic: if the experiment's metrics match the hypothesis's
        predictions, push confidence up; otherwise push it down.
        """
        if experiment.status != ExperimentStatus.COMPLETED:
            return -0.05  # failed experiments slightly weaken confidence
        supporting_w = (
            getattr(getattr(self.config, "hypothesis", None),
                    "supporting_evidence_weight", 0.15)
            if self.config else 0.15
        )
        contradicting_w = (
            getattr(getattr(self.config, "hypothesis", None),
                    "contradicting_evidence_weight", 0.20)
            if self.config else 0.20
        )
        expected_supporting = (
            experiment.metadata.get("expected_supporting") or []
        )
        expected_contradicting = (
            experiment.metadata.get("expected_contradicting") or []
        )
        # Did the experiment produce evidence matching either side?
        metrics_str = " ".join(
            f"{k}={v}" for k, v in (experiment.metrics or {}).items()
        ).lower()
        supports = any(
            self._fuzzy_match(s, metrics_str) for s in expected_supporting
        )
        contradicts = any(
            self._fuzzy_match(c, metrics_str) for c in expected_contradicting
        )
        delta = 0.0
        if supports:
            delta += supporting_w
        if contradicts:
            delta -= contradicting_w
        return delta

    @staticmethod
    def _fuzzy_match(needle: str, haystack: str) -> bool:
        """Cheap fuzzy match — any 4+ char word from needle appears in haystack."""
        if not needle:
            return False
        import re
        words = re.findall(r"\b\w{4,}\b", needle.lower())
        return any(w in haystack for w in words)

    def _supported_threshold(self) -> float:
        return (
            getattr(getattr(self.config, "hypothesis", None),
                    "max_supported_confidence", 0.95)
            if self.config else 0.95
        )

    def _refuted_threshold(self) -> float:
        return (
            getattr(getattr(self.config, "hypothesis", None),
                    "min_refuted_confidence", 0.05)
            if self.config else 0.05
        )

    # ── Heuristic fallbacks ──────────────────────────────────────────────

    def _heuristic_generate(
        self, observation: str, domain: str | None, max_h: int,
    ) -> list[Hypothesis]:
        """Produce a single trivial hypothesis when no LLM is available."""
        return [
            Hypothesis(
                statement=(
                    f"The observation '{observation[:120]}' is explained by "
                    f"an underlying mechanism that can be tested empirically."
                ),
                predictions=[
                    "Repeatable measurement will show consistent results.",
                ],
                falsification_criteria=(
                    "If the measurement varies wildly across repetitions, "
                    "the hypothesis is refuted."
                ),
                prior=0.5,
                confidence=0.5,
                domain=domain,
                status=HypothesisStatus.PROPOSED,
            )
        ][:max_h]

    def _heuristic_design(self, hypothesis: Hypothesis) -> Experiment:
        return Experiment(
            hypothesis_id=hypothesis.id,
            name="heuristic_experiment",
            description=(
                f"Run a mock simulation to test: {hypothesis.statement[:100]}"
            ),
            simulator="mock",
            design={
                "parameters": {"x": 1.0},
                "config": {},
                "metrics": ["plausibility"],
            },
            metadata={
                "expected_supporting": hypothesis.predictions,
                "expected_contradicting": [
                    hypothesis.falsification_criteria or "",
                ],
            },
        )


__all__ = ["DefaultHypothesisGenerator"]
