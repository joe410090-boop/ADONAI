"""Scientific Discovery Super-Node — autonomous multi-agent research system.

A hierarchical state-machine architecture for iterative design optimization:

    Research Director
           │
           ▼
    Creator Agent  ──►  Simulation Engine  ──►  Reviewer Agent
           ▲                                           │
           │                                           ▼
           └────────  Learning Engine  ◄──────────────┘

Each cycle = one generation of evolutionary experimentation.

Integrates with A.D.O.N.AI v3's LLM client (Ollama / OpenAI-compatible).
"""
from adonai.discovery.discovery_node import (
    DiscoveryState, Design, SimulationResult, GenerationRecord,
    SimulationEngine, LearningEngine, ResearchDirector,
    DiscoveryCampaign, run_campaign,
)

__all__ = [
    "DiscoveryState", "Design", "SimulationResult", "GenerationRecord",
    "SimulationEngine", "LearningEngine", "ResearchDirector",
    "DiscoveryCampaign", "run_campaign",
]
