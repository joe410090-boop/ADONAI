"""Exception hierarchy for A.D.O.N.AI v3."""
from __future__ import annotations


class AdonaiError(Exception):
    """Base exception for all framework errors."""


class ConfigError(AdonaiError):
    """Configuration is invalid or missing required values."""


class LLMError(AdonaiError):
    """LLM backend failure."""


class AdonaiMemoryError(AdonaiError):
    """Memory backend operation failed."""


class ToolError(AdonaiError):
    """Tool execution failed."""


class ToolNotFoundError(ToolError):
    """Requested tool does not exist."""


class PermissionDeniedError(ToolError):
    """Tool execution denied by permission policy."""


class AgentError(AdonaiError):
    """Agent operation failed."""


class AgentNotFoundError(AgentError):
    """Requested agent type does not exist."""


class SkillError(AdonaiError):
    """Skill operation failed."""


class TaskError(AdonaiError):
    """Long-running task failed."""


class MCPError(AdonaiError):
    """MCP operation failed."""


class PlanningError(AdonaiError):
    """Planner failed to produce a valid plan."""


class ReasoningError(AdonaiError):
    """Reasoning strategy failed."""


class ExecutionError(AdonaiError):
    """Execution engine failure."""


class CheckpointError(AdonaiError):
    """Checkpoint save/restore failed."""


# ──────────────────────────────────────────────────────────────────────────────
# v4 — Research-grade extensions
# ──────────────────────────────────────────────────────────────────────────────


class SafetyViolationError(AdonaiError):
    """A proposed action violated a safety invariant.

    Raised by :class:`SafetyGuard` implementations when a plan, patch, or
    experiment is rejected before execution.  The framework treats this as
    a hard stop — the offending action is rolled back (if started) and the
    violation is recorded in the audit log.
    """


class HypothesisError(AdonaiError):
    """Hypothesis lifecycle failure (generation, test, or update)."""


class SimulationError(AdonaiError):
    """Simulator backend failure (OpenFOAM, PyBullet, CARLA, Isaac Sim, …)."""


class ModelRouterError(AdonaiError):
    """Model router could not satisfy the request (no available model)."""


class SelfImprovementError(AdonaiError):
    """Self-improvement pipeline failure (sandbox, regression, or merge)."""


class CritiqueError(AdonaiError):
    """Critic agent produced an invalid or unparseable critique."""


class DebateError(AdonaiError):
    """Multi-agent debate framework failure."""


class KnowledgeGraphError(AdonaiError):
    """Knowledge-graph operation failed (entity, relation, or query)."""


class ExperimentLoopError(AdonaiError):
    """Autonomous experiment loop failed to converge or was aborted."""


class StrategicReasoningError(AdonaiError):
    """Strategic reasoning hierarchy failed (mission, strategic, or tactical)."""


class ReflectionError(AdonaiError):
    """Reflection engine failure (LLM parse, persistence, or reinforcement)."""
