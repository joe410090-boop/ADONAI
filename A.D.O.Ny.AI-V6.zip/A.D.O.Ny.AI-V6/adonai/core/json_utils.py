"""JSON extraction utility for LLM outputs."""
from __future__ import annotations

import json
import re
from typing import Any

__all__ = ["JSONExtractionError", "extract_json"]


class JSONExtractionError(ValueError):
    pass


# A code fence may or may not have a language tag (```json / ```python / ```).
# We capture two flavors:
#   * complete fence:   ```lang ... ```
#   * opening-only:     ```lang ...   (no closing ```, common when the LLM
#                       runs out of tokens mid-JSON inside a fenced block)
_FENCE_FULL_RE = re.compile(r"```(?:[a-zA-Z0-9_+-]+)?\s*(.*?)\s*```", re.DOTALL | re.IGNORECASE)
_FENCE_OPEN_RE = re.compile(r"^\s*```(?:[a-zA-Z0-9_+-]+)?\s*\n", re.MULTILINE)
_OBJ_RE = re.compile(r"(\{.*\}|\[.*\])", re.DOTALL)
# Trailing commas before a closing bracket/brace, e.g. {"a":1,} or [1,2,].
# The regex is greedy-matched on the outside-string context, but to keep
# things simple we run it on the whole text and accept the (tiny) risk of
# touching a comma that lives inside a string literal — small models that
# emit trailing commas rarely also emit ` ,]` inside string values.
_TRAILING_COMMA_RE = re.compile(r",(\s*[}\]])")


def _normalize_escapes(text: str) -> str:
    """Convert literal \\n / \\t outside of JSON strings to actual newlines/tabs.

    Small models sometimes return text where newlines are represented as
    the two-character sequence \\n instead of actual newline bytes.  This
    makes regex-based fence detection and JSON parsing fail because the
    entire response is one long line.

    Inside JSON string values (between double-quotes), \\n is a valid
    escape and must be preserved as-is.
    """
    if "\\n" not in text and "\\t" not in text:
        return text
    out = []
    in_string = False
    escape = False
    i = 0
    while i < len(text):
        ch = text[i]
        if escape:
            out.append(ch)
            escape = False
            i += 1
            continue
        if ch == "\\":
            if i + 1 < len(text) and text[i + 1] in ("n", "t"):
                if in_string:
                    # Inside a JSON string — keep the escape intact.
                    out.append(ch)
                    out.append(text[i + 1])
                    i += 2
                    continue
                else:
                    # Outside a JSON string — convert to real whitespace.
                    out.append("\n" if text[i + 1] == "n" else "\t")
                    i += 2
                    continue
            else:
                out.append(ch)
                escape = True
                i += 1
                continue
        if ch == '"':
            in_string = not in_string
        out.append(ch)
        i += 1
    return "".join(out)


def _strip_fences(text: str) -> str:
    """Remove markdown code fences (```json ... ```) from LLM output.

    Handles two cases:
      1. Complete fence (```json ... ```): keep only the inner content.
      2. Opening-only fence (```json ...): strip the leading fence line so
         the remaining text starts at the JSON.  This happens when small
         models run out of tokens mid-JSON while still inside a fenced
         block.
    """
    m = _FENCE_FULL_RE.search(text)
    if m:
        return m.group(1).strip()
    # Try opening-only fence: if the text starts with ```lang\n, drop that
    # prefix line.
    m = _FENCE_OPEN_RE.match(text)
    if m:
        return text[m.end():].strip()
    return text.strip()


def _fix_invalid_escapes(text: str) -> str:
    """Fix invalid JSON escape sequences produced by small models.

    JSON only allows these escapes: \\" \\\\ \\/ \\b \\f \\n \\r \\t \\uXXXX
    Small models (qwen3-4b) sometimes produce:
      - \\' (escaped single quote) — invalid in JSON, valid in Python
      - \\x41 (hex escape) — invalid in JSON
      - \\a, \\v, \\0 — invalid in JSON

    This function removes the backslash from invalid escapes, turning
    \\' into ' and \\x41 into x41 (which is then harmless text).
    """
    # Valid JSON escapes: \" \\ \/ \b \f \n \r \t \uXXXX
    # Replace \' with ' (most common small-model mistake)
    text = re.sub(r"\\'", "'", text)
    # Replace other invalid escapes (\a, \v, \0, \x) by removing backslash
    text = re.sub(r'\\([av0x])', r'\1', text)
    return text


def _strip_trailing_commas(text: str) -> str:
    """Remove trailing commas before ``}`` and ``]``.

    Small models (qwen3-4b, qwen2.5-7b) frequently emit JSON like::

        {"a": 1, "b": 2,}
        [1, 2, 3,]

    which is invalid JSON.  This function strips the trailing comma so
    ``json.loads`` accepts the payload.
    """
    return _TRAILING_COMMA_RE.sub(r"\1", text)


def _repair_truncated_json(text: str) -> str:
    """Attempt to repair truncated JSON by closing open brackets/braces/strings.

    Handles truncation in the middle of:
    - A string value (closes the string)
    - A key with no value (adds :null)
    - After a trailing comma (removes it)
    """
    stack: list[str] = []
    in_string = False
    escape = False
    # Track the last significant char outside strings to determine
    # whether a truncated string is a key (needs :null) or a value.
    last_significant: str = ""

    for ch in text:
        if escape:
            escape = False
            continue
        if ch == "\\":
            escape = True
            continue
        if ch == '"':
            if in_string:
                in_string = False
                last_significant = '"'
            else:
                in_string = True
            continue
        if in_string:
            continue
        if ch in "{[]:,":
            last_significant = ch
        if ch in "{[":
            stack.append(ch)
        elif ch == "}" and stack and stack[-1] == "{":
            stack.pop()
        elif ch == "]" and stack and stack[-1] == "[":
            stack.pop()

    result = text

    if in_string:
        # Close the truncated string.
        result += '"'
        # If this string was a key (not a value), add :null so the
        # resulting JSON is valid.
        in_object = bool(stack) and stack[-1] == "{"
        if in_object and last_significant in ("{", ","):
            result += ": null"
    elif last_significant == ",":
        # Trailing comma — strip it so json.loads doesn't choke.
        stripped = result.rstrip()
        if stripped.endswith(","):
            result = stripped[:-1]

    # Close open containers in reverse order.
    for opener in reversed(stack):
        result += "]" if opener == "[" else "}"

    return result


def extract_json(text: str) -> Any:
    """Extract JSON from an LLM response string.

    Tries multiple strategies in order:
    1. Normalize literal \\n/\\t (small models) then strip fences
    2. Parse as-is
    3. Fix invalid escapes (\\', \\x, etc.)
    4. Strip trailing commas (small models: {"a":1,})
    5. Repair truncated JSON (small models run out of tokens)
    6. Find first balanced object/array by brute-force slicing
    7. Regex fallback
    """
    if not text or not text.strip():
        raise JSONExtractionError("empty LLM response")

    # CRITICAL: Normalize escape sequences BEFORE stripping fences.
    # Small models (qwen3-4b) return markdown fences with literal \\n
    # instead of real newlines, e.g.  "```json\\n{\\n  ...\\n}"
    # Without normalization, the fence regex treats the entire response
    # as one line and fails to match the opening/closing ``` pair.
    normalized = _normalize_escapes(text)

    # Strip markdown code fences (also handles opening-only fences).
    cleaned = _strip_fences(normalized)

    # Strategy 1: parse as-is.
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        pass

    # Strategy 2: fix invalid escapes (\' \a \v \x).
    fixed = _fix_invalid_escapes(cleaned)
    if fixed != cleaned:
        try:
            return json.loads(fixed)
        except json.JSONDecodeError:
            pass
        cleaned = fixed

    # Strategy 3: strip trailing commas ({"a":1,} / [1,2,]).
    comma_stripped = _strip_trailing_commas(cleaned)
    if comma_stripped != cleaned:
        try:
            return json.loads(comma_stripped)
        except json.JSONDecodeError:
            pass
        cleaned = comma_stripped

    # Strategy 4: repair truncated JSON (small models run out of tokens).
    repaired = _repair_truncated_json(cleaned)
    if repaired != cleaned:
        try:
            return json.loads(repaired)
        except json.JSONDecodeError:
            pass

    # Strategy 5: find first balanced {...} or [...] via bracket-matching scan.
    # The previous implementation was O(n²) — it tried every possible end
    # index via repeated json.loads, which on a 10KB LLM response could be
    # 10,000 parse attempts. This scan walks the string once, tracking
    # string/escape state, and tries json.loads exactly once per balanced
    # candidate (in order of decreasing length, so the longest valid prefix
    # wins).
    for opener, closer in (("{", "}"), ("[", "]")):
        start = cleaned.find(opener)
        if start == -1:
            continue
        # Walk forward from `start` tracking nesting depth and string state.
        depth = 0
        in_str = False
        escape = False
        candidates: list[int] = []  # end-indices where depth returns to 0
        for i in range(start, len(cleaned)):
            ch = cleaned[i]
            if in_str:
                if escape:
                    escape = False
                elif ch == "\\":
                    escape = True
                elif ch == '"':
                    in_str = False
                continue
            if ch == '"':
                in_str = True
                continue
            if ch == opener:
                depth += 1
            elif ch == closer:
                depth -= 1
                if depth == 0:
                    candidates.append(i + 1)
                    # Keep scanning — we want the longest valid prefix.
        # Try candidates longest-first (most likely to be the full object).
        for end in sorted(candidates, reverse=True):
            try:
                return json.loads(cleaned[start:end])
            except json.JSONDecodeError:
                continue

    # Strategy 6: regex match.
    m = _OBJ_RE.search(cleaned)
    if m:
        try:
            return json.loads(m.group(1))
        except json.JSONDecodeError:
            pass

    preview = text[:200].replace("\n", "\\n")
    raise JSONExtractionError(
        f"could not extract JSON from LLM response (preview: {preview!r})"
    )
