"""Dependency injection container.

Single source of truth for all wired subsystems.  Subsystems are registered
lazily and resolved on first use, so startup is fast and circular imports
are avoided.
"""
from __future__ import annotations

import logging
from typing import Any, Callable, TypeVar

log = logging.getLogger(__name__)

T = TypeVar("T")


class Container:
    """A simple service locator with lazy singleton resolution.

    Usage::

        c = Container()
        c.register("llm", build_llm_client, config)
        llm = c.resolve("llm")  # builds once, caches

    The factory is called with the args supplied at register time.
    """

    def __init__(self) -> None:
        self._factories: dict[str, tuple[Callable[..., Any], tuple, dict]] = {}
        self._instances: dict[str, Any] = {}
        self._singletons: set[str] = set()

    def register(
        self,
        name: str,
        factory: Callable[..., Any],
        *args: Any,
        singleton: bool = True,
        **kwargs: Any,
    ) -> None:
        """Register a factory under *name*.  If singleton, the result is cached."""
        self._factories[name] = (factory, args, kwargs)
        if singleton:
            self._singletons.add(name)
        # Invalidate any cached instance so the new factory takes effect.
        self._instances.pop(name, None)

    def register_instance(self, name: str, instance: Any) -> None:
        """Register a pre-built instance (skips the factory)."""
        self._instances[name] = instance
        self._singletons.add(name)

    def resolve(self, name: str) -> Any:
        """Resolve a registered service.  Raises KeyError if unknown."""
        if name in self._instances:
            return self._instances[name]
        if name not in self._factories:
            raise KeyError(f"no service registered as {name!r}")
        factory, args, kwargs = self._factories[name]
        instance = factory(*args, **kwargs)
        if name in self._singletons:
            self._instances[name] = instance
        return instance

    def get(self, name: str) -> Any:
        """Alias for resolve()."""
        return self.resolve(name)

    def has(self, name: str) -> bool:
        return name in self._factories or name in self._instances

    def list_services(self) -> list[str]:
        return sorted(set(self._factories) | set(self._instances))

    async def shutdown(self) -> None:
        """Close any service that has a `close()` method."""
        for name, instance in list(self._instances.items()):
            close = getattr(instance, "close", None)
            if callable(close):
                try:
                    result = close()
                    if hasattr(result, "__await__"):
                        await result
                except Exception as e:
                    log.warning("Container.shutdown(%s): %s", name, e)
        self._instances.clear()
        self._factories.clear()
        self._singletons.clear()
