"""Event bus — the nervous system for multi-agent collaboration.

Agents publish events; other agents subscribe.  This decouples producers
from consumers and enables the blackboard architecture.
"""
from __future__ import annotations

import asyncio
import logging
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Awaitable

log = logging.getLogger(__name__)


class EventTypes:
    """Canonical event type strings."""
    TASK_CREATED = "task.created"
    TASK_STARTED = "task.started"
    TASK_COMPLETED = "task.completed"
    TASK_FAILED = "task.failed"
    TASK_CANCELLED = "task.cancelled"

    PLAN_CREATED = "plan.created"
    PLAN_REVISED = "plan.revised"
    STEP_STARTED = "step.started"
    STEP_COMPLETED = "step.completed"
    STEP_FAILED = "step.failed"

    TOOL_CALLED = "tool.called"
    TOOL_RESULT = "tool.result"

    MEMORY_ADDED = "memory.added"
    MEMORY_CONSOLIDATED = "memory.consolidated"

    SKILL_CREATED = "skill.created"
    SKILL_USED = "skill.used"
    SKILL_RETIRED = "skill.retired"
    SKILL_COMPOSED = "skill.composed"

    AGENT_MESSAGE = "agent.message"
    AGENT_HANDOFF = "agent.handoff"

    LEARNING_CYCLE = "learning.cycle"
    REFLECTION_DONE = "reflection.done"

    ERROR = "error"
    AUDIT = "audit"

    # ── v4 subsystem events ────────────────────────────────────────────
    CRITIQUE_COMPLETED = "critique.completed"
    CRITIQUE_BLOCKED = "critique.blocked"

    DEBATE_STARTED = "debate.started"
    DEBATE_TURN = "debate.turn"
    DEBATE_COMPLETED = "debate.completed"

    HYPOTHESIS_GENERATED = "hypothesis.generated"
    HYPOTHESIS_SUPPORTED = "hypothesis.supported"
    HYPOTHESIS_REFUTED = "hypothesis.refuted"

    EXPERIMENT_STARTED = "experiment.started"
    EXPERIMENT_COMPLETED = "experiment.completed"
    EXPERIMENT_LOOP_ITERATION = "experiment_loop.iteration"
    EXPERIMENT_LOOP_CONVERGED = "experiment_loop.converged"

    LESSON_LEARNED = "lesson.learned"

    SKILL_EVOLVED = "skill.evolved"
    SKILL_PROMOTED = "skill.promoted"

    SELF_IMPROVEMENT_PROPOSED = "self_improvement.proposed"
    SELF_IMPROVEMENT_VERIFIED = "self_improvement.verified"
    SELF_IMPROVEMENT_MERGED = "self_improvement.merged"
    SELF_IMPROVEMENT_REJECTED = "self_improvement.rejected"

    SIMULATION_STARTED = "simulation.started"
    SIMULATION_COMPLETED = "simulation.completed"

    STRATEGY_DECOMPOSED = "strategy.decomposed"

    PROMPT_ENGINEERED = "prompt.engineered"

    MEMORY_COMPRESSED = "memory.compressed"


@dataclass
class Event:
    """A single event on the bus."""
    type: str
    payload: dict[str, Any] = field(default_factory=dict)
    source: str | None = None
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


# Subscriber = async callable that takes an Event
Subscriber = Callable[[Event], Awaitable[None]]


class EventBus:
    """In-process async event bus with topic + wildcard subscriptions.

    subscribe/unsubscribe are synchronous because they perform simple
    list operations with no yield points — they are safe in the
    asyncio single-threaded model without explicit locking.

    publish() acquires ``self._lock`` to atomically snapshot the
    subscriber lists and append to history before dispatching events
    to subscribers.
    """

    def __init__(self) -> None:
        self._subscribers: dict[str, list[Subscriber]] = defaultdict(list)
        self._wildcard_subscribers: list[Subscriber] = []
        self._history: deque[Event] = deque(maxlen=1000)
        self._lock = asyncio.Lock()

    def subscribe(self, event_type: str, subscriber: Subscriber) -> None:
        """Subscribe to an event type.  Use '*' to subscribe to everything."""
        if event_type == "*":
            self._wildcard_subscribers.append(subscriber)
        else:
            self._subscribers[event_type].append(subscriber)

    def unsubscribe(self, event_type: str, subscriber: Subscriber) -> None:
        if event_type == "*":
            try:
                self._wildcard_subscribers.remove(subscriber)
            except ValueError:
                pass
        else:
            try:
                self._subscribers[event_type].remove(subscriber)
            except ValueError:
                pass

    async def publish(self, event: Event) -> None:
        """Publish an event to all matching subscribers (fire-and-forget).

        Subscribers are dispatched concurrently via ``asyncio.gather`` so
        a single slow subscriber doesn't block the publisher or other
        subscribers.  Exceptions in individual subscribers are caught and
        logged — they never propagate to the publisher.
        """
        # Acquire the lock to atomically snapshot subscribers and append
        # to history.  The actual subscriber dispatch happens *outside*
        # the lock so that concurrent publishes are not serialized.
        async with self._lock:
            self._history.append(event)
            subs = (
                list(self._subscribers.get(event.type, []))
                + list(self._wildcard_subscribers)
            )

        if not subs:
            return

        # Dispatch all subscribers concurrently.  Each subscriber's
        # exception is caught and logged individually so one bad
        # subscriber can't break the others or the publisher.
        async def _safe_call(sub: Subscriber, ev: Event) -> None:
            try:
                await sub(ev)
            except Exception as e:
                # Defensive name lookup — bound methods, lambdas, partials,
                # and callable objects don't all expose `__name__` directly.
                name = (
                    getattr(sub, "__name__", None)
                    or getattr(getattr(sub, "__func__", None), "__name__", None)
                    or getattr(getattr(sub, "__class__", None), "__name__", None)
                    or repr(sub)
                )
                log.warning("EventBus subscriber %s raised: %s", name, e)

        # gather with return_exceptions=True is belt-and-suspenders —
        # _safe_call already swallows.  But if a subscriber is a
        # non-async callable that raises synchronously, gather catches
        # it here too.
        await asyncio.gather(
            *(_safe_call(sub, event) for sub in subs),
            return_exceptions=True,
        )

    def history(self, event_type: str | None = None, limit: int = 100) -> list[Event]:
        """Return recent events, optionally filtered by type."""
        events = self._history if event_type is None else [
            e for e in self._history if e.type == event_type
        ]
        return list(events)[-limit:]

    def clear(self) -> None:
        self._history.clear()


class EventPublisher:
    """Mixin that gives a class access to an :class:`EventBus`.

    Subsystems that want to emit events without holding a direct
    reference to the bus can subclass this and call :meth:`_emit`.

    ``_event_bus`` is an **instance** variable, initialised to ``None``
    in ``__init__``.  The process-wide convenience classmethod
    :meth:`set_event_bus` sets a *class-level* default that all
    instances without an explicit instance value will inherit via
    normal Python attribute resolution.
    """

    _event_bus: EventBus | None = None  # class-level default, shared

    def __init__(self) -> None:
        # Explicitly set instance variable so each object owns its own
        # reference.  If the class-level default was set via
        # set_event_bus(), Python MRO falls through to it when the
        # instance attribute is None.
        self._event_bus: EventBus | None = None

    @classmethod
    def set_event_bus(cls, bus: EventBus | None) -> None:
        """Set the process-wide event bus used by all publishers.

        This sets a class-level default.  Individual instances can
        override it by assigning ``self._event_bus`` directly.
        """
        cls._event_bus = bus

    @property
    def event_bus(self) -> EventBus | None:
        # Instance attribute first; fall back to class-level default.
        if self._event_bus is not None:
            return self._event_bus
        # Check the class hierarchy for a class-level default.
        for klass in type(self).__mro__:
            if "_event_bus" in klass.__dict__ and klass.__dict__["_event_bus"] is not None:
                return klass.__dict__["_event_bus"]
        return None

    async def _emit(self, event_type: str, payload: dict | None = None, *, source: str | None = None) -> None:
        """Publish an event on the bus (fire-and-forget, never raises)."""
        bus = self.event_bus
        if bus is None:
            return
        try:
            await bus.publish(Event(
                type=event_type,
                payload=payload or {},
                source=source or self.__class__.__name__,
            ))
        except Exception as e:
            log.debug("EventBus publish failed (non-fatal): %s", e)