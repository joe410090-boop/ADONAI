"""Pydantic domain models — the typed data flowing between all subsystems.

All models use Pydantic v2 for validation + JSON serialization.
Enums are str-based for SQLite-friendly storage.
"""
from __future__ import annotations

import time
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _uid(prefix: str = "") -> str:
    return f"{prefix}{uuid.uuid4().hex[:16]}"


# ──────────────────────────────────────────────────────────────────────────────
# Task & Plan
# ──────────────────────────────────────────────────────────────────────────────

class TaskStatus(str, Enum):
    PENDING = "pending"
    PLANNING = "planning"
    RUNNING = "running"
    BLOCKED = "blocked"
    PAUSED = "paused"
    COMPLETED = "completed"
    PARTIAL = "partial"
    FAILED = "failed"
    CANCELLED = "cancelled"


class TaskPriority(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class TaskComplexity(str, Enum):
    """Estimated complexity — drives planning strategy."""
    TRIVIAL = "trivial"        # single LLM call
    SIMPLE = "simple"          # 1-3 tool calls
    MODERATE = "moderate"      # multi-step plan
    COMPLEX = "complex"        # multi-agent decomposition
    OPEN_ENDED = "open_ended"  # research/exploration


class Task(BaseModel):
    """A unit of work the agent must accomplish."""
    id: str = Field(default_factory=lambda: _uid("task_"))
    parent_id: str | None = None
    goal: str
    description: str | None = None
    context: dict[str, Any] = Field(default_factory=dict)
    priority: TaskPriority = TaskPriority.MEDIUM
    complexity: TaskComplexity = TaskComplexity.SIMPLE
    status: TaskStatus = TaskStatus.PENDING
    assigned_agent: str | None = None
    dependencies: list[str] = Field(default_factory=list)
    max_steps: int = 20
    max_duration_s: int = 300
    max_retries: int = 2
    retry_count: int = 0
    session_id: str | None = None
    created_at: datetime = Field(default_factory=_utc_now)
    started_at: datetime | None = None
    completed_at: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class VerificationType(str, Enum):
    """How to verify a plan step produced correct output (fable-mode principle).

    Each step must define a check that can *actually fail*.  "I reviewed it
    and it looks right" is NOT a check.  If a step genuinely has no failable
    check, use UNVERIFIED so the gap is visible downstream.
    """
    TEST_RUN = "test_run"             # Run an assertion/test; it must pass
    FILE_EXISTS = "file_exists"       # A file must exist at the expected path
    OUTPUT_CONTAINS = "output_contains"  # Output must contain expected keywords
    SOURCE_FETCHED = "source_fetched"  # A source was actually fetched and read
    EXIT_CODE = "exit_code"           # Process exited with code 0
    UNVERIFIED = "unverified"         # Explicitly marked: no failable check
    # Auto-resolved by VerificationGate when the planner returns a
    # verification_type the system doesn't recognize.
    LLM_CHECK = "llm_check"           # LLM asked to confirm output matches expected_outcome


class PlanStep(BaseModel):
    """One step in an executable plan."""
    id: str = Field(default_factory=lambda: _uid("step_"))
    description: str
    tool: str | None = None
    parameters: dict[str, Any] = Field(default_factory=dict)
    expected_outcome: str | None = None
    dependencies: list[str] = Field(default_factory=list)
    status: TaskStatus = TaskStatus.PENDING
    rationale: str | None = None
    risk_level: Literal["low", "medium", "high"] = "low"
    estimated_duration_s: float | None = None
    assigned_agent: str | None = None
    # ── Fable-mode: verification gate fields ─────────────────────────────
    verification_type: VerificationType = VerificationType.UNVERIFIED
    verification_detail: str | None = None
    # Set by the executor after running the gate.
    verification_passed: bool | None = None
    verification_message: str | None = None


class Plan(BaseModel):
    """A hierarchical, executable task graph."""
    id: str = Field(default_factory=lambda: _uid("plan_"))
    task_id: str
    goal: str
    steps: list[PlanStep] = Field(default_factory=list)
    strategy: str | None = None
    reasoning_trace: str | None = None
    alternative_branches: list[list[PlanStep]] = Field(default_factory=list)
    confidence: float = 0.5
    revised: int = 0
    created_at: datetime = Field(default_factory=_utc_now)
    metadata: dict[str, Any] = Field(default_factory=dict)
    """v4 — planner metadata (ToT score, candidate count, etc.)."""


class TaskResult(BaseModel):
    """Outcome of executing a task."""
    task_id: str
    status: TaskStatus
    output: Any = None
    error: str | None = None
    artifacts: list[str] = Field(default_factory=list)
    steps_executed: int = 0
    duration_s: float = 0.0
    confidence: float = 0.0
    lessons: list[str] = Field(default_factory=list)
    tool_calls: list[ToolCall] = Field(default_factory=list)  # resolved by model_rebuild() below
    timestamp: datetime = Field(default_factory=_utc_now)


# ──────────────────────────────────────────────────────────────────────────────
# Memory
# ──────────────────────────────────────────────────────────────────────────────

class MemoryType(str, Enum):
    WORKING = "working"
    EPISODIC = "episodic"
    SEMANTIC = "semantic"
    USER = "user"
    PROJECT = "project"
    PROCEDURAL = "procedural"


class Memory(BaseModel):
    """A single memory record."""
    id: str = Field(default_factory=lambda: _uid("mem_"))
    type: MemoryType
    content: str
    embedding: list[float] | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    importance: float = 0.5
    confidence: float = 1.0
    access_count: int = 0
    last_accessed: datetime | None = None
    created_at: datetime = Field(default_factory=_utc_now)
    expires_at: datetime | None = None
    tags: list[str] = Field(default_factory=list)
    source: str | None = None
    session_id: str | None = None


# ──────────────────────────────────────────────────────────────────────────────
# Tools
# ──────────────────────────────────────────────────────────────────────────────

class ToolCall(BaseModel):
    """A request to invoke a tool."""
    id: str = Field(default_factory=lambda: _uid("call_"))
    tool: str
    parameters: dict[str, Any] = Field(default_factory=dict)
    reasoning: str | None = None
    timestamp: datetime = Field(default_factory=_utc_now)


class ToolResult(BaseModel):
    """The result of a tool execution."""
    call_id: str
    tool: str
    success: bool
    output: Any = None
    error: str | None = None
    duration_s: float = 0.0
    metadata: dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime = Field(default_factory=_utc_now)


# Fix the forward-reference in TaskResult.
TaskResult.model_rebuild()


# ──────────────────────────────────────────────────────────────────────────────
# Skills
# ──────────────────────────────────────────────────────────────────────────────

class SkillCategory(str, Enum):
    CODING = "coding"
    RESEARCH = "research"
    WEB = "web"
    PROJECT_MANAGEMENT = "project_management"
    ANALYSIS = "analysis"
    WRITING = "writing"
    CUSTOM = "custom"


class Skill(BaseModel):
    """A reusable, versioned skill extracted from successful executions."""
    id: str = Field(default_factory=lambda: _uid("skill_"))
    name: str
    description: str
    category: SkillCategory = SkillCategory.CUSTOM
    version: str = "1.0.0"
    examples: list[str] = Field(default_factory=list)
    trigger_patterns: list[str] = Field(default_factory=list)
    procedure: list[PlanStep] = Field(default_factory=list)
    required_tools: list[str] = Field(default_factory=list)
    success_rate: float = 0.0
    usage_count: int = 0
    failure_count: int = 0
    last_used: datetime | None = None
    created_at: datetime = Field(default_factory=_utc_now)
    created_from: str | None = None  # source task_id
    author: str = "adonai"
    tags: list[str] = Field(default_factory=list)
    active: bool = True


class ComposedSkill(Skill):
    """A skill composed of two or more other skills.

    Composed skills chain the procedures of their constituent skills:
    when invoked, each constituent's procedure runs in order, with the
    output of one feeding as input to the next.

    Use cases:
      - "research + summarise" → composed skill that searches then
        condenses the results.
      - "analyse + visualise" → composed skill that runs data analysis
        then generates a chart.
      - "test + deploy" → composed skill that runs tests then deploys
        if they pass.
    """
    component_skill_ids: list[str] = Field(default_factory=list)
    composition_strategy: str = Field(
        default="sequential",
        description="sequential | parallel | conditional",
    )
    # For conditional composition: a Python expression evaluated against
    # the upstream output.  When True, the next component runs.
    condition: str | None = None


# ──────────────────────────────────────────────────────────────────────────────
# Multi-agent
# ──────────────────────────────────────────────────────────────────────────────

class AgentCapability(BaseModel):
    name: str
    description: str
    tools: list[str] = Field(default_factory=list)
    examples: list[str] = Field(default_factory=list)


class AgentMessage(BaseModel):
    """Inter-agent communication envelope."""
    id: str = Field(default_factory=lambda: _uid("msg_"))
    from_agent: str
    to_agent: str | None = None  # None = broadcast
    type: Literal["task", "result", "query", "info", "error", "handoff", "vote"]
    content: Any
    task_id: str | None = None
    confidence: float = 1.0
    timestamp: datetime = Field(default_factory=_utc_now)


# ──────────────────────────────────────────────────────────────────────────────
# Experience & Learning
# ──────────────────────────────────────────────────────────────────────────────

class Experience(BaseModel):
    """A recorded (plan, outcome, lesson) tuple for long-term learning."""
    id: str = Field(default_factory=lambda: _uid("exp_"))
    task_goal: str
    task_complexity: TaskComplexity = TaskComplexity.SIMPLE
    plan_id: str
    plan_snapshot: dict[str, Any]
    outcome: TaskStatus
    success: bool
    duration_s: float
    mistakes: list[str] = Field(default_factory=list)
    lessons: list[str] = Field(default_factory=list)
    tool_effectiveness: dict[str, float] = Field(default_factory=dict)
    skill_id: str | None = None
    agent_used: str | None = None
    created_at: datetime = Field(default_factory=_utc_now)


class Preference(BaseModel):
    """A learned user preference."""
    key: str
    value: Any
    confidence: float = 0.0
    observations: int = 0
    last_updated: datetime = Field(default_factory=_utc_now)
    evidence: list[str] = Field(default_factory=list)


# ──────────────────────────────────────────────────────────────────────────────
# Knowledge Graph
# ──────────────────────────────────────────────────────────────────────────────

class Entity(BaseModel):
    """A node in the knowledge graph."""
    id: str = Field(default_factory=lambda: _uid("ent_"))
    type: Literal[
        "concept", "project", "skill", "file", "goal", "event",
        "person", "tool", "agent", "fact",
    ]
    name: str
    description: str | None = None
    properties: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(default_factory=_utc_now)


class Relation(BaseModel):
    """An edge in the knowledge graph."""
    id: str = Field(default_factory=lambda: _uid("rel_"))
    source_id: str
    target_id: str
    type: Literal[
        "depends_on", "part_of", "created_by", "uses", "knows",
        "relates_to", "derived_from", "produced", "consumed",
        "is_a", "has_property", "measured_at",
    ]
    properties: dict[str, Any] = Field(default_factory=dict)
    weight: float = 1.0
    created_at: datetime = Field(default_factory=_utc_now)


class KnowledgeGraphSnapshot(BaseModel):
    """A queryable snapshot of the knowledge graph."""
    entities: list[Entity]
    relations: list[Relation]


# ──────────────────────────────────────────────────────────────────────────────
# Audit
# ──────────────────────────────────────────────────────────────────────────────

class AuditEntry(BaseModel):
    """Immutable audit log entry."""
    id: str = Field(default_factory=lambda: _uid("audit_"))
    timestamp: datetime = Field(default_factory=_utc_now)
    agent: str
    action: str
    target: str | None = None
    parameters: dict[str, Any] = Field(default_factory=dict)
    approved: bool = True
    outcome: Literal["success", "failure", "blocked", "pending"] = "pending"
    risk_level: Literal["low", "medium", "high"] = "low"
    session_id: str | None = None
    duration_s: float | None = None


# ──────────────────────────────────────────────────────────────────────────────
# v4 — Research-grade extensions
# ──────────────────────────────────────────────────────────────────────────────

# ── Upgrade 1: Critic Agent ──────────────────────────────────────────────────


class CritiqueReport(BaseModel):
    """Output of the dedicated Critic Agent (Upgrade 1).

    The Critic runs *between* the Executor and the Verifier in the new
    pipeline: ``Planner → Executor → Critic → Verifier``.  Its job is to
    challenge assumptions, surface weaknesses, propose alternative plans,
    detect hallucinations, evaluate efficiency, and flag premature
    conclusions.
    """
    id: str = Field(default_factory=lambda: _uid("crit_"))
    task_id: str
    target_kind: Literal["plan", "step", "result", "hypothesis", "experiment"] = "result"
    target_ref: str | None = None
    confidence: float = 0.5
    """Critic's confidence in the target's correctness (0..1)."""
    weaknesses: list[str] = Field(default_factory=list)
    """Concrete weaknesses identified in the target."""
    alternatives: list[str] = Field(default_factory=list)
    """Alternative approaches the planner/executor could have taken."""
    hallucination_flags: list[str] = Field(default_factory=list)
    """Specific claims that appear fabricated or unsupported by evidence."""
    efficiency_notes: list[str] = Field(default_factory=list)
    """Observations about wasted steps, redundant calls, slow paths."""
    premature_conclusion: bool = False
    """True if the Critic thinks the agent concluded too early."""
    risk_score: float = 0.5
    """Aggregate risk of executing on the target (0=safe, 1=dangerous)."""
    recommendation: Literal["accept", "revise", "reject", "escalate"] = "accept"
    """What the Critic recommends the pipeline do next."""
    rationale: str | None = None
    created_at: datetime = Field(default_factory=_utc_now)
    metadata: dict[str, Any] = Field(default_factory=dict)


# ── Upgrade 4: Reflection Engine ─────────────────────────────────────────────


class Lesson(BaseModel):
    """A learned lesson stored by the Reflection Engine (Upgrade 4).

    Schema matches the user's required JSON shape:
    ``{"lesson", "confidence", "applicable_domains"}`` plus optional
    provenance fields for auditability.
    """
    id: str = Field(default_factory=lambda: _uid("lesson_"))
    lesson: str
    confidence: float = 0.5
    applicable_domains: list[str] = Field(default_factory=list)
    source_task_id: str | None = None
    source_session_id: str | None = None
    evidence: list[str] = Field(default_factory=list)
    """Concrete observations that support the lesson."""
    counter_evidence: list[str] = Field(default_factory=list)
    """Observations that contradict the lesson (keeps us honest)."""
    times_reinforced: int = 0
    times_contradicted: int = 0
    created_at: datetime = Field(default_factory=_utc_now)
    last_reinforced_at: datetime | None = None
    tags: list[str] = Field(default_factory=list)


# ── Upgrade 7 & 8: Hypothesis + Experiment Loop ──────────────────────────────


class HypothesisStatus(str, Enum):
    PROPOSED = "proposed"
    DESIGNING = "designing"
    TESTING = "testing"
    ANALYZING = "analyzing"
    SUPPORTED = "supported"
    REFUTED = "refuted"
    INCONCLUSIVE = "inconclusive"
    RETIRED = "retired"


class Hypothesis(BaseModel):
    """A falsifiable scientific hypothesis (Upgrade 7).

    Pipeline: ``Observation → Hypothesis → Experiment Design → Execution
    → Verification``.
    """
    id: str = Field(default_factory=lambda: _uid("hyp_"))
    statement: str
    """The hypothesis in plain language — must be falsifiable."""
    confidence: float = 0.3
    prior: float = 0.5
    """Prior probability before any experiment."""
    posterior: float | None = None
    """Posterior probability after experiments."""
    supporting_evidence: list[str] = Field(default_factory=list)
    """Evidence IDs or free-text observations that support the hypothesis."""
    contradicting_evidence: list[str] = Field(default_factory=list)
    predictions: list[str] = Field(default_factory=list)
    """What the hypothesis predicts we will observe."""
    falsification_criteria: str | None = None
    """Concrete observation that would refute the hypothesis."""
    experiment_ids: list[str] = Field(default_factory=list)
    status: HypothesisStatus = HypothesisStatus.PROPOSED
    domain: str | None = None
    parent_hypothesis_id: str | None = None
    """For hypothesis refinement trees."""
    created_at: datetime = Field(default_factory=_utc_now)
    updated_at: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ExperimentStatus(str, Enum):
    DESIGNED = "designed"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    ABORTED = "aborted"


class Experiment(BaseModel):
    """A single experiment designed to test a hypothesis (Upgrade 8)."""
    id: str = Field(default_factory=lambda: _uid("exp_"))
    hypothesis_id: str
    name: str
    description: str
    design: dict[str, Any] = Field(default_factory=dict)
    """Free-form design spec (parameters, conditions, simulator, etc.)."""
    simulator: str | None = None
    """Name of the simulator to use (e.g. ``openfoam``, ``pybullet``)."""
    status: ExperimentStatus = ExperimentStatus.DESIGNED
    started_at: datetime | None = None
    completed_at: datetime | None = None
    duration_s: float | None = None
    result: dict[str, Any] | None = None
    """Raw simulator output / metric dict."""
    metrics: dict[str, float] = Field(default_factory=dict)
    """Extracted scalar metrics (e.g. ``{"efficiency": 0.42}``)."""
    supports_hypothesis: bool | None = None
    """Set by the analyser after the experiment completes."""
    confidence_delta: float = 0.0
    """How much this experiment moved the hypothesis confidence."""
    error: str | None = None
    artifacts: list[str] = Field(default_factory=list)
    created_at: datetime = Field(default_factory=_utc_now)
    metadata: dict[str, Any] = Field(default_factory=dict)


# ── Upgrade 6: Multi-Agent Debate ────────────────────────────────────────────


class DebateStance(str, Enum):
    PROPONENT = "proponent"
    SKEPTIC = "skeptic"
    ENGINEER = "engineer"
    RESEARCHER = "researcher"
    JUDGE = "judge"


class DebateTurn(BaseModel):
    """One utterance in a multi-agent debate."""
    id: str = Field(default_factory=lambda: _uid("turn_"))
    agent: str
    stance: DebateStance
    content: str
    evidence: list[str] = Field(default_factory=list)
    citations: list[str] = Field(default_factory=list)
    confidence: float = 0.5
    timestamp: datetime = Field(default_factory=_utc_now)


class Debate(BaseModel):
    """A full multi-agent debate session (Upgrade 6)."""
    id: str = Field(default_factory=lambda: _uid("debate_"))
    question: str
    turns: list[DebateTurn] = Field(default_factory=list)
    rounds: int = 2
    participants: list[DebateStance] = Field(default_factory=list)
    winner: DebateStance | None = None
    winning_argument: str | None = None
    verdict: str | None = None
    """Judge's free-text verdict."""
    confidence: float = 0.5
    created_at: datetime = Field(default_factory=_utc_now)
    completed_at: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


# ── Upgrade 9: Model Router ──────────────────────────────────────────────────


class ModelTier(str, Enum):
    SMALL = "small"
    """Fast, cheap, low-capability (e.g. 1-3B params)."""
    MEDIUM = "medium"
    """Balanced (e.g. 7-13B params)."""
    LARGE = "large"
    """Slow, expensive, high-capability (e.g. 70B+, frontier)."""
    VISION = "vision"
    """Multimodal vision-capable."""
    EMBEDDING = "embedding"
    """Embedding-only."""


class ModelRoute(BaseModel):
    """A routing decision made by the ModelRouter (Upgrade 9)."""
    model_tier: ModelTier
    model_name: str
    backend: str
    rationale: str | None = None
    estimated_latency_s: float | None = None
    estimated_cost_tokens: int | None = None
    confidence: float = 0.5


# ── Upgrade 10: Self-Improvement Framework ───────────────────────────────────


class PatchStatus(str, Enum):
    PROPOSED = "proposed"
    SANDBOX_TESTING = "sandbox_testing"
    REGRESSION_TESTING = "regression_testing"
    VERIFIED = "verified"
    MERGED = "merged"
    REJECTED = "rejected"
    ROLLED_BACK = "rolled_back"


class SelfImprovementPatch(BaseModel):
    """A proposed code change generated by the self-improvement pipeline.

    Pipeline: ``Observe bottleneck → Propose patch → Sandbox testing →
    Regression testing → Verification → Optional merge``.  The pipeline
    NEVER modifies core runtime files directly; patches are merged only
    after passing all gates.
    """
    id: str = Field(default_factory=lambda: _uid("patch_"))
    bottleneck: str
    """What problem the patch addresses."""
    target_file: str
    """File the patch modifies (must NOT be in the protected core list)."""
    diff: str
    """Unified diff or full replacement content."""
    rationale: str
    proposed_by: str = "self_improvement_engine"
    status: PatchStatus = PatchStatus.PROPOSED
    sandbox_result: dict[str, Any] | None = None
    regression_result: dict[str, Any] | None = None
    verification_result: dict[str, Any] | None = None
    merged_at: datetime | None = None
    rolled_back_at: datetime | None = None
    rollback_reason: str | None = None
    safety_checks: list[str] = Field(default_factory=list)
    risk_score: float = 0.5
    created_at: datetime = Field(default_factory=_utc_now)
    metadata: dict[str, Any] = Field(default_factory=dict)


# ── Upgrade 11: Simulation Abstraction Layer ─────────────────────────────────


class SimulationStatus(str, Enum):
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    ABORTED = "aborted"


class SimulationSpec(BaseModel):
    """Input spec for any simulator (Upgrade 11)."""
    simulator: str
    """Name of the simulator backend (e.g. ``openfoam``, ``pybullet``)."""
    config: dict[str, Any] = Field(default_factory=dict)
    """Simulator-specific configuration dict."""
    parameters: dict[str, Any] = Field(default_factory=dict)
    """User-tunable parameters (geometry, initial conditions, etc.)."""
    metrics: list[str] = Field(default_factory=list)
    """Metrics to collect (e.g. ``["lift_coefficient", "drag_coefficient"]``)."""
    max_duration_s: float = 3600.0
    timeout_s: float = 600.0
    working_dir: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class SimulationResult(BaseModel):
    """Output of any simulator (Upgrade 11)."""
    id: str = Field(default_factory=lambda: _uid("sim_"))
    spec: SimulationSpec
    status: SimulationStatus = SimulationStatus.PENDING
    metrics: dict[str, float] = Field(default_factory=dict)
    """Scalar metrics requested in ``spec.metrics``."""
    artifacts: list[str] = Field(default_factory=list)
    """Files produced by the simulation (logs, meshes, trajectories…)."""
    log: str | None = None
    error: str | None = None
    started_at: datetime | None = None
    completed_at: datetime | None = None
    duration_s: float | None = None
    raw: dict[str, Any] | None = None
    """Backend-specific raw output, for advanced consumers."""


# ── Upgrade 12: Long-Term Strategic Reasoning ────────────────────────────────


class GoalLevel(str, Enum):
    MISSION = "mission"
    """Top-level, never changes (e.g. "Build a research platform")."""
    STRATEGIC = "strategic"
    """Quarterly / monthly objectives."""
    TACTICAL = "tactical"
    """Weekly / daily objectives."""
    TASK = "task"
    """Concrete actionable task (maps to a :class:`Task`)."""


class StrategicGoal(BaseModel):
    """A node in the goals hierarchy (Upgrade 12).

    Hierarchy: ``Mission → Strategic Goals → Tactical Goals → Tasks``.
    Each goal tracks priority, dependencies, progress, and success
    probability so the agent can reason about long-horizon plans.
    """
    id: str = Field(default_factory=lambda: _uid("goal_"))
    level: GoalLevel
    title: str
    description: str | None = None
    parent_goal_id: str | None = None
    """Parent goal in the hierarchy."""
    child_goal_ids: list[str] = Field(default_factory=list)
    task_ids: list[str] = Field(default_factory=list)
    """Tasks directly attached to this goal."""
    priority: TaskPriority = TaskPriority.MEDIUM
    dependencies: list[str] = Field(default_factory=list)
    """IDs of other goals this one depends on."""
    progress: float = 0.0
    """0..1 completion fraction."""
    success_probability: float = 0.5
    """Estimated probability this goal will be achieved (0..1)."""
    status: Literal[
        "proposed", "active", "blocked", "completed", "abandoned"
    ] = "proposed"
    target_completion_at: datetime | None = None
    created_at: datetime = Field(default_factory=_utc_now)
    updated_at: datetime | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


# ── Upgrade 2: Knowledge Graph extensions ────────────────────────────────────


class Evidence(BaseModel):
    """Evidence record attached to a KG fact (Upgrade 2)."""
    id: str = Field(default_factory=lambda: _uid("ev_"))
    source: str
    """Where the evidence came from (URL, file, agent name, observation)."""
    source_kind: Literal[
        "web", "file", "agent", "observation", "experiment",
        "user", "inference", "external",
    ] = "inference"
    snippet: str | None = None
    """Quoted snippet or summary from the source."""
    confidence: float = 0.5
    """How reliable this evidence is (0..1)."""
    observed_at: datetime = Field(default_factory=_utc_now)
    metadata: dict[str, Any] = Field(default_factory=dict)
