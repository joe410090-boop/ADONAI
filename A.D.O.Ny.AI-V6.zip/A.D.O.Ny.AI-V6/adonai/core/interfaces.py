"""Abstract interfaces — the contracts between all subsystems.

Concrete implementations live in sibling packages (memory/, agents/, tools/,
etc.).  Every interface is async to support long-running, concurrent ops.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, AsyncIterator, Literal, Protocol

from adonai.core.models import (
    AgentMessage, CritiqueReport, Debate, Experiment, Experience,
    Hypothesis, Lesson, Memory, MemoryType, ModelRoute, Plan, PlanStep,
    SelfImprovementPatch, SimulationResult, SimulationSpec, Skill,
    StrategicGoal, Task, TaskResult, ToolCall, ToolResult,
)


# ──────────────────────────────────────────────────────────────────────────────
# LLM Client
# ──────────────────────────────────────────────────────────────────────────────

@dataclass
class LLMResponse:
    text: str
    tool_calls: list[ToolCall] | None = None
    raw: Any = None
    finish_reason: str = "stop"
    tokens_in: int = 0
    tokens_out: int = 0
    model: str = ""
    duration_s: float = 0.0
    # The raw assistant message dict, in the backend's native format.
    # Used by the ToolCallingAgent to feed the assistant turn (with
    # tool_calls) back into the next request without re-serializing
    # — this avoids format mismatches between OpenAI (stringified
    # arguments) and Ollama (object arguments).
    message: dict[str, Any] | None = None


class LLMClient(ABC):
    """Abstraction over local Qwen / Llama / Mistral backends."""

    @abstractmethod
    async def complete(
        self,
        messages: list[dict[str, str]],
        tools: list[dict] | None = None,
        temperature: float = 0.7,
        max_tokens: int = 2048,
        stop: list[str] | None = None,
        **kwargs: Any,
    ) -> LLMResponse:
        """Single-shot completion."""

    @abstractmethod
    async def stream(
        self,
        messages: list[dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 2048,
    ) -> AsyncIterator[str]:
        """Streaming completion."""

    @abstractmethod
    async def embed(self, text: str | list[str]) -> list[list[float]]:
        """Generate embeddings."""

    async def close(self) -> None:
        """Release resources."""


# ──────────────────────────────────────────────────────────────────────────────
# Tool
# ──────────────────────────────────────────────────────────────────────────────

class Tool(ABC):
    """Base class for all native & MCP tools."""

    name: str = ""
    description: str = ""
    parameters: dict = {}     # JSON schema — subclasses should set their own
    risk_level: str = "low"
    requires_approval: bool = False
    tags: list[str] = []
    category: str = "general"
    # v9 fix: opt-out flag for the LLM response cache. Side-effecting
    # tools (web_search, http_fetch, terminal, file_write) should set
    # ``cacheable = False`` so the CachedLLMClient doesn't serve a
    # stale tool-call response from the cache. Tools that are pure
    # functions of their arguments (calculator, json_extract) can leave
    # this True so identical tool-call prompts hit cache. Default True
    # preserves backward compatibility for existing pure tools.
    cacheable: bool = True

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        # Materialize per-subclass copies of mutable class defaults so a
        # subclass that mutates self.parameters["x"]=... cannot corrupt the
        # shared parent-level dict (classic Python mutable-default footgun).
        if "parameters" in cls.__dict__ and isinstance(cls.parameters, dict):
            cls.parameters = dict(cls.parameters)
        if "tags" in cls.__dict__ and isinstance(cls.tags, list):
            cls.tags = list(cls.tags)

    @abstractmethod
    async def execute(self, **params: Any) -> ToolResult:
        """Run the tool with the given parameters."""

    def schema(self) -> dict:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


# ──────────────────────────────────────────────────────────────────────────────
# Agent
# ──────────────────────────────────────────────────────────────────────────────

class Agent(ABC):
    """Base class for all agents (executive + sub-agents)."""

    name: str = "base_agent"
    role: str = "generic"
    capabilities: list[str] = []
    preferred_tools: list[str] = []
    system_prompt: str = ""

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        if "capabilities" in cls.__dict__ and isinstance(cls.capabilities, list):
            cls.capabilities = list(cls.capabilities)
        if "preferred_tools" in cls.__dict__ and isinstance(cls.preferred_tools, list):
            cls.preferred_tools = list(cls.preferred_tools)

    @abstractmethod
    async def run(self, task: Task) -> TaskResult:
        """Execute a task and return its result."""

    def can_handle(self, goal: str) -> float:
        """Return 0..1 confidence this agent can handle *goal*."""
        return 0.0

    async def observe(self) -> dict[str, Any]:
        return {}

    async def communicate(self, message: AgentMessage) -> None:
        return None


# ──────────────────────────────────────────────────────────────────────────────
# Memory Store
# ──────────────────────────────────────────────────────────────────────────────

class MemoryStore(ABC):
    """Persistence backend for a single memory type."""

    @abstractmethod
    async def add(self, memory: Memory) -> str: ...

    @abstractmethod
    async def get(self, memory_id: str) -> Memory | None: ...

    @abstractmethod
    async def search(
        self,
        query: str | list[float],
        top_k: int = 5,
        filters: dict[str, Any] | None = None,
    ) -> list[Memory]: ...

    @abstractmethod
    async def update(self, memory_id: str, updates: dict[str, Any]) -> bool: ...

    @abstractmethod
    async def delete(self, memory_id: str) -> bool: ...

    @abstractmethod
    async def count(self, filters: dict[str, Any] | None = None) -> int: ...


# ──────────────────────────────────────────────────────────────────────────────
# Skill Store
# ──────────────────────────────────────────────────────────────────────────────

class SkillStore(ABC):
    @abstractmethod
    async def save(self, skill: Skill) -> str: ...
    @abstractmethod
    async def load(self, skill_id: str) -> Skill | None: ...
    @abstractmethod
    async def find_by_trigger(self, query: str) -> list[Skill]: ...
    @abstractmethod
    async def list_all(self, category: str | None = None) -> list[Skill]: ...
    @abstractmethod
    async def delete(self, skill_id: str) -> bool: ...
    @abstractmethod
    async def update_stats(self, skill_id: str, success: bool) -> None: ...


# ──────────────────────────────────────────────────────────────────────────────
# Reasoner
# ──────────────────────────────────────────────────────────────────────────────

class Reasoner(ABC):
    """A reasoning strategy (CoT, ToT, self-consistency, debate, etc.)."""

    name: str = "base_reasoner"

    @abstractmethod
    async def reason(
        self,
        task: Task,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Return {conclusion, confidence, trace, alternatives}."""


# ──────────────────────────────────────────────────────────────────────────────
# Planner
# ──────────────────────────────────────────────────────────────────────────────

class Planner(ABC):
    @abstractmethod
    async def plan(self, task: Task, context: dict[str, Any] | None = None) -> Plan: ...

    @abstractmethod
    async def replan(
        self, task: Task, previous_plan: Plan, failed_step: PlanStep, reason: str,
    ) -> Plan: ...


# ──────────────────────────────────────────────────────────────────────────────
# Executor
# ──────────────────────────────────────────────────────────────────────────────

class Executor(ABC):
    @abstractmethod
    async def execute(self, task: Task, plan: Plan) -> TaskResult: ...


# ──────────────────────────────────────────────────────────────────────────────
# Browser Driver
# ──────────────────────────────────────────────────────────────────────────────

class BrowserDriver(ABC):
    @abstractmethod
    async def open(self, url: str) -> dict: ...
    @abstractmethod
    async def click(self, selector: str) -> dict: ...
    @abstractmethod
    async def type_text(self, selector: str, text: str) -> dict: ...
    @abstractmethod
    async def extract(self, selector: str | None = None) -> str: ...
    @abstractmethod
    async def scroll(self, direction: str = "down", amount: int = 500) -> dict: ...
    @abstractmethod
    async def screenshot(self, path: str | None = None) -> str: ...
    @abstractmethod
    async def close(self) -> None: ...


# ──────────────────────────────────────────────────────────────────────────────
# MCP Client
# ──────────────────────────────────────────────────────────────────────────────

class MCPClient(ABC):
    @abstractmethod
    async def connect(self, server_name: str, config: dict) -> bool: ...
    @abstractmethod
    async def discover_tools(self, server_name: str) -> list[dict]: ...
    @abstractmethod
    async def call_tool(self, server_name: str, tool_name: str, params: dict) -> Any: ...
    @abstractmethod
    async def list_servers(self) -> list[str]: ...
    @abstractmethod
    async def disconnect(self, server_name: str) -> bool: ...
    @abstractmethod
    async def close(self) -> None: ...


# ──────────────────────────────────────────────────────────────────────────────
# v4 — Research-grade extensions
# ──────────────────────────────────────────────────────────────────────────────


# ── Upgrade 1: Critic Agent ──────────────────────────────────────────────────


class Critic(ABC):
    """Challenges assumptions, surfaces weaknesses, evaluates risk.

    Runs in the pipeline between the Executor and the Verifier:
    ``Planner → Executor → Critic → Verifier``.
    """

    name: str = "base_critic"

    @abstractmethod
    async def critique(
        self,
        task: Task,
        target: Any,
        *,
        target_kind: str = "result",
        context: dict[str, Any] | None = None,
    ) -> CritiqueReport:
        """Critique a plan / step / result / hypothesis / experiment."""


# ── Upgrade 9: Model Router ──────────────────────────────────────────────────


class ModelRouter(ABC):
    """Picks the best LLM for a task based on complexity / cost / latency."""

    @abstractmethod
    async def route(
        self,
        *,
        task: Task | None = None,
        prompt: str | None = None,
        complexity: str | None = None,
        capability: str | None = None,
    ) -> ModelRoute:
        """Return the best :class:`ModelRoute` for the request."""

    @abstractmethod
    def get_client(self, route: ModelRoute) -> LLMClient:
        """Resolve a :class:`ModelRoute` to a concrete :class:`LLMClient`."""

    @abstractmethod
    async def record_latency(
        self, route: ModelRoute, latency_s: float, success: bool,
    ) -> None:
        """Feed observed latency back into routing decisions."""


# ── Upgrade 11: Simulator ────────────────────────────────────────────────────


class Simulator(ABC):
    """Universal simulation interface (Upgrade 11).

    Concrete adapters: OpenFOAM, PyBullet, CARLA, Isaac Sim, custom.
    """

    name: str = "base_simulator"

    @abstractmethod
    async def run_simulation(self, spec: SimulationSpec) -> SimulationResult:
        """Run a simulation; block until completion or timeout."""

    @abstractmethod
    async def collect_metrics(
        self, result: SimulationResult, metric_names: list[str],
    ) -> dict[str, float]:
        """Extract named scalar metrics from a completed simulation."""

    @abstractmethod
    async def evaluate_results(
        self, result: SimulationResult, criteria: dict[str, Any],
    ) -> dict[str, Any]:
        """Apply evaluation criteria (thresholds, targets) to a result."""

    @abstractmethod
    async def health_check(self) -> bool:
        """Return True if the simulator backend is reachable."""


# ── Upgrade 10: Safety Guard ─────────────────────────────────────────────────


class SafetyGuard(ABC):
    """Plan / patch / experiment safety gate.

    Approves, blocks, or escalates a proposed action *before* it runs.
    Implementations may consult the audit log, the permission policy,
    or external validators.
    """

    name: str = "base_safety_guard"

    @abstractmethod
    async def review_plan(self, plan: Plan) -> CritiqueReport:
        """Review a plan before execution."""

    @abstractmethod
    async def review_patch(
        self, patch: SelfImprovementPatch,
    ) -> Literal["approve", "block", "escalate"]:
        """Review a self-improvement patch before sandboxing."""

    @abstractmethod
    async def review_experiment(
        self, experiment: Experiment,
    ) -> Literal["approve", "block", "escalate"]:
        """Review an experiment design before running it."""


# ── Upgrade 6: Debate Framework ──────────────────────────────────────────────


class DebateFramework(ABC):
    """Multi-agent debate orchestration (Upgrade 6).

    Runs N agents (research / skeptic / engineer …) over M rounds, then
    a Judge agent picks the strongest argument and returns a verdict.
    """

    @abstractmethod
    async def debate(
        self,
        question: str,
        *,
        rounds: int = 2,
        participants: list[str] | None = None,
        context: dict[str, Any] | None = None,
    ) -> Debate:
        """Run a debate and return the full transcript + verdict."""


# ── Upgrade 7: Hypothesis Generator ──────────────────────────────────────────


class HypothesisGenerator(ABC):
    """Generates falsifiable hypotheses from observations (Upgrade 7)."""

    @abstractmethod
    async def generate(
        self,
        observation: str,
        *,
        domain: str | None = None,
        max_hypotheses: int = 3,
        context: dict[str, Any] | None = None,
    ) -> list[Hypothesis]:
        """Produce candidate hypotheses from an observation."""

    @abstractmethod
    async def design_experiment(
        self, hypothesis: Hypothesis,
    ) -> Experiment:
        """Design an experiment that tests *hypothesis*."""

    @abstractmethod
    async def verify(
        self, hypothesis: Hypothesis, experiment: Experiment,
    ) -> Hypothesis:
        """Update the hypothesis confidence based on experiment results."""


# ── Upgrade 8: Experiment Loop ───────────────────────────────────────────────


class ExperimentLoop(ABC):
    """Iterative research loop: observe → hypothesize → test → learn."""

    @abstractmethod
    async def run(
        self,
        goal: str,
        *,
        max_iterations: int = 10,
        confidence_threshold: float = 0.85,
        resource_budget_s: float | None = None,
        context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Run the loop until convergence, resource limit, or interruption."""

    @abstractmethod
    async def step(self, state: dict[str, Any]) -> dict[str, Any]:
        """Execute one iteration of the loop (observe→hypothesize→…)."""

    @abstractmethod
    async def stop(self) -> None:
        """Gracefully stop a running loop."""


# ── Upgrade 12: Strategic Reasoner ───────────────────────────────────────────


class StrategicReasoner(ABC):
    """Long-horizon goal hierarchy: Mission → Strategic → Tactical → Task."""

    @abstractmethod
    async def decompose(
        self, mission: str, *, depth: int = 3,
    ) -> list[StrategicGoal]:
        """Decompose a mission into a goal hierarchy."""

    @abstractmethod
    async def prioritize(
        self, goals: list[StrategicGoal],
    ) -> list[StrategicGoal]:
        """Re-order goals by priority + success probability + dependencies."""

    @abstractmethod
    async def update_progress(
        self, goal_id: str, progress_delta: float,
    ) -> StrategicGoal:
        """Update a goal's progress and propagate to ancestors."""

    @abstractmethod
    async def replan_strategy(
        self, blocked_goal: StrategicGoal,
    ) -> list[StrategicGoal]:
        """Re-decompose a blocked goal into alternative sub-goals."""


# ── Upgrade 4: Reflection Engine ─────────────────────────────────────────────


class ReflectionEngine(ABC):
    """Structured post-task reflection (Upgrade 4).

    Runs after every task execution and produces a list of :class:`Lesson`
    objects that the planner, critic, and skill-evolver can consult.
    """

    @abstractmethod
    async def reflect(
        self,
        task: Task,
        plan: Plan | None,
        result: TaskResult,
        *,
        context: dict[str, Any] | None = None,
    ) -> list[Lesson]:
        """Return lessons learned from this task execution."""

    @abstractmethod
    async def recall_lessons(
        self,
        *,
        domain: str | None = None,
        top_k: int = 10,
    ) -> list[Lesson]:
        """Recall past lessons relevant to a domain."""

    @abstractmethod
    async def reinforce(
        self, lesson_id: str, supports: bool,
    ) -> Lesson:
        """Reinforce or contradict an existing lesson."""


# ── Upgrade 5: Skill Evolver ─────────────────────────────────────────────────


class SkillEvolver(ABC):
    """Promotes repeated successful behavior into callable skills.

    Pipeline: ``Experience → Pattern Analysis → Skill Extraction →
    Skill Registry → callable Tool``.
    """

    @abstractmethod
    async def mine_patterns(self) -> list[dict[str, Any]]:
        """Mine the experience store for repeated successful patterns."""

    @abstractmethod
    async def extract_skill(
        self, pattern: dict[str, Any],
    ) -> Skill | None:
        """Convert a repeated pattern into a :class:`Skill`."""

    @abstractmethod
    async def promote_to_tool(self, skill: Skill) -> str:
        """Register a skill as a callable tool; returns the tool name."""

    @abstractmethod
    async def verify_skill(
        self, skill: Skill, held_out_examples: list[Task],
    ) -> dict[str, Any]:
        """Behaviorally verify a skill against held-out examples."""
