"""Dependency graph — models step dependencies + topological ordering.

v4 hardening:
  * has_cycle() detects dependency cycles via DFS (Tarjan-style). Cycles
    would otherwise deadlock the executor (ready_steps() returns [] forever).
  * topological_order() returns a valid execution order or raises if cyclic.
  * next_step() now prefers low-risk steps first (sorts by risk_level) so
    the agent fails fast on risky operations before committing to them.
"""
from __future__ import annotations

from collections import defaultdict, deque
from typing import Any

from adonai.core.models import Plan, PlanStep, TaskStatus


class DependencyGraph:
    """Models step dependencies within a plan."""

    def __init__(self, plan: Plan) -> None:
        self.plan = plan
        self._by_id: dict[str, PlanStep] = {s.id: s for s in plan.steps}
        self._edges: dict[str, list[str]] = defaultdict(list)
        for step in plan.steps:
            for dep in step.dependencies:
                if dep in self._by_id:
                    self._edges[dep].append(step.id)

    def ready_steps(self) -> list[PlanStep]:
        """Return PENDING steps whose deps are all COMPLETED.

        Sorted by risk_level (low first) so the agent fails fast on risky
        operations before committing resources to them.
        """
        out = []
        for step in self.plan.steps:
            if step.status != TaskStatus.PENDING:
                continue
            if all(self._by_id[d].status == TaskStatus.COMPLETED
                   for d in step.dependencies if d in self._by_id):
                out.append(step)
        # Sort by risk_level (low < medium < high < critical) then by id for stability.
        _risk_order = {"low": 0, "medium": 1, "high": 2, "critical": 3}
        out.sort(key=lambda s: (_risk_order.get(getattr(s, "risk_level", "low"), 0), s.id))
        return out

    def next_step(self) -> PlanStep | None:
        """Pick the next step to execute (lowest-risk ready step)."""
        ready = self.ready_steps()
        return ready[0] if ready else None

    def is_complete(self) -> bool:
        """True if all steps are in a terminal state (COMPLETED or FAILED)."""
        return all(s.status in (TaskStatus.COMPLETED, TaskStatus.FAILED)
                   for s in self.plan.steps)

    def is_succeeded(self) -> bool:
        """True only if ALL steps COMPLETED (no failures)."""
        return bool(self.plan.steps) and all(
            s.status == TaskStatus.COMPLETED for s in self.plan.steps
        )

    def blocked_steps(self) -> list[PlanStep]:
        """PENDING steps with at least one FAILED dependency."""
        out = []
        for step in self.plan.steps:
            if step.status != TaskStatus.PENDING:
                continue
            if any(self._by_id[d].status == TaskStatus.FAILED
                   for d in step.dependencies if d in self._by_id):
                out.append(step)
        return out

    def progress(self) -> dict[str, int]:
        """Return status counts."""
        counts: dict[str, int] = defaultdict(int)
        for s in self.plan.steps:
            counts[s.status.value] += 1
        return dict(counts)

    # ──────────────────────────────────────────────────────────────────────
    # Cycle detection (v4)
    # ──────────────────────────────────────────────────────────────────────

    def has_cycle(self) -> bool:
        """Detect whether the dependency graph contains a cycle.

        Uses iterative DFS with 3-color marking (white/gray/black).
        A cycle exists iff we encounter a gray node during traversal.
        """
        WHITE, GRAY, BLACK = 0, 1, 2
        color: dict[str, int] = {sid: WHITE for sid in self._by_id}

        def dfs(start: str) -> bool:
            # Iterative DFS to avoid recursion-limit issues on large plans.
            stack: list[tuple[str, int]] = [(start, 0)]
            color[start] = GRAY
            while stack:
                node, child_idx = stack[-1]
                children = self._edges.get(node, [])
                if child_idx >= len(children):
                    color[node] = BLACK
                    stack.pop()
                    continue
                child = children[child_idx]
                stack[-1] = (node, child_idx + 1)
                if color[child] == GRAY:
                    return True  # back-edge → cycle
                if color[child] == WHITE:
                    color[child] = GRAY
                    stack.append((child, 0))
            return False

        for sid in self._by_id:
            if color[sid] == WHITE:
                if dfs(sid):
                    return True
        return False

    def find_cycle(self) -> list[str] | None:
        """Return one cycle as a list of step IDs, or None if acyclic."""
        WHITE, GRAY, BLACK = 0, 1, 2
        color: dict[str, int] = {sid: WHITE for sid in self._by_id}
        parent: dict[str, str | None] = {sid: None for sid in self._by_id}

        def dfs(start: str) -> list[str] | None:
            stack: list[tuple[str, int]] = [(start, 0)]
            color[start] = GRAY
            while stack:
                node, child_idx = stack[-1]
                children = self._edges.get(node, [])
                if child_idx >= len(children):
                    color[node] = BLACK
                    stack.pop()
                    continue
                child = children[child_idx]
                stack[-1] = (node, child_idx + 1)
                if color[child] == GRAY:
                    # Reconstruct cycle: walk parents from `node` back to `child`.
                    cycle = [child, node]
                    p = parent.get(node)
                    while p is not None and p != child:
                        cycle.append(p)
                        p = parent.get(p)
                    cycle.reverse()
                    return cycle
                if color[child] == WHITE:
                    color[child] = GRAY
                    parent[child] = node
                    stack.append((child, 0))
            return None

        for sid in self._by_id:
            if color[sid] == WHITE:
                result = dfs(sid)
                if result is not None:
                    return result
        return None

    def topological_order(self) -> list[str]:
        """Return a topological ordering of step IDs. Raises if cyclic."""
        if self.has_cycle():
            cycle = self.find_cycle() or []
            raise ValueError(f"dependency graph has a cycle: {' -> '.join(cycle)}")
        # Kahn's algorithm.
        in_degree: dict[str, int] = {sid: 0 for sid in self._by_id}
        for src, dsts in self._edges.items():
            for d in dsts:
                in_degree[d] = in_degree.get(d, 0) + 1
        queue = deque(sorted(sid for sid, deg in in_degree.items() if deg == 0))
        order: list[str] = []
        while queue:
            node = queue.popleft()
            order.append(node)
            for child in sorted(self._edges.get(node, [])):
                in_degree[child] -= 1
                if in_degree[child] == 0:
                    queue.append(child)
        if len(order) != len(self._by_id):
            # Shouldn't happen (has_cycle would have caught it) but defensive.
            raise ValueError("topological sort failed (residual cycle)")
        return order


def detect_plan_cycles(plan: Plan) -> list[str] | None:
    """Convenience: return one cycle in *plan* (list of step IDs) or None.

    Used by the planner to validate a generated plan before returning it
    to the executor.
    """
    return DependencyGraph(plan).find_cycle()
