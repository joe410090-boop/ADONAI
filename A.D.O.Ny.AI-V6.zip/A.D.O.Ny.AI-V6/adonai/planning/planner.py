"""Hierarchical planner — LLM-backed plan generation.

This is the *real* planner: ask the LLM to decompose the goal into a
JSON plan, parse it, fall back to a single synthesis step if parsing
fails.  No hard-coded search triggers, no research-first pre-pass, no
"obvious search request" detector — the LLM is now given the tool
schemas via native tool calling inside the executor, so it can decide
for itself when to call web_search / python_exec / etc.

Public API:
    planner.plan(task)  → Plan
    planner.replan(...)  → Plan
"""
from __future__ import annotations

import json
import logging
from typing import Any

from adonai.core.interfaces import LLMClient, Planner
from adonai.core.json_utils import JSONExtractionError, extract_json
from adonai.core.models import (
    Experience, Plan, PlanStep, Task, TaskComplexity, TaskStatus,
    VerificationType,
)
from adonai.llm.prompt import SystemPrompts

log = logging.getLogger(__name__)


class HierarchicalPlanner(Planner):
    """LLM-backed hierarchical planner producing executable task graphs."""

    def __init__(
        self,
        llm: LLMClient,
        memory_manager=None,
        tool_manager=None,
    ) -> None:
        self.llm = llm
        self.memory = memory_manager
        self.tools = tool_manager
        # v7: ToolScorer ranks tools by historical effectiveness so the
        # planner's prompt presents the most relevant tools first. Previously
        # ToolScorer was fully implemented (58 LOC) but never instantiated.
        self._tool_scorer = None
        if tool_manager is not None:
            try:
                from adonai.tools.scoring import ToolScorer
                self._tool_scorer = ToolScorer(tool_manager)
            except Exception:
                pass

    async def plan(self, task: Task, context: dict[str, Any] | None = None) -> Plan:
        """Decompose a task into a structured plan, consulting memory first."""
        context = dict(context or {})

        # 1. Recall similar past experiences for context-aware planning.
        experiences: list[Experience] = []
        if self.memory:
            try:
                experiences = await self.memory.recall_similar(task.goal, top_k=5)
            except Exception as e:
                log.warning("Planner.recall_similar failed: %s", e)

        # 2. Build available-tools catalog for the prompt (filter debug tools).
        # Include evolved skills in tool catalog
        evolved_skills = []
        if hasattr(self, 'skills_manager') and self.skills_manager is not None:
            try:
                evolved_skills = await self.skills_manager.list_skills()
            except Exception:
                pass
        # v6: find skills relevant to this goal so the planner can recommend
        # them in the plan. Previously find_skills_for_goal() existed but was
        # never called by the planner — skills were listed but not matched.
        relevant_skills: list = []
        if hasattr(self, 'skills_manager') and self.skills_manager is not None:
            try:
                relevant_skills = await self.skills_manager.find_skills_for_goal(task.goal, top_k=3)
                if relevant_skills:
                    context["relevant_skills"] = [
                        {"name": s.name, "description": getattr(s, "description", "")}
                        for s in relevant_skills
                    ]
                    log.debug(
                        "Planner: found %d relevant skill(s) for goal",
                        len(relevant_skills),
                    )
            except Exception as e:
                log.debug("Planner find_skills_for_goal failed (non-fatal): %s", e)
        if "available_tools" not in context and self.tools is not None:
            try:
                context["available_tools"] = await self.tools.list_user_facing()
            except Exception as e:
                log.warning("Planner could not fetch tool catalog: %s", e)
        # Append evolved skills to the tool catalog
        if evolved_skills:
            existing = context.get("available_tools") or []
            context["available_tools"] = list(existing) + list(evolved_skills)

        # 3. Ask the LLM to produce a structured plan.
        user_prompt = await self._build_user_prompt(task, context, experiences)
        # Substitute the current date into the PLANNER prompt so the
        # model knows what year it's in (small models default to their
        # training-cutoff year when forming search queries otherwise).
        from datetime import datetime as _dt
        _now = _dt.now()
        planner_system = SystemPrompts.PLANNER.format(
            current_date=_now.strftime("%Y-%m-%d"),
            current_year=_now.year,
        )
        # v6: read temperature hint from context so TreeOfThoughtPlanner
        # can achieve real diversity across candidates. Previously the hint
        # was injected into context but never read — all candidates used
        # the hardcoded 0.3, making ToT diversity a no-op.
        _temperature = 0.3
        if context and "tot_temperature_hint" in context:
            try:
                _temperature = float(context["tot_temperature_hint"])
            except (TypeError, ValueError):
                pass
        # v7: read strategy hint from context so ToT candidates can
        # specialize (e.g. "minimize tool calls" vs "maximize verification
        # gates"). Previously the hint was injected into context by
        # tot_planner.py:321-325 but never read here — the strategy axis
        # of ToT diversity was inert.
        _strategy_hint = ""
        if context and "tot_strategy_hint" in context:
            hint = context.get("tot_strategy_hint")
            if isinstance(hint, str) and hint.strip():
                _strategy_hint = (
                    f"\n\nPLANNING STRATEGY HINT for this candidate: {hint}. "
                    f"Emphasize this aspect in your plan."
                )
        if _strategy_hint:
            user_prompt = user_prompt + _strategy_hint
        resp = await self.llm.complete(
            messages=[
                {"role": "system", "content": planner_system},
                {"role": "user", "content": user_prompt},
            ],
            temperature=_temperature,
            max_tokens=2048,
        )

        # 4. Parse + validate.
        try:
            data = extract_json(resp.text or "")
        except JSONExtractionError as e:
            preview = (resp.text or "")[:300].replace("\n", "\\n")
            log.warning(
                "Planner failed to parse LLM response as JSON (%s). "
                "Response preview: %r. Using fallback plan.",
                e, preview,
            )
            return self._fallback_plan(task)

        # 5. Empty-steps guard — fall back when LLM returns 0 steps.
        raw_steps = data.get("steps") or []
        if not raw_steps:
            log.warning("Planner LLM returned valid JSON but with no steps. Using fallback plan.")
            return self._fallback_plan(task)

        # 6. Convert to PlanStep objects.
        desc_to_id: dict[str, str] = {}
        steps: list[PlanStep] = []
        for raw in raw_steps:
            if not isinstance(raw, dict):
                continue
            tool_val = raw.get("tool")
            if isinstance(tool_val, str) and tool_val.lower() in ("null", "none", "n/a", ""):
                tool_val = None
            step = PlanStep(
                description=raw.get("description", "(no description)"),
                tool=tool_val,
                parameters=raw.get("parameters", {}) or {},
                expected_outcome=raw.get("expected_outcome"),
                risk_level=raw.get("risk_level", "low"),
                rationale=raw.get("rationale"),
                verification_type=self._resolve_verification_type(
                    raw.get("verification_type"), step_tool=tool_val,
                ),
                verification_detail=raw.get("verification_detail"),
            )
            if step.description not in desc_to_id:
                desc_to_id[step.description] = step.id
            steps.append(step)

        if not steps:
            log.warning("Planner produced 0 valid steps after filtering. Using fallback plan.")
            return self._fallback_plan(task)

        # 7. Resolve dependencies.
        for raw, step in zip(raw_steps, steps):
            if not isinstance(raw, dict):
                continue
            resolved_deps: list[str] = []
            for dep in (raw.get("dependencies") or []):
                if isinstance(dep, int) and 0 <= dep < len(steps):
                    resolved_deps.append(steps[dep].id)
                elif isinstance(dep, str):
                    resolved_deps.append(desc_to_id.get(dep, dep))
                else:
                    resolved_deps.append(desc_to_id.get(str(dep), str(dep)))
            step.dependencies = resolved_deps

        plan = Plan(
            task_id=task.id, goal=task.goal, steps=steps,
            strategy=data.get("strategy"),
            confidence=float(data.get("confidence", 0.5)),
        )
        # Validate the dependency graph is acyclic — a cycle would deadlock
        # the executor (ready_steps() returns [] forever). If we find one,
        # break it by dropping the back-edge rather than failing the whole plan.
        from adonai.planning.graph import DependencyGraph
        graph = DependencyGraph(plan)
        cycle = graph.find_cycle()
        if cycle and len(cycle) >= 2:
            log.warning("Planner detected dependency cycle %s — breaking back-edge", cycle)
            # The back-edge is from cycle[-1] -> cycle[0]. Drop it.
            last_step_id = cycle[-1]
            first_step_id = cycle[0]
            for s in plan.steps:
                if s.id == last_step_id:
                    s.dependencies = [d for d in s.dependencies if d != first_step_id]
                    break
            # Rebuild the graph after breaking the back-edge so the
            # topological-order computation below sees the acyclic graph.
            graph = DependencyGraph(plan)
        # v9 fix: wire topological_order() into the planner's pre-return
        # validation so a deterministic execution order is computed and
        # exposed on Plan.metadata.execution_order. Previously
        # graph.topological_order() (graph.py:161-192) was dead code —
        # computed nowhere. The executor still uses graph.ready_steps()
        # at runtime, but stashing the order here gives the runtime/API
        # a deterministic, declarative view of the plan that's useful
        # for progress reporting, replay, and audit.
        try:
            execution_order = graph.topological_order()
        except ValueError as e:
            # Defensive: cycle-break above should prevent this, but
            # if a residual cycle remains we still return the plan
            # (the executor's ready_steps() loop will simply terminate
            # early with whatever steps it could run).
            log.warning("Planner topological_order failed (non-fatal): %s", e)
            execution_order = [s.id for s in plan.steps]
        plan.metadata = plan.metadata or {}
        plan.metadata["execution_order"] = execution_order
        log.info("Planner produced %d-step plan for task %s", len(steps), task.id)
        return plan

    async def replan(
        self, task: Task, previous_plan: Plan, failed_step: PlanStep, reason: str,
        step_outputs: list[dict] | None = None,
    ) -> Plan:
        """Generate a revised plan after a step fails.

        v4: if the previous plan has pre-computed `alternative_branches`
        (from TreeOfThoughtPlanner), try the next alternative before
        spending an LLM call on a fresh plan. The alternatives were
        already scored at planning time, so the next-best branch is
        usually better than a from-scratch replan.

        v9 fix: accept ``step_outputs`` (a list of
        ``{step_id, status, output_preview}`` dicts for the last few
        completed steps) so the replan LLM prompt can see actual tool
        outputs from the failed run, not just description strings.
        Previously only the step *descriptions* were passed, so the
        LLM had no visibility into *why* a step failed or what the
        successful upstream steps actually returned — making
        data-driven replanning impossible. The parameter defaults to
        None for backward compatibility (callers that don't pass it
        get the old behaviour).
        """
        log.info(
            "Replanning task %s after failed step '%s' (%s)",
            task.id, failed_step.description, reason,
        )
        # Try alternative branches first (cheap — no LLM call).
        if previous_plan.alternative_branches:
            import copy as _copy
            for branch_steps in previous_plan.alternative_branches:
                # Deep-copy so the executor can mutate steps without affecting
                # other branches or the original plan.
                steps_copy = _copy.deepcopy(branch_steps)
                alt_plan = Plan(
                    task_id=task.id, goal=task.goal, steps=steps_copy,
                    strategy=f"{previous_plan.strategy or 'unknown'} (alt-branch)",
                    confidence=max(0.1, previous_plan.confidence - 0.1),
                    revised=previous_plan.revised + 1,
                    parent_plan_id=previous_plan.id,
                )
                # Validate the alternative is acyclic before returning it.
                from adonai.planning.graph import DependencyGraph
                if not DependencyGraph(alt_plan).has_cycle():
                    log.info("Replan: using pre-computed alternative branch (confidence=%.2f)", alt_plan.confidence)
                    # Drop the used branch so the next replan doesn't reuse it.
                    previous_plan.alternative_branches.remove(branch_steps)
                    return alt_plan
                log.warning("Replan: alternative branch had a cycle, skipping")
            log.info("Replan: all alternative branches exhausted or cyclic — falling back to LLM replan")

        completed = [s.description for s in previous_plan.steps if s.status == TaskStatus.COMPLETED]
        remaining = [s.description for s in previous_plan.steps
                     if s.status not in (TaskStatus.COMPLETED, TaskStatus.FAILED)]

        # v9 fix: include the actual outputs of the last few completed
        # steps in the replan prompt so the LLM can reason about what
        # already happened (not just the descriptions). The caller
        # (executor) is expected to pass up to 3 entries shaped like
        # ``{step_id, status, output_preview}``. We cap previews to
        # 500 chars each to keep the prompt bounded.
        step_outputs_block = ""
        if step_outputs:
            try:
                previews = []
                for entry in step_outputs[-3:]:
                    if not isinstance(entry, dict):
                        continue
                    sid = entry.get("step_id") or entry.get("id") or "?"
                    status = entry.get("status") or "?"
                    preview = entry.get("output_preview")
                    if preview is None:
                        preview = entry.get("output")
                    if preview is None:
                        preview = ""
                    preview_str = str(preview)[:500]
                    previews.append(f"- step={sid} status={status} output={preview_str!r}")
                if previews:
                    step_outputs_block = (
                        "\n\nRecent step outputs (most recent first):\n"
                        + "\n".join(reversed(previews))
                    )
            except Exception as e:
                log.debug("Replan: failed to format step_outputs (non-fatal): %s", e)

        prompt = (
            f"Original goal: {task.goal}\n\n"
            f"Completed steps: {json.dumps(completed)}\n"
            f"Failed step: '{failed_step.description}' — reason: {reason}\n"
            f"Remaining steps: {json.dumps(remaining)}\n"
            f"{step_outputs_block}\n\n"
            f"Produce a REVISED plan that avoids the failure. Keep completed steps. "
            f"Output the same JSON schema."
        )
        # Substitute the current date into the PLANNER prompt (same as
        # in plan() above).
        from datetime import datetime as _dt
        _now = _dt.now()
        planner_system = SystemPrompts.PLANNER.format(
            current_date=_now.strftime("%Y-%m-%d"),
            current_year=_now.year,
        )
        resp = await self.llm.complete(
            messages=[
                {"role": "system", "content": planner_system},
                {"role": "user", "content": prompt},
            ],
            temperature=0.4, max_tokens=2048,
        )
        try:
            data = extract_json(resp.text or "")
        except JSONExtractionError as e:
            preview = (resp.text or "")[:300].replace("\n", "\\n")
            log.warning("Planner.replan failed to parse JSON (%s). Preview: %r", e, preview)
            data = {"steps": [], "strategy": "replan-fallback", "confidence": 0.2}

        desc_to_id: dict[str, str] = {}
        steps: list[PlanStep] = []
        for raw in data.get("steps") or []:
            if not isinstance(raw, dict):
                continue
            tool_val = raw.get("tool")
            if isinstance(tool_val, str) and tool_val.lower() in ("null", "none", "n/a", ""):
                tool_val = None
            step = PlanStep(
                description=raw.get("description", "(no description)"),
                tool=tool_val,
                parameters=raw.get("parameters", {}) or {},
                expected_outcome=raw.get("expected_outcome"),
                risk_level=raw.get("risk_level", "low"),
                rationale=raw.get("rationale"),
                verification_type=self._resolve_verification_type(
                    raw.get("verification_type"), step_tool=tool_val,
                ),
                verification_detail=raw.get("verification_detail"),
            )
            if step.description not in desc_to_id:
                desc_to_id[step.description] = step.id
            steps.append(step)
        for raw, step in zip(data.get("steps") or [], steps):
            if not isinstance(raw, dict):
                continue
            resolved_deps: list[str] = []
            for dep in (raw.get("dependencies") or []):
                if isinstance(dep, int) and 0 <= dep < len(steps):
                    resolved_deps.append(steps[dep].id)
                elif isinstance(dep, str):
                    resolved_deps.append(desc_to_id.get(dep, dep))
                else:
                    resolved_deps.append(desc_to_id.get(str(dep), str(dep)))
            step.dependencies = resolved_deps
        replan_plan = Plan(
            task_id=task.id, goal=task.goal, steps=steps,
            strategy=data.get("strategy"),
            confidence=float(data.get("confidence", 0.3)),
            revised=previous_plan.revised + 1,
        )
        # v9 fix: stash execution_order on the replanned Plan too, so the
        # replan output is symmetric with plan() output (callers can rely
        # on Plan.metadata.execution_order being present on any plan).
        from adonai.planning.graph import DependencyGraph as _DG
        try:
            replan_plan.metadata = replan_plan.metadata or {}
            replan_plan.metadata["execution_order"] = _DG(replan_plan).topological_order()
        except ValueError as e:
            log.warning("Replan topological_order failed (non-fatal): %s", e)
            replan_plan.metadata = replan_plan.metadata or {}
            replan_plan.metadata["execution_order"] = [s.id for s in replan_plan.steps]
        return replan_plan

    # ──────────────────────────────────────────────────────────────────────────
    # Helpers
    # ──────────────────────────────────────────────────────────────────────────

    async def _build_user_prompt(
        self, task: Task, context: dict[str, Any],
        experiences: list[Experience],
    ) -> str:
        exp_block = ""
        if experiences:
            exp_block = "\n\nRelevant past experiences:\n" + "\n".join(
                f"- Goal: {e.task_goal} → {'success' if e.success else 'failure'}; "
                f"lessons: {'; '.join(e.lessons) or 'none'}"
                for e in experiences
            )
        # Retrieve reflection lessons
        reflection_lessons = []
        if hasattr(self, 'reflection_engine') and self.reflection_engine is not None:
            try:
                # recall_lessons signature is recall_lessons(self, *, domain=None, top_k=10).
                # The previous call passed `task.goal` positionally into the
                # keyword-only `domain` parameter, raising TypeError that was
                # silently swallowed by the bare except below — leaving
                # reflection lessons NEVER injected into planning prompts.
                # Fix: pass `domain=` explicitly, and handle both Lesson
                # objects (Pydantic, has .lesson attribute) and plain dicts.
                lessons_raw = await self.reflection_engine.recall_lessons(
                    domain=task.goal, top_k=3,
                )
                # Normalise to plain dicts/strings so the f-string below works.
                for l in lessons_raw or []:
                    if hasattr(l, "lesson"):
                        # Pydantic Lesson model
                        reflection_lessons.append(
                            getattr(l, "lesson", None)
                            or getattr(l, "content", None)
                            or str(l)
                        )
                    elif isinstance(l, dict):
                        reflection_lessons.append(
                            l.get("lesson") or l.get("content") or str(l)
                        )
                    else:
                        reflection_lessons.append(str(l))
            except Exception as e:
                log.debug("recall_lessons failed (non-fatal): %s", e)
        if reflection_lessons:
            exp_block += "\n\nReflection lessons:\n" + "\n".join(
                f"- {l}" for l in reflection_lessons
            )

        # v5 fix: explicitly surface reasoning + engineered_prompt as
        # labeled, human-readable blocks. Previously these were buried in
        # the generic "Additional context" JSON dump alongside other keys,
        # and small LLMs often ignored them. The runtime was calling
        # ReasoningEngine.reason() and PromptEngineeringNode.engineer()
        # (1-4 LLM calls per task) but the planner never highlighted their
        # output, so the conclusions had zero effect on the produced plan.
        reasoning_block = ""
        reasoning = context.get("reasoning") if context else None
        if reasoning and isinstance(reasoning, dict):
            strategy = reasoning.get("strategy") or reasoning.get("approach") or "unknown"
            confidence = reasoning.get("confidence")
            conclusion = reasoning.get("conclusion") or reasoning.get("answer") or ""
            issues = reasoning.get("issues") or []
            parts = [f"Strategy: {strategy}"]
            if confidence is not None:
                parts.append(f"Confidence: {float(confidence):.2f}")
            if conclusion:
                parts.append(f"Conclusion: {str(conclusion)[:600]}")
            if issues:
                parts.append("Issues to watch for: " + "; ".join(str(i) for i in issues[:5]))
            reasoning_block = "\n\nReasoning analysis (use this to inform the plan):\n" + "\n".join(
                f"- {p}" for p in parts
            )

        engineered_block = ""
        engineered = context.get("engineered_prompt") if context else None
        if engineered and isinstance(engineered, str) and engineered.strip():
            engineered_block = (
                "\n\nEngineered prompt specification (use these requirements):\n"
                + engineered[:2000]
            )

        # v5: Knowledge Graph context — retrieve relevant entities/relations
        # for the task goal. Previously only the TreeOfThoughtPlanner called
        # kg.context_for(); the base HierarchicalPlanner never queried the KG,
        # so KG data accumulated but was never used in standard planning.
        # v6 fix: context_for() returns a str (joined lines), NOT a dict.
        # The previous code called kg_ctx.get("entities") on a str, which
        # raised AttributeError: 'str' object has no attribute 'get' —
        # silently caught by the broad except, so kg_block was always empty.
        kg_block = ""
        if hasattr(self, 'knowledge_graph') and self.knowledge_graph is not None:
            try:
                kg_ctx = await self.knowledge_graph.context_for(task.goal, max_entities=10)
                if kg_ctx:
                    # context_for() returns a pre-formatted string.
                    if isinstance(kg_ctx, str):
                        kg_block = "\n\nKnowledge graph context:\n" + kg_ctx
                    # Backward compat: if a future version returns a dict,
                    # handle it the old way.
                    elif isinstance(kg_ctx, dict):
                        parts = []
                        entities = kg_ctx.get("entities") or kg_ctx.get("relevant_entities") or []
                        if entities:
                            ent_lines = []
                            for e in entities[:10]:
                                if isinstance(e, dict):
                                    name = e.get("name") or e.get("entity") or "?"
                                    conf = e.get("confidence", 0.5)
                                    ent_lines.append(f"  - {name} (conf={conf:.2f})")
                                else:
                                    ent_lines.append(f"  - {e}")
                            if ent_lines:
                                parts.append("Relevant entities:\n" + "\n".join(ent_lines))
                        relations = kg_ctx.get("relations") or []
                        if relations:
                            rel_lines = []
                            for r in relations[:10]:
                                if isinstance(r, dict):
                                    src = r.get("source") or r.get("subject") or "?"
                                    rel = r.get("relation") or r.get("type") or "?"
                                    tgt = r.get("target") or r.get("object") or "?"
                                    rel_lines.append(f"  - {src} --[{rel}]--> {tgt}")
                                else:
                                    rel_lines.append(f"  - {r}")
                            if rel_lines:
                                parts.append("Relevant relations:\n" + "\n".join(rel_lines))
                        summary = kg_ctx.get("summary")
                        if summary and isinstance(summary, str):
                            parts.append(f"Summary: {summary[:400]}")
                        if parts:
                            kg_block = "\n\nKnowledge graph context:\n" + "\n".join(parts)
            except Exception as e:
                log.debug("KG context_for failed (non-fatal): %s", e)

        ctx_block = ""
        # Exclude keys we've already surfaced as labeled blocks above so
        # they don't appear twice (once labeled, once in the JSON dump).
        safe_ctx = {
            k: v for k, v in (context or {}).items()
            if k not in ("available_tools", "reasoning", "engineered_prompt",
                         "prompt_package")
        }
        if safe_ctx:
            ctx_block = f"\n\nAdditional context:\n{json.dumps(safe_ctx, default=str)}"
        tools_block = ""
        available_tools = context.get("available_tools") if context else None
        if available_tools:
            # v7: rank tools by effectiveness for this goal using ToolScorer.
            # This reorders the tool list so the most relevant tools appear
            # first in the prompt — small models pay more attention to the
            # top of the list. Falls back to the original order if scoring
            # fails (non-fatal).
            ranked_tools = list(available_tools)
            if self._tool_scorer is not None and len(ranked_tools) > 1:
                try:
                    scores = self._tool_scorer.rank_for_goal(task.goal, top_k=len(ranked_tools))
                    # Build a name→score map and sort tools by score descending.
                    score_map = dict(scores)
                    ranked_tools = sorted(
                        ranked_tools,
                        key=lambda t: score_map.get(getattr(t, "name", ""), 0.0),
                        reverse=True,
                    )
                except Exception:
                    pass  # fall back to original order
            tool_lines = []
            for t in ranked_tools:
                name = getattr(t, "name", str(t))
                desc = getattr(t, "description", "") or ""
                if len(desc) > 120:
                    desc = desc[:117] + "..."
                tool_lines.append(f"  - {name}: {desc}")
            tools_block = (
                "\n\nAvailable tools (use these names VERBATIM in the `tool` field):\n"
                + "\n".join(tool_lines)
            )

        # v9 fix: Strategic goals — query the StrategicGoalStore for pending
        # goals that align with this task, and inject them as a labeled block.
        # Previously the Strategic Reasoner decomposed missions into goals
        # that were persisted to SQLite but NEVER consulted during planning —
        # the goal store was write-only.
        strategic_block = ""
        if hasattr(self, 'strategic_reasoner') and self.strategic_reasoner is not None:
            try:
                store = getattr(self.strategic_reasoner, "store", None)
                if store is not None:
                    pending = await store.get_pending(limit=5)
                    if pending:
                        lines = []
                        for g in pending:
                            if hasattr(g, "description"):
                                desc = g.description or g.title or "(no description)"
                            elif isinstance(g, dict):
                                desc = g.get("description") or g.get("title") or "(no description)"
                            else:
                                desc = str(g)
                            # Truncate each goal line to keep the prompt tight.
                            lines.append(f"  - {str(desc)[:120]}")
                        if lines:
                            strategic_block = (
                                "\n\nStrategic goals (align this plan with the active mission where possible):\n"
                                + "\n".join(lines)
                            )
            except Exception as e:
                log.debug("Strategic goals retrieval failed (non-fatal): %s", e)

        return (
            f"Goal: {task.goal}\n"
            f"Description: {task.description or 'N/A'}\n"
            f"Priority: {task.priority.value}\n"
            f"Complexity: {task.complexity.value}\n"
            f"Max steps allowed: {task.max_steps}"
            f"{strategic_block}{engineered_block}{reasoning_block}{kg_block}{exp_block}{ctx_block}{tools_block}\n\n"
            f"Produce the plan as JSON."
        )

    @staticmethod
    def _resolve_verification_type(
        raw_val: Any, *, step_tool: str | None,
    ) -> VerificationType:
        """Map the LLM's verification_type string to the enum."""
        if isinstance(raw_val, str):
            mapping = {
                "test_run": VerificationType.TEST_RUN,
                "file_exists": VerificationType.FILE_EXISTS,
                "output_contains": VerificationType.OUTPUT_CONTAINS,
                "source_fetched": VerificationType.SOURCE_FETCHED,
                "exit_code": VerificationType.EXIT_CODE,
                "unverified": VerificationType.UNVERIFIED,
                "llm_check": VerificationType.LLM_CHECK,
            }
            return mapping.get(raw_val.lower().strip(), VerificationType.LLM_CHECK)
        if step_tool in ("python_exec", "terminal"):
            return VerificationType.EXIT_CODE
        if step_tool == "file.write":
            return VerificationType.FILE_EXISTS
        if step_tool in ("web_search", "web_fetch"):
            return VerificationType.OUTPUT_CONTAINS
        return VerificationType.UNVERIFIED

    def _fallback_plan(self, task: Task) -> Plan:
        """Minimal fallback when the LLM planner fails to produce JSON.

        Single synthesis step — the executor will pass the goal to the
        LLM directly.  No heuristic tool-selection; the LLM gets to
        decide via native tool calling (if the executor is the
        ToolCallingAgent) or via a plain synthesis call.
        """
        step = PlanStep(
            description=f"Respond to: {task.goal}",
            tool=None, parameters={},
            expected_outcome="A direct response to the user's goal",
            risk_level="low",
            verification_type=VerificationType.UNVERIFIED,
        )
        return Plan(
            task_id=task.id, goal=task.goal, steps=[step],
            strategy="fallback: single synthesis step (planner parse failure)",
            confidence=0.3,
        )
