"""Upgrade 3 — Tree-of-Thought Planning.

Replaces single-plan generation with:

    Generate N plans → Evaluate → Score → Select best

Configurable branching factor (``config.tot.branching_factor``).

The :class:`TreeOfThoughtPlanner` decorates any base :class:`Planner`
(usually :class:`~adonai.planning.planner.HierarchicalPlanner`) and
produces N candidate plans in parallel, scores them with a configurable
rubric, picks the best, and stores the runners-up in
``Plan.alternative_branches`` so the executor can branch on
verification failure.

The planner also consults the Knowledge Graph (Upgrade 2) and the
Critic (Upgrade 1) for pre-execution review of the top candidates.
"""
from __future__ import annotations

import asyncio
import logging
import math
from typing import Any

from adonai.core.exceptions import PlanningError
from adonai.core.interfaces import Critic, Planner
from adonai.core.models import (
    Plan, PlanStep, Task, TaskComplexity, TaskStatus, VerificationType,
)

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Plan scoring rubric
# ──────────────────────────────────────────────────────────────────────────────


class PlanScorer:
    """Scores a candidate plan with a configurable rubric.

    Rubric weights come from ``config.tot.score_weights`` and default to::

        confidence:      0.40
        step_count:      0.15
        tool_coverage:   0.15
        dep_structure:   0.15
        risk:            0.15
    """

    def __init__(self, weights: dict[str, float] | None = None) -> None:
        self.weights = weights or {
            "confidence": 0.40,
            "step_count": 0.15,
            "tool_coverage": 0.15,
            "dep_structure": 0.15,
            "risk": 0.15,
        }

    def score(self, plan: Plan, available_tools: list[str] | None = None) -> float:
        """Return a score in [0, 1] — higher is better."""
        if not plan.steps:
            return 0.0

        # 1. Confidence (already in [0, 1]).
        conf = max(0.0, min(1.0, plan.confidence))

        # 2. Step count — penalize very long or very short plans.
        n = len(plan.steps)
        # Ideal ~5 steps; smoothly penalize outside [3, 8].
        if 3 <= n <= 8:
            step_score = 1.0
        else:
            step_score = max(0.0, 1.0 - abs(n - 5) * 0.1)

        # 3. Tool coverage — fraction of plan steps that use a known tool.
        if available_tools:
            used_tools = {
                s.tool for s in plan.steps
                if s.tool and s.tool in available_tools
            }
            coverage = min(1.0, len(used_tools) / max(1, len(available_tools)))
            # Don't reward using every tool — reward using a sensible subset.
            tool_score = 1.0 - abs(coverage - 0.4) * 1.5
            tool_score = max(0.0, tool_score)
        else:
            tool_score = 0.7  # neutral when no tool list

        # 4. Dependency structure — reward properly-chained DAGs.
        # v9 fix: previously this rewarded "30-60% of steps have no deps"
        # which biased the scorer toward *disconnected forests* (lots of
        # independent steps with no chain). A plan where every step
        # depends on the previous one (linear chain) scored WORSE than
        # a plan with random disconnected steps, which is backwards.
        # Replace with: score = 1.0 - (longest_path_length / n_steps).
        # A linear chain has longest_path_length == n_steps → score 0.0
        # (no parallelism) — but that's the only pathological case;
        # realistic plans with a couple of parallel branches and a
        # reasonable chain length land in [0.5, 0.9]. A disconnected
        # forest (every step independent) has longest_path_length == 1
        # → score ~1.0 BUT only because n_steps > 1 means there's no
        # structure to penalise; combined with the other rubric
        # dimensions this is no longer a free high score.
        if n <= 1:
            dep_score = 0.5
        else:
            longest = self._longest_path_length(plan)
            dep_score = max(0.0, 1.0 - (longest / n))
            dep_score = min(1.0, dep_score)

        # 5. Risk — penalize high-risk steps without verification.
        high_risk_unverified = sum(
            1 for s in plan.steps
            if s.risk_level == "high" and s.verification_type == VerificationType.UNVERIFIED
        )
        risk_score = max(0.0, 1.0 - high_risk_unverified * 0.25)

        w = self.weights
        total = (
            w.get("confidence", 0.4) * conf
            + w.get("step_count", 0.15) * step_score
            + w.get("tool_coverage", 0.15) * tool_score
            + w.get("dep_structure", 0.15) * dep_score
            + w.get("risk", 0.15) * risk_score
        )
        # Normalize by total weight (in case user re-weighted).
        weight_sum = sum(w.values()) or 1.0
        return max(0.0, min(1.0, total / weight_sum))

    @staticmethod
    def _longest_path_length(plan: Plan) -> int:
        """Longest dependency-chain length (in nodes) in the plan DAG.

        v9 fix: used by the dep_structure rubric to reward plans with
        a sensible amount of chaining. Computed via topological DFS
        over the DependencyGraph — O(V+E). Returns 1 for a plan with
        no edges (every step independent).
        """
        from adonai.planning.graph import DependencyGraph
        graph = DependencyGraph(plan)
        # Build child list once. graph._edges maps step_id -> list of
        # dependents (children that depend on it).
        # in_degree counts how many deps each step has.
        in_degree: dict[str, int] = {s.id: 0 for s in plan.steps}
        children: dict[str, list[str]] = {s.id: [] for s in plan.steps}
        by_id = {s.id: s for s in plan.steps}
        for s in plan.steps:
            for dep in s.dependencies:
                if dep in by_id:
                    children[dep].append(s.id)
                    in_degree[s.id] = in_degree.get(s.id, 0) + 1
        # longest[v] = longest path ending at v (in nodes).
        longest: dict[str, int] = {sid: 1 for sid in by_id}
        # Process in topological order so all predecessors are computed first.
        from collections import deque
        queue = deque([sid for sid, deg in in_degree.items() if deg == 0])
        seen = 0
        while queue:
            node = queue.popleft()
            seen += 1
            for child in children[node]:
                if longest[node] + 1 > longest[child]:
                    longest[child] = longest[node] + 1
                in_degree[child] -= 1
                if in_degree[child] == 0:
                    queue.append(child)
        if seen == 0:
            return 1
        return max(longest.values()) if longest else 1


# ──────────────────────────────────────────────────────────────────────────────
# TreeOfThoughtPlanner
# ──────────────────────────────────────────────────────────────────────────────


class TreeOfThoughtPlanner(Planner):
    """Generate N candidate plans, score them, pick the best.

    Wraps a base :class:`Planner` (typically the
    :class:`~adonai.planning.planner.HierarchicalPlanner`).  Each
    candidate is generated with a different ``temperature`` to encourage
    diversity, then scored with :class:`PlanScorer`.  The top-K runners-up
    are stored on the winning plan's ``alternative_branches`` field so
    the executor can fall back to them on verification failure.

    The planner also:

    * Consults the Knowledge Graph (Upgrade 2) via ``knowledge_graph``
      to inject context into the planning prompt.
    * Optionally invokes the :class:`Critic` (Upgrade 1) on the top 2
      candidates when their scores are within ``min_score_delta``.
    """

    def __init__(
        self,
        base_planner: Planner,
        *,
        branching_factor: int = 3,
        max_depth: int = 2,
        parallel_generation: bool = True,
        scorer: PlanScorer | None = None,
        knowledge_graph: Any = None,
        critic: Critic | None = None,
        config: Any = None,
    ) -> None:
        self.base = base_planner
        self.branching_factor = max(1, branching_factor)
        self.max_depth = max(1, max_depth)
        self.parallel = parallel_generation
        self.scorer = scorer or PlanScorer(
            getattr(getattr(config, "tot", None), "score_weights", None)
            if config else None
        )
        self.kg = knowledge_graph
        self.critic = critic
        self.config = config
        # Cache the base planner's tool list once.
        self._available_tools: list[str] | None = None

    # ── Planner interface ─────────────────────────────────────────────────

    async def plan(
        self, task: Task, context: dict[str, Any] | None = None,
    ) -> Plan:
        """Generate N plans in parallel, score, pick best."""
        context = dict(context or {})

        # 1. Inject KG context if available.
        if self.kg is not None and not context.get("kg_context"):
            try:
                kg_ctx = await self.kg.context_for(task.goal)
                if kg_ctx:
                    context["kg_context"] = kg_ctx
            except Exception as e:
                log.debug("KG context fetch failed: %s", e)

        # 2. Resolve the available-tools list once.
        if self._available_tools is None:
            tools = getattr(self.base, "tools", None)
            if tools is not None:
                try:
                    self._available_tools = [
                        t.name for t in await tools.list_user_facing()
                    ]
                except Exception:
                    self._available_tools = []

        # 3. Trivial / greeting shortcut — let the base planner handle it.
        if task.complexity in (TaskComplexity.TRIVIAL, TaskComplexity.SIMPLE):
            log.debug("ToT: complexity=%s — delegating to base planner",
                      task.complexity.value)
            return await self.base.plan(task, context)

        # 4. Generate N candidate plans.
        candidates = await self._generate_candidates(task, context)
        if not candidates:
            log.warning("ToT: no candidates generated — falling back to base planner")
            return await self.base.plan(task, context)

        if len(candidates) == 1:
            return candidates[0]

        # 5. Score every candidate.
        scored = [
            (self.scorer.score(p, self._available_tools), p) for p in candidates
        ]
        scored.sort(key=lambda x: x[0], reverse=True)
        log.info(
            "ToT: %d candidates scored. Top: %.3f, 2nd: %.3f",
            len(scored), scored[0][0], scored[1][0] if len(scored) > 1 else 0.0,
        )

        # 6. If the top 2 are too close, run the critic to break the tie.
        best_score, best_plan = scored[0]
        if (
            len(scored) >= 2
            and (best_score - scored[1][0]) < self._min_score_delta()
            and self.critic is not None
        ):
            try:
                best_plan = await self._critic_tiebreak(
                    task, scored[0][1], scored[1][1], context,
                )
            except Exception as e:
                log.warning("ToT critic tiebreak failed: %s", e)

        # 7. Stash runners-up as alternative branches.
        best_plan.alternative_branches = [
            list(p.steps) for _, p in scored[1:3] if p is not best_plan
        ]
        best_plan.metadata = best_plan.metadata or {}
        best_plan.metadata["tot_score"] = round(best_score, 4)
        best_plan.metadata["tot_candidates"] = len(scored)
        best_plan.reasoning_trace = (
            f"ToT: generated {len(scored)} candidates, "
            f"top score={best_score:.3f}, "
            f"selected plan has {len(best_plan.steps)} steps."
        )
        return best_plan

    async def replan(
        self, task: Task, previous_plan: Plan, failed_step: PlanStep, reason: str,
        step_outputs: list[dict] | None = None,
    ) -> Plan:
        """Replan by first trying alternative_branches, then base.replan.

        v9 fix: accept ``step_outputs`` (forwarded to base.replan) so the
        LLM replan prompt can include actual tool outputs. Default None
        preserves backward compatibility.
        """
        # 1. If the previous plan kept alternative branches, try them.
        if previous_plan.alternative_branches:
            log.info(
                "ToT.replan: trying alternative branch (%d available)",
                len(previous_plan.alternative_branches),
            )
            alt_steps = previous_plan.alternative_branches.pop(0)
            alt_plan = Plan(
                task_id=task.id, goal=task.goal, steps=alt_steps,
                strategy="tot:alternative_branch",
                confidence=max(0.2, previous_plan.confidence - 0.1),
                revised=previous_plan.revised + 1,
                alternative_branches=previous_plan.alternative_branches,
            )
            return alt_plan
        # 2. Otherwise fall through to base.replan.
        try:
            return await self.base.replan(
                task, previous_plan, failed_step, reason,
                step_outputs=step_outputs,
            )
        except TypeError:
            # Backward-compat: base planner may not yet accept step_outputs.
            return await self.base.replan(task, previous_plan, failed_step, reason)

    # ── Internals ─────────────────────────────────────────────────────────

    async def _generate_candidates(
        self, task: Task, context: dict[str, Any],
    ) -> list[Plan]:
        """Generate ``branching_factor`` candidate plans.

        We achieve diversity by perturbing the LLM ``temperature`` and
        the planning ``strategy`` hint.  If the base planner doesn't
        expose a ``temperature`` kwarg, the perturbation is a no-op and
        we still get diversity from LLM stochasticity.
        """
        temps = self._temperatures()
        coros = [self._gen_one(task, context, t, i) for i, t in enumerate(temps)]
        if self.parallel:
            results = await asyncio.gather(*coros, return_exceptions=True)
        else:
            results = []
            for c in coros:
                try:
                    results.append(await c)
                except Exception as e:
                    results.append(e)
        plans: list[Plan] = []
        for r in results:
            if isinstance(r, Exception):
                log.debug("ToT candidate generation failed: %s", r)
                continue
            if isinstance(r, Plan) and r.steps:
                plans.append(r)
        return plans

    async def _gen_one(
        self, task: Task, context: dict[str, Any], temperature: float, idx: int,
    ) -> Plan:
        """Generate one candidate with the given temperature.

        We delegate to the base planner.  Most planners don't accept a
        ``temperature`` kwarg directly, so we instead override the
        underlying LLM's default temperature by temporarily swapping
        ``config.llm.temperature`` if accessible — but only if it's safe
        to do so.
        """
        # The base planner reads temperature from its own internal logic;
        # we approximate diversity by re-rolling via repeated calls and
        # trusting LLM stochasticity.  In practice, ollama/openai backends
        # already sample stochastically when temperature > 0.
        # Inject a per-candidate hint into context so the base planner
        # can pick it up if it wants to.
        ctx = dict(context)
        ctx["tot_candidate_index"] = idx
        ctx["tot_temperature_hint"] = temperature
        ctx["tot_strategy_hint"] = self._strategy_hint(idx)
        return await self.base.plan(task, ctx)

    def _temperatures(self) -> list[float]:
        """Spread temperatures around the configured base for diversity."""
        # Spread between 0.2 and 0.7 to get diverse-but-coherent plans.
        base = 0.3
        spread = 0.25
        if self.branching_factor == 1:
            return [base]
        step = (2 * spread) / (self.branching_factor - 1)
        return [round(max(0.05, base - spread + i * step), 3)
                for i in range(self.branching_factor)]

    def _strategy_hint(self, idx: int) -> str:
        hints = [
            "minimize tool calls",
            "maximize verification gates",
            "favor parallelizable steps",
            "favor conservative risk",
            "favor breadth-first exploration",
        ]
        return hints[idx % len(hints)]

    def _min_score_delta(self) -> float:
        if self.config is None:
            return 0.05
        return getattr(getattr(self.config, "tot", None), "min_score_delta", 0.05)

    async def _critic_tiebreak(
        self,
        task: Task,
        plan_a: Plan,
        plan_b: Plan,
        context: dict[str, Any],
    ) -> Plan:
        """Run the critic on both plans; pick the one it prefers."""
        if self.critic is None:
            return plan_a
        log.info("ToT: top-2 within delta — invoking critic for tiebreak")
        rep_a, rep_b = await asyncio.gather(
            self.critic.critique(task, plan_a, target_kind="plan", context=context),
            self.critic.critique(task, plan_b, target_kind="plan", context=context),
            return_exceptions=True,
        )
        # On error, fall back to plan_a (the higher-scored one).
        if isinstance(rep_a, Exception) or isinstance(rep_b, Exception):
            log.warning("ToT critic tiebreak errored — keeping top plan")
            return plan_a
        # Pick the plan with higher critic confidence and lower risk.
        score_a = rep_a.confidence - 0.5 * rep_a.risk_score
        score_b = rep_b.confidence - 0.5 * rep_b.risk_score
        if score_b > score_a + 0.05:
            log.info(
                "ToT critic prefers plan B (critic_score=%.3f > %.3f)",
                score_b, score_a,
            )
            return plan_b
        return plan_a


__all__ = ["TreeOfThoughtPlanner", "PlanScorer"]
