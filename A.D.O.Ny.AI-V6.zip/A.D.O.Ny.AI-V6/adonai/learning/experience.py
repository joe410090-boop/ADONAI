"""Experience store — persists (plan, outcome, lesson) tuples to SQLite."""
from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Any

from adonai.config.settings import Config
from adonai.core.models import Experience, TaskResult, TaskStatus


class ExperienceStore:
    """SQLite-backed experience recorder."""

    def __init__(self, config: Config) -> None:
        self.db_path = Path(config.memory.sqlite_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_schema(self) -> None:
        with self._conn() as conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS experiences (
                id            TEXT PRIMARY KEY,
                task_goal     TEXT NOT NULL,
                task_complexity TEXT NOT NULL,
                plan_id       TEXT NOT NULL,
                plan_snapshot TEXT NOT NULL,
                outcome       TEXT NOT NULL,
                success       INTEGER NOT NULL,
                duration_s    REAL NOT NULL,
                mistakes      TEXT NOT NULL DEFAULT '[]',
                lessons       TEXT NOT NULL DEFAULT '[]',
                tool_effectiveness TEXT NOT NULL DEFAULT '{}',
                skill_id      TEXT,
                agent_used    TEXT,
                created_at    REAL NOT NULL
            )""")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_exp_created ON experiences(created_at)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_exp_success ON experiences(success)")
            conn.commit()

    async def record(
        self, task_goal: str, plan_id: str, plan_snapshot: dict[str, Any],
        result: TaskResult, *, task_complexity: str = "simple",
        mistakes: list[str] | None = None, lessons: list[str] | None = None,
        tool_effectiveness: dict[str, float | dict] | None = None,
        skill_id: str | None = None, agent_used: str | None = None,
    ) -> str:
        from adonai.core.models import _uid
        exp_id = _uid("exp_")
        with self._conn() as conn:
            conn.execute(
                """INSERT INTO experiences
                   (id, task_goal, task_complexity, plan_id, plan_snapshot, outcome,
                    success, duration_s, mistakes, lessons, tool_effectiveness,
                    skill_id, agent_used, created_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    exp_id, task_goal, task_complexity, plan_id,
                    json.dumps(plan_snapshot, default=str),
                    result.status.value,
                    1 if result.status == TaskStatus.COMPLETED else 0,
                    result.duration_s,
                    json.dumps(mistakes or []),
                    json.dumps(lessons or result.lessons or []),
                    json.dumps(tool_effectiveness or {}),
                    skill_id, agent_used, time.time(),
                ),
            )
            conn.commit()
        return exp_id

    async def recent(self, limit: int = 20) -> list[Experience]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM experiences ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        out = []
        for row in rows:
            try:
                out.append(Experience(
                    id=row["id"], task_goal=row["task_goal"],
                    task_complexity=row["task_complexity"],
                    plan_id=row["plan_id"],
                    plan_snapshot=json.loads(row["plan_snapshot"]),
                    outcome=TaskStatus(row["outcome"]),
                    success=bool(row["success"]),
                    duration_s=float(row["duration_s"]),
                    mistakes=json.loads(row["mistakes"]),
                    lessons=json.loads(row["lessons"]),
                    tool_effectiveness=json.loads(row["tool_effectiveness"]),
                    skill_id=row["skill_id"], agent_used=row["agent_used"],
                ))
            except Exception:
                continue
        return out

    async def stats(self) -> dict[str, Any]:
        with self._conn() as conn:
            total = conn.execute("SELECT COUNT(*) AS n FROM experiences").fetchone()["n"]
            successes = conn.execute(
                "SELECT COUNT(*) AS n FROM experiences WHERE success = 1"
            ).fetchone()["n"]
            failures = total - successes
            avg_duration = conn.execute(
                "SELECT AVG(duration_s) AS v FROM experiences"
            ).fetchone()["v"] or 0.0
        return {
            "total": total, "successes": successes, "failures": failures,
            "success_rate": (successes / total) if total > 0 else 0.0,
            "avg_duration_s": float(avg_duration),
        }
