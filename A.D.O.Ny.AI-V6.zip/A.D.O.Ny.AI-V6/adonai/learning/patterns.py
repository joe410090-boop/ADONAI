"""Pattern extractor — mines past experiences, plans, designs, and agent routing
for recurring patterns and generates actionable insights.

Enhanced from the basic statistical version to:
  - Use the LLM for natural-language pattern analysis
  - Mine plans and design parameters (not just goals/outcomes)
  - Identify parameter-to-outcome correlations (Pearson)
  - Analyze agent routing patterns and effectiveness
  - Track fitness evolution over discovery campaigns
  - Generate concrete optimization recommendations
  - Fall back to statistical analysis when LLM is unavailable
  - Integrate with the learning loop and knowledge graph
"""
from __future__ import annotations

import json
import logging
import math
import sqlite3
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from adonai.config.settings import Config
from adonai.core.interfaces import LLMClient

log = logging.getLogger(__name__)


class PatternExtractor:
    """Mine the experiences table for execution patterns and generate insights.

    This is the analytical core of the learning loop — it transforms raw
    execution history into actionable intelligence that feeds back into
    the planner, creator, and reviewer agents.
    """

    def __init__(self, config: Config, llm: LLMClient | None = None) -> None:
        self.config = config
        self.db_path = Path(config.memory.sqlite_path)
        self.llm = llm

    def analyze(self) -> dict[str, Any]:
        """Return a summary of patterns observed (statistical analysis).

        This is the fast, LLM-free path.  Use :meth:`analyze_with_llm`
        for natural-language insights.
        """
        if not self.db_path.exists():
            return {"total_experiences": 0, "note": "no database yet"}

        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        try:
            analysis: dict[str, Any] = {
                "analyzed_at": time.time(),
                "analyzed_at_iso": datetime.now(timezone.utc).isoformat(),
            }

            # ── 1. Experience statistics ────────────────────────────────
            analysis["experiences"] = self._analyze_experiences(conn)

            # ── 2. Tool effectiveness ───────────────────────────────────
            analysis["tool_effectiveness"] = self._analyze_tools(conn)

            # ── 3. Goal patterns ────────────────────────────────────────
            analysis["goal_patterns"] = self._analyze_goals(conn)

            # ── 4. Failure analysis ────────────────────────────────────
            analysis["failure_patterns"] = self._analyze_failures(conn)

            # ── 5. Agent routing patterns ──────────────────────────────
            analysis["agent_patterns"] = self._analyze_agents(conn)

            # ── 6. Plan complexity patterns ────────────────────────────
            analysis["plan_patterns"] = self._analyze_plans(conn)

            # ── 7. Parameter correlations ──────────────────────────────
            analysis["parameter_correlations"] = self._analyze_correlations(conn)

            # ── 8. Time patterns ───────────────────────────────────────
            analysis["time_patterns"] = self._analyze_time_patterns(conn)

            # ── 9. Discovery campaign patterns ─────────────────────────
            analysis["discovery_patterns"] = self._analyze_discovery(conn)

            # ── 10. Generate recommendations ───────────────────────────
            analysis["recommendations"] = self._generate_recommendations(analysis)

            return analysis

        finally:
            conn.close()

    async def analyze_with_llm(self) -> dict[str, Any]:
        """Full analysis with LLM-powered natural-language insights.

        Runs the statistical analysis first, then asks the LLM to
        interpret the patterns and generate strategic recommendations.
        Falls back to statistical-only if LLM is unavailable.
        """
        stats = self.analyze()
        if self.llm is None:
            stats["llm_insights"] = None
            return stats

        try:
            # Build a compact summary for the LLM.
            summary = self._build_llm_summary(stats)
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": (
                        "You are the Pattern Analysis Agent.  Analyze the "
                        "execution history and identify actionable patterns. "
                        "Output STRICT JSON:\n"
                        "{\n"
                        '  "key_insights": ["<insight 1>", ...],\n'
                        '  "optimization_opportunities": ["<opportunity 1>", ...],\n'
                        '  "risk_factors": ["<risk 1>", ...],\n'
                        '  "strategic_recommendations": ["<rec 1>", ...],\n'
                        '  "predicted_next_failures": ["<prediction 1>", ...],\n'
                        '  "confidence": 0.0..1.0\n'
                        "}"
                    )},
                    {"role": "user", "content": summary},
                ],
                temperature=0.3,
                max_tokens=1024,
            )
            from adonai.core.json_utils import extract_json
            insights = extract_json(resp.text or "")
            stats["llm_insights"] = insights
        except Exception as e:
            log.warning("LLM pattern analysis failed: %s", e)
            stats["llm_insights"] = None

        return stats

    # ═══════════════════════════════════════════════════════════════════════════
    # Statistical analysis methods
    # ═══════════════════════════════════════════════════════════════════════════

    def _analyze_experiences(self, conn: sqlite3.Connection) -> dict[str, Any]:
        """Overall experience statistics."""
        try:
            total = conn.execute("SELECT COUNT(*) AS n FROM experiences").fetchone()["n"]
            successes = conn.execute(
                "SELECT COUNT(*) AS n FROM experiences WHERE success = 1"
            ).fetchone()["n"]
            failures = total - successes
            avg_duration = conn.execute(
                "SELECT AVG(duration_s) AS v FROM experiences"
            ).fetchone()["v"] or 0.0

            # Status breakdown.
            cur = conn.execute(
                "SELECT outcome, COUNT(*) AS n FROM experiences GROUP BY outcome"
            )
            status_counts = {r["outcome"]: r["n"] for r in cur.fetchall()}

            # Recent trend (last 10 vs previous 10).
            recent = conn.execute(
                "SELECT success FROM experiences ORDER BY created_at DESC LIMIT 10"
            ).fetchall()
            older = conn.execute(
                "SELECT success FROM experiences ORDER BY created_at DESC LIMIT 10 OFFSET 10"
            ).fetchall()
            recent_rate = sum(1 for r in recent if r["success"]) / max(1, len(recent))
            older_rate = sum(1 for r in older if r["success"]) / max(1, len(older))
            trend = "improving" if recent_rate > older_rate + 0.1 else (
                "declining" if recent_rate < older_rate - 0.1 else "stable"
            )

            return {
                "total": total,
                "successes": successes,
                "failures": failures,
                "success_rate": round(successes / total, 4) if total > 0 else 0.0,
                "avg_duration_s": round(float(avg_duration), 2),
                "status_counts": status_counts,
                "recent_success_rate": round(recent_rate, 4),
                "trend": trend,
            }
        except Exception as e:
            log.debug("Experience analysis failed: %s", e)
            return {"total": 0, "error": str(e)}

    def _analyze_tools(self, conn: sqlite3.Connection) -> dict[str, Any]:
        """Tool effectiveness aggregated across all experiences."""
        try:
            cur = conn.execute("SELECT tool_effectiveness FROM experiences LIMIT 500")
            tool_totals: dict[str, list[float]] = {}
            for row in cur.fetchall():
                eff = json.loads(row["tool_effectiveness"] or "{}")
                for tool, score in eff.items():
                    # v8: tool_effectiveness values may be dicts
                    # {calls, success, avg_duration_s} or raw floats.
                    # Extract a numeric score either way.
                    if isinstance(score, dict):
                        # Derive effectiveness from success/call ratio.
                        calls = score.get("calls", 0)
                        success = score.get("success", 0)
                        numeric = (success / calls) if calls > 0 else 0.5
                    else:
                        numeric = float(score)
                    tool_totals.setdefault(tool, []).append(numeric)

            tool_stats: dict[str, dict[str, float]] = {}
            for tool, scores in tool_totals.items():
                tool_stats[tool] = {
                    "avg_score": round(sum(scores) / len(scores), 4),
                    "uses": len(scores),
                    "min": round(min(scores), 4),
                    "max": round(max(scores), 4),
                    "std_dev": round(
                        math.sqrt(
                            sum((s - sum(scores) / len(scores)) ** 2 for s in scores)
                            / len(scores)
                        ), 4
                    ),
                }

            # Rank tools by effectiveness.
            ranked = sorted(
                tool_stats.items(),
                key=lambda x: x[1]["avg_score"],
                reverse=True,
            )
            return {
                "tools": tool_stats,
                "best_tools": [
                    {"name": t, **s} for t, s in ranked[:5]
                ],
                "worst_tools": [
                    {"name": t, **s} for t, s in ranked[-3:] if len(ranked) >= 3
                ],
            }
        except Exception as e:
            log.debug("Tool analysis failed: %s", e)
            return {"tools": {}, "error": str(e)}

    def _analyze_goals(self, conn: sqlite3.Connection) -> dict[str, Any]:
        """Goal keyword patterns and category distribution."""
        try:
            cur = conn.execute("SELECT task_goal, success FROM experiences LIMIT 500")
            word_freq: dict[str, dict[str, int]] = defaultdict(
                lambda: {"success": 0, "failure": 0, "total": 0}
            )
            categories: dict[str, int] = defaultdict(int)

            for r in cur.fetchall():
                success = bool(r["success"])
                goal = r["task_goal"].lower()
                # Categorize.
                if any(w in goal for w in ["code", "write", "implement", "build"]):
                    categories["coding"] += 1
                elif any(w in goal for w in ["search", "research", "find", "news"]):
                    categories["research"] += 1
                elif any(w in goal for w in ["design", "optimize", "engineer"]):
                    categories["engineering"] += 1
                elif any(w in goal for w in ["analyze", "data", "csv", "json"]):
                    categories["analysis"] += 1
                else:
                    categories["general"] += 1

                # Word frequency.
                for w in goal.split():
                    w = w.strip(".,!?\"'")
                    if len(w) < 4:
                        continue
                    word_freq[w]["total"] += 1
                    if success:
                        word_freq[w]["success"] += 1
                    else:
                        word_freq[w]["failure"] += 1

            # Compute success rate per keyword.
            keyword_stats = []
            for word, counts in word_freq.items():
                if counts["total"] >= 2:  # only words appearing 2+ times
                    keyword_stats.append({
                        "keyword": word,
                        "frequency": counts["total"],
                        "success_rate": round(counts["success"] / counts["total"], 4),
                    })
            keyword_stats.sort(key=lambda x: x["frequency"], reverse=True)

            return {
                "categories": dict(categories),
                "top_keywords": keyword_stats[:20],
                "high_failure_keywords": [
                    k for k in keyword_stats if k["success_rate"] < 0.5
                ][:10],
            }
        except Exception as e:
            log.debug("Goal analysis failed: %s", e)
            return {"error": str(e)}

    def _analyze_failures(self, conn: sqlite3.Connection) -> dict[str, Any]:
        """Failure pattern analysis — recurring mistakes + lessons."""
        try:
            cur = conn.execute(
                "SELECT mistakes, lessons, task_goal, duration_s "
                "FROM experiences WHERE success = 0 LIMIT 200"
            )
            lesson_freq: dict[str, int] = {}
            mistake_freq: dict[str, int] = {}
            failure_durations: list[float] = []

            for r in cur.fetchall():
                for lesson in json.loads(r["lessons"] or "[]"):
                    key = lesson[:120].lower()
                    lesson_freq[key] = lesson_freq.get(key, 0) + 1
                for mistake in json.loads(r["mistakes"] or "[]"):
                    key = mistake[:120].lower()
                    mistake_freq[key] = mistake_freq.get(key, 0) + 1
                failure_durations.append(float(r["duration_s"] or 0))

            avg_failure_duration = (
                sum(failure_durations) / len(failure_durations)
                if failure_durations else 0
            )

            return {
                "top_lessons": sorted(
                    lesson_freq.items(), key=lambda t: t[1], reverse=True
                )[:10],
                "top_mistakes": sorted(
                    mistake_freq.items(), key=lambda t: t[1], reverse=True
                )[:10],
                "avg_failure_duration_s": round(avg_failure_duration, 2),
                "total_failures_analyzed": len(failure_durations),
            }
        except Exception as e:
            log.debug("Failure analysis failed: %s", e)
            return {"error": str(e)}

    def _analyze_agents(self, conn: sqlite3.Connection) -> dict[str, Any]:
        """Agent routing patterns — which agents succeed/fail most."""
        try:
            cur = conn.execute(
                "SELECT agent_used, success, duration_s "
                "FROM experiences WHERE agent_used IS NOT NULL LIMIT 500"
            )
            agent_stats: dict[str, dict[str, Any]] = defaultdict(
                lambda: {"total": 0, "successes": 0, "failures": 0, "total_duration": 0.0}
            )
            for r in cur.fetchall():
                agent = r["agent_used"]
                agent_stats[agent]["total"] += 1
                if r["success"]:
                    agent_stats[agent]["successes"] += 1
                else:
                    agent_stats[agent]["failures"] += 1
                agent_stats[agent]["total_duration"] += float(r["duration_s"] or 0)

            result = {}
            for agent, stats in agent_stats.items():
                result[agent] = {
                    "total": stats["total"],
                    "success_rate": round(stats["successes"] / stats["total"], 4),
                    "avg_duration_s": round(stats["total_duration"] / stats["total"], 2),
                }
            return result
        except Exception as e:
            log.debug("Agent analysis failed: %s", e)
            return {"error": str(e)}

    def _analyze_plans(self, conn: sqlite3.Connection) -> dict[str, Any]:
        """Plan complexity patterns — step count vs success rate."""
        try:
            cur = conn.execute(
                "SELECT plan_snapshot, success FROM experiences LIMIT 500"
            )
            step_counts: list[tuple[int, bool]] = []
            for r in cur.fetchall():
                try:
                    plan = json.loads(r["plan_snapshot"] or "{}")
                    steps = plan.get("steps", [])
                    step_counts.append((len(steps), bool(r["success"])))
                except (json.JSONDecodeError, TypeError):
                    continue

            if not step_counts:
                return {"note": "no plan data"}

            # Group by step count.
            by_steps: dict[int, list[bool]] = defaultdict(list)
            for n, success in step_counts:
                by_steps[n].append(success)

            complexity_stats = {}
            for n, successes in sorted(by_steps.items()):
                complexity_stats[n] = {
                    "count": len(successes),
                    "success_rate": round(sum(1 for s in successes if s) / len(successes), 4),
                }

            avg_steps = sum(n for n, _ in step_counts) / len(step_counts)
            return {
                "avg_steps": round(avg_steps, 2),
                "complexity_breakdown": complexity_stats,
                "optimal_step_count": self._find_optimal_complexity(by_steps),
            }
        except Exception as e:
            log.debug("Plan analysis failed: %s", e)
            return {"error": str(e)}

    def _analyze_correlations(self, conn: sqlite3.Connection) -> dict[str, Any]:
        """Parameter-to-outcome correlations (Pearson coefficient).

        Mines plan parameters and correlates them with success/failure
        to identify which parameters matter most.
        """
        try:
            cur = conn.execute(
                "SELECT plan_snapshot, success FROM experiences LIMIT 500"
            )
            param_values: dict[str, list[float]] = defaultdict(list)
            outcomes: list[float] = []

            for r in cur.fetchall():
                try:
                    plan = json.loads(r["plan_snapshot"] or "{}")
                    for step in plan.get("steps", []):
                        params = step.get("parameters", {})
                        for key, value in params.items():
                            if isinstance(value, (int, float)):
                                param_values[key].append(float(value))
                except (json.JSONDecodeError, TypeError):
                    pass
                outcomes.append(1.0 if r["success"] else 0.0)

            correlations = {}
            for param, values in param_values.items():
                if len(values) >= 5 and len(values) == len(outcomes):
                    corr = self._pearson(values, outcomes[:len(values)])
                    if abs(corr) > 0.2:  # only report meaningful correlations
                        correlations[param] = round(corr, 4)

            return {
                "correlations": correlations,
                "positively_correlated": sorted(
                    [(k, v) for k, v in correlations.items() if v > 0],
                    key=lambda x: x[1], reverse=True,
                )[:5],
                "negatively_correlated": sorted(
                    [(k, v) for k, v in correlations.items() if v < 0],
                    key=lambda x: x[1],
                )[:5],
            }
        except Exception as e:
            log.debug("Correlation analysis failed: %s", e)
            return {"error": str(e)}

    def _analyze_time_patterns(self, conn: sqlite3.Connection) -> dict[str, Any]:
        """Temporal patterns — when do tasks succeed/fail most?"""
        try:
            cur = conn.execute(
                "SELECT created_at, success, duration_s FROM experiences LIMIT 500"
            )
            hourly: dict[int, list[bool]] = defaultdict(list)
            durations: list[float] = []
            for r in cur.fetchall():
                hour = datetime.fromtimestamp(r["created_at"], tz=timezone.utc).hour
                hourly[hour].append(bool(r["success"]))
                durations.append(float(r["duration_s"] or 0))

            hourly_stats = {}
            for hour in sorted(hourly.keys()):
                successes = hourly[hour]
                hourly_stats[hour] = {
                    "count": len(successes),
                    "success_rate": round(sum(1 for s in successes if s) / len(successes), 4),
                }

            return {
                "hourly_breakdown": hourly_stats,
                "avg_duration_s": round(sum(durations) / len(durations), 2) if durations else 0,
                "peak_hour": max(hourly_stats.items(), key=lambda x: x[1]["count"])[0]
                    if hourly_stats else None,
            }
        except Exception as e:
            log.debug("Time analysis failed: %s", e)
            return {"error": str(e)}

    def _analyze_discovery(self, conn: sqlite3.Connection) -> dict[str, Any]:
        """Discovery campaign patterns — fitness evolution + best parameters."""
        try:
            # Check if discovery tables exist.
            tables = {
                r[0] for r in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                ).fetchall()
            }
            if "discovery_campaigns" not in tables:
                return {"note": "no discovery campaigns yet"}

            # Campaign statistics.
            campaigns = conn.execute(
                "SELECT * FROM discovery_campaigns ORDER BY updated_at DESC LIMIT 50"
            ).fetchall()

            if not campaigns:
                return {"note": "no campaigns found"}

            total_campaigns = len(campaigns)
            completed = sum(1 for c in campaigns if c["status"] == "completed")
            target_reached = sum(
                1 for c in campaigns
                if c["best_fitness"] and c["target_fitness"]
                and c["best_fitness"] >= c["target_fitness"]
            )
            avg_best_fitness = (
                sum(c["best_fitness"] for c in campaigns if c["best_fitness"])
                / total_campaigns
            )

            # Analyze best designs across campaigns.
            best_designs: list[dict] = []
            for c in campaigns:
                if c["best_design"]:
                    try:
                        design = json.loads(c["best_design"])
                        design["campaign_id"] = c["id"]
                        design["fitness"] = c["best_fitness"]
                        best_designs.append(design)
                    except json.JSONDecodeError:
                        pass

            # Parameter trends across best designs.
            param_trends: dict[str, list[float]] = defaultdict(list)
            for design in best_designs:
                for key, value in design.items():
                    if isinstance(value, (int, float)) and key not in ("fitness", "campaign_id"):
                        param_trends[key].append(float(value))

            param_stats = {}
            for param, values in param_trends.items():
                if len(values) >= 2:
                    param_stats[param] = {
                        "avg": round(sum(values) / len(values), 4),
                        "min": round(min(values), 4),
                        "max": round(max(values), 4),
                        "range": round(max(values) - min(values), 4),
                    }

            return {
                "total_campaigns": total_campaigns,
                "completed": completed,
                "target_reached": target_reached,
                "target_reach_rate": round(target_reached / total_campaigns, 4),
                "avg_best_fitness": round(avg_best_fitness, 4),
                "parameter_trends": param_stats,
                "best_designs": best_designs[:5],
            }
        except Exception as e:
            log.debug("Discovery analysis failed: %s", e)
            return {"error": str(e)}

    # ═══════════════════════════════════════════════════════════════════════════
    # Recommendation generation
    # ═══════════════════════════════════════════════════════════════════════════

    def _generate_recommendations(self, analysis: dict[str, Any]) -> list[str]:
        """Generate concrete, actionable recommendations from the analysis."""
        recs: list[str] = []

        # Experience-based recommendations.
        exp = analysis.get("experiences", {})
        if exp.get("total", 0) >= 5:
            rate = exp.get("success_rate", 0)
            if rate < 0.5:
                recs.append(
                    f"Overall success rate is {rate:.0%} — consider simplifying "
                    f"plans (current avg: {exp.get('avg_duration_s', 0):.1f}s). "
                    f"The planner may be over-complicating tasks."
                )
            trend = exp.get("trend", "stable")
            if trend == "declining":
                recs.append(
                    "Success rate is declining — recent tasks are failing more "
                    "than older ones.  Check if a recent config change caused "
                    "regression."
                )
            elif trend == "improving":
                recs.append("Success rate is improving — the learning loop is working.")

        # Tool-based recommendations.
        tools = analysis.get("tool_effectiveness", {})
        worst = tools.get("worst_tools", [])
        for tool in worst[:2]:
            recs.append(
                f"Tool '{tool['name']}' has low effectiveness "
                f"({tool['avg_score']:.2f}) — consider replacing or improving it."
            )

        # Failure-based recommendations.
        failures = analysis.get("failure_patterns", {})
        top_mistakes = failures.get("top_mistakes", [])
        if top_mistakes:
            mistake, count = top_mistakes[0]
            recs.append(
                f"Most common mistake ({count}x): '{mistake}' — "
                f"add a pre-check or guard for this."
            )

        # Plan complexity recommendations.
        plans = analysis.get("plan_patterns", {})
        optimal = plans.get("optimal_step_count")
        if optimal:
            recs.append(
                f"Optimal plan length is {optimal} steps — "
                f"plans with this length have the highest success rate."
            )

        # Correlation recommendations.
        corr = analysis.get("parameter_correlations", {})
        pos = corr.get("positively_correlated", [])
        neg = corr.get("negatively_correlated", [])
        if pos:
            param, score = pos[0]
            recs.append(
                f"Parameter '{param}' is positively correlated with success "
                f"(r={score:+.2f}) — increase this value in future plans."
            )
        if neg:
            param, score = neg[0]
            recs.append(
                f"Parameter '{param}' is negatively correlated with success "
                f"(r={score:+.2f}) — decrease this value in future plans."
            )

        # Agent routing recommendations.
        agents = analysis.get("agent_patterns", {})
        for agent_name, stats in agents.items():
            if stats.get("success_rate", 1.0) < 0.4 and stats.get("total", 0) >= 3:
                recs.append(
                    f"Agent '{agent_name}' has low success rate "
                    f"({stats['success_rate']:.0%}) — review its system prompt "
                    f"or preferred tools."
                )

        # Discovery recommendations.
        disc = analysis.get("discovery_patterns", {})
        if disc.get("total_campaigns", 0) >= 2:
            reach_rate = disc.get("target_reach_rate", 0)
            if reach_rate < 0.5:
                recs.append(
                    f"Discovery target reach rate is {reach_rate:.0%} — "
                    f"consider lowering target_fitness or increasing max_generations."
                )
            param_trends = disc.get("parameter_trends", {})
            for param, stats in param_trends.items():
                if stats["range"] < 0.1 * stats["avg"]:
                    recs.append(
                        f"Discovery parameter '{param}' is converging "
                        f"(range={stats['range']:.2f}) — the optimizer may "
                        f"be stuck in a local optimum."
                    )

        return recs if recs else ["Insufficient data for recommendations — keep running tasks."]

    def _build_llm_summary(self, stats: dict[str, Any]) -> str:
        """Build a compact summary for LLM analysis."""
        exp = stats.get("experiences", {})
        tools = stats.get("tool_effectiveness", {})
        failures = stats.get("failure_patterns", {})
        plans = stats.get("plan_patterns", {})
        corr = stats.get("parameter_correlations", {})
        agents = stats.get("agent_patterns", {})

        lines = [
            f"EXECUTION HISTORY SUMMARY",
            f"Total experiences: {exp.get('total', 0)}",
            f"Success rate: {exp.get('success_rate', 0):.1%} (trend: {exp.get('trend', '?')})",
            f"Avg duration: {exp.get('avg_duration_s', 0):.1f}s",
            "",
            f"TOOL EFFECTIVENESS:",
        ]
        for tool in tools.get("best_tools", [])[:3]:
            lines.append(f"  {tool['name']}: {tool['avg_score']:.2f} ({tool['uses']} uses)")
        for tool in tools.get("worst_tools", [])[:2]:
            lines.append(f"  {tool['name']}: {tool['avg_score']:.2f} (needs improvement)")

        lines.append("")
        lines.append("FAILURE PATTERNS:")
        for mistake, count in failures.get("top_mistakes", [])[:3]:
            lines.append(f"  ({count}x) {mistake[:80]}")

        lines.append("")
        lines.append(f"PLAN COMPLEXITY: avg={plans.get('avg_steps', '?')} steps, "
                     f"optimal={plans.get('optimal_step_count', '?')}")

        lines.append("")
        lines.append("PARAMETER CORRELATIONS:")
        for param, score in corr.get("positively_correlated", [])[:3]:
            lines.append(f"  {param}: {score:+.2f} (positive)")
        for param, score in corr.get("negatively_correlated", [])[:3]:
            lines.append(f"  {param}: {score:+.2f} (negative)")

        lines.append("")
        lines.append("AGENT PERFORMANCE:")
        for agent, a_stats in list(agents.items())[:5]:
            lines.append(f"  {agent}: {a_stats['success_rate']:.1%} success, "
                        f"{a_stats['avg_duration_s']:.1f}s avg")

        lines.append("")
        lines.append("STATISTICAL RECOMMENDATIONS:")
        for rec in stats.get("recommendations", [])[:5]:
            lines.append(f"  - {rec}")

        lines.append("")
        lines.append("Analyze these patterns and provide strategic insights, "
                     "optimization opportunities, risk factors, and predictions.")

        return "\n".join(lines)

    # ═══════════════════════════════════════════════════════════════════════════
    # Helpers
    # ═══════════════════════════════════════════════════════════════════════════

    @staticmethod
    def _pearson(x: list[float], y: list[float]) -> float:
        """Pearson correlation coefficient."""
        n = len(x)
        if n < 2:
            return 0.0
        sx, sy = sum(x), sum(y)
        sxx = sum(xi * xi for xi in x)
        syy = sum(yi * yi for yi in y)
        sxy = sum(xi * yi for xi, yi in zip(x, y))
        num = n * sxy - sx * sy
        den = math.sqrt((n * sxx - sx * sx) * (n * syy - sy * sy))
        return num / den if den != 0 else 0.0

    @staticmethod
    def _find_optimal_complexity(by_steps: dict[int, list[bool]]) -> int | None:
        """Find the step count with the highest success rate (min 3 samples)."""
        best_rate = -1.0
        best_n = None
        for n, successes in by_steps.items():
            if len(successes) >= 3:
                rate = sum(1 for s in successes if s) / len(successes)
                if rate > best_rate:
                    best_rate = rate
                    best_n = n
        return best_n
