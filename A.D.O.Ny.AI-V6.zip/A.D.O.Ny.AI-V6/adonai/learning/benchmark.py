"""Benchmark runner — periodically measures agent performance on a fixed suite.

The benchmark runner maintains a fixed set of benchmark tasks (configurable),
runs them on a schedule, and tracks the outcomes over time.  This gives
the self-improvement loop a concrete signal: if performance on a benchmark
drops after a change, the change should be rolled back.

Benchmarks are stored in SQLite so historical results survive restarts.
The runner is designed to be called from the LearningLoop or the
ExecutiveController on a schedule (e.g. every 100 tasks or every hour).
"""
from __future__ import annotations

import json
import logging
import sqlite3
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

log = logging.getLogger(__name__)


@dataclass
class BenchmarkTask:
    """A single benchmark task definition."""
    id: str
    goal: str
    expected_keywords: list[str] = field(default_factory=list)
    category: str = "general"
    timeout_s: float = 120.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id, "goal": self.goal,
            "expected_keywords": self.expected_keywords,
            "category": self.category, "timeout_s": self.timeout_s,
        }


@dataclass
class BenchmarkResult:
    """A single benchmark run's outcome."""
    id: str
    task_id: str
    success: bool
    duration_s: float
    output_preview: str = ""
    keyword_coverage: float = 0.0
    error: str | None = None
    run_at: float = field(default_factory=time.time)

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id, "task_id": self.task_id, "success": self.success,
            "duration_s": self.duration_s, "output_preview": self.output_preview,
            "keyword_coverage": self.keyword_coverage, "error": self.error,
            "run_at": self.run_at,
        }


# Default benchmark suite — a small, diverse set of tasks that exercise
# the agent's planning, tool-calling, and synthesis capabilities.
DEFAULT_BENCHMARKS: list[BenchmarkTask] = [
    BenchmarkTask(
        id="bench_math",
        goal="What is 17 * 23? Answer with just the number.",
        expected_keywords=["391"],
        category="math",
        timeout_s=30.0,
    ),
    BenchmarkTask(
        id="bench_greeting",
        goal="Hello, how are you?",
        expected_keywords=["hello", "help"],
        category="conversation",
        timeout_s=30.0,
    ),
    BenchmarkTask(
        id="bench_code",
        goal="Write a Python function that returns the factorial of n.",
        expected_keywords=["def", "factorial", "return"],
        category="coding",
        timeout_s=60.0,
    ),
    BenchmarkTask(
        id="bench_explanation",
        goal="Explain what a recursion is in 2 sentences.",
        expected_keywords=["function", "calls", "itself"],
        category="explanation",
        timeout_s=45.0,
    ),
]


class BenchmarkRunner:
    """Run benchmark tasks + track performance over time.

    Args:
        db_path: SQLite path for persisting benchmark results.
        benchmarks: List of benchmark task definitions.  Defaults to
            :data:`DEFAULT_BENCHMARKS`.
    """

    def __init__(
        self,
        db_path: str | Path | None = None,
        benchmarks: list[BenchmarkTask] | None = None,
    ) -> None:
        self.db_path = Path(db_path) if db_path else None
        self.benchmarks = benchmarks or list(DEFAULT_BENCHMARKS)
        if self.db_path:
            self._init_db()

    def _init_db(self) -> None:
        if not self.db_path:
            return
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS benchmark_results (
                    id TEXT PRIMARY KEY,
                    task_id TEXT NOT NULL,
                    success INTEGER NOT NULL,
                    duration_s REAL NOT NULL,
                    output_preview TEXT NOT NULL DEFAULT '',
                    keyword_coverage REAL NOT NULL DEFAULT 0,
                    error TEXT,
                    run_at REAL NOT NULL
                )
            """)
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_bench_task "
                "ON benchmark_results(task_id)"
            )
            conn.execute(
                "CREATE INDEX IF NOT EXISTS idx_bench_run_at "
                "ON benchmark_results(run_at)"
            )
            conn.commit()

    def _save_result(self, result: BenchmarkResult) -> None:
        if not self.db_path:
            return
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.execute(
                """INSERT INTO benchmark_results
                   (id, task_id, success, duration_s, output_preview,
                    keyword_coverage, error, run_at)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (result.id, result.task_id, int(result.success),
                 result.duration_s, result.output_preview,
                 result.keyword_coverage, result.error, result.run_at),
            )
            conn.commit()

    async def run_one(
        self, benchmark: BenchmarkTask, runtime: Any,
    ) -> BenchmarkResult:
        """Run a single benchmark task against the runtime."""
        import asyncio
        result_id = f"br_{uuid.uuid4().hex[:12]}"
        start = time.time()
        try:
            # Use asyncio.wait_for to enforce the timeout.
            output = await asyncio.wait_for(
                runtime.chat(benchmark.goal),
                timeout=benchmark.timeout_s,
            )
            duration_s = time.time() - start
            output_str = str(output or "")
            # Compute keyword coverage.
            coverage = 0.0
            if benchmark.expected_keywords:
                output_lower = output_str.lower()
                hits = sum(
                    1 for kw in benchmark.expected_keywords
                    if kw.lower() in output_lower
                )
                coverage = hits / len(benchmark.expected_keywords)
            # v9 fix: tighten the success threshold for short keyword
            # lists. Previously `coverage >= 0.5` for all lists — too
            # lenient. For a 2-keyword list (e.g. ["hello", "help"]),
            # hitting 1/2 = 0.5 passed, so "Hello, how are you?" passed
            # the bench_greeting benchmark if the response contained
            # "hello" OR "help" (which any greeting response does). Now:
            #   - keyword lists of length <= 4 require coverage >= 0.75
            #     (so 1/2 fails, 3/4 passes, 4/4 passes).
            #   - keyword lists of length > 4 keep the original 0.5
            #     threshold (these are typically longer explanation
            #     tasks where partial coverage is meaningful).
            threshold = 0.75 if len(benchmark.expected_keywords) <= 4 else 0.5
            success = coverage >= threshold
            return BenchmarkResult(
                id=result_id, task_id=benchmark.id, success=success,
                duration_s=duration_s, output_preview=output_str[:500],
                keyword_coverage=coverage,
            )
        except asyncio.TimeoutError:
            return BenchmarkResult(
                id=result_id, task_id=benchmark.id, success=False,
                duration_s=time.time() - start,
                error=f"timeout after {benchmark.timeout_s}s",
            )
        except Exception as e:
            return BenchmarkResult(
                id=result_id, task_id=benchmark.id, success=False,
                duration_s=time.time() - start,
                error=f"{type(e).__name__}: {e}",
            )

    async def run_all(self, runtime: Any) -> list[BenchmarkResult]:
        """Run all benchmark tasks against the runtime + persist results."""
        results: list[BenchmarkResult] = []
        for bench in self.benchmarks:
            result = await self.run_one(bench, runtime)
            self._save_result(result)
            results.append(result)
            log.info(
                "Benchmark %s: success=%s coverage=%.2f duration=%.1fs",
                bench.id, result.success, result.keyword_coverage,
                result.duration_s,
            )
        return results

    def history(
        self, task_id: str | None = None, limit: int = 50,
    ) -> list[dict[str, Any]]:
        """Return historical benchmark results from SQLite."""
        if not self.db_path:
            return []
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.row_factory = sqlite3.Row
            if task_id:
                rows = conn.execute(
                    "SELECT * FROM benchmark_results WHERE task_id = ? "
                    "ORDER BY run_at DESC LIMIT ?",
                    (task_id, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM benchmark_results "
                    "ORDER BY run_at DESC LIMIT ?",
                    (limit,),
                ).fetchall()
        return [dict(r) for r in rows]

    def summary(self) -> dict[str, Any]:
        """Return aggregate benchmark statistics."""
        if not self.db_path:
            return {"total_runs": 0}
        with sqlite3.connect(str(self.db_path)) as conn:
            total = conn.execute(
                "SELECT COUNT(*) AS n FROM benchmark_results"
            ).fetchone()[0]
            if total == 0:
                return {"total_runs": 0}
            successes = conn.execute(
                "SELECT COUNT(*) AS n FROM benchmark_results WHERE success = 1"
            ).fetchone()[0]
            avg_duration = conn.execute(
                "SELECT AVG(duration_s) AS d FROM benchmark_results"
            ).fetchone()[0] or 0.0
            avg_coverage = conn.execute(
                "SELECT AVG(keyword_coverage) AS c FROM benchmark_results"
            ).fetchone()[0] or 0.0
            # Recent trend (last 10 runs).
            recent = conn.execute(
                "SELECT AVG(success) AS s FROM ("
                "  SELECT success FROM benchmark_results "
                "  ORDER BY run_at DESC LIMIT 10"
                ")"
            ).fetchone()[0] or 0.0
        return {
            "total_runs": total,
            "success_rate": successes / total,
            "avg_duration_s": avg_duration,
            "avg_keyword_coverage": avg_coverage,
            "recent_success_rate": recent,
            "benchmark_count": len(self.benchmarks),
        }
