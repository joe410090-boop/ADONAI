"""LearningLoop — async background loop: observe → analyze → reflect → improve → store → reuse."""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from adonai.config.settings import Config
from adonai.core.models import Plan, Task, TaskResult, TaskStatus
from adonai.learning.experience import ExperienceStore
from adonai.learning.analytics import AnalyticsTracker
from adonai.learning.patterns import PatternExtractor
from adonai.reasoning.reflection import ReflectionReasoner
from adonai.skills.manager import SkillManager

log = logging.getLogger(__name__)


class LearningLoop:
    """Post-completion learning pipeline (runs as a background asyncio task).

    v4 — now invokes the Reflection Engine (Upgrade 4) and Skill Evolver
    (Upgrade 5) in addition to the v3 reflection + skill extraction.
    Also feeds observations into the Knowledge Graph (Upgrade 2) so
    facts accumulate over time.

    All v4 integrations are best-effort: if a v4 subsystem isn't
    configured (None), the loop falls back to the v3 behavior.
    """

    def __init__(
        self,
        config: Config,
        llm: Any,
        skill_manager: SkillManager | None = None,
        analytics: AnalyticsTracker | None = None,
        *,
        reflection_engine: Any = None,
        skill_evolver: Any = None,
        knowledge_graph: Any = None,
        memory_manager: Any = None,
        self_improvement_engine: Any = None,
        prompt_optimizer: Any = None,
        benchmark_runner: Any = None,
        runtime: Any = None,
    ) -> None:
        self.config = config
        self.experiences = ExperienceStore(config)
        self.reflector = ReflectionReasoner(llm) if config.reflection.enabled else None
        self.skills = skill_manager
        self.analytics = analytics or AnalyticsTracker(config)
        self.patterns = PatternExtractor(config, llm=llm)
        # v4 — optional research-grade subsystems.
        self.reflection_engine = reflection_engine
        self.skill_evolver = skill_evolver
        self.knowledge_graph = knowledge_graph
        # v4.1 — memory_manager is wired post-construction by runtime.py
        # so the loop can persist experiences as episodic memories,
        # making them retrievable via MemoryManager.recall_similar().
        self.memory_manager = memory_manager
        # v5 — SelfImprovementEngine, wired so maybe_auto_improve() can
        # be called after each task to detect repeated failures and
        # propose code/prompt improvements. Previously the engine was
        # fully written (737 LOC) but maybe_auto_improve() was NEVER
        # called from anywhere — pure dead code.
        self.self_improvement_engine = self_improvement_engine
        # v5 — PromptOptimizer: records task outcomes against the current
        # prompt variant and periodically generates+promotes new variants.
        # Previously fully implemented but never instantiated in production.
        self.prompt_optimizer = prompt_optimizer
        # v5 — BenchmarkRunner: runs the default benchmark suite every
        # N tasks. Previously fully implemented but never instantiated.
        self.benchmark_runner = benchmark_runner
        # v5 — runtime reference (for BenchmarkRunner.run_all which calls
        # runtime.chat()). Weak ref to avoid circular dependency.
        self._runtime = runtime
        self._task_count = 0  # for interval-based scheduling
        self._queue: asyncio.Queue[tuple[Task, Plan | None, TaskResult]] = asyncio.Queue()
        self._task: asyncio.Task | None = None

    def start(self) -> None:
        if self._task is not None:
            return
        self._task = asyncio.create_task(self._run())

    async def stop(self) -> None:
        if self._task is None:
            return
        await self._queue.put((None, None, None))  # sentinel
        try:
            await asyncio.wait_for(self._task, timeout=5.0)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            self._task.cancel()
        self._task = None

    async def submit(self, task: Task, plan: Plan | None, result: TaskResult) -> None:
        """Enqueue a (task, plan, result) tuple for asynchronous learning."""
        if not (self.config.reflection.enabled or self.config.self_improvement.enabled):
            return
        await self._queue.put((task, plan, result))

    async def _run(self) -> None:
        log.info("LearningLoop started")
        while True:
            try:
                task, plan, result = await self._queue.get()
            except asyncio.CancelledError:
                break
            if task is None:
                break
            try:
                await self._process(task, plan, result)
            except Exception as e:
                log.warning("LearningLoop processing error: %s", e)
        log.info("LearningLoop stopped")

    async def _process(self, task: Task, plan: Plan | None, result: TaskResult) -> None:
        # ── PERF OPT: Skip heavy reflection + KG for simple tasks ──────
        # TRIVIAL and SIMPLE tasks don't benefit from post-hoc LLM reflection,
        # knowledge graph extraction, or self-improvement analysis. A simple
        # task like "what's the weather?" needs 1 LLM call — adding 4 more
        # after completion triples latency for no gain.
        is_simple = task.complexity.value in ("trivial", "simple")
        if is_simple:
            log.debug(
                "LearningLoop: skipping reflection+KG for %s task %s",
                task.complexity.value, task.id,
            )
            # Still record analytics for simple tasks (cheap, no LLM call).
            try:
                self.analytics.record("task.duration_s", result.duration_s,
                                       {"status": result.status.value})
                self.analytics.record("task.success",
                                       1.0 if result.status == TaskStatus.COMPLETED else 0.0,
                                       {"agent": task.assigned_agent or "unknown"})
                self.analytics.record("task.steps_executed", result.steps_executed)
            except Exception as e:
                log.debug("Analytics recording failed: %s", e)
            self._task_count += 1
            return

        # 1. Reflect (optional — costs an LLM call).
        lessons: list[str] = list(result.lessons or [])
        mistakes: list[str] = []
        if self.reflector is not None:
            try:
                refl = await self.reflector.reason(
                    task, {"output": result.output}
                )
                # Only record REAL issues, not reflection subsystem failures.
                issues = refl.get("issues", [])
                for issue in issues:
                    # Filter out reflection parse failures — those are
                    # subsystem noise, not task mistakes.
                    if not issue.startswith("reflection_failed:"):
                        mistakes.append(issue)
                lessons.extend(mistakes)
                # v7 fix: apply the revised conclusion from reflection.
                # Previously the revised conclusion was computed by
                # ReflectionReasoner.reason() but discarded — only issues
                # were read. Now we update the result's output with the
                # revised version so the user sees the improved answer.
                revised = refl.get("conclusion")
                if (
                    revised
                    and isinstance(revised, str)
                    and revised.strip()
                    and revised != result.output
                ):
                    result.output = revised
                    log.debug(
                        "LearningLoop: reflection revised result output "
                        "(%d → %d chars)",
                        len(result.output or ""), len(revised),
                    )
            except Exception as e:
                # Don't record reflection failures as mistakes.
                log.debug("Reflection failed (non-fatal): %s", e)

        # 1b. v4 — Run the structured Reflection Engine (Upgrade 4).
        # This produces persistent Lesson objects that future plans can
        # consult via `recall_lessons(domain=...)`.
        if self.reflection_engine is not None:
            try:
                v4_lessons = await self.reflection_engine.reflect(
                    task, plan, result,
                )
                # Pull lesson text into the result.lessons list so the
                # experience record benefits from both v3 + v4 reflections.
                for lesson in v4_lessons:
                    if lesson.lesson and lesson.lesson not in lessons:
                        lessons.append(lesson.lesson)
            except Exception as e:
                log.debug("v4 Reflection Engine failed (non-fatal): %s", e)

        # 2. Persist the experience.
        # v6 fix: compute tool_effectiveness from ToolRegistry.all_stats()
        # and pass it to record(). Previously this was always omitted, so
        # the experiences.tool_effectiveness column was always '{}' —
        # making the PatternExtractor's tool-warning branch permanently
        # silent (it reads this column to detect tools with low avg_score).
        tool_effectiveness: dict[str, dict] = {}
        if self._runtime is not None:
            try:
                tools = getattr(self._runtime, "tools", None)
                if tools is not None and hasattr(tools, "all_stats"):
                    all_stats = tools.all_stats()
                    # Only include tools that were actually used in this task.
                    # We detect usage by checking the plan's steps for tool names.
                    used_tools: set[str] = set()
                    if plan is not None:
                        for step in plan.steps:
                            if step.tool and step.status.value == "completed":
                                used_tools.add(step.tool)
                    for tool_name, stats in all_stats.items():
                        # Include all tools with stats, but mark which were
                        # used in this task. This gives the pattern extractor
                        # enough data to compute effectiveness over time.
                        if isinstance(stats, dict) and stats.get("calls", 0) > 0:
                            tool_effectiveness[tool_name] = {
                                "calls": stats.get("calls", 0),
                                "success": stats.get("success", 0),
                                "fail": stats.get("fail", 0),
                                "avg_duration_s": (
                                    stats.get("total_s", 0) / stats["calls"]
                                    if stats.get("calls") else 0.0
                                ),
                                "used_in_this_task": tool_name in used_tools,
                            }
            except Exception as e:
                log.debug("tool_effectiveness computation failed: %s", e)
        try:
            await self.experiences.record(
                task_goal=task.goal,
                task_complexity=task.complexity.value,
                plan_id=plan.id if plan else "no_plan",
                plan_snapshot=plan.model_dump(mode="json") if plan else {},
                result=result,
                mistakes=mistakes, lessons=lessons,
                tool_effectiveness=tool_effectiveness or None,
                agent_used=task.assigned_agent,
            )
        except Exception as e:
            log.warning("Experience recording failed: %s", e)

        # 2a. ALSO write an episodic Memory entry with the experience
        # metadata so MemoryManager.recall_similar() can find it later.
        # Previously recall_similar() always returned [] because nothing
        # wrote experiences with the `experience` metadata key — they
        # were only in the separate ExperienceStore.  Now the planner's
        # recall_similar() call (planner.py:52) actually returns results.
        if self.memory_manager is not None:
            try:
                from adonai.core.models import Memory, MemoryType
                exp_data = {
                    "task_goal": task.goal,
                    "success": result.status.value == "completed",
                    "lessons": lessons,
                    "mistakes": mistakes,
                    "agent_used": task.assigned_agent,
                    "duration_s": result.duration_s,
                }
                content = (
                    f"Task: {task.goal}\n"
                    f"Success: {exp_data['success']}\n"
                    f"Lessons: {'; '.join(lessons) or 'none'}"
                )
                await self.memory_manager.add(Memory(
                    type=MemoryType.EPISODIC,
                    content=content,
                    importance=0.8 if exp_data["success"] else 0.6,
                    source="learning_loop",
                    session_id=task.session_id,
                    metadata={"experience": exp_data},
                ))
            except Exception as e:
                log.debug("Episodic memory write failed (non-fatal): %s", e)

        # Analyze patterns and log actionable insights.
        # v9 fix: removed the dead `if asyncio.iscoroutine(analysis):
        # analysis = await analysis` guard. PatternExtractor.analyze()
        # is a sync method (in-memory dict/list math, no I/O) — the
        # guard was originally defensive but never actually triggered
        # because analyze() never returned a coroutine. Keeping it
        # implied the API might be async, which misled readers. If a
        # future refactor makes analyze() async, the call site will
        # need updating anyway (a sync call to an async function
        # returns a coroutine but never executes it — the guard was
        # masking that bug class, not fixing it). We now call it
        # directly as a sync function.
        try:
            analysis = self.patterns.analyze()
            if analysis:
                # v5 fix: use the CORRECT keys returned by PatternExtractor.
                # Previously loop.py read analysis["tool_effectiveness"].items()
                # expecting tool_name → {failure_rate, count}, but the actual
                # structure is {"tools": {...}, "best_tools": [...], "worst_tools": [...]}.
                # The warning block was permanently silent. Now it fires.
                tool_eff = analysis.get("tool_effectiveness", {})
                tools_map = tool_eff.get("tools", {}) if isinstance(tool_eff, dict) else {}
                for tool_name, stats in tools_map.items():
                    if isinstance(stats, dict):
                        uses = stats.get("uses", 0)
                        avg_score = stats.get("avg_score", 1.0)
                        if uses >= 3 and avg_score < 0.5:
                            log.warning(
                                "Learning: tool '%s' has low avg_score %.2f (n=%d)",
                                tool_name, avg_score, uses,
                            )
                # Log trend — v5 fix: analysis["experiences"]["trend"] is a string,
                # not analysis["experience_trend"]["direction"].
                exp_data = analysis.get("experiences", {})
                if isinstance(exp_data, dict):
                    trend = exp_data.get("trend", "")
                    if trend == "declining":
                        log.warning("Learning: success rate is DECLINING")
                    elif trend == "improving":
                        log.info("Learning: success rate is IMPROVING")
            # v8: Feed recommendations back into the planner's memory
            # so the planner can adjust its strategy based on learning insights.
            recommendations = analysis.get("recommendations", [])
            if recommendations and self._runtime is not None:
                try:
                    from adonai.core.models import Memory, MemoryType
                    rec_content = "Learned recommendations:\n" + "\n".join(f"- {r}" for r in recommendations[:10])
                    rec_memory = Memory(
                        type=MemoryType.PROCEDURAL,
                        content=rec_content,
                        importance=0.7,
                        confidence=0.8,
                        tags=["learning", "recommendations", "auto"],
                        source="learning_loop",
                    )
                    await self._runtime.memory.add(rec_memory)
                    log.debug("Fed %d recommendations into procedural memory", len(recommendations))
                except Exception as e:
                    log.debug("Failed to feed recommendations to memory: %s", e)
        except Exception as e:
            log.debug("Pattern analysis failed: %s", e)

        # 3. Extract a skill (only on success).
        if (self.skills is not None and plan is not None
                and result.status.value == "completed"
                and self.config.agent.auto_extract_skills):
            try:
                await self.skills.extract_from_task(task, plan, result)
            except Exception as e:
                log.warning("Skill extraction failed: %s", e)

        # 3b. v4 — Run the Skill Evolver (Upgrade 5) to mine patterns
        # and promote repeated successes to callable tools.
        if self.skill_evolver is not None:
            try:
                cycle_result = await self.skill_evolver.run_cycle()
                if cycle_result.get("promoted", 0) > 0:
                    log.info(
                        "v4 Skill Evolver: promoted %d skill(s)",
                        cycle_result["promoted"],
                    )
            except Exception as e:
                log.debug("v4 Skill Evolver cycle failed (non-fatal): %s", e)

        # 3c. v4 — Feed observations into the Knowledge Graph (Upgrade 2)
        # so facts accumulate over time.  We feed both the task goal and
        # (truncated) result output as observations.
        if self.knowledge_graph is not None and self.config.knowledge_graph.enabled:
            try:
                obs_text = (
                    f"Task: {task.goal}\n"
                    f"Outcome: {result.status.value}\n"
                    f"Output: {str(result.output)[:500] if result.output else '(empty)'}"
                )
                await self.knowledge_graph.extract_from_text(
                    obs_text,
                    source=f"task:{task.id}",
                    source_kind="observation",
                    max_entities=self.config.knowledge_graph.max_entities_per_observation,
                )
            except Exception as e:
                log.debug("v4 KG observation feed failed (non-fatal): %s", e)

        # 4. Periodically retire low-performing skills.
        if self.skills is not None and self.config.skills.auto_extract:
            try:
                retired = await self.skills.retire_low_performers()
                if retired > 0:
                    log.info("Retired %d low-performing skills", retired)
            except Exception as e:
                log.warning("Skill retirement failed: %s", e)

        # 5. Record analytics.
        try:
            self.analytics.record("task.duration_s", result.duration_s,
                                   {"status": result.status.value})
            self.analytics.record("task.success",
                                   1.0 if result.status == TaskStatus.COMPLETED else 0.0,
                                   {"agent": task.assigned_agent or "unknown"})
            self.analytics.record("task.steps_executed", result.steps_executed)
        except Exception as e:
            log.warning("Analytics recording failed: %s", e)

        # 6. v5: Trigger self-improvement if conditions warrant.
        # Previously SelfImprovementEngine.maybe_auto_improve() was
        # defined (safety/self_improvement.py:599) but NEVER called
        # from anywhere. Now the LearningLoop calls it after every task
        # so the engine can detect repeated failures and propose
        # code/prompt improvements. The engine itself decides whether
        # to actually run (based on recent failure rate thresholds).
        if self.self_improvement_engine is not None:
            try:
                # Compute recent success rate from the experience store.
                # v9 fix: maybe_auto_improve now triggers if rate < 0.7
                # (configurable) AND there are >= min_tasks (default 5)
                # recent experiences. Previously the threshold was 0.5
                # (catastrophic) and min_tasks was 10, so the pipeline
                # essentially never fired. We also now pass tool_registry
                # so observe_bottlenecks can find tool-call bottlenecks
                # (the analytics-only path always returned []).
                recent = []
                try:
                    recent = await self.experiences.recent(limit=20)
                except Exception:
                    pass
                if recent:
                    successes = sum(1 for e in recent if getattr(e, "success", False))
                    success_rate = successes / len(recent)
                    # v9: pass tool_registry from runtime if available.
                    _tool_reg = getattr(self._runtime, "tools", None) if self._runtime else None
                    await self.self_improvement_engine.maybe_auto_improve(
                        recent_success_rate=success_rate,
                        min_tasks=5,
                        analytics=self.analytics,
                        tool_registry=_tool_reg,
                    )
            except Exception as e:
                log.debug("SelfImprovement maybe_auto_improve failed (non-fatal): %s", e)

        # 7. v5: PromptOptimizer — record this task's outcome against the
        # current prompt variant. Every N tasks, generate new variants and
        # promote the best one. Previously the PromptOptimizer was fully
        # implemented (239 LOC) but NEVER instantiated in production.
        self._task_count += 1
        if self.prompt_optimizer is not None:
            try:
                # Record the outcome against the current variant (if any).
                if self.prompt_optimizer._current is not None:
                    self.prompt_optimizer.record_outcome(
                        self.prompt_optimizer._current,
                        success=(result.status == TaskStatus.COMPLETED),
                        confidence=result.confidence or 0.5,
                    )
                # Every optimization_interval_tasks, generate + score + promote.
                interval = getattr(
                    getattr(self.config, "prompt_optimizer", None),
                    "optimization_interval_tasks", 50,
                )
                if self._task_count % interval == 0:
                    # v6 fix: retrieve the base prompt correctly. Previously
                    # getattr(tca, "system_prompt", base_prompt) looked for a
                    # non-existent attribute — ToolCallingAgent builds its
                    # system prompt dynamically via _build_system_prompt().
                    # We now call that method (or use a cached version).
                    base_prompt = "You are ADONAI, an autonomous AI assistant."
                    if self._runtime is not None:
                        tca = getattr(self._runtime, "tool_calling_agent", None)
                        if tca is not None:
                            # Try the property first (v6), then the method,
                            # then the attribute (legacy).
                            if hasattr(tca, "system_prompt") and isinstance(
                                getattr(type(tca), "system_prompt", None), property
                            ):
                                base_prompt = tca.system_prompt or base_prompt
                            elif hasattr(tca, "_build_system_prompt"):
                                try:
                                    base_prompt = await tca._build_system_prompt()
                                except Exception:
                                    pass
                            elif hasattr(tca, "system_prompt"):
                                base_prompt = getattr(tca, "system_prompt", base_prompt) or base_prompt
                    variants = await self.prompt_optimizer.generate_variants(base_prompt)
                    if variants:
                        log.info(
                            "PromptOptimizer: generated %d variants (round %d)",
                            len(variants), self._task_count // interval,
                        )
                        # v6 fix: actually PROMOTE the best variant. Previously
                        # variants were generated and immediately discarded —
                        # maybe_promote() was never called. We now score each
                        # variant by running a quick self-evaluation, then
                        # promote the best one if it beats the current prompt.
                        best_variant = None
                        best_score = -1.0
                        for v in variants:
                            # v8: Score variants by structural quality, not
                            # just length.  Reward variants that contain
                            # concrete directives, examples, or constraints.
                            prompt_lower = v.prompt.lower()
                            structural_signals = sum([
                                0.15 if "example" in prompt_lower or "for instance" in prompt_lower else 0,
                                0.10 if "must" in prompt_lower or "always" in prompt_lower or "never" in prompt_lower else 0,
                                0.10 if "step" in prompt_lower or "first" in prompt_lower else 0,
                                0.10 if "output" in prompt_lower or "return" in prompt_lower or "format" in prompt_lower else 0,
                                0.05 if len(v.prompt) > 500 else 0,  # reasonable length
                            ])
                            estimated = min(1.0, 0.3 + structural_signals)
                            v.score = estimated
                            if estimated > best_score:
                                best_score = estimated
                                best_variant = v
                        if best_variant is not None:
                            promoted = self.prompt_optimizer.maybe_promote(best_variant)
                            if promoted:
                                log.info(
                                    "PromptOptimizer: promoted variant %s "
                                    "(score=%.3f) — will apply to future tasks",
                                    best_variant.id, best_variant.score,
                                )
            except Exception as e:
                log.debug("PromptOptimizer step failed (non-fatal): %s", e)

        # 8. v5: BenchmarkRunner — run the benchmark suite every N tasks.
        # Previously the BenchmarkRunner was fully implemented (272 LOC) but
        # NEVER instantiated in production. Now it runs periodically so
        # performance trends are tracked over time.
        # v6: compare with previous round's success rate and trigger
        # SelfImprovement rollback if there's a regression (>20% drop).
        if self.benchmark_runner is not None and self._runtime is not None:
            try:
                bench_interval = getattr(
                    getattr(self.config, "benchmark", None),
                    "interval_tasks", 100,
                )
                if self._task_count % bench_interval == 0:
                    log.info(
                        "BenchmarkRunner: starting benchmark round (round %d)",
                        self._task_count // bench_interval,
                    )
                    # v6: get previous round's summary for comparison.
                    prev_success_rate: float | None = None
                    try:
                        summary = self.benchmark_runner.summary()
                        prev_success_rate = summary.get("recent_success_rate")
                    except Exception:
                        pass
                    results = await self.benchmark_runner.run_all(self._runtime)
                    successes = sum(1 for r in results if r.success)
                    current_rate = successes / len(results) if results else 0.0
                    log.info(
                        "BenchmarkRunner: %d/%d benchmarks passed (%.1f%%)",
                        successes, len(results), current_rate * 100,
                    )
                    # v6: regression detection — if success rate dropped >20%
                    # vs the previous round, trigger rollback of the last
                    # merged self-improvement patch (if any).
                    if (prev_success_rate is not None
                            and prev_success_rate > 0
                            and current_rate < prev_success_rate - 0.20):
                        log.warning(
                            "BenchmarkRunner: REGRESSION detected — "
                            "success rate dropped from %.1f%% to %.1f%%. "
                            "Attempting rollback of last self-improvement patch.",
                            prev_success_rate * 100, current_rate * 100,
                        )
                        if self.self_improvement_engine is not None:
                            try:
                                # Find the most recently merged patch.
                                patches = getattr(
                                    self.self_improvement_engine, "_patches", {}
                                ) or {}
                                from adonai.safety.self_improvement import PatchStatus
                                merged = [
                                    p for p in patches.values()
                                    if getattr(p, "status", None) == PatchStatus.MERGED
                                ]
                                if merged:
                                    merged.sort(
                                        key=lambda p: getattr(p, "merged_at", 0),
                                        reverse=True,
                                    )
                                    last_patch = merged[0]
                                    await self.self_improvement_engine.rollback(last_patch)
                                    log.warning(
                                        "BenchmarkRunner: rolled back patch %s "
                                        "due to benchmark regression",
                                        last_patch.id,
                                    )
                            except Exception as e:
                                log.debug(
                                    "BenchmarkRunner rollback attempt failed: %s", e
                                )
            except Exception as e:
                log.debug("BenchmarkRunner step failed (non-fatal): %s", e)
