"""Prompt optimizer — auto-tunes system prompts based on task outcomes.

The prompt optimizer tracks which system-prompt variants produce the
best task outcomes (highest confidence, lowest failure rate) and
promotes the winner.  It runs as part of the self-improvement cycle.

Pipeline:
  1. Generate N variants of the current system prompt (LLM-driven
     paraphrasing, with temperature 0.8 for diversity).
  2. Run each variant on a small benchmark sample.
  3. Score each variant by mean confidence × success_rate.
  4. Promote the best-scoring variant as the new "current" prompt.
  5. Persist the history so future optimisation rounds build on it.

The optimizer is conservative: it only promotes a variant if it beats
the current prompt by a margin (default 5%).  This prevents churn from
noise.
"""
from __future__ import annotations

import json
import logging
import sqlite3
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from adonai.core.interfaces import LLMClient

log = logging.getLogger(__name__)


@dataclass
class PromptVariant:
    """A single system-prompt variant + its measured performance."""
    id: str
    prompt: str
    score: float = 0.0
    sample_count: int = 0
    success_count: int = 0
    mean_confidence: float = 0.0
    created_at: float = field(default_factory=time.time)
    is_current: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id, "prompt": self.prompt, "score": self.score,
            "sample_count": self.sample_count, "success_count": self.success_count,
            "mean_confidence": self.mean_confidence,
            "created_at": self.created_at, "is_current": self.is_current,
        }


class PromptOptimizer:
    """Auto-tune system prompts based on task outcomes.

    Args:
        llm: The LLM client (used for variant generation).
        db_path: SQLite path for persisting variant history.
        promotion_margin: Minimum score improvement (0..1) required to
            promote a variant over the current prompt.  Default 0.05.
        max_variants: Maximum variants per optimisation round.  Default 3.
    """

    def __init__(
        self,
        llm: LLMClient,
        db_path: str | Path | None = None,
        *,
        promotion_margin: float = 0.05,
        max_variants: int = 3,
    ) -> None:
        self.llm = llm
        self.db_path = Path(db_path) if db_path else None
        self.promotion_margin = promotion_margin
        self.max_variants = max_variants
        self._current: PromptVariant | None = None
        self._history: list[PromptVariant] = []
        if self.db_path:
            self._init_db()
            self._load_current()

    def _init_db(self) -> None:
        if not self.db_path:
            return
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS prompt_variants (
                    id TEXT PRIMARY KEY,
                    prompt TEXT NOT NULL,
                    score REAL NOT NULL DEFAULT 0,
                    sample_count INTEGER NOT NULL DEFAULT 0,
                    success_count INTEGER NOT NULL DEFAULT 0,
                    mean_confidence REAL NOT NULL DEFAULT 0,
                    created_at REAL NOT NULL,
                    is_current INTEGER NOT NULL DEFAULT 0
                )
            """)
            conn.commit()

    def _load_current(self) -> None:
        if not self.db_path:
            return
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.row_factory = sqlite3.Row
            row = conn.execute(
                "SELECT * FROM prompt_variants WHERE is_current = 1 "
                "ORDER BY created_at DESC LIMIT 1"
            ).fetchone()
        if row:
            self._current = PromptVariant(
                id=row["id"], prompt=row["prompt"], score=row["score"],
                sample_count=row["sample_count"],
                success_count=row["success_count"],
                mean_confidence=row["mean_confidence"],
                created_at=row["created_at"], is_current=True,
            )

    def _save_variant(self, variant: PromptVariant) -> None:
        if not self.db_path:
            return
        with sqlite3.connect(str(self.db_path)) as conn:
            conn.execute(
                """INSERT OR REPLACE INTO prompt_variants
                   (id, prompt, score, sample_count, success_count,
                    mean_confidence, created_at, is_current)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (variant.id, variant.prompt, variant.score,
                 variant.sample_count, variant.success_count,
                 variant.mean_confidence, variant.created_at,
                 1 if variant.is_current else 0),
            )
            conn.commit()

    @property
    def current_prompt(self) -> str | None:
        """Return the current best system prompt, or None if not yet optimised."""
        return self._current.prompt if self._current else None

    async def generate_variants(
        self, base_prompt: str, n: int | None = None,
    ) -> list[PromptVariant]:
        """Generate N paraphrased variants of the base prompt.

        Uses the LLM with high temperature for diversity.  Each variant
        is a distinct rephrasing that preserves the intent.
        """
        n = n or self.max_variants
        try:
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": (
                        f"Generate {n} distinct paraphrased versions of the "
                        f"following system prompt.  Each version should "
                        f"preserve the intent but use different wording, "
                        f"structure, and emphasis.  Output JSON: "
                        f'{{"variants": ["...", "...", "..."]}}'
                    )},
                    {"role": "user", "content": base_prompt},
                ],
                temperature=0.8, max_tokens=1024,
            )
            from adonai.core.json_utils import extract_json
            data = extract_json(resp.text or "")
            variants_raw = data.get("variants", [])
            if not isinstance(variants_raw, list):
                return []
            results: list[PromptVariant] = []
            for i, v in enumerate(variants_raw[:n]):
                if not isinstance(v, str) or not v.strip():
                    continue
                results.append(PromptVariant(
                    id=f"pv_{uuid.uuid4().hex[:12]}",
                    prompt=v.strip(),
                ))
            return results
        except Exception as e:
            log.warning("Prompt variant generation failed: %s", e)
            return []

    def record_outcome(
        self, variant: PromptVariant, *, success: bool, confidence: float,
    ) -> None:
        """Record a task outcome for a variant and update its score."""
        variant.sample_count += 1
        if success:
            variant.success_count += 1
        # Update mean confidence via running average.
        old_sum = variant.mean_confidence * (variant.sample_count - 1)
        variant.mean_confidence = (old_sum + confidence) / variant.sample_count
        # Score = success_rate × mean_confidence.
        success_rate = variant.success_count / variant.sample_count
        variant.score = success_rate * variant.mean_confidence
        self._save_variant(variant)

    def maybe_promote(self, candidate: PromptVariant) -> bool:
        """Promote the candidate if it beats the current prompt by margin.

        Returns True if the candidate was promoted.
        """
        if self._current is None:
            # No current prompt — promote unconditionally.
            candidate.is_current = True
            self._current = candidate
            self._save_variant(candidate)
            log.info(
                "PromptOptimizer: promoted variant %s (score=%.3f) as initial",
                candidate.id, candidate.score,
            )
            return True
        if candidate.score >= self._current.score + self.promotion_margin:
            self._current.is_current = False
            self._save_variant(self._current)
            candidate.is_current = True
            self._current = candidate
            self._save_variant(candidate)
            log.info(
                "PromptOptimizer: promoted variant %s (score=%.3f > current %.3f)",
                candidate.id, candidate.score, self._current.score,
            )
            return True
        return False

    def stats(self) -> dict[str, Any]:
        """Return optimiser statistics."""
        return {
            "has_current": self._current is not None,
            "current_score": self._current.score if self._current else 0.0,
            "current_sample_count": self._current.sample_count if self._current else 0,
            "promotion_margin": self.promotion_margin,
            "max_variants": self.max_variants,
        }
