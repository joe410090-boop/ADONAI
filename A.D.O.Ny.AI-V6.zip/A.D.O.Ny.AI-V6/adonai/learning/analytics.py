"""Analytics tracker — runtime metric collection."""
from __future__ import annotations

import json
import logging
import sqlite3
import time
from pathlib import Path
from typing import Any

from adonai.config.settings import Config

log = logging.getLogger(__name__)


class AnalyticsTracker:
    """Tracks runtime metrics: task success rate, tool effectiveness, etc."""

    def __init__(self, config: Config) -> None:
        self.config = config
        self.db_path = Path(config.analytics.metrics_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_schema()
        self._enabled = config.analytics.enabled

    def _conn(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_schema(self) -> None:
        with self._conn() as conn:
            conn.execute("""CREATE TABLE IF NOT EXISTS metrics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                value REAL NOT NULL,
                tags TEXT NOT NULL DEFAULT '{}',
                timestamp REAL NOT NULL
            )""")
            # v9 fix: run migration BEFORE creating indexes that depend on
            # the migrated columns. Previously CREATE INDEX idx_metrics_ts
            # ran before the timestamp column was added, causing
            # "no such column: timestamp" on legacy tables.
            try:
                cols = {row["name"] for row in conn.execute("PRAGMA table_info(metrics)").fetchall()}
                if "tags" not in cols:
                    conn.execute(
                        "ALTER TABLE metrics ADD COLUMN tags TEXT NOT NULL DEFAULT '{}'"
                    )
                    log.info("Analytics: migrated metrics table — added `tags` column")
                if "timestamp" not in cols:
                    conn.execute(
                        "ALTER TABLE metrics ADD COLUMN timestamp REAL NOT NULL DEFAULT 0"
                    )
                    log.info("Analytics: migrated metrics table — added `timestamp` column")
                if "value" not in cols:
                    conn.execute(
                        "ALTER TABLE metrics ADD COLUMN value REAL NOT NULL DEFAULT 0"
                    )
                    log.info("Analytics: migrated metrics table — added `value` column")
                if "name" not in cols:
                    conn.execute(
                        "ALTER TABLE metrics ADD COLUMN name TEXT NOT NULL DEFAULT ''"
                    )
                    log.info("Analytics: migrated metrics table — added `name` column")
            except Exception as e:
                log.debug("Analytics migration check failed (non-fatal): %s", e)
            # Now create indexes (after migration so columns exist).
            conn.execute("CREATE INDEX IF NOT EXISTS idx_metrics_name ON metrics(name)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_metrics_ts ON metrics(timestamp)")
            conn.commit()

    def record(self, name: str, value: float, tags: dict[str, Any] | None = None) -> None:
        if not self._enabled:
            return
        with self._conn() as conn:
            conn.execute(
                "INSERT INTO metrics (name, value, tags, timestamp) VALUES (?, ?, ?, ?)",
                (name, value, json.dumps(tags or {}, default=str), time.time()),
            )
            conn.commit()

    def get_series(self, name: str, limit: int = 100) -> list[dict[str, Any]]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM metrics WHERE name = ? ORDER BY timestamp DESC LIMIT ?",
                (name, limit),
            ).fetchall()
        return [{"name": r["name"], "value": r["value"],
                 "tags": json.loads(r["tags"]), "timestamp": r["timestamp"]}
                for r in rows]

    def summary(self) -> dict[str, Any]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT name, COUNT(*) AS n, AVG(value) AS avg, MIN(value) AS min, MAX(value) AS max "
                "FROM metrics GROUP BY name"
            ).fetchall()
        return {
            r["name"]: {"count": r["n"], "avg": r["avg"], "min": r["min"], "max": r["max"]}
            for r in rows
        }
