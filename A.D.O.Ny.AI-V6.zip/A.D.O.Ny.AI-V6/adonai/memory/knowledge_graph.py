"""Knowledge graph — graph-based memory layer over entities + relations.

v4 Upgrade 2: the knowledge graph now stores **confidence scores** and
**evidence records** on every entity and relation, supports LLM-driven
entity/relation extraction from arbitrary text, and exposes a
``context_for()`` helper that the planner consults before generating
plans.

Stored in SQLite (no external graph DB required).  Supports:

* Entity CRUD with confidence + evidence tracking
* Relation CRUD with confidence + evidence tracking
* Graph traversal (BFS up to N hops) with confidence-weighted edges
* Semantic retrieval (find entities by name/type)
* Context generation (collect neighborhood for LLM prompt)
* Fact confidence (Bayesian-style update from multiple evidence sources)
* Evidence tracking (every fact links back to its sources)
* LLM-driven entity/relation extraction from free text
"""
from __future__ import annotations

import json
import logging
import re
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from uuid import uuid4

from adonai.core.exceptions import KnowledgeGraphError
from adonai.core.models import Entity, Evidence, KnowledgeGraphSnapshot, Relation

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Entity-extraction prompt
# ──────────────────────────────────────────────────────────────────────────────

_EXTRACTION_SYSTEM_PROMPT = (
    "You are an information-extraction agent for a knowledge graph.\n"
    "Given an observation (text from the web, a file, an agent, or an "
    "experiment), extract entities and relations as JSON.\n\n"
    "Output schema:\n"
    "{\n"
    '  "entities": [\n'
    '    {"name": str, "type": "concept"|"project"|"skill"|"file"|"goal"|'
    '"event"|"person"|"tool"|"agent"|"fact", "description": str?}\n'
    "  ],\n"
    '  "relations": [\n'
    '    {"source": str, "target": str, "type": "depends_on"|"part_of"|'
    '"created_by"|"uses"|"knows"|"relates_to"|"derived_from"|"produced"|'
    '"consumed"|"is_a"|"has_property"|"measured_at", "weight": float?}\n'
    "  ]\n"
    "}\n\n"
    "Rules:\n"
    "1. Use the SAME entity name strings in relations as in entities.\n"
    "2. Only extract entities that are explicitly mentioned or strongly "
    "implied.\n"
    "3. Prefer 'is_a' for taxonomic relations (e.g. OpenFOAM is_a CFD Solver).\n"
    "4. Return ONLY the JSON.  No prose, no markdown fences."
)


# ──────────────────────────────────────────────────────────────────────────────
# KnowledgeGraph (v4)
# ──────────────────────────────────────────────────────────────────────────────


class KnowledgeGraph:
    """SQLite-backed knowledge graph with confidence + evidence tracking."""

    def __init__(
        self,
        db_path: str | Path,
        *,
        llm: Any = None,
        default_confidence: float = 0.5,
    ) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self.llm = llm
        self.default_confidence = default_confidence
        # v7: persistent connection — eliminates per-call handshake cost.
        self._persistent_conn: sqlite3.Connection | None = None
        self._ensure_schema()

    def _conn(self) -> sqlite3.Connection:
        """Return a persistent connection (v7 fix).

        Previously this opened a fresh sqlite3.connect() on EVERY call,
        paying the full SQLite handshake cost (1-5ms) per add_entity /
        add_relation / context_for invocation. With N+1 query patterns
        in extract_from_text (one INSERT per entity + one per relation),
        a 10-entity / 5-relation extraction took 16 separate connection
        setups. Now uses a single persistent connection with WAL journaling,
        matching the pattern already used by SQLiteMemoryStore.
        """
        if self._persistent_conn is None:
            self._persistent_conn = sqlite3.connect(
                str(self.db_path), check_same_thread=False,
            )
            self._persistent_conn.row_factory = sqlite3.Row
            self._persistent_conn.execute("PRAGMA journal_mode=WAL")
            self._persistent_conn.execute("PRAGMA synchronous=NORMAL")
            self._persistent_conn.execute("PRAGMA foreign_keys = ON")
        return self._persistent_conn

    def _ensure_schema(self) -> None:
        with self._conn() as conn:
            # Entities (v3 base + v4 confidence + evidence summary).
            conn.execute("""CREATE TABLE IF NOT EXISTS kg_entities (
                id TEXT PRIMARY KEY,
                type TEXT NOT NULL,
                name TEXT NOT NULL,
                description TEXT,
                properties TEXT NOT NULL DEFAULT '{}',
                confidence REAL NOT NULL DEFAULT 0.5,
                evidence_count INTEGER NOT NULL DEFAULT 0,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL
            )""")
            # Relations (v3 base + v4 confidence + evidence summary).
            conn.execute("""CREATE TABLE IF NOT EXISTS kg_relations (
                id TEXT PRIMARY KEY,
                source_id TEXT NOT NULL,
                target_id TEXT NOT NULL,
                type TEXT NOT NULL,
                properties TEXT NOT NULL DEFAULT '{}',
                weight REAL NOT NULL DEFAULT 1.0,
                confidence REAL NOT NULL DEFAULT 0.5,
                evidence_count INTEGER NOT NULL DEFAULT 0,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL,
                FOREIGN KEY (source_id) REFERENCES kg_entities(id) ON DELETE CASCADE,
                FOREIGN KEY (target_id) REFERENCES kg_entities(id) ON DELETE CASCADE
            )""")
            # v4 — Evidence table (links sources to facts).
            conn.execute("""CREATE TABLE IF NOT EXISTS kg_evidence (
                id TEXT PRIMARY KEY,
                fact_kind TEXT NOT NULL,
                fact_id TEXT NOT NULL,
                source TEXT NOT NULL,
                source_kind TEXT NOT NULL,
                snippet TEXT,
                confidence REAL NOT NULL DEFAULT 0.5,
                observed_at REAL NOT NULL,
                metadata TEXT NOT NULL DEFAULT '{}'
            )""")
            # Indexes.
            conn.execute("CREATE INDEX IF NOT EXISTS idx_kg_ent_type ON kg_entities(type)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_kg_ent_name ON kg_entities(name)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_kg_rel_src ON kg_relations(source_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_kg_rel_tgt ON kg_relations(target_id)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_kg_rel_type ON kg_relations(type)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_kg_ev_fact ON kg_evidence(fact_kind, fact_id)")
            conn.commit()
            # Migrate old tables (v3 → v4) if needed.
            self._maybe_migrate_v3(conn)

    def _maybe_migrate_v3(self, conn: sqlite3.Connection) -> None:
        """Add v4 columns to v3 tables if they're missing."""
        # Entities
        ent_cols = {r[1] for r in conn.execute("PRAGMA table_info(kg_entities)").fetchall()}
        if "confidence" not in ent_cols:
            conn.execute("ALTER TABLE kg_entities ADD COLUMN confidence REAL NOT NULL DEFAULT 0.5")
        if "evidence_count" not in ent_cols:
            conn.execute("ALTER TABLE kg_entities ADD COLUMN evidence_count INTEGER NOT NULL DEFAULT 0")
        if "updated_at" not in ent_cols:
            conn.execute("ALTER TABLE kg_entities ADD COLUMN updated_at REAL NOT NULL DEFAULT 0")
        # Relations
        rel_cols = {r[1] for r in conn.execute("PRAGMA table_info(kg_relations)").fetchall()}
        if "confidence" not in rel_cols:
            conn.execute("ALTER TABLE kg_relations ADD COLUMN confidence REAL NOT NULL DEFAULT 0.5")
        if "evidence_count" not in rel_cols:
            conn.execute("ALTER TABLE kg_relations ADD COLUMN evidence_count INTEGER NOT NULL DEFAULT 0")
        if "updated_at" not in rel_cols:
            conn.execute("ALTER TABLE kg_relations ADD COLUMN updated_at REAL NOT NULL DEFAULT 0")
        conn.commit()

    # ── Entities ────────────────────────────────────────────────────────────

    async def add_entity(
        self,
        entity: Entity,
        *,
        confidence: float | None = None,
        evidence: Evidence | None = None,
    ) -> str:
        """Insert or update an entity, optionally attaching evidence.

        If the entity already exists (by name + type), the confidence is
        updated using a Bayesian-style combination rather than overwriting.
        """
        now = time.time()
        conf = confidence if confidence is not None else self.default_confidence
        with self._conn() as conn:
            # Upsert by (name, type) — keep the existing id if present.
            existing = conn.execute(
                "SELECT id, confidence, evidence_count FROM kg_entities "
                "WHERE name = ? AND type = ?",
                (entity.name, entity.type),
            ).fetchone()
            if existing:
                # Bayesian-ish update: combine prior + new evidence.
                new_conf = self._combine_confidence(
                    existing["confidence"], conf,
                    existing["evidence_count"],
                )
                conn.execute(
                    """UPDATE kg_entities
                       SET description = COALESCE(?, description),
                           properties = ?,
                           confidence = ?,
                           evidence_count = evidence_count + ?,
                           updated_at = ?
                       WHERE id = ?""",
                    (entity.description,
                     json.dumps(entity.properties, default=str),
                     new_conf,
                     1 if evidence else 0,
                     now,
                     existing["id"]),
                )
                entity_id = existing["id"]
            else:
                conn.execute(
                    """INSERT INTO kg_entities
                       (id, type, name, description, properties, confidence,
                        evidence_count, created_at, updated_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (entity.id, entity.type, entity.name, entity.description,
                     json.dumps(entity.properties, default=str),
                     conf, 1 if evidence else 0, now, now),
                )
                entity_id = entity.id

            if evidence:
                self._insert_evidence(conn, "entity", entity_id, evidence)
            conn.commit()
        return entity_id

    async def get_entity(self, entity_id: str) -> Entity | None:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM kg_entities WHERE id = ?", (entity_id,)
            ).fetchone()
        return _row_to_entity(row) if row else None

    async def get_entity_confidence(self, entity_id: str) -> float | None:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT confidence FROM kg_entities WHERE id = ?", (entity_id,)
            ).fetchone()
        return float(row["confidence"]) if row else None

    async def find_entities(
        self, *, name: str | None = None, type: str | None = None,
        limit: int = 50,
    ) -> list[Entity]:
        sql = "SELECT * FROM kg_entities WHERE 1=1"
        params: list[Any] = []
        if name:
            sql += " AND name LIKE ?"
            params.append(f"%{name}%")
        if type:
            sql += " AND type = ?"
            params.append(type)
        sql += " ORDER BY confidence DESC LIMIT ?"
        params.append(limit)
        # v7: offload the blocking SQLite call to a thread pool so the
        # event loop isn't blocked. This is especially important for
        # context_for() which calls find_entities in a loop (up to 10x
        # per plan). check_same_thread=False on the persistent connection
        # makes this safe.
        def _do_query():
            with self._conn() as conn:
                rows = conn.execute(sql, params).fetchall()
            return [_row_to_entity(r) for r in rows]
        import asyncio as _aio
        return await _aio.to_thread(_do_query)

    async def delete_entity(self, entity_id: str) -> bool:
        with self._conn() as conn:
            cur = conn.execute("DELETE FROM kg_entities WHERE id = ?", (entity_id,))
            conn.commit()
            return cur.rowcount > 0

    # ── Relations ───────────────────────────────────────────────────────────

    async def add_relation(
        self,
        relation: Relation,
        *,
        confidence: float | None = None,
        evidence: Evidence | None = None,
    ) -> str:
        """Insert or update a relation, optionally attaching evidence."""
        now = time.time()
        conf = confidence if confidence is not None else self.default_confidence
        with self._conn() as conn:
            existing = conn.execute(
                "SELECT id, confidence, evidence_count FROM kg_relations "
                "WHERE source_id = ? AND target_id = ? AND type = ?",
                (relation.source_id, relation.target_id, relation.type),
            ).fetchone()
            if existing:
                new_conf = self._combine_confidence(
                    existing["confidence"], conf, existing["evidence_count"],
                )
                conn.execute(
                    """UPDATE kg_relations
                       SET properties = ?, weight = ?, confidence = ?,
                           evidence_count = evidence_count + ?, updated_at = ?
                       WHERE id = ?""",
                    (json.dumps(relation.properties, default=str),
                     relation.weight, new_conf,
                     1 if evidence else 0, now, existing["id"]),
                )
                rel_id = existing["id"]
            else:
                conn.execute(
                    """INSERT INTO kg_relations
                       (id, source_id, target_id, type, properties, weight,
                        confidence, evidence_count, created_at, updated_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (relation.id, relation.source_id, relation.target_id,
                     relation.type,
                     json.dumps(relation.properties, default=str),
                     relation.weight, conf,
                     1 if evidence else 0, now, now),
                )
                rel_id = relation.id
            if evidence:
                self._insert_evidence(conn, "relation", rel_id, evidence)
            conn.commit()
        return rel_id

    async def get_neighbors(
        self, entity_id: str, *, max_hops: int = 1, max_results: int = 20,
        min_confidence: float = 0.0,
    ) -> KnowledgeGraphSnapshot:
        """BFS traversal from *entity_id* up to *max_hops*.

        v4: filters out facts with confidence < ``min_confidence`` and
        sorts edges by descending confidence.
        """
        visited: set[str] = {entity_id}
        entities: list[Entity] = []
        relations: list[Relation] = []
        frontier = [entity_id]
        for _ in range(max_hops):
            if not frontier or len(entities) >= max_results:
                break
            next_frontier: list[str] = []
            for eid in frontier:
                with self._conn() as conn:
                    rows = conn.execute(
                        "SELECT * FROM kg_relations "
                        "WHERE (source_id = ? OR target_id = ?) "
                        "AND confidence >= ? "
                        "ORDER BY confidence DESC",
                        (eid, eid, min_confidence),
                    ).fetchall()
                for row in rows:
                    rel = _row_to_relation(row)
                    relations.append(rel)
                    other = rel.target_id if rel.source_id == eid else rel.source_id
                    if other not in visited:
                        visited.add(other)
                        next_frontier.append(other)
                        ent = await self.get_entity(other)
                        if ent:
                            entities.append(ent)
                            if len(entities) >= max_results:
                                break
            frontier = next_frontier
        # Include the starting entity.
        root = await self.get_entity(entity_id)
        if root:
            entities.insert(0, root)
        # Deduplicate relations.
        seen_rel_ids = set()
        unique_rels = []
        for r in relations:
            if r.id not in seen_rel_ids:
                seen_rel_ids.add(r.id)
                unique_rels.append(r)
        return KnowledgeGraphSnapshot(entities=entities, relations=unique_rels)

    async def snapshot(self, limit: int = 1000) -> KnowledgeGraphSnapshot:
        with self._conn() as conn:
            ent_rows = conn.execute(
                "SELECT * FROM kg_entities ORDER BY confidence DESC LIMIT ?", (limit,)
            ).fetchall()
            rel_rows = conn.execute(
                "SELECT * FROM kg_relations ORDER BY confidence DESC LIMIT ?", (limit,)
            ).fetchall()
        return KnowledgeGraphSnapshot(
            entities=[_row_to_entity(r) for r in ent_rows],
            relations=[_row_to_relation(r) for r in rel_rows],
        )

    # ── Evidence ───────────────────────────────────────────────────────────

    async def add_evidence(
        self, fact_kind: str, fact_id: str, evidence: Evidence,
    ) -> str:
        """Attach an evidence record to an entity or relation.

        ``fact_kind`` must be ``"entity"`` or ``"relation"``.
        Also bumps the fact's confidence using Bayesian combination.
        """
        if fact_kind not in ("entity", "relation"):
            raise KnowledgeGraphError(
                f"fact_kind must be 'entity' or 'relation', got {fact_kind!r}"
            )
        # Map fact_kind → SQL table name (handles the entities/relations
        # pluralization explicitly to avoid "kg_entitys" typos).
        table = "kg_entities" if fact_kind == "entity" else "kg_relations"
        with self._conn() as conn:
            self._insert_evidence(conn, fact_kind, fact_id, evidence)
            row = conn.execute(
                f"SELECT confidence, evidence_count FROM {table} WHERE id = ?",
                (fact_id,),
            ).fetchone()
            if row:
                new_conf = self._combine_confidence(
                    row["confidence"], evidence.confidence, row["evidence_count"],
                )
                conn.execute(
                    f"UPDATE {table} SET confidence = ?, "
                    f"evidence_count = evidence_count + 1, updated_at = ? WHERE id = ?",
                    (new_conf, time.time(), fact_id),
                )
            conn.commit()
        return evidence.id

    async def list_evidence(
        self, fact_kind: str, fact_id: str,
    ) -> list[Evidence]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT * FROM kg_evidence WHERE fact_kind = ? AND fact_id = ? "
                "ORDER BY observed_at DESC",
                (fact_kind, fact_id),
            ).fetchall()
        return [_row_to_evidence(r) for r in rows]

    # ── Entity extraction (LLM-driven) ─────────────────────────────────────

    async def extract_from_text(
        self,
        text: str,
        *,
        source: str = "unknown",
        source_kind: str = "inference",
        max_entities: int = 10,
    ) -> dict[str, Any]:
        """Extract entities + relations from free text using the LLM.

        Returns a dict ``{"entities_added": N, "relations_added": M,
        "evidence_id": str}``.  Falls back to a regex-based extractor when
        no LLM is configured.
        """
        if not text or not text.strip():
            return {"entities_added": 0, "relations_added": 0}

        evidence = Evidence(
            source=source, source_kind=source_kind,  # type: ignore[arg-type]
            snippet=text[:1000], confidence=0.7,
        )

        if self.llm is None:
            extracted = self._regex_extract(text, max_entities)
        else:
            try:
                extracted = await self._llm_extract(text, max_entities)
            except Exception as e:
                log.warning("KG LLM extraction failed (%s) — falling back to regex", e)
                extracted = self._regex_extract(text, max_entities)

        # Insert extracted entities, building a name→id map.
        # v7: batch the inserts in a single transaction so a 10-entity /
        # 5-relation extraction does 1 commit instead of 15.
        name_to_id: dict[str, str] = {}
        entities_added = 0
        conn = self._conn()
        try:
            conn.execute("BEGIN")
            for ent_data in extracted.get("entities", [])[:max_entities]:
                try:
                    ent = Entity(
                        type=ent_data.get("type", "concept"),  # type: ignore[arg-type]
                        name=str(ent_data.get("name", "")).strip(),
                        description=ent_data.get("description"),
                    )
                    if not ent.name:
                        continue
                    ent_id = await self.add_entity(ent, evidence=evidence)
                    name_to_id[ent.name] = ent_id
                    entities_added += 1
                except Exception as e:
                    log.debug("KG entity insert failed: %s", e)

            # Insert extracted relations (same transaction).
            relations_added = 0
            for rel_data in extracted.get("relations", []):
                try:
                    src_name = str(rel_data.get("source", "")).strip()
                    tgt_name = str(rel_data.get("target", "")).strip()
                    src_id = name_to_id.get(src_name)
                    tgt_id = name_to_id.get(tgt_name)
                    if not src_id or not tgt_id:
                        continue
                    rel = Relation(
                        source_id=src_id, target_id=tgt_id,
                        type=rel_data.get("type", "relates_to"),  # type: ignore[arg-type]
                        weight=float(rel_data.get("weight", 1.0)),
                    )
                    await self.add_relation(rel, evidence=evidence)
                    relations_added += 1
                except Exception as e:
                    log.debug("KG relation insert failed: %s", e)
            conn.commit()
        except Exception as e:
            conn.rollback()
            log.warning("KG extract_from_text transaction failed: %s", e)

        return {
            "entities_added": entities_added,
            "relations_added": relations_added,
            "evidence_id": evidence.id,
        }

    async def _llm_extract(self, text: str, max_entities: int) -> dict[str, Any]:
        from adonai.core.json_utils import extract_json
        resp = await self.llm.complete(
            messages=[
                {"role": "system", "content": _EXTRACTION_SYSTEM_PROMPT},
                {"role": "user", "content": text[:8000]},
            ],
            temperature=0.1,
            max_tokens=1024,
        )
        try:
            data = extract_json(resp.text or "")
        except Exception:
            return {"entities": [], "relations": []}
        return data if isinstance(data, dict) else {"entities": [], "relations": []}

    def _regex_extract(self, text: str, max_entities: int) -> dict[str, Any]:
        """Cheap fallback: extract capitalized noun phrases as concepts."""
        # Match sequences of Capitalized Words (2+ words).
        pattern = re.compile(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\b")
        seen: set[str] = set()
        entities: list[dict[str, Any]] = []
        for m in pattern.findall(text):
            name = m.strip()
            if name.lower() in seen or len(name) < 4:
                continue
            seen.add(name.lower())
            entities.append({"name": name, "type": "concept", "description": None})
            if len(entities) >= max_entities:
                break
        return {"entities": entities, "relations": []}

    # ── Context generation for the planner ─────────────────────────────────

    async def context_for(
        self,
        query: str,
        *,
        max_hops: int = 2,
        max_entities: int = 20,
        min_confidence: float = 0.3,
    ) -> str:
        """Build a natural-language context string for the planner.

        Finds entities whose name appears in *query*, expands the
        neighborhood up to *max_hops*, and renders the result as a
        readable summary that can be injected into the planner prompt.
        """
        # Find anchor entities by name overlap with the query.
        words = [w for w in re.split(r"\W+", query) if len(w) >= 3]
        anchors: list[Entity] = []
        for w in words[:10]:  # cap to avoid O(N²) lookups
            try:
                hits = await self.find_entities(name=w, limit=5)
                anchors.extend(hits)
            except Exception:
                continue

        # v8: Embedding-based fallback — if keyword matching found nothing
        # (or very few anchors), embed the query and find entities whose
        # descriptions are semantically closest.  This catches cases where
        # the query uses synonyms or paraphrases of entity names.
        if len(anchors) < 2 and self.llm is not None:
            try:
                emb_result = await self.llm.embed(query)
                if emb_result:
                    query_vec = emb_result[0] if isinstance(emb_result[0], list) else emb_result
                    # Search all entities and rank by description similarity.
                    with self._conn() as conn:
                        rows = conn.execute(
                            "SELECT * FROM kg_entities ORDER BY confidence DESC LIMIT 200"
                        ).fetchall()
                    for row in rows:
                        ent = _row_to_entity(row)
                        if ent.id in {a.id for a in anchors}:
                            continue
                        # Embed entity name+description and compare.
                        ent_text = f"{ent.name} {ent.description or ''}"
                        ent_emb = await self.llm.embed(ent_text)
                        if ent_emb:
                            ent_vec = ent_emb[0] if isinstance(ent_emb[0], list) else ent_emb
                            sim = self._cosine(query_vec, ent_vec)
                            if sim >= 0.7:  # threshold for semantic anchoring
                                anchors.append(ent)
                    log.debug("KG context_for: embedding fallback found %d anchors", len(anchors) - len([a for a in anchors if a.id not in {a.id for a in anchors}]))
            except Exception as e:
                log.debug("KG embedding-based entity anchoring failed (non-fatal): %s", e)

        if not anchors:
            return ""
        # De-duplicate anchors.
        seen_ids: set[str] = set()
        unique_anchors: list[Entity] = []
        for a in anchors:
            if a.id in seen_ids:
                continue
            seen_ids.add(a.id)
            unique_anchors.append(a)
        unique_anchors = unique_anchors[:max_entities]

        # Expand each anchor's neighborhood.
        all_entities: dict[str, Entity] = {a.id: a for a in unique_anchors}
        all_relations: list[Relation] = []
        for a in unique_anchors:
            try:
                snap = await self.get_neighbors(
                    a.id, max_hops=max_hops, max_results=max_entities,
                    min_confidence=min_confidence,
                )
            except Exception:
                continue
            for e in snap.entities:
                if e.id not in all_entities:
                    all_entities[e.id] = e
            all_relations.extend(snap.relations)

        if not all_entities:
            return ""

        # Render as a readable block.
        lines: list[str] = ["Knowledge-graph context:"]
        for e in list(all_entities.values())[:max_entities]:
            conf_str = ""
            # We didn't pull confidence into the model object in v3 form;
            # fetch it directly.
            try:
                conf = await self.get_entity_confidence(e.id)
                if conf is not None:
                    conf_str = f" (confidence={conf:.2f})"
            except Exception:
                pass
            desc = f" — {e.description}" if e.description else ""
            lines.append(f"  • {e.name} ({e.type}){conf_str}{desc}")
        # Render a few high-confidence relations.
        seen_rels: set[str] = set()
        for r in all_relations:
            key = f"{r.source_id}->{r.target_id}:{r.type}"
            if key in seen_rels:
                continue
            seen_rels.add(key)
            src = all_entities.get(r.source_id)
            tgt = all_entities.get(r.target_id)
            if not src or not tgt:
                continue
            lines.append(f"  • {src.name} --{r.type}--> {tgt.name}")
            if len(seen_rels) >= 30:
                break
        return "\n".join(lines)

    # ── Confidence combination + evidence insert ───────────────────────────

    @staticmethod
    def _combine_confidence(
        prior: float, new: float, prior_count: int,
    ) -> float:
        """Bayesian-ish confidence update.

        Treats ``prior`` as the mean of ``prior_count`` Beta(α,β) samples
        with α=2, β=2 prior, and updates with the new evidence.  This
        prevents a single high-confidence source from overwhelming many
        low-confidence ones (and vice-versa).
        """
        # Treat as Beta-Binomial: alpha = 1 + prior_count * prior,
        # beta = 1 + prior_count * (1 - prior).
        # New observation adds (new, 1-new).
        alpha = 1.0 + max(0, prior_count) * max(0.0, min(1.0, prior))
        beta = 1.0 + max(0, prior_count) * (1.0 - max(0.0, min(1.0, prior)))
        alpha += max(0.0, min(1.0, new))
        beta += 1.0 - max(0.0, min(1.0, new))
        return alpha / (alpha + beta)

    def _insert_evidence(
        self, conn: sqlite3.Connection, fact_kind: str, fact_id: str,
        evidence: Evidence,
    ) -> None:
        # Always generate a fresh evidence ID so the same Evidence object
        # can be attached to multiple facts without UNIQUE constraint
        # violations.
        from adonai.core.models import _uid
        ev_id = _uid("ev_")
        conn.execute(
            """INSERT INTO kg_evidence
               (id, fact_kind, fact_id, source, source_kind, snippet,
                confidence, observed_at, metadata)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (ev_id, fact_kind, fact_id, evidence.source,
             evidence.source_kind, evidence.snippet, evidence.confidence,
             evidence.observed_at.timestamp() if evidence.observed_at else time.time(),
             json.dumps(evidence.metadata, default=str)),
        )


# ──────────────────────────────────────────────────────────────────────────────
# Row converters
# ──────────────────────────────────────────────────────────────────────────────


def _row_to_entity(row: sqlite3.Row) -> Entity:
    return Entity(
        id=row["id"], type=row["type"], name=row["name"],
        description=row["description"],
        properties=json.loads(row["properties"] or "{}"),
        created_at=datetime.fromtimestamp(row["created_at"], tz=timezone.utc),
    )


def _row_to_relation(row: sqlite3.Row) -> Relation:
    return Relation(
        id=row["id"], source_id=row["source_id"], target_id=row["target_id"],
        type=row["type"], properties=json.loads(row["properties"] or "{}"),
        weight=float(row["weight"]),
        created_at=datetime.fromtimestamp(row["created_at"], tz=timezone.utc),
    )


def _row_to_evidence(row: sqlite3.Row) -> Evidence:
    return Evidence(
        id=row["id"],
        source=row["source"],
        source_kind=row["source_kind"],  # type: ignore[arg-type]
        snippet=row["snippet"],
        confidence=float(row["confidence"]),
        observed_at=datetime.fromtimestamp(row["observed_at"], tz=timezone.utc),
        metadata=json.loads(row["metadata"] or "{}"),
    )
