"""Working memory — bounded LRU of recent context (in-process)."""
from __future__ import annotations

from collections import deque
from typing import Any

from adonai.core.models import Memory, MemoryType


class WorkingMemory:
    """In-process bounded LRU of recent context items."""

    def __init__(self, capacity: int = 32) -> None:
        self._buf: deque[Memory] = deque(maxlen=capacity)
        self._capacity = capacity

    def add(self, mem: Memory) -> None:
        if mem.type != MemoryType.WORKING:
            mem = mem.model_copy(update={"type": MemoryType.WORKING})
        self._buf.append(mem)

    def recent(self, k: int = 10) -> list[Memory]:
        return list(self._buf)[-k:]

    def clear(self) -> None:
        self._buf.clear()

    @property
    def size(self) -> int:
        return len(self._buf)

    @property
    def capacity(self) -> int:
        return self._capacity

    def as_messages(self, k: int = 10) -> list[dict[str, str]]:
        """Render recent items as OpenAI-style messages for LLM context."""
        out: list[dict[str, str]] = []
        for m in self.recent(k):
            role = "assistant" if m.source == "agent" else "user"
            out.append({"role": role, "content": m.content})
        return out
