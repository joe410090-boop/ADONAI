"""ChromaDB-backed semantic memory store — HNSW index for fast similarity search."""
from __future__ import annotations

import json
import logging
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from adonai.core.interfaces import LLMClient, MemoryStore
from adonai.core.models import Memory, MemoryType

log = logging.getLogger(__name__)


class ChromaMemoryStore(MemoryStore):
    """Persistent semantic memory store backed by ChromaDB."""

    def __init__(
        self,
        *,
        persist_path: str | Path,
        collection: str = "memories",
        embedding_dim: int = 768,
        llm: LLMClient | None = None,
    ) -> None:
        try:
            import chromadb
        except ImportError as e:
            raise ImportError(
                "the `chromadb` package is required for ChromaMemoryStore. "
                "Install it via `pip install chromadb`."
            ) from e
        self.persist_path = Path(persist_path)
        self.persist_path.mkdir(parents=True, exist_ok=True)
        self.embedding_dim = embedding_dim
        self.llm = llm
        self._client = chromadb.PersistentClient(path=str(self.persist_path))
        self._collection = self._client.get_or_create_collection(
            name=collection, metadata={"hnsw:space": "cosine"}
        )

    async def add(self, memory: Memory) -> str:
        mem_id = memory.id or f"mem_{uuid.uuid4().hex[:16]}"
        if memory.embedding is None and self.llm is not None:
            try:
                emb = await self.llm.embed(memory.content)
                if emb and isinstance(emb[0], list):
                    emb = emb[0]
                memory.embedding = emb
            except Exception as e:
                log.warning("Chroma embed failed: %s", e)
                memory.embedding = [0.0] * self.embedding_dim
        self._collection.upsert(
            ids=[mem_id],
            documents=[memory.content],
            embeddings=[memory.embedding] if memory.embedding else None,
            metadatas=[_flatten_metadata(memory)],
        )
        return mem_id

    async def get(self, memory_id: str) -> Memory | None:
        result = self._collection.get(ids=[memory_id])
        if not result["ids"]:
            return None
        return _chroma_to_memory(memory_id, result)

    async def search(
        self,
        query: str | list[float],
        top_k: int = 5,
        filters: dict[str, Any] | None = None,
    ) -> list[Memory]:
        if isinstance(query, list):
            q_emb = query
        elif self.llm is not None:
            emb = await self.llm.embed(query)
            q_emb = emb[0] if emb and isinstance(emb[0], list) else emb
        else:
            result = self._collection.query(
                query_texts=[query], n_results=top_k, where=filters
            )
            return _chroma_results_to_memories(result)

        result = self._collection.query(
            query_embeddings=[q_emb], n_results=top_k, where=filters
        )
        return _chroma_results_to_memories(result)

    async def update(self, memory_id: str, updates: dict[str, Any]) -> bool:
        current = await self.get(memory_id)
        if current is None:
            return False
        merged = current.model_copy(update=updates)
        await self.add(merged)
        return True

    async def delete(self, memory_id: str) -> bool:
        before = self._collection.count()
        self._collection.delete(ids=[memory_id])
        return self._collection.count() < before

    async def count(self, filters: dict[str, Any] | None = None) -> int:
        return self._collection.count()


def _flatten_metadata(memory: Memory) -> dict[str, Any]:
    """ChromaDB metadata must be flat str/int/float — JSON-encode complex values."""
    return {
        "type": memory.type.value,
        "importance": float(memory.importance),
        "confidence": float(memory.confidence),
        "access_count": int(memory.access_count),
        "source": memory.source or "",
        "session_id": memory.session_id or "",
        "tags": json.dumps(memory.tags),
        "metadata_json": json.dumps(memory.metadata, default=str),
        "created_at": memory.created_at.timestamp() if memory.created_at else 0.0,
    }


def _chroma_to_memory(mem_id: str, result: dict) -> Memory:
    # ChromaDB .get() returns flat lists (ids: [...], metadatas: [...], documents: [...], embeddings: [...])
    # whereas .query() returns nested lists (ids: [[...]], metadatas: [[...]], ...).
    # The distinguishing factor is the SHAPE of `ids`: in flat shape, ids[0] is a
    # string; in nested shape, ids[0] is a list. We can't use the shape of
    # embeddings/metadatas alone because embeddings are always list-of-lists.
    ids_list = result.get("ids") or []
    nested = bool(ids_list) and isinstance(ids_list[0], list)

    if not nested:
        # flat shape (from .get())
        if mem_id not in ids_list:
            return Memory(
                id=mem_id, type=MemoryType.SEMANTIC, content="",
                embedding=None, metadata={}, importance=0.5, confidence=1.0,
            )
        idx = ids_list.index(mem_id)

        def _pick_flat(key: str) -> Any:
            v = result.get(key) or []
            return v[idx] if idx < len(v) else None

        md = _pick_flat("metadatas") or {}
        content = _pick_flat("documents") or ""
        emb = _pick_flat("embeddings")
    else:
        # nested shape (from .query()) — flatten the first (and usually only) result-set
        flat_ids = ids_list[0] if ids_list else []
        if mem_id not in flat_ids:
            return Memory(
                id=mem_id, type=MemoryType.SEMANTIC, content="",
                embedding=None, metadata={}, importance=0.5, confidence=1.0,
            )
        idx = flat_ids.index(mem_id)

        def _pick_nested(key: str) -> Any:
            v = result.get(key) or []
            if not v:
                return None
            inner = v[0] if isinstance(v[0], list) else v
            return inner[idx] if idx < len(inner) else None

        md = _pick_nested("metadatas") or {}
        content = _pick_nested("documents") or ""
        emb = _pick_nested("embeddings")
    metadata = json.loads(md.get("metadata_json", "{}")) if md else {}
    created_ts = md.get("created_at", 0.0)
    return Memory(
        id=mem_id,
        type=MemoryType(md.get("type", "semantic")),
        content=content,
        embedding=list(emb) if emb is not None else None,
        metadata=metadata,
        importance=float(md.get("importance", 0.5)),
        confidence=float(md.get("confidence", 1.0)),
        access_count=int(md.get("access_count", 0)),
        created_at=datetime.fromtimestamp(created_ts, tz=timezone.utc) if created_ts else None,
        tags=json.loads(md.get("tags", "[]")) if md else [],
        source=md.get("source"),
        session_id=md.get("session_id"),
    )


def _chroma_results_to_memories(result: dict) -> list[Memory]:
    out: list[Memory] = []
    if not result.get("ids"):
        return out
    ids = result["ids"][0] if isinstance(result["ids"][0], list) else result["ids"]
    docs = (result.get("documents") or [[]])[0]
    metas = (result.get("metadatas") or [[]])[0]
    embs = (result.get("embeddings") or [[]])[0]
    for i, mid in enumerate(ids):
        doc = docs[i] if i < len(docs) else ""
        md = metas[i] if i < len(metas) else {}
        emb = embs[i] if i < len(embs) else None
        out.append(_chroma_to_memory(mid, {
            "ids": [mid], "documents": [doc], "metadatas": [md],
            "embeddings": [emb] if emb is not None else [],
        }))
    return out
