"""SQLite-backed memory store with cosine-similarity search.

Works with the Python stdlib `sqlite3` module — no external deps required.
Embeddings are stored as JSON arrays.  For ≤100k items, in-Python cosine
similarity is fast enough; switch to ChromaDB for larger corpora.
"""
from __future__ import annotations

import json
import logging
import math
import sqlite3
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from adonai.core.interfaces import LLMClient, MemoryStore
from adonai.core.models import Memory, MemoryType

log = logging.getLogger(__name__)


class SQLiteMemoryStore(MemoryStore):
    """Persistent memory store backed by SQLite.

    Each instance owns a single table.  Table is created idempotently.
    """

    def __init__(
        self,
        db_path: str | Path,
        *,
        table_name: str = "memories",
        embedding_dim: int = 768,
        llm: LLMClient | None = None,
    ) -> None:
        self.db_path = Path(db_path)
        self.table_name = table_name
        self.embedding_dim = embedding_dim
        self.llm = llm
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        # ── Connection pooling ──────────────────────────────────────────
        # The previous implementation opened a fresh sqlite3.connect() on
        # every call (and two per get() — one SELECT, one UPDATE to bump
        # access_count).  For a hot path like recall() that's a lot of
        # connection setup overhead.  We keep one persistent connection
        # per store instance with WAL + NORMAL synchronous mode.  SQLite
        # handles concurrent reads from multiple connections fine; for
        # concurrent writes the WAL journal serializes them.
        self._conn: sqlite3.Connection = sqlite3.connect(
            str(self.db_path), check_same_thread=False,
        )
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.execute("PRAGMA synchronous=NORMAL")
        # A re-entrant lock guards writes so we don't interleave
        # transactions across coroutines on the same connection.
        self._lock = __import__("threading").RLock()
        self._ensure_schema()

    def _conn_ctx(self) -> sqlite3.Connection:
        """Return the shared connection (use ``with`` for write transactions).

        Kept for backward compat with code that uses ``with self._conn_ctx() as c:``.
        """
        return self._conn

    def _ensure_schema(self) -> None:
        with self._conn:
            self._conn.execute(
                f"""CREATE TABLE IF NOT EXISTS {self.table_name} (
                    id            TEXT PRIMARY KEY,
                    type          TEXT NOT NULL,
                    content       TEXT NOT NULL,
                    embedding     TEXT,
                    metadata      TEXT NOT NULL DEFAULT '{{}}',
                    importance    REAL NOT NULL DEFAULT 0.5,
                    confidence    REAL NOT NULL DEFAULT 1.0,
                    access_count  INTEGER NOT NULL DEFAULT 0,
                    last_accessed REAL,
                    created_at    REAL NOT NULL,
                    expires_at    REAL,
                    tags          TEXT NOT NULL DEFAULT '[]',
                    source        TEXT,
                    session_id    TEXT
                )"""
            )
            self._conn.execute(
                f"CREATE INDEX IF NOT EXISTS idx_{self.table_name}_type "
                f"ON {self.table_name}(type)"
            )
            self._conn.execute(
                f"CREATE INDEX IF NOT EXISTS idx_{self.table_name}_session "
                f"ON {self.table_name}(session_id)"
            )
            self._conn.execute(
                f"CREATE INDEX IF NOT EXISTS idx_{self.table_name}_created "
                f"ON {self.table_name}(created_at)"
            )
            # Add a content index for faster LIKE searches.
            self._conn.execute(
                f"CREATE INDEX IF NOT EXISTS idx_{self.table_name}_content "
                f"ON {self.table_name}(content)"
            )
            self._conn.commit()

    def close(self) -> None:
        """Close the shared connection.  Safe to call multiple times."""
        try:
            self._conn.close()
        except Exception:
            pass

    async def add(self, memory: Memory) -> str:
        mem_id = memory.id or f"mem_{uuid.uuid4().hex[:16]}"
        # Auto-embed if no embedding and LLM is available.
        if memory.embedding is None and self.llm is not None and memory.type != MemoryType.WORKING:
            try:
                emb = await self.llm.embed(memory.content)
                if emb and isinstance(emb[0], list):
                    emb = emb[0]
                memory.embedding = emb
            except Exception as e:
                log.warning("Embedding failed for memory %s: %s", mem_id, e)

        with self._lock:
            conn = self._conn
            conn.execute(
                f"""INSERT OR REPLACE INTO {self.table_name}
                    (id, type, content, embedding, metadata, importance, confidence,
                     access_count, last_accessed, created_at, expires_at, tags,
                     source, session_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    mem_id,
                    memory.type.value,
                    memory.content,
                    json.dumps(memory.embedding) if memory.embedding else None,
                    json.dumps(memory.metadata, default=str),
                    memory.importance,
                    memory.confidence,
                    memory.access_count,
                    memory.last_accessed.timestamp() if memory.last_accessed else None,
                    memory.created_at.timestamp() if memory.created_at else time.time(),
                    memory.expires_at.timestamp() if memory.expires_at else None,
                    json.dumps(memory.tags),
                    memory.source,
                    memory.session_id,
                ),
            )
            conn.commit()
        return mem_id

    async def get(self, memory_id: str) -> Memory | None:
        with self._lock:
            conn = self._conn
            cur = conn.execute(
                f"SELECT * FROM {self.table_name} WHERE id = ?", (memory_id,)
            )
            row = cur.fetchone()
        if not row:
            return None
        # Update access count.
        with self._lock:
            conn = self._conn
            conn.execute(
                f"UPDATE {self.table_name} SET access_count = access_count + 1, "
                f"last_accessed = ? WHERE id = ?",
                (time.time(), memory_id),
            )
            conn.commit()
        return _row_to_memory(row)

    async def search(
        self,
        query: str | list[float],
        top_k: int = 5,
        filters: dict[str, Any] | None = None,
    ) -> list[Memory]:
        # Treat "*", "", or None as "return all" — the previous behaviour of
        # compiling "*" to LIKE '%*%' silently matched only memories whose
        # content literally contained an asterisk, which broke every
        # consolidation/pruning/summarization caller that passed "*".
        if isinstance(query, str) and (query == "*" or not query.strip()):
            return await self.search_all(top_k=top_k, filters=filters)

        # ── Semantic search for string queries ──────────────────────────
        # The previous implementation fell through to LIKE '%query%' for
        # every string query, even though embeddings were computed and
        # stored on every add().  Natural-language queries almost never
        # substring-match stored content, so recall effectively returned
        # nothing useful.  We now embed the query and do cosine search
        # when an LLM is available — falling back to LIKE only when no
        # LLM is configured or embedding fails.
        if isinstance(query, str) and self.llm is not None:
            try:
                emb_result = await self.llm.embed(query)
                if emb_result:
                    # embed() returns list[list[float]] (batch shape).
                    query_vec = emb_result[0] if isinstance(emb_result[0], list) else emb_result
                    return await self.search(query_vec, top_k=top_k, filters=filters)
            except Exception as e:
                log.debug(
                    "Embedding-based search failed, falling back to LIKE: %s", e,
                )

        with self._lock:
            conn = self._conn
            if isinstance(query, list):
                # Vector search.
                rows = _fetch_with_filter(conn, self.table_name, filters)
                scored = []
                for row in rows:
                    emb = _parse_embedding(row["embedding"])
                    if emb is None:
                        continue
                    sim = _cosine(query, emb)
                    scored.append((sim, row))
                scored.sort(key=lambda t: t[0], reverse=True)
                # Propagate similarity scores so MemoryManager.recall()
                # can use them in its blended ranking.
                results_with_scores = []
                for sim_val, r in scored[:top_k]:
                    mem = _row_to_memory(r)
                    mem._sim_score = sim_val  # type: ignore[attr-defined]
                    results_with_scores.append(mem)
                return results_with_scores
            else:
                sql = f"SELECT * FROM {self.table_name} WHERE content LIKE ?"
                params: list[Any] = [f"%{query}%"]
                if filters:
                    sql, params = _apply_filters(sql, params, filters)
                sql += " ORDER BY importance DESC, created_at DESC LIMIT ?"
                params.append(top_k)
                rows = conn.execute(sql, params).fetchall()
        return [_row_to_memory(r) for r in rows]

    async def search_all(
        self,
        top_k: int = 1000,
        filters: dict[str, Any] | None = None,
    ) -> list[Memory]:
        """Return up to *top_k* memories (no content filter). Used by
        consolidation / pruning / dedup passes that need to scan the whole
        store without matching a literal asterisk."""
        with self._lock:
            conn = self._conn
            sql = f"SELECT * FROM {self.table_name}"
            params: list[Any] = []
            if filters:
                sql, params = _apply_filters(sql, params, filters)
            sql += " ORDER BY importance DESC, created_at DESC LIMIT ?"
            params.append(top_k)
            rows = conn.execute(sql, params).fetchall()
        return [_row_to_memory(r) for r in rows]

    async def update(self, memory_id: str, updates: dict[str, Any]) -> bool:
        if not updates:
            return False
        current = await self.get(memory_id)
        if current is None:
            return False
        merged = current.model_copy(update=updates)
        await self.add(merged)
        return True

    async def delete(self, memory_id: str) -> bool:
        with self._lock:
            conn = self._conn
            cur = conn.execute(
                f"DELETE FROM {self.table_name} WHERE id = ?", (memory_id,)
            )
            conn.commit()
            return cur.rowcount > 0

    async def count(self, filters: dict[str, Any] | None = None) -> int:
        with self._lock:
            conn = self._conn
            sql = f"SELECT COUNT(*) AS n FROM {self.table_name}"
            params: list[Any] = []
            if filters:
                sql, params = _apply_filters(sql, params, filters)
            return int(conn.execute(sql, params).fetchone()["n"])

    async def delete_old(self, before_ts: float, *, min_importance: float = 0.0) -> int:
        """Delete memories older than *before_ts* with importance < min_importance."""
        with self._lock:
            conn = self._conn
            cur = conn.execute(
                f"DELETE FROM {self.table_name} WHERE created_at < ? AND importance < ?",
                (before_ts, min_importance),
            )
            conn.commit()
            return cur.rowcount


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────

def _row_to_memory(row: sqlite3.Row) -> Memory:
    def _ts(t):
        return datetime.fromtimestamp(t, tz=timezone.utc) if t else None

    return Memory(
        id=row["id"],
        type=MemoryType(row["type"]),
        content=row["content"],
        embedding=_parse_embedding(row["embedding"]),
        metadata=json.loads(row["metadata"] or "{}"),
        importance=float(row["importance"]),
        confidence=float(row["confidence"]),
        access_count=int(row["access_count"]),
        last_accessed=_ts(row["last_accessed"]),
        created_at=_ts(row["created_at"]),
        expires_at=_ts(row["expires_at"]),
        tags=json.loads(row["tags"] or "[]"),
        source=row["source"],
        session_id=row["session_id"],
    )


def _parse_embedding(s: str | None) -> list[float] | None:
    if not s:
        return None
    try:
        return [float(x) for x in json.loads(s)]
    except (json.JSONDecodeError, TypeError):
        return None


def _cosine(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


def _fetch_with_filter(conn, table: str, filters: dict | None) -> list[sqlite3.Row]:
    sql = f"SELECT * FROM {table}"
    params: list[Any] = []
    if filters:
        sql, params = _apply_filters(sql, params, filters)
    return conn.execute(sql, params).fetchall()


def _apply_filters(sql: str, params: list, filters: dict) -> tuple[str, list]:
    clauses: list[str] = []
    for key, value in filters.items():
        if key.startswith("metadata."):
            sub = key[len("metadata."):]
            clauses.append(f"json_extract(metadata, '$.{sub}') = ?")
            params.append(str(value))
        elif key in ("type", "source", "session_id"):
            clauses.append(f"{key} = ?")
            params.append(str(value))
        else:
            clauses.append(f"json_extract(metadata, '$.{key}') = ?")
            params.append(str(value))
    if clauses:
        sql += " WHERE " + " AND ".join(clauses)
    return sql, params
