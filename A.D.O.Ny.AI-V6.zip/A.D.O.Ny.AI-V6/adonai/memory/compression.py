"""Memory Compression Engine — summarization + pruning + deduplication.

Improvements over the base memory system:
  1. Summarization: LLM summarizes groups of old memories into compact semantic entries
  2. Importance-based pruning: Delete low-importance memories that haven't been accessed
  3. Embedding-based deduplication: Don't store memories that are too similar to existing ones
  4. Tiered storage: Hot (recent) → Warm (important) → Cold (old, summarized)
  5. Automatic triggering: Runs when memory count exceeds threshold
"""
from __future__ import annotations

import logging
import math
import time
from datetime import datetime, timezone
from typing import Any

from adonai.core.interfaces import LLMClient
from adonai.core.models import Memory, MemoryType

log = logging.getLogger(__name__)


class MemoryCompressor:
    """Compresses and prunes memories to bound growth.

    Strategies:
    1. Summarization: Group N old memories → 1 summary memory (via LLM)
    2. Pruning: Delete memories with low importance + low access count
    3. Deduplication: Skip storing memories that are >85% similar to existing ones
    4. Decay: Reduce importance of old memories over time
    """

    def __init__(
        self,
        llm: LLMClient,
        memory_manager,
        *,
        consolidation_threshold: int = 100,
        max_memories: int = 10_000,
        similarity_threshold: float = 0.85,
        decay_rate: float = 0.01,  # per day
        min_consolidation_interval_s: float = 300.0,  # v8: at least 5 min between consolidations
    ) -> None:
        self.llm = llm
        self.memory = memory_manager
        self.consolidation_threshold = consolidation_threshold
        self.max_memories = max_memories
        self.similarity_threshold = similarity_threshold
        self.decay_rate = decay_rate
        self._last_consolidation_time: float = 0.0
        self._min_consolidation_interval_s = min_consolidation_interval_s

    async def compress(self) -> dict[str, int]:
        """Run the full compression pipeline.

        Returns stats: {summarized, pruned, deduplicated, decayed}
        """
        stats = {
            "summarized": 0,
            "pruned": 0,
            "deduplicated": 0,
            "decayed": 0,
        }

        log.info("Starting memory compression...")

        # 1. Apply importance decay to old memories.
        stats["decayed"] = await self._apply_decay()

        # 2. Prune low-importance, low-access memories.
        stats["pruned"] = await self._prune_low_importance()

        # 3. Summarize groups of old episodic memories.
        stats["summarized"] = await self._summarize_old_memories()

        # 4. Deduplicate similar memories.
        stats["deduplicated"] = await self._deduplicate()

        import time as _time
        self._last_consolidation_time = _time.time()
        log.info(
            "Memory compression complete: %d summarized, %d pruned, %d deduped, %d decayed",
            stats["summarized"], stats["pruned"], stats["deduplicated"], stats["decayed"],
        )
        return stats

    async def _apply_decay(self) -> int:
        """Reduce importance of old memories over time.

        Memories older than 7 days get their importance reduced by
        decay_rate per day. This ensures old memories naturally fade
        unless they're frequently accessed (which boosts importance).
        """
        decayed = 0
        now = time.time()
        seven_days_ago = now - (7 * 86400)

        for store_attr in ("episodic", "semantic", "user", "project"):
            store = getattr(self.memory, store_attr, None)
            if store is None:
                continue

            try:
                # Get all memories (search with wildcard).
                memories = await store.search("*", top_k=500)
                for mem in memories:
                    if mem.created_at and mem.created_at.timestamp() < seven_days_ago:
                        # Calculate days since creation.
                        days_old = (now - mem.created_at.timestamp()) / 86400
                        if days_old > 7:
                            # Apply decay.
                            decay_factor = 1.0 - (self.decay_rate * (days_old - 7))
                            new_importance = max(0.01, mem.importance * decay_factor)

                            # Boost if recently accessed.
                            if mem.last_accessed:
                                days_since_access = (now - mem.last_accessed.timestamp()) / 86400
                                if days_since_access < 1:
                                    new_importance = min(1.0, new_importance + 0.1)

                            if abs(new_importance - mem.importance) > 0.01:
                                await store.update(mem.id, {"importance": new_importance})
                                decayed += 1
            except Exception as e:
                log.debug("Decay failed for %s: %s", store_attr, e)

        return decayed

    async def _prune_low_importance(self) -> int:
        """Delete memories with very low importance and no recent access.

        Criteria for deletion:
        - importance < 0.1
        - access_count == 0
        - older than 24 hours
        """
        pruned = 0
        now = time.time()
        one_day_ago = now - 86400

        for store_attr in ("episodic", "semantic", "user", "project"):
            store = getattr(self.memory, store_attr, None)
            if store is None:
                continue

            try:
                memories = await store.search("*", top_k=500)
                for mem in memories:
                    created_ts = mem.created_at.timestamp() if mem.created_at else 0
                    if (
                        mem.importance < 0.1
                        and mem.access_count == 0
                        and created_ts < one_day_ago
                    ):
                        await store.delete(mem.id)
                        pruned += 1
            except Exception as e:
                log.debug("Pruning failed for %s: %s", store_attr, e)

        log.info("Pruned %d low-importance memories", pruned)
        return pruned

    async def _summarize_old_memories(self) -> int:
        """Summarize groups of old episodic memories into compact semantic entries.

        Groups 10 old memories → 1 LLM summary → stored as semantic memory.
        Original memories are deleted after summarization.
        """
        if self.memory.episodic is None:
            return 0

        try:
            count = await self.memory.episodic.count()
            if count < self.consolidation_threshold:
                return 0

            # Get ALL episodic memories (search returns by importance DESC),
            # then re-sort by age ASC so we target the truly oldest ones.
            all_memories = await self.memory.episodic.search("*", top_k=200)
            all_memories.sort(key=lambda m: m.created_at or datetime.min.replace(tzinfo=timezone.utc))
            older = all_memories[:20]
            if not older or len(older) < 10:
                return 0

            # Combine their content.
            combined = "\n".join(f"- {m.content[:200]}" for m in older)

            # Ask the LLM to summarize.
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": (
                        "Summarize the following memories into 5 concise bullet points. "
                        "Each bullet should capture a key fact or lesson. Be specific."
                    )},
                    {"role": "user", "content": combined},
                ],
                temperature=0.2,
                max_tokens=512,
            )

            # Store the summary as a semantic memory.
            summary = Memory(
                type=MemoryType.SEMANTIC,
                content=resp.text,
                importance=0.8,
                confidence=0.9,
                tags=["consolidated", "summary", "auto-compressed"],
                source="memory_compressor",
            )
            await self.memory.add(summary)

            # Delete the original memories (only low-importance ones).
            deleted = 0
            for m in older:
                if m.importance < 0.3:
                    await self.memory.episodic.delete(m.id)
                    deleted += 1

            log.info("Summarized %d memories into 1 summary (deleted %d originals)", len(older), deleted)
            return deleted

        except Exception as e:
            log.error("Summarization failed: %s", e)
            return 0

    async def _deduplicate(self) -> int:
        """Remove duplicate memories using embedding similarity.

        If a new memory is >85% similar to an existing one, skip storing it.
        This runs on existing memories to clean up past duplicates.
        """
        deduped = 0

        for store_attr in ("episodic", "semantic"):
            store = getattr(self.memory, store_attr, None)
            if store is None:
                continue

            try:
                memories = await store.search("*", top_k=200)
                if len(memories) < 2:
                    continue

                # Compare each pair.
                # v9 fix: hash dedup is fast but shallow (first 200 chars
                # only, normalised lowercase). It misses paraphrases,
                # truncation differences, and near-duplicates. Embedding
                # dedup is strictly more accurate but was previously
                # gated on `deduped == 0` — meaning ANY hash-duplicate
                # found would suppress the embedding pass, leaving
                # semantically-near-duplicate memories that differ in
                # the first 200 chars uncaught. We now ALWAYS run the
                # embedding pass when an LLM is available, accumulating
                # any additional deletions on top of the hash-dedup
                # count. The embedding pass defensively re-fetches the
                # surviving memories so it doesn't try to delete IDs
                # that the hash pass already removed.
                seen_hashes: set[str] = set()
                for mem in memories:
                    # Simple dedup: hash the first 100 chars of content.
                    content_hash = self._content_hash(mem.content)
                    if content_hash in seen_hashes:
                        await store.delete(mem.id)
                        deduped += 1
                    else:
                        seen_hashes.add(content_hash)

                # Embedding-based dedup (more accurate but slower).
                # v9 fix: run unconditionally — see comment above.
                if self.llm is not None:
                    try:
                        # Re-fetch the surviving memories so the embedding
                        # pass doesn't reference IDs that the hash pass
                        # already deleted (which would raise on .delete()).
                        surviving = await store.search("*", top_k=200)
                        deduped += await self._embedding_dedup(store, surviving)
                    except Exception as e:
                        log.debug("Embedding dedup pass failed for %s: %s", store_attr, e)

            except Exception as e:
                log.debug("Dedup failed for %s: %s", store_attr, e)

        log.info("Deduplicated %d memories", deduped)
        return deduped

    async def _embedding_dedup(self, store, memories: list[Memory]) -> int:
        """Use embedding similarity to find and remove duplicates."""
        deduped = 0
        to_delete: list[str] = []

        # Get embeddings for all memories.
        embeddings: list[tuple[str, list[float]]] = []
        for mem in memories:
            if mem.embedding:
                embeddings.append((mem.id, mem.embedding))

        # Compare each pair.
        for i, (id1, emb1) in enumerate(embeddings):
            if id1 in to_delete:
                continue
            for j, (id2, emb2) in enumerate(embeddings):
                if i >= j or id2 in to_delete:
                    continue
                sim = self._cosine_similarity(emb1, emb2)
                if sim > self.similarity_threshold:
                    # Keep the one with higher importance.
                    mem1 = next((m for m in memories if m.id == id1), None)
                    mem2 = next((m for m in memories if m.id == id2), None)
                    if mem1 and mem2:
                        if mem1.importance >= mem2.importance:
                            to_delete.append(id2)
                        else:
                            to_delete.append(id1)

        for mid in to_delete:
            await store.delete(mid)
            deduped += 1

        return deduped

    @staticmethod
    def _content_hash(content: str) -> str:
        """Generate a hash of the content for fast dedup."""
        import hashlib
        normalized = content.lower().strip()[:200]
        return hashlib.md5(normalized.encode()).hexdigest()

    @staticmethod
    def _cosine_similarity(a: list[float], b: list[float]) -> float:
        """Calculate cosine similarity between two vectors."""
        if not a or not b or len(a) != len(b):
            return 0.0
        dot = sum(x * y for x, y in zip(a, b))
        na = math.sqrt(sum(x * x for x in a))
        nb = math.sqrt(sum(y * y for y in b))
        if na == 0 or nb == 0:
            return 0.0
        return dot / (na * nb)

    def should_consolidate(self) -> bool:
        """v8: Check whether enough time has passed since last consolidation.

        This is used alongside the write-count trigger in MemoryManager
        so that consolidation also fires on time intervals, not just
        after every N writes.  Prevents the scenario where 49 writes
        happen and then a restart loses the pending consolidation.
        """
        import time as _time
        return (_time.time() - self._last_consolidation_time) >= self._min_consolidation_interval_s

    async def should_store(self, memory: Memory) -> bool:
        """Check if a memory should be stored (dedup check).

        Returns True if the memory is novel enough to store.
        """
        if not self.memory or not memory.embedding:
            return True

        for store_attr in ("episodic", "semantic"):
            store = getattr(self.memory, store_attr, None)
            if store is None:
                continue
            try:
                results = await store.search(memory.embedding, top_k=1)
                if results:
                    sim = self._cosine_similarity(memory.embedding, results[0].embedding or [])
                    if sim > self.similarity_threshold:
                        log.debug("Skipping duplicate memory (similarity: %.2f)", sim)
                        return False
            except Exception:
                continue

        return True
