"""MemoryManager — orchestrates the 6-tier memory system.

Tiers:
  - Working     → in-process LRU (WorkingMemory)
  - Episodic    → SQLiteMemoryStore (table: memories_episodic)
  - Semantic    → SQLiteMemoryStore or ChromaMemoryStore (table: memories_semantic)
  - Procedural  → SQLiteMemoryStore (table: memories_procedural) — learned procedures
  - User        → SQLiteMemoryStore (table: memories_user)
  - Project     → SQLiteMemoryStore (table: memories_project)

Exposes a unified recall() API that the planner, reasoning engine, and
learning loop can call without caring about backend topology.
"""
from __future__ import annotations

import logging
from typing import Any

from adonai.config.settings import Config
from adonai.core.events import EventPublisher, EventTypes
from adonai.core.interfaces import LLMClient, MemoryStore
from adonai.core.models import Memory, MemoryType, Skill
from adonai.memory.working import WorkingMemory
from adonai.memory.sqlite_store import SQLiteMemoryStore
from adonai.memory.knowledge_graph import KnowledgeGraph

log = logging.getLogger(__name__)


class MemoryManager(EventPublisher):
    """Top-level memory facade combining all backends."""

    def __init__(
        self,
        config: Config,
        llm: LLMClient,
        *,
        episodic: MemoryStore | None = None,
        semantic: MemoryStore | None = None,
        procedural: MemoryStore | None = None,
        user: MemoryStore | None = None,
        project: MemoryStore | None = None,
        knowledge_graph: KnowledgeGraph | None = None,
        compressor: Any = None,
    ) -> None:
        self.config = config
        self.llm = llm
        self.working = WorkingMemory(capacity=config.memory.working_window)
        self.episodic = episodic
        self.semantic = semantic
        self.procedural = procedural
        self.user = user
        self.project = project
        self.kg = knowledge_graph
        self._write_count = 0
        self._consolidation_interval = config.memory.consolidation_interval
        # MemoryCompressor — wired lazily so we don't create a circular
        # import at module load.
        self.compressor = compressor

    async def add(self, memory: Memory) -> str:
        """Store a memory in the appropriate backend(s)."""
        self.working.add(memory)
        target = self._route(memory.type)
        if target is None:
            return memory.id
        # Before storing to long-term, check if the compressor says
        # the memory is not novel enough (dedup check).
        if self.compressor is not None:
            try:
                if not await self.compressor.should_store(memory):
                    log.debug("Compressor rejected memory (duplicate): %s", memory.id)
                    return memory.id
            except Exception as e:
                log.debug("Compressor should_store check failed: %s", e)
        mem_id = await target.add(memory)
        self._write_count += 1
        # Trigger consolidation on write-count OR elapsed time.
        should_consolidate = (
            self._write_count % self._consolidation_interval == 0
            or (self.compressor is not None and self.compressor.should_consolidate())
        )
        if should_consolidate:
            try:
                await self.consolidate()
            except Exception as e:
                log.warning("Memory consolidation failed: %s", e)
        return mem_id

    async def recall(
        self,
        query: str,
        top_k: int = 5,
        types: list[MemoryType] | None = None,
        filters: dict[str, Any] | None = None,
    ) -> list[Memory]:
        """Unified semantic recall across all configured stores.

        Searches episodic, semantic, procedural, and working memory by
        default.  Working memory results are converted to Memory objects
        with type=WORKING before being merged with the long-term results.
        """
        results: list[Memory] = []
        types = types or [
            MemoryType.EPISODIC, MemoryType.SEMANTIC, MemoryType.PROCEDURAL,
        ]

        if MemoryType.EPISODIC in types and self.episodic:
            try:
                results.extend(await self.episodic.search(query, top_k=top_k, filters=filters))
            except Exception as e:
                log.warning("Episodic search failed: %s", e)

        if MemoryType.SEMANTIC in types and self.semantic:
            try:
                results.extend(await self.semantic.search(query, top_k=top_k, filters=filters))
            except Exception as e:
                log.warning("Semantic search failed: %s", e)

        if MemoryType.PROCEDURAL in types and self.procedural:
            try:
                results.extend(await self.procedural.search(query, top_k=top_k, filters=filters))
            except Exception as e:
                log.warning("Procedural search failed: %s", e)

        # Also query working memory (recent items as Memory objects).
        if MemoryType.WORKING in types or not types:
            try:
                wm_top_k = max(1, top_k // 4)
                for item in self.working.recent(wm_top_k):
                    # working.recent() already returns Memory objects;
                    # ensure the type is set to WORKING.
                    if item.type != MemoryType.WORKING:
                        item = item.model_copy(update={"type": MemoryType.WORKING})
                    results.append(item)
            except Exception as e:
                log.warning("Working memory recall failed: %s", e)

        # Deduplicate by id, sort by a blended score that combines
        # similarity, importance, and recency.
        # v8 fix: similarity scores from per-store cosine search are now
        # propagated through to the merge ranking via _sim_score attribute
        # set by SQLiteMemoryStore.search().  The blended score is:
        #   0.6 * similarity + 0.3 * importance + 0.1 * recency_boost
        # For results from non-vector paths (LIKE, working memory) where
        # _sim_score is absent, we fall back to 0.5 (neutral).
        import time as _time
        now = _time.time()
        seen: set[str] = set()
        unique = []
        for m in results:
            if m.id in seen:
                continue
            seen.add(m.id)
            # Similarity from vector search (0..1), or 0.5 neutral default.
            sim = getattr(m, "_sim_score", 0.5)
            # Recency factor: items created in the last hour get a boost.
            age_s = now - (m.created_at.timestamp() if hasattr(m.created_at, 'timestamp') else 0)
            recency_boost = max(0.0, 1.0 - age_s / 3600.0) * 0.1  # up to +0.1
            # Blended score = weighted combination.
            m._blended_score = 0.6 * sim + 0.3 * m.importance + 0.1 * recency_boost  # type: ignore[attr-defined]
            unique.append(m)
        unique.sort(key=lambda m: getattr(m, "_blended_score", m.importance), reverse=True)
        return unique[:top_k]

    async def recall_similar(self, goal: str, top_k: int = 5) -> list:
        """Recall similar past experiences from episodic store."""
        if not self.episodic:
            return []
        try:
            memories = await self.episodic.search(goal, top_k=top_k)
            from adonai.core.models import Experience
            experiences = []
            for m in memories:
                exp_data = m.metadata.get("experience") if m.metadata else None
                if exp_data:
                    try:
                        experiences.append(Experience(**exp_data))
                    except Exception:
                        continue
            return experiences
        except Exception as e:
            log.warning("recall_similar failed: %s", e)
            return []

    async def get_preference(self, key: str, default: Any = None) -> Any:
        if not self.user:
            return default
        try:
            hits = await self.user.search(key, top_k=1, filters={"metadata.pref_key": key})
            if hits:
                return hits[0].metadata.get("pref_value", default)
        except Exception:
            pass
        return default

    async def set_preference(self, key: str, value: Any, confidence: float = 0.5) -> None:
        if not self.user:
            return
        mem = Memory(
            type=MemoryType.USER,
            content=f"{key}={value}",
            importance=confidence,
            metadata={"pref_key": key, "pref_value": value},
            tags=["preference"],
        )
        await self.add(mem)

    async def consolidate(self) -> int:
        """Summarize & re-rank older memories to bound growth.

        When a :class:`~adonai.memory.compression.MemoryCompressor` is
        wired (preferred), delegates to it for the full pipeline
        (decay + prune + summarise + dedup).  Otherwise falls back to
        the legacy LLM-summarize-and-delete path.
        """
        log.info("Running memory consolidation...")

        # Preferred path: use MemoryCompressor when wired.
        if self.compressor is not None:
            try:
                stats = await self.compressor.compress()
                # Emit memory.compressed event.
                await self._emit(EventTypes.MEMORY_COMPRESSED, {
                    "summarized": stats.get("summarized", 0),
                    "pruned": stats.get("pruned", 0),
                    "deduplicated": stats.get("deduplicated", 0),
                    "decayed": stats.get("decayed", 0),
                })
                return (
                    stats.get("summarized", 0)
                    + stats.get("pruned", 0)
                    + stats.get("deduplicated", 0)
                )
            except Exception as e:
                log.warning(
                    "MemoryCompressor.compress failed (%s) — falling back to legacy", e,
                )

        # Legacy path (no compressor).
        if not self.episodic:
            return 0
        try:
            count = await self.episodic.count()
            if count < 100:
                return 0
            # Pull a slice of older, low-importance memories.
            older = await self.episodic.search("*", top_k=20)
            if not older:
                return 0
            combined = "\n".join(f"- {m.content}" for m in older)
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": "Summarize the following memories into 5 concise bullet points."},
                    {"role": "user", "content": combined},
                ],
                temperature=0.2, max_tokens=256,
            )
            from adonai.core.models import MemoryType
            summary = Memory(
                type=MemoryType.SEMANTIC,
                content=resp.text,
                importance=0.7,
                tags=["consolidated", "summary"],
                source="consolidation",
            )
            await self.add(summary)
            for m in older:
                if m.importance < 0.3:
                    await self.episodic.delete(m.id)
            log.info("Consolidation complete.")
            return len(older)
        except Exception as e:
            log.error("Consolidation failed: %s", e)
            return 0

    def _route(self, t: MemoryType) -> MemoryStore | None:
        if t == MemoryType.WORKING:
            return None
        if t == MemoryType.EPISODIC:
            return self.episodic
        if t == MemoryType.SEMANTIC:
            return self.semantic
        if t == MemoryType.PROCEDURAL:
            return self.procedural
        if t == MemoryType.USER:
            return self.user
        if t == MemoryType.PROJECT:
            return self.project
        return None


def build_memory_manager(config: Config, llm: LLMClient) -> MemoryManager:
    """Build a fully-wired MemoryManager from *config*."""
    episodic = SQLiteMemoryStore(
        db_path=config.memory.sqlite_path,
        table_name="memories_episodic",
        embedding_dim=config.llm.embedding_dim,
        llm=llm,
    )
    procedural = SQLiteMemoryStore(
        db_path=config.memory.sqlite_path,
        table_name="memories_procedural",
        embedding_dim=config.llm.embedding_dim,
        llm=llm,
    )
    user = SQLiteMemoryStore(
        db_path=config.memory.sqlite_path,
        table_name="memories_user",
        embedding_dim=config.llm.embedding_dim,
        llm=llm,
    )
    project = SQLiteMemoryStore(
        db_path=config.memory.sqlite_path,
        table_name="memories_project",
        embedding_dim=config.llm.embedding_dim,
        llm=llm,
    )

    semantic: MemoryStore | None = None
    if config.memory.use_chroma:
        try:
            from adonai.memory.chroma_store import ChromaMemoryStore
            semantic = ChromaMemoryStore(
                persist_path=config.memory.chroma_path,
                collection="semantic",
                embedding_dim=config.llm.embedding_dim,
                llm=llm,
            )
        except ImportError:
            pass
    if semantic is None:
        semantic = SQLiteMemoryStore(
            db_path=config.memory.sqlite_path,
            table_name="memories_semantic",
            embedding_dim=config.llm.embedding_dim,
            llm=llm,
        )

    kg = None
    if config.memory.use_knowledge_graph:
        kg = KnowledgeGraph(
            config.memory.graph_path,
            llm=llm,
            default_confidence=config.knowledge_graph.default_confidence,
        )

    # Build the MemoryManager first so the compressor can reference it.
    manager = MemoryManager(
        config=config, llm=llm,
        episodic=episodic, semantic=semantic, procedural=procedural,
        user=user, project=project, knowledge_graph=kg,
    )

    # Wire the MemoryCompressor (preferred consolidation path).
    try:
        from adonai.memory.compression import MemoryCompressor
        manager.compressor = MemoryCompressor(
            llm=llm,
            memory_manager=manager,
            consolidation_threshold=config.memory.consolidation_interval,
        )
    except Exception as e:
        log.debug("MemoryCompressor wiring skipped: %s", e)

    return manager
