"""Database initialization — idempotent schema creation."""
from __future__ import annotations

import logging
import sqlite3
from pathlib import Path

from adonai.config.settings import Config

log = logging.getLogger(__name__)


_SCHEMA = """
CREATE TABLE IF NOT EXISTS memories_episodic (
    id TEXT PRIMARY KEY, type TEXT NOT NULL, content TEXT NOT NULL,
    embedding TEXT, metadata TEXT NOT NULL DEFAULT '{}',
    importance REAL NOT NULL DEFAULT 0.5, confidence REAL NOT NULL DEFAULT 1.0,
    access_count INTEGER NOT NULL DEFAULT 0, last_accessed REAL,
    created_at REAL NOT NULL, expires_at REAL, tags TEXT NOT NULL DEFAULT '[]',
    source TEXT, session_id TEXT
);
CREATE TABLE IF NOT EXISTS memories_semantic (
    id TEXT PRIMARY KEY, type TEXT NOT NULL, content TEXT NOT NULL,
    embedding TEXT, metadata TEXT NOT NULL DEFAULT '{}',
    importance REAL NOT NULL DEFAULT 0.5, confidence REAL NOT NULL DEFAULT 1.0,
    access_count INTEGER NOT NULL DEFAULT 0, last_accessed REAL,
    created_at REAL NOT NULL, expires_at REAL, tags TEXT NOT NULL DEFAULT '[]',
    source TEXT, session_id TEXT
);
CREATE TABLE IF NOT EXISTS memories_user (
    id TEXT PRIMARY KEY, type TEXT NOT NULL, content TEXT NOT NULL,
    embedding TEXT, metadata TEXT NOT NULL DEFAULT '{}',
    importance REAL NOT NULL DEFAULT 0.5, confidence REAL NOT NULL DEFAULT 1.0,
    access_count INTEGER NOT NULL DEFAULT 0, last_accessed REAL,
    created_at REAL NOT NULL, expires_at REAL, tags TEXT NOT NULL DEFAULT '[]',
    source TEXT, session_id TEXT
);
CREATE TABLE IF NOT EXISTS memories_project (
    id TEXT PRIMARY KEY, type TEXT NOT NULL, content TEXT NOT NULL,
    embedding TEXT, metadata TEXT NOT NULL DEFAULT '{}',
    importance REAL NOT NULL DEFAULT 0.5, confidence REAL NOT NULL DEFAULT 1.0,
    access_count INTEGER NOT NULL DEFAULT 0, last_accessed REAL,
    created_at REAL NOT NULL, expires_at REAL, tags TEXT NOT NULL DEFAULT '[]',
    source TEXT, session_id TEXT
);
CREATE TABLE IF NOT EXISTS tasks (
    id TEXT PRIMARY KEY, goal TEXT NOT NULL, status TEXT NOT NULL,
    plan TEXT NOT NULL DEFAULT '{}', steps_log TEXT NOT NULL DEFAULT '[]',
    result TEXT, created_at REAL NOT NULL, updated_at REAL NOT NULL,
    parent_task_id TEXT, owner_agent TEXT, session_id TEXT
);
CREATE TABLE IF NOT EXISTS task_checkpoints (
    id TEXT PRIMARY KEY, task_id TEXT NOT NULL, snapshot TEXT NOT NULL,
    created_at REAL NOT NULL,
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_updated ON tasks(updated_at);
CREATE INDEX IF NOT EXISTS idx_checkpoints_task ON task_checkpoints(task_id);
"""


def init_db(config: Config | None = None, *, path: str | Path | None = None) -> Path:
    """Create the SQLite DB + all required tables (idempotent)."""
    if config is None:
        from adonai.config.settings import load_config
        config = load_config()
    db_path = Path(path) if path else Path(config.memory.sqlite_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)
    log.info("Initialising SQLite DB at %s", db_path)
    conn = sqlite3.connect(str(db_path))
    try:
        conn.executescript(_SCHEMA)
        conn.commit()
    finally:
        conn.close()
    return db_path
