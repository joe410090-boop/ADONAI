"""MCP integration — client + discovery + health monitoring + routing."""
from adonai.mcp.client import MCPClientImpl, build_mcp_client

__all__ = ["MCPClientImpl", "build_mcp_client"]
