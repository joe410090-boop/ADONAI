"""MCP client — async, multi-server, with health monitoring + fallback routing."""
from __future__ import annotations

import asyncio
import json
import logging
import time
from pathlib import Path
from typing import Any

import yaml

from adonai.config.settings import MCPConfig
from adonai.core.exceptions import MCPError
from adonai.core.interfaces import MCPClient

log = logging.getLogger(__name__)


class MCPClientImpl(MCPClient):
    """Async MCP client — manages multiple MCP server connections."""

    def __init__(self, config: MCPConfig) -> None:
        self.config = config
        self._sessions: dict[str, Any] = {}
        self._transports: dict[str, Any] = {}  # AsyncExitStack per server (for clean shutdown)
        self._tools_cache: dict[str, list[dict]] = {}
        self._health: dict[str, dict[str, Any]] = {}  # server → {healthy, last_check, error}
        self._lock = asyncio.Lock()

    async def start(self) -> None:
        """Load the MCP servers config + connect to all allowed servers."""
        config_path = Path(self.config.config_path)
        if not config_path.exists():
            log.info("No MCP config at %s — skipping discovery", config_path)
            return
        try:
            data = yaml.safe_load(config_path.read_text()) or {}
        except Exception as e:
            log.warning("Failed to parse MCP config %s: %s", config_path, e)
            return

        servers = data.get("mcpServers") or data.get("servers") or {}
        for name, spec in servers.items():
            if self.config.allowed_servers and name not in self.config.allowed_servers:
                continue
            try:
                await self.connect(name, spec)
            except Exception as e:
                log.warning("MCP connect(%s) failed: %s", name, e)

    async def connect(self, server_name: str, config: dict) -> bool:
        try:
            from mcp import ClientSession, StdioServerParameters
            from mcp.client.stdio import stdio_client
        except ImportError:
            log.warning("`mcp` package not installed — MCP disabled")
            return False

        cmd = config.get("command")
        args = config.get("args", [])
        env = config.get("env")
        if not cmd:
            log.warning("MCP server %s has no command — skipping", server_name)
            return False

        try:
            params = StdioServerParameters(command=cmd, args=args, env=env)
            # Use AsyncExitStack so that if session.initialize() raises,
            # both the stdio_client and the ClientSession are properly
            # exited — preventing subprocess + pipe leaks. The previous
            # direct __aenter__ calls left resources dangling on failure.
            import contextlib
            async with contextlib.AsyncExitStack() as stack:
                read, write = await stack.enter_async_context(stdio_client(params))
                session = await stack.enter_async_context(ClientSession(read, write))
                await session.initialize()
                # Pop the session + transport out of the stack so they stay
                # alive after we exit the `async with` block. We transfer
                # ownership to self._sessions / self._transports.
                self._sessions[server_name] = session
                self._transports[server_name] = stack.pop_all()
            self._health[server_name] = {
                "healthy": True, "last_check": time.time(), "error": None,
            }
            log.info("Connected to MCP server %s", server_name)
            return True
        except Exception as e:
            self._health[server_name] = {
                "healthy": False, "last_check": time.time(), "error": str(e),
            }
            log.warning("MCP session init for %s failed: %s", server_name, e)
            return False

    async def discover_tools(self, server_name: str) -> list[dict]:
        session = self._sessions.get(server_name)
        if session is None:
            return []
        if server_name in self._tools_cache:
            return self._tools_cache[server_name]
        try:
            result = await asyncio.wait_for(
                session.list_tools(), timeout=self.config.discovery_timeout_s
            )
        except asyncio.TimeoutError:
            log.warning("MCP discover_tools(%s) timed out", server_name)
            return []
        except Exception as e:
            log.warning("MCP discover_tools(%s) failed: %s", server_name, e)
            return []
        tools = []
        for t in result.tools:
            tools.append({
                "name": t.name,
                "description": t.description or "",
                "parameters": t.inputSchema or {"type": "object", "properties": {}},
            })
        self._tools_cache[server_name] = tools
        return tools

    async def call_tool(self, server_name: str, tool_name: str, params: dict) -> Any:
        session = self._sessions.get(server_name)
        if session is None:
            raise MCPError(f"MCP server {server_name!r} not connected")
        try:
            result = await asyncio.wait_for(
                session.call_tool(tool_name, params),
                timeout=self.config.tool_call_timeout_s,
            )
        except asyncio.TimeoutError:
            raise MCPError(f"MCP call_tool({server_name}.{tool_name}) timed out")
        if hasattr(result, "content") and result.content:
            pieces = []
            for c in result.content:
                if hasattr(c, "text"):
                    pieces.append(c.text)
                else:
                    pieces.append(str(c))
            return "\n".join(pieces)
        return result

    async def list_servers(self) -> list[str]:
        return list(self._sessions.keys())

    async def disconnect(self, server_name: str) -> bool:
        session = self._sessions.pop(server_name, None)
        transport_stack = self._transports.pop(server_name, None)
        self._tools_cache.pop(server_name, None)
        self._health.pop(server_name, None)
        if session is None and transport_stack is None:
            return False
        # Close via the AsyncExitStack — this exits both the ClientSession
        # and the underlying stdio_client, killing the subprocess cleanly.
        if transport_stack is not None:
            try:
                await transport_stack.aclose()
            except Exception as e:
                log.debug("MCP disconnect(%s) transport close: %s", server_name, e)
        elif session is not None:
            # Fallback for sessions created before the AsyncExitStack fix.
            try:
                await session.__aexit__(None, None, None)
            except Exception as e:
                log.debug("MCP disconnect(%s) session close: %s", server_name, e)
        return True

    async def health_check(self) -> dict[str, dict[str, Any]]:
        """Check the health of all connected servers."""
        for name in list(self._sessions.keys()):
            try:
                # Cheap health check — list_tools with a short timeout.
                await asyncio.wait_for(
                    self._sessions[name].list_tools(),
                    timeout=5.0,
                )
                self._health[name] = {
                    "healthy": True, "last_check": time.time(), "error": None,
                }
            except Exception as e:
                self._health[name] = {
                    "healthy": False, "last_check": time.time(), "error": str(e),
                }
        return dict(self._health)

    async def close(self) -> None:
        for name in list(self._sessions.keys()):
            await self.disconnect(name)


async def build_mcp_client(config: MCPConfig) -> MCPClientImpl | None:
    """Build an MCPClient from config; returns None when disabled."""
    if not config.enabled:
        return None
    try:
        client = MCPClientImpl(config)
        await client.start()
        return client
    except ImportError:
        return None
    except Exception as e:
        log.warning("MCP client build failed: %s", e)
        return None
