"""A.D.O.N.AI v4 — Autonomous Distributed Orchestrator for Networked AI.

A research-grade autonomous AI operating system.  Builds on v3 with 12
research-grade upgrades:

    v3 foundation:
        - 8-agent hierarchy (executive, planner, researcher, coder, memory,
          reflection, learning, file_analyst, scientist)
        - 5-tier memory system (working, episodic, semantic, user, project)
        - 6-strategy reasoning engine (CoT, ToT, self-consistency,
          reflection, debate, verification)
        - Dynamic skill acquisition + self-improvement loop
        - Knowledge graph + multi-agent collaboration (blackboard + voting)
        - Autonomous execution engine with checkpointing + crash recovery
        - Universal tool framework + enterprise MCP integration

    v4 research-grade extensions:
        1.  Critic Agent — Plan→Execute→Critic→Verifier pipeline
        2.  Knowledge Graph — confidence + evidence tracking + LLM extraction
        3.  Tree-of-Thought Planning — N candidate plans, ranked
        4.  Reflection Engine — structured Lesson objects after every task
        5.  Skill Evolution System — patterns → skills → callable tools
        6.  Multi-Agent Debate — Researcher/Skeptic/Engineer + Judge
        7.  Hypothesis Generator — falsifiable hypotheses + Bayesian updates
        8.  Autonomous Experiment Loop — observe→hypothesize→test→learn
        9.  Model Router — complexity/cost/latency-aware LLM selection
        10. Self-Improvement Framework — sandboxed patches + auto-rollback
        11. Simulation Abstraction — OpenFOAM/PyBullet/CARLA/Isaac Sim API
        12. Strategic Reasoning — Mission→Strategic→Tactical→Task hierarchy

Lazy attribute access keeps `import adonai` fast.
"""
from __future__ import annotations

__version__ = "4.0.0"


def __getattr__(name: str):
    """PEP 562 — lazy attribute access for heavy subsystems."""
    if name == "ADONAI":
        from adonai.runtime import ADONAI
        return ADONAI
    if name in ("Config", "load_config", "get_config"):
        from adonai.config.settings import load_config, Config, get_config
        return {"Config": Config, "load_config": load_config, "get_config": get_config}[name]
    raise AttributeError(f"module 'adonai' has no attribute {name!r}")


__all__ = ["ADONAI", "Config", "load_config", "get_config", "__version__"]
