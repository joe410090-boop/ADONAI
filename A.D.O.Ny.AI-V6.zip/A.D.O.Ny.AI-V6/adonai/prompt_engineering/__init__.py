"""Self-Prompt Engineering System — turns raw user requests into
structured engineering prompts before planning.

Public API::

    from adonai.prompt_engineering import PromptEngineeringNode, PromptPackage

    node = PromptEngineeringNode(llm=ai.llm, store=PromptStore(db_path))
    package = await node.engineer("Build me a CRM")
    print(package.engineered_prompt)
    print(package.architecture_plan.milestones)
"""
from __future__ import annotations

from adonai.prompt_engineering.architecture_planner import ArchitecturePlanner
from adonai.prompt_engineering.detector import DomainDetector
from adonai.prompt_engineering.models import (
    ArchitecturePlan,
    Complexity,
    DomainTemplate,
    InferredRequirement,
    Milestone,
    ModuleSpec,
    ProjectType,
    PromptOutcome,
    PromptPackage,
    QualityGate,
    Risk,
    SoftwareDomain,
    TestingStrategy,
)
from adonai.prompt_engineering.node import PromptEngineeringNode
from adonai.prompt_engineering.requirements import RequirementsInferrer
from adonai.prompt_engineering.store import PromptStore
from adonai.prompt_engineering.templates import (
    BaseDomainTemplate,
    TemplateRegistry,
    get_global_registry,
    register_template,
)

__all__ = [
    "ArchitecturePlanner",
    "ArchitecturePlan",
    "BaseDomainTemplate",
    "Complexity",
    "DomainDetector",
    "DomainTemplate",
    "InferredRequirement",
    "Milestone",
    "ModuleSpec",
    "ProjectType",
    "PromptEngineeringNode",
    "PromptOutcome",
    "PromptPackage",
    "QualityGate",
    "RequirementsInferrer",
    "Risk",
    "SoftwareDomain",
    "PromptStore",
    "TemplateRegistry",
    "TestingStrategy",
    "get_global_registry",
    "register_template",
]
