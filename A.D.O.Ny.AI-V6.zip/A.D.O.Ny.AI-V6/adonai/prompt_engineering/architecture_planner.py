"""Architecture planner — produces a high-level implementation plan.

Given a :class:`PromptPackage`, the planner synthesises:

* milestones (ordered phases)
* module specs (files to create)
* external dependencies
* execution order
* risks + mitigations
* validation + testing strategy

The planner is heuristic-first (no LLM required) so it always returns
something useful.  When the LLM is available, it can be used to refine
milestone names and add domain-specific risks (best-effort).
"""
from __future__ import annotations

import logging
from typing import Any

from adonai.prompt_engineering.models import (
    ArchitecturePlan,
    Complexity,
    DomainTemplate,
    Milestone,
    ModuleSpec,
    ProjectType,
    PromptPackage,
    Risk,
    TestingStrategy,
)

log = logging.getLogger(__name__)


class ArchitecturePlanner:
    """Synthesise an :class:`ArchitecturePlan` from a :class:`PromptPackage`."""

    def __init__(self, llm: Any = None) -> None:
        self.llm = llm

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    def plan(
        self,
        package: PromptPackage,
        template: DomainTemplate | None = None,
    ) -> ArchitecturePlan:
        """Produce an architecture plan."""
        modules = self._derive_modules(package, template)
        milestones = self._derive_milestones(package, modules)
        risks = self._derive_risks(package, template)
        testing = self._derive_testing(package, template)
        execution_order = [m.name for m in milestones]
        estimated_loc = self._estimate_loc(package, modules)

        return ArchitecturePlan(
            summary=self._summary(package),
            milestones=milestones,
            modules=modules,
            dependencies=list(template.common_project_structure) if template else [],
            execution_order=execution_order,
            risks=risks,
            validation_strategy=self._validation_strategy(package, testing),
            testing_strategy=testing,
            estimated_loc=estimated_loc,
        )

    # ------------------------------------------------------------------ #
    # Module derivation
    # ------------------------------------------------------------------ #

    def _derive_modules(
        self, package: PromptPackage, template: DomainTemplate | None,
    ) -> list[ModuleSpec]:
        """Derive module specs from the domain + inferred requirements."""
        modules: list[ModuleSpec] = []

        # Always include a project root + config.
        modules.append(ModuleSpec(
            name="project_root",
            purpose="Project layout + README + .gitignore + LICENSE",
            files=["README.md", ".gitignore", "LICENSE", "pyproject.toml"],
        ))
        modules.append(ModuleSpec(
            name="config",
            purpose="Layered configuration (env > file > defaults)",
            files=["config/settings.py", "config/default.yaml", ".env.example"],
        ))
        modules.append(ModuleSpec(
            name="tests",
            purpose="Test suite + fixtures",
            files=["tests/__init__.py", "tests/conftest.py", "tests/test_smoke.py"],
        ))

        # Domain-driven modules.
        d = package.detected_domain
        if d.value == "backend_api":
            modules.extend([
                ModuleSpec(
                    name="api_routes",
                    purpose="HTTP route handlers",
                    dependencies=["schemas", "services"],
                    files=["app/api/routes.py", "app/api/deps.py"],
                ),
                ModuleSpec(
                    name="schemas",
                    purpose="Pydantic request/response models",
                    files=["app/schemas.py"],
                ),
                ModuleSpec(
                    name="services",
                    purpose="Business logic layer",
                    dependencies=["models", "repositories"],
                    files=["app/services.py"],
                ),
                ModuleSpec(
                    name="models",
                    purpose="SQLAlchemy ORM models",
                    files=["app/models.py"],
                ),
                ModuleSpec(
                    name="repositories",
                    purpose="Data access layer",
                    dependencies=["models"],
                    files=["app/repositories.py"],
                ),
                ModuleSpec(
                    name="auth",
                    purpose="JWT issuance + verification",
                    files=["app/auth.py"],
                ),
                ModuleSpec(
                    name="db",
                    purpose="Database session + migrations",
                    files=["app/db.py", "alembic.ini", "alembic/versions/"],
                ),
            ])
        elif d.value in ("frontend", "web_development", "full_stack"):
            modules.extend([
                ModuleSpec(
                    name="components",
                    purpose="Reusable UI components",
                    files=["src/components/"],
                ),
                ModuleSpec(
                    name="pages",
                    purpose="Top-level pages / routes",
                    dependencies=["components"],
                    files=["src/pages/"],
                ),
                ModuleSpec(
                    name="hooks",
                    purpose="Custom React hooks",
                    files=["src/hooks/"],
                ),
                ModuleSpec(
                    name="store",
                    purpose="Global state management",
                    files=["src/store/"],
                ),
                ModuleSpec(
                    name="api_client",
                    purpose="Typed API client",
                    files=["src/api/"],
                ),
            ])
        elif d.value == "cli":
            modules.extend([
                ModuleSpec(
                    name="cli",
                    purpose="CLI entry point + subcommands",
                    files=["cli/main.py", "cli/commands.py"],
                ),
                ModuleSpec(
                    name="core",
                    purpose="Core logic invoked by the CLI",
                    files=["cli/core.py"],
                ),
            ])
        elif d.value in ("ai_ml", "scientific_computing"):
            modules.extend([
                ModuleSpec(
                    name="data",
                    purpose="Data loading + preprocessing",
                    files=["src/data.py"],
                ),
                ModuleSpec(
                    name="model",
                    purpose="Model definitions + training loop",
                    dependencies=["data"],
                    files=["src/model.py", "src/train.py"],
                ),
                ModuleSpec(
                    name="evaluate",
                    purpose="Evaluation metrics + reports",
                    dependencies=["model"],
                    files=["src/evaluate.py"],
                ),
                ModuleSpec(
                    name="notebooks",
                    purpose="Exploratory notebooks",
                    files=["notebooks/exploration.ipynb"],
                ),
            ])
        elif d.value == "autonomous_agents":
            modules.extend([
                ModuleSpec(
                    name="agent",
                    purpose="Agent core + reasoning loop",
                    files=["agent/core.py", "agent/reasoning.py"],
                ),
                ModuleSpec(
                    name="tools",
                    purpose="Tool registry + builtin tools",
                    files=["agent/tools/__init__.py", "agent/tools/builtin.py"],
                ),
                ModuleSpec(
                    name="memory",
                    purpose="Multi-tier memory",
                    files=["agent/memory.py"],
                ),
                ModuleSpec(
                    name="safety",
                    purpose="Safety guard + permission policy",
                    files=["agent/safety.py"],
                ),
            ])
        elif d.value in ("devops", "cloud_infrastructure"):
            modules.extend([
                ModuleSpec(
                    name="terraform",
                    purpose="Terraform modules + root stack",
                    files=["infra/main.tf", "infra/variables.tf", "infra/outputs.tf"],
                ),
                ModuleSpec(
                    name="ci_cd",
                    purpose="CI/CD pipeline definitions",
                    files=[".github/workflows/deploy.yml"],
                ),
                ModuleSpec(
                    name="scripts",
                    purpose="Operational runbooks + scripts",
                    files=["scripts/deploy.sh", "scripts/rollback.sh"],
                ),
            ])
        else:
            # Generic application skeleton.
            modules.append(ModuleSpec(
                name="core",
                purpose="Domain-specific core logic",
                files=["src/core.py"],
            ))

        # Add Docker / CI / docs as universal modules.
        modules.append(ModuleSpec(
            name="containerisation",
            purpose="Container build + compose for local dev",
            files=["Dockerfile", "docker-compose.yml"],
        ))
        modules.append(ModuleSpec(
            name="ci",
            purpose="CI workflow (lint + test on PRs)",
            files=[".github/workflows/ci.yml"],
        ))

        return modules

    # ------------------------------------------------------------------ #
    # Milestone derivation
    # ------------------------------------------------------------------ #

    def _derive_milestones(
        self, package: PromptPackage, modules: list[ModuleSpec],
    ) -> list[Milestone]:
        """Group modules into ordered milestones."""
        # Default phases for any project.
        phases = [
            ("scaffold", "Project scaffold + tooling + CI"),
            ("core", "Core domain logic + data layer"),
            ("features", "Feature implementation covering inferred requirements"),
            ("hardening", "Auth, security, error handling, logging"),
            ("testing", "Unit + integration tests + coverage"),
            ("docs", "README, API docs, deployment guide"),
            ("release", "Docker, CI/CD, release tagging"),
        ]

        # Assign modules to phases by name.
        module_to_phase = {
            "project_root": "scaffold",
            "config": "scaffold",
            "containerisation": "release",
            "ci": "release",
            "tests": "testing",
            "api_routes": "features",
            "schemas": "core",
            "services": "core",
            "models": "core",
            "repositories": "core",
            "db": "core",
            "auth": "hardening",
            "components": "features",
            "pages": "features",
            "hooks": "features",
            "store": "core",
            "api_client": "core",
            "cli": "features",
            "core_cli": "core",
            "data": "core",
            "model": "core",
            "evaluate": "testing",
            "notebooks": "docs",
            "agent": "core",
            "tools": "core",
            "memory": "core",
            "safety": "hardening",
            "terraform": "features",
            "ci_cd": "release",
            "scripts": "docs",
            "core": "core",
        }

        by_phase: dict[str, list[str]] = {p[0]: [] for p in phases}
        for m in modules:
            phase = module_to_phase.get(m.name, "features")
            by_phase[phase].append(m.name)

        out: list[Milestone] = []
        for i, (name, desc) in enumerate(phases):
            out.append(Milestone(
                name=name,
                description=desc,
                modules=by_phase[name],
                dependencies=[out[i - 1].name] if i > 0 else [],
                validation=f"Phase '{name}' passes its smoke test",
            ))
        return out

    # ------------------------------------------------------------------ #
    # Risk derivation
    # ------------------------------------------------------------------ #

    def _derive_risks(
        self, package: PromptPackage, template: DomainTemplate | None,
    ) -> list[Risk]:
        risks: list[Risk] = []
        c = package.estimated_complexity
        if c in (Complexity.COMPLEX, Complexity.VERY_COMPLEX):
            risks.append(Risk(
                description="High complexity — scope creep likely",
                severity="high",
                mitigation="Lock the milestone list before implementation; reject scope changes without explicit ack.",
            ))

        # Domain-specific risks.
        d = package.detected_domain
        if d.value == "backend_api":
            risks.append(Risk(
                description="Database schema may evolve during development",
                severity="medium",
                mitigation="Adopt Alembic from day 1; never apply schema changes manually.",
            ))
            risks.append(Risk(
                description="Auth implementation has many edge cases (token rotation, revocation, RBAC)",
                severity="high",
                mitigation="Use a battle-tested library (e.g. fastapi-users); add integration tests for every auth flow.",
            ))
        elif d.value in ("frontend", "web_development", "full_stack"):
            risks.append(Risk(
                description="State management can become inconsistent as features grow",
                severity="medium",
                mitigation="Adopt a single source of truth (Zustand / Redux Toolkit) before adding the 3rd feature.",
            ))
        elif d.value == "autonomous_agents":
            risks.append(Risk(
                description="Unbounded tool use can cause runaway costs + side effects",
                severity="critical",
                mitigation="Hard cap on tool calls per task + human approval gate for destructive tools.",
            ))
        elif d.value in ("devops", "cloud_infrastructure"):
            risks.append(Risk(
                description="Destructive infra changes can take down production",
                severity="critical",
                mitigation="Always run `plan` first; gate apply behind human approval; enable state locking.",
            ))
        elif d.value == "ai_ml":
            risks.append(Risk(
                description="Training data may leak into evaluation set",
                severity="high",
                mitigation="Strict train/val/test split before any modelling; log dataset hash.",
            ))

        # Inferred-requirement overload risk.
        if len(package.inferred_requirements) > 15:
            risks.append(Risk(
                description=f"{len(package.inferred_requirements)} inferred requirements may over-scope the MVP",
                severity="medium",
                mitigation="Promote only `must`-priority items to v1; defer `should`/`could` to later iterations.",
            ))

        return risks

    # ------------------------------------------------------------------ #
    # Testing strategy
    # ------------------------------------------------------------------ #

    def _derive_testing(
        self, package: PromptPackage, template: DomainTemplate | None,
    ) -> TestingStrategy:
        if template is not None:
            base = template.testing_expectations
        else:
            base = TestingStrategy()
        # Adjust by complexity.
        c = package.estimated_complexity
        if c in (Complexity.COMPLEX, Complexity.VERY_COMPLEX):
            base.load_tests = True
            base.security_tests = True
            base.coverage_target = 0.9
        return base

    # ------------------------------------------------------------------ #
    # Validation + summary
    # ------------------------------------------------------------------ #

    def _validation_strategy(self, package: PromptPackage, testing: TestingStrategy) -> str:
        parts = [
            f"Unit tests must pass with coverage ≥ {int(testing.coverage_target * 100)}%",
            "All quality gates (lint, type-check, format) must be green on CI",
        ]
        if testing.integration_tests:
            parts.append("Integration tests must cover the top 3 user journeys")
        if testing.security_tests:
            parts.append("Security scan (pip-audit / npm audit / trivy) must report 0 criticals")
        return "; ".join(parts) + "."

    def _summary(self, package: PromptPackage) -> str:
        return (
            f"{package.detected_domain.value} project ({package.project_type.value}) "
            f"using {package.recommended_language}"
            + (f" + {package.framework}" if package.framework else "")
            + f"; complexity={package.estimated_complexity.value}"
        )

    def _estimate_loc(self, package: PromptPackage, modules: list[ModuleSpec]) -> int:
        """Rough LoC estimate: 200 per module + complexity multiplier."""
        base = len(modules) * 200
        multiplier = {
            Complexity.TRIVIAL: 0.5,
            Complexity.SIMPLE: 0.75,
            Complexity.MODERATE: 1.0,
            Complexity.COMPLEX: 1.5,
            Complexity.VERY_COMPLEX: 2.5,
        }.get(package.estimated_complexity, 1.0)
        return int(base * multiplier)
