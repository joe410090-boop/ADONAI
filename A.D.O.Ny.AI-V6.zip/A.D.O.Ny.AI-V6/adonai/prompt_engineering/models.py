"""Pydantic models for the Self-Prompt Engineering System.

These models are the structured contract between the Prompt Engineering
Node and the rest of the A.D.O.N.AI pipeline (planner, executor, agents).
"""
from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


# --------------------------------------------------------------------------- #
# Enums
# --------------------------------------------------------------------------- #

class SoftwareDomain(str, Enum):
    """Recognised software engineering domains.

    New domains can be added by registering a template via
    :class:`adonai.prompt_engineering.templates.TemplateRegistry`; the
    enum is the canonical list of *built-in* domains.
    """
    WEB_DEVELOPMENT = "web_development"
    BACKEND_API = "backend_api"
    FRONTEND = "frontend"
    FULL_STACK = "full_stack"
    MOBILE = "mobile"
    DESKTOP = "desktop"
    CLI = "cli"
    AI_ML = "ai_ml"
    AUTONOMOUS_AGENTS = "autonomous_agents"
    ROBOTICS = "robotics"
    EMBEDDED = "embedded"
    OPERATING_SYSTEMS = "operating_systems"
    NETWORKING = "networking"
    CYBERSECURITY = "cybersecurity"
    DEVOPS = "devops"
    CLOUD_INFRASTRUCTURE = "cloud_infrastructure"
    DATABASES = "databases"
    BLOCKCHAIN = "blockchain"
    GAME_DEVELOPMENT = "game_development"
    BROWSER_DEVELOPMENT = "browser_development"
    COMPILERS = "compilers"
    DISTRIBUTED_SYSTEMS = "distributed_systems"
    DATA_ENGINEERING = "data_engineering"
    SCIENTIFIC_COMPUTING = "scientific_computing"
    UNKNOWN = "unknown"


class ProjectType(str, Enum):
    """High-level project shape — drives template selection."""
    SERVICE = "service"               # HTTP API, gRPC service, microservice
    LIBRARY = "library"               # importable package, SDK
    APPLICATION = "application"       # end-user app (web/mobile/desktop/cli)
    PIPELINE = "pipeline"             # ETL, batch, streaming
    INFRASTRUCTURE = "infrastructure" # terraform/k8s/ansible
    TOOL = "tool"                     # CLI utility, dev tool
    RESEARCH = "research"             # experiment, notebook, benchmark
    EMBEDDED_FIRMWARE = "embedded_firmware"
    OTHER = "other"


class Complexity(str, Enum):
    TRIVIAL = "trivial"
    SIMPLE = "simple"
    MODERATE = "moderate"
    COMPLEX = "complex"
    VERY_COMPLEX = "very_complex"


# --------------------------------------------------------------------------- #
# Sub-models
# --------------------------------------------------------------------------- #

class Risk(BaseModel):
    """Identified risk + mitigation."""
    description: str
    severity: str = Field(default="medium", description="low|medium|high|critical")
    mitigation: str = ""


class Milestone(BaseModel):
    """A high-level milestone in the architecture plan."""
    name: str
    description: str = ""
    modules: list[str] = Field(default_factory=list)
    dependencies: list[str] = Field(default_factory=list, description="other milestone names this depends on")
    validation: str = ""


class ModuleSpec(BaseModel):
    """A module/file to be created."""
    name: str
    purpose: str = ""
    dependencies: list[str] = Field(default_factory=list)
    files: list[str] = Field(default_factory=list, description="expected file paths")


class InferredRequirement(BaseModel):
    """A requirement inferred from the domain when the user omitted it."""
    category: str = Field(description="e.g. 'auth', 'logging', 'testing'")
    description: str
    rationale: str = ""
    priority: str = Field(default="should", description="must|should|could")


class TestingStrategy(BaseModel):
    """How the project should be tested."""
    unit_tests: bool = True
    integration_tests: bool = True
    end_to_end_tests: bool = False
    property_tests: bool = False
    load_tests: bool = False
    security_tests: bool = False
    coverage_target: float = 0.85
    frameworks: list[str] = Field(default_factory=list)
    notes: str = ""


class QualityGate(BaseModel):
    name: str
    command: str = ""
    description: str = ""


# --------------------------------------------------------------------------- #
# Domain Template
# --------------------------------------------------------------------------- #

class DomainTemplate(BaseModel):
    """Static, declarative specification of a software engineering domain.

    A :class:`DomainTemplate` carries the *default* engineering knowledge
    for a domain (recommended stack, required features, coding standards,
    deliverables, quality gates, testing expectations, security
    requirements, etc.).  The :class:`PromptEngineeringNode` blends the
    template with the user's request to produce a
    :class:`PromptPackage`.
    """
    domain: SoftwareDomain
    name: str = Field(description="Human-friendly domain name")
    description: str = ""
    recommended_language: str = "python"
    recommended_framework: str = ""
    alternative_frameworks: list[str] = Field(default_factory=list)
    architecture: str = "layered"
    common_project_structure: list[str] = Field(default_factory=list)
    engineering_principles: list[str] = Field(default_factory=list)
    required_features: list[str] = Field(default_factory=list)
    coding_standards: list[str] = Field(default_factory=list)
    deliverables: list[str] = Field(default_factory=list)
    quality_gates: list[QualityGate] = Field(default_factory=list)
    testing_expectations: TestingStrategy = Field(default_factory=TestingStrategy)
    security_requirements: list[str] = Field(default_factory=list)
    performance_recommendations: list[str] = Field(default_factory=list)
    documentation_standards: list[str] = Field(default_factory=list)
    deployment_expectations: list[str] = Field(default_factory=list)
    # Keyword hints used by the DomainDetector.
    detection_keywords: list[str] = Field(default_factory=list)
    detection_weight: float = 1.0


# --------------------------------------------------------------------------- #
# Architecture Plan
# --------------------------------------------------------------------------- #

class ArchitecturePlan(BaseModel):
    """High-level implementation plan generated after the engineered prompt."""
    summary: str = ""
    milestones: list[Milestone] = Field(default_factory=list)
    modules: list[ModuleSpec] = Field(default_factory=list)
    dependencies: list[str] = Field(default_factory=list, description="external packages/services")
    execution_order: list[str] = Field(default_factory=list, description="milestone names in execution order")
    risks: list[Risk] = Field(default_factory=list)
    validation_strategy: str = ""
    testing_strategy: TestingStrategy = Field(default_factory=TestingStrategy)
    estimated_loc: int = Field(default=0, description="rough lines-of-code estimate")


# --------------------------------------------------------------------------- #
# Prompt Package — the main output
# --------------------------------------------------------------------------- #

class PromptPackage(BaseModel):
    """The complete output of the Prompt Engineering Node.

    This object is the single source of truth consumed by downstream
    agents (planner, executor, coder, reviewer).  The Builder NEVER
    receives the raw user request — only ``engineered_prompt``.
    """
    # Inputs
    original_request: str
    context_snapshot: dict[str, Any] = Field(default_factory=dict)

    # Detection
    detected_domain: SoftwareDomain = SoftwareDomain.UNKNOWN
    project_type: ProjectType = ProjectType.OTHER
    confidence: float = Field(default=0.0, ge=0.0, le=1.0)

    # Inference
    inferred_requirements: list[InferredRequirement] = Field(default_factory=list)
    recommended_language: str = "python"
    framework: str = ""
    architecture: str = "layered"
    database: str = ""

    # Engineered prompt (the main deliverable)
    engineered_prompt: str = ""

    # Architecture plan
    architecture_plan: ArchitecturePlan = Field(default_factory=ArchitecturePlan)

    # Auxiliary metadata
    risks: list[Risk] = Field(default_factory=list)
    milestones: list[Milestone] = Field(default_factory=list)
    recommended_tools: list[str] = Field(default_factory=list)
    testing_strategy: TestingStrategy = Field(default_factory=TestingStrategy)
    estimated_complexity: Complexity = Complexity.MODERATE

    # Self-improvement metadata
    template_id: str = ""
    generated_at: float = 0.0

    def summary(self) -> str:
        """One-line summary for logging."""
        return (
            f"PromptPackage(domain={self.detected_domain.value}, "
            f"lang={self.recommended_language}, fw={self.framework or '-'}, "
            f"complexity={self.estimated_complexity.value}, "
            f"inferred={len(self.inferred_requirements)}, "
            f"risks={len(self.risks)}, milestones={len(self.milestones)})"
        )


# --------------------------------------------------------------------------- #
# Self-improvement record
# --------------------------------------------------------------------------- #

class PromptOutcome(BaseModel):
    """Outcome of using a PromptPackage — fed back into the store."""
    prompt_id: str
    build_success: bool = False
    bug_count: int = 0
    completion_time_s: float = 0.0
    user_satisfaction: float = Field(default=0.0, ge=0.0, le=1.0)
    code_quality_score: float = Field(default=0.0, ge=0.0, le=1.0)
    notes: str = ""
