"""Requirements inferrer — fills in defaults the user didn't specify.

For every detected domain, the inferrer walks the list of
``required_features`` from the domain template and decides whether each
one is *must*, *should*, or *could* based on the request.  It also adds
domain-specific defaults (e.g. Postgres for backend, React for frontend).

The inferrer never overrides explicit user choices — it only fills gaps.
"""
from __future__ import annotations

import logging
import re
from typing import Any

from adonai.prompt_engineering.models import (
    DomainTemplate,
    InferredRequirement,
    ProjectType,
    SoftwareDomain,
)

log = logging.getLogger(__name__)


# Domain-specific "always infer" rules.  Each rule is a function that
# returns a list of InferredRequirement.  These run for every request
# of the matching domain, regardless of the template's required_features.

def _backend_defaults(request: str, template: DomainTemplate) -> list[InferredRequirement]:
    out: list[InferredRequirement] = []
    r = request.lower()
    # Auth
    if not any(k in r for k in ("auth", "jwt", "oauth", "session", "login")):
        out.append(InferredRequirement(
            category="auth",
            description="JWT-based authentication with refresh tokens",
            rationale="Backend APIs need authentication by default",
            priority="must",
        ))
    # OpenAPI / docs
    if "openapi" not in r and "swagger" not in r:
        out.append(InferredRequirement(
            category="docs",
            description="OpenAPI spec auto-generated from route signatures",
            rationale="Auto-discoverable API contract",
            priority="should",
        ))
    # Health checks
    if "health" not in r:
        out.append(InferredRequirement(
            category="ops",
            description="Liveness + readiness health-check endpoints",
            rationale="Required by orchestrators (k8s, ECS)",
            priority="must",
        ))
    # Rate limiting
    if "rate" not in r:
        out.append(InferredRequirement(
            category="security",
            description="Per-IP rate limiting on auth + write endpoints",
            rationale="Default abuse protection",
            priority="should",
        ))
    # Migrations
    if "migration" not in r:
        out.append(InferredRequirement(
            category="database",
            description="Schema migration tool (Alembic) with revision history",
            rationale="Safe schema evolution",
            priority="must",
        ))
    # Structured logging
    if "log" not in r:
        out.append(InferredRequirement(
            category="logging",
            description="Structured JSON logging with request-id correlation",
            rationale="Production observability",
            priority="must",
        ))
    return out


def _frontend_defaults(request: str, template: DomainTemplate) -> list[InferredRequirement]:
    out: list[InferredRequirement] = []
    r = request.lower()
    if "typescript" not in r and "ts" not in r.split():
        out.append(InferredRequirement(
            category="language",
            description="TypeScript with strict mode",
            rationale="Type safety prevents runtime errors at scale",
            priority="must",
        ))
    if not any(k in r for k in ("test", "vitest", "jest")):
        out.append(InferredRequirement(
            category="testing",
            description="Component tests with Vitest + React Testing Library",
            rationale="Catch UI regressions",
            priority="should",
        ))
    if "tailwind" not in r and "css module" not in r:
        out.append(InferredRequirement(
            category="styling",
            description="Tailwind CSS for utility-first styling",
            rationale="Rapid iteration + consistent design tokens",
            priority="should",
        ))
    if "accessibility" not in r and "a11y" not in r:
        out.append(InferredRequirement(
            category="a11y",
            description="WCAG 2.1 AA compliance + keyboard navigation",
            rationale="Inclusive UX + legal compliance",
            priority="should",
        ))
    return out


def _fullstack_defaults(request: str, template: DomainTemplate) -> list[InferredRequirement]:
    return _backend_defaults(request, template) + _frontend_defaults(request, template)


def _mobile_defaults(request: str, template: DomainTemplate) -> list[InferredRequirement]:
    out: list[InferredRequirement] = []
    r = request.lower()
    if "offline" not in r:
        out.append(InferredRequirement(
            category="offline",
            description="Offline-first with local cache + background sync",
            rationale="Mobile networks are unreliable",
            priority="should",
        ))
    if "push" not in r:
        out.append(InferredRequirement(
            category="notifications",
            description="Push notification support (APNs + FCM)",
            rationale="User re-engagement",
            priority="could",
        ))
    if "analytics" not in r:
        out.append(InferredRequirement(
            category="analytics",
            description="Privacy-respecting analytics (no PII by default)",
            rationale="Understand usage without violating privacy",
            priority="should",
        ))
    return out


def _cli_defaults(request: str, template: DomainTemplate) -> list[InferredRequirement]:
    out: list[InferredRequirement] = []
    r = request.lower()
    if "help" not in r and "--help" not in r:
        out.append(InferredRequirement(
            category="ux",
            description="Auto-generated --help text + man page",
            rationale="Discoverability",
            priority="must",
        ))
    if "completion" not in r:
        out.append(InferredRequirement(
            category="ux",
            description="Shell completion scripts (bash/zsh/fish)",
            rationale="Power-user UX",
            priority="should",
        ))
    if "config" not in r:
        out.append(InferredRequirement(
            category="config",
            description="Layered config: CLI flags > env vars > config file",
            rationale="Flexible deployment",
            priority="should",
        ))
    return out


def _ai_ml_defaults(request: str, template: DomainTemplate) -> list[InferredRequirement]:
    out: list[InferredRequirement] = []
    r = request.lower()
    if "experiment" not in r and "mlflow" not in r:
        out.append(InferredRequirement(
            category="experiment-tracking",
            description="MLflow or Weights & Biases for experiment tracking",
            rationale="Reproducible research",
            priority="must",
        ))
    if "dataset" not in r and "data version" not in r:
        out.append(InferredRequirement(
            category="data",
            description="Dataset versioning (DVC or similar)",
            rationale="Reproducible training",
            priority="should",
        ))
    if "ci" not in r:
        out.append(InferredRequirement(
            category="ci",
            description="CI pipeline that re-trains + evaluates on PRs",
            rationale="Catch model regressions before merge",
            priority="should",
        ))
    return out


def _agents_defaults(request: str, template: DomainTemplate) -> list[InferredRequirement]:
    out: list[InferredRequirement] = []
    r = request.lower()
    if "memory" not in r:
        out.append(InferredRequirement(
            category="memory",
            description="Multi-tier memory (working / episodic / semantic)",
            rationale="Agents need persistent context",
            priority="must",
        ))
    if "tool" not in r:
        out.append(InferredRequirement(
            category="tools",
            description="Tool registry with permission policy + audit log",
            rationale="Controlled, observable tool use",
            priority="must",
        ))
    if "safety" not in r and "guardrail" not in r:
        out.append(InferredRequirement(
            category="safety",
            description="Safety guard + approval gate for destructive actions",
            rationale="Autonomous agents must not run amok",
            priority="must",
        ))
    if "observability" not in r:
        out.append(InferredRequirement(
            category="observability",
            description="Per-step tracing + token accounting",
            rationale="Debuggability of long reasoning chains",
            priority="should",
        ))
    return out


def _devops_defaults(request: str, template: DomainTemplate) -> list[InferredRequirement]:
    out: list[InferredRequirement] = []
    r = request.lower()
    if "lint" not in r and "validate" not in r:
        out.append(InferredRequirement(
            category="validation",
            description="Pre-apply linting (tflint / cfn-lint / yamllint)",
            rationale="Catch infra mistakes before deployment",
            priority="must",
        ))
    if "plan" not in r and "dry-run" not in r:
        out.append(InferredRequirement(
            category="safety",
            description="Plan/dry-run stage gated by human approval",
            rationale="Prevent destructive infra changes",
            priority="must",
        ))
    if "state" not in r:
        out.append(InferredRequirement(
            category="state",
            description="Remote state backend with locking (S3+DynamoDB)",
            rationale="Concurrent infra changes need state locking",
            priority="must",
        ))
    return out


def _database_defaults(request: str, template: DomainTemplate) -> list[InferredRequirement]:
    out: list[InferredRequirement] = []
    r = request.lower()
    if "backup" not in r:
        out.append(InferredRequirement(
            category="ops",
            description="Automated daily backups + point-in-time recovery",
            rationale="Data durability",
            priority="must",
        ))
    if "index" not in r:
        out.append(InferredRequirement(
            category="performance",
            description="Index strategy reviewed for top-10 queries",
            rationale="Query performance",
            priority="should",
        ))
    if "migration" not in r:
        out.append(InferredRequirement(
            category="schema",
            description="Forward-only migrations with rollback scripts",
            rationale="Safe schema evolution",
            priority="must",
        ))
    return out


def _security_defaults(request: str, template: DomainTemplate) -> list[InferredRequirement]:
    out: list[InferredRequirement] = []
    r = request.lower()
    if "scope" not in r:
        out.append(InferredRequirement(
            category="safety",
            description="Explicit attack scope + written authorization",
            rationale="Legal + ethical compliance",
            priority="must",
        ))
    if "log" not in r:
        out.append(InferredRequirement(
            category="audit",
            description="Audit log of every action taken",
            rationale="Accountability",
            priority="must",
        ))
    return out


def _game_defaults(request: str, template: DomainTemplate) -> list[InferredRequirement]:
    out: list[InferredRequirement] = []
    r = request.lower()
    if "physics" not in r and "2d" not in r and "3d" not in r:
        out.append(InferredRequirement(
            category="engine",
            description="Choose 2D vs 3D engine upfront (Godot 2D/3D or Unity)",
            rationale="Avoid costly mid-project pivots",
            priority="must",
        ))
    if "asset" not in r:
        out.append(InferredRequirement(
            category="assets",
            description="Asset pipeline with versioned atlases + audio",
            rationale="Build reproducibility",
            priority="should",
        ))
    return out


def _desktop_defaults(request: str, template: DomainTemplate) -> list[InferredRequirement]:
    out: list[InferredRequirement] = []
    r = request.lower()
    if "auto-update" not in r and "autoupdate" not in r:
        out.append(InferredRequirement(
            category="ops",
            description="Signed auto-update channel (Sparkle / Squirrel)",
            rationale="Security patch distribution",
            priority="must",
        ))
    if "installer" not in r:
        out.append(InferredRequirement(
            category="distribution",
            description="Cross-platform installers (MSI / DMG / AppImage)",
            rationale="User-friendly install",
            priority="should",
        ))
    return out


# Registry of domain-specific inferrers.
_DOMAIN_INFFERERS = {
    SoftwareDomain.BACKEND_API: _backend_defaults,
    SoftwareDomain.WEB_DEVELOPMENT: _frontend_defaults,
    SoftwareDomain.FRONTEND: _frontend_defaults,
    SoftwareDomain.FULL_STACK: _fullstack_defaults,
    SoftwareDomain.MOBILE: _mobile_defaults,
    SoftwareDomain.CLI: _cli_defaults,
    SoftwareDomain.AI_ML: _ai_ml_defaults,
    SoftwareDomain.AUTONOMOUS_AGENTS: _agents_defaults,
    SoftwareDomain.DEVOPS: _devops_defaults,
    SoftwareDomain.CLOUD_INFRASTRUCTURE: _devops_defaults,
    SoftwareDomain.DATABASES: _database_defaults,
    SoftwareDomain.CYBERSECURITY: _security_defaults,
    SoftwareDomain.GAME_DEVELOPMENT: _game_defaults,
    SoftwareDomain.DESKTOP: _desktop_defaults,
}


class RequirementsInferrer:
    """Infer missing requirements based on the detected domain + request."""

    def infer(
        self,
        request: str,
        template: DomainTemplate,
        project_type: ProjectType,
    ) -> list[InferredRequirement]:
        """Return the full list of inferred requirements.

        Combines:
        1. The template's ``required_features`` (each becomes a
           ``should``-priority InferredRequirement unless the user
           explicitly mentioned it).
        2. Domain-specific defaults from the inferrer registry above.
        """
        out: list[InferredRequirement] = []
        r = request.lower()

        # 1. Walk template's required_features.
        for feature in template.required_features:
            # Heuristic: if a word from the feature appears in the request,
            # assume the user already specified it and skip.
            feature_words = [w for w in re.split(r"[\s_/]+", feature.lower()) if len(w) > 3]
            already_specified = any(w in r for w in feature_words)
            if already_specified:
                continue
            out.append(InferredRequirement(
                category=feature,
                description=feature.replace("_", " ").capitalize(),
                rationale=f"Standard practice for {template.domain.value}",
                priority="should",
            ))

        # 2. Run domain-specific inferrer.
        inferrer = _DOMAIN_INFFERERS.get(template.domain)
        if inferrer is not None:
            out.extend(inferrer(request, template))

        # De-duplicate by (category, description).
        seen: set[tuple[str, str]] = set()
        deduped: list[InferredRequirement] = []
        for req in out:
            key = (req.category, req.description.lower())
            if key in seen:
                continue
            seen.add(key)
            deduped.append(req)

        return deduped
