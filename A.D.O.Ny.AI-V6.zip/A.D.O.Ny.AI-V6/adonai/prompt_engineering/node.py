"""PromptEngineeringNode — the orchestrator that turns a raw user request
into a structured, engineered prompt + architecture plan.

This is the **first stage** of the reasoning pipeline.  The downstream
planner, executor, and coder agents consume the
:class:`PromptPackage` produced here — they NEVER see the raw user
request.

Execution flow::

    user_request
        ↓
    DomainDetector.detect_domain         → (domain, confidence)
        ↓
    TemplateRegistry.get(domain)         → DomainTemplate
        ↓
    RequirementsInferrer.infer           → [InferredRequirement, ...]
        ↓
    ArchitecturePlanner.plan             → ArchitecturePlan
        ↓
    PromptEngineeringNode.render_prompt  → engineered_prompt (string)
        ↓
    PromptStore.save_package             → prompt_id (for self-improvement)
        ↓
    PromptPackage                        ← consumed by downstream agents
"""
from __future__ import annotations

import logging
import time
from typing import Any

from adonai.prompt_engineering.architecture_planner import ArchitecturePlanner
from adonai.core.events import EventPublisher, EventTypes
from adonai.prompt_engineering.detector import DomainDetector
from adonai.prompt_engineering.models import (
    DomainTemplate,
    PromptPackage,
    SoftwareDomain,
)
from adonai.prompt_engineering.requirements import RequirementsInferrer
from adonai.prompt_engineering.store import PromptStore
from adonai.prompt_engineering.templates.base import (
    TemplateRegistry,
    get_global_registry,
)

log = logging.getLogger(__name__)


class PromptEngineeringNode(EventPublisher):
    """The main entry point of the Self-Prompt Engineering System.

    Construct with optional dependencies (LLM, custom registry, custom
    store).  Calling :meth:`engineer` returns a :class:`PromptPackage`
    that downstream agents consume.
    """

    def __init__(
        self,
        *,
        registry: TemplateRegistry | None = None,
        store: PromptStore | None = None,
        llm: Any = None,
        config: Any = None,
    ) -> None:
        self.registry = registry or get_global_registry()
        self.llm = llm
        self.config = config
        # Store is optional — when None, self-improvement is disabled.
        self.store = store
        self.detector = DomainDetector(self.registry, llm=self.llm)
        self.inferrer = RequirementsInferrer()
        self.planner = ArchitecturePlanner(llm=self.llm)

    # ------------------------------------------------------------------ #
    # Public API
    # ------------------------------------------------------------------ #

    async def engineer(
        self,
        request: str,
        *,
        context: dict[str, Any] | None = None,
    ) -> PromptPackage:
        """Transform a raw user request into a :class:`PromptPackage`."""
        started_at = time.time()
        ctx = dict(context or {})

        # 1. Detect domain.
        domain, confidence = self.detector.detect_domain(request)
        if confidence < 0.5 and self.llm is not None:
            domain, confidence = await self.detector.refine_with_llm(
                request, domain, confidence,
            )

        # 2. Get template (or build a generic one for UNKNOWN).
        template = self.registry.get(domain)
        if template is None:
            template = self._fallback_template(domain)
            log.warning(
                "No template registered for domain %s — using generic fallback",
                domain.value,
            )

        # 3. Allow the plugin to customise based on the request.
        plugin = self.registry.get_plugin(domain)
        if plugin is not None:
            try:
                template = plugin.customize(template, request, context=ctx)
            except Exception as e:
                log.debug("Template.customize failed (non-fatal): %s", e)

        # 4. Project type + complexity.
        project_type = self.detector.detect_project_type(request, domain)
        complexity = self.detector.estimate_complexity(request)

        # 5. Infer requirements.
        inferred = self.inferrer.infer(request, template, project_type)

        # 6. Build the (incomplete) package so the planner can use it.
        package = PromptPackage(
            original_request=request,
            context_snapshot=ctx,
            detected_domain=domain,
            project_type=project_type,
            confidence=confidence,
            inferred_requirements=inferred,
            recommended_language=template.recommended_language,
            framework=template.recommended_framework,
            architecture=template.architecture,
            database=self._infer_database(template, request),
            template_id=template.domain.value,
            generated_at=started_at,
            estimated_complexity=complexity,
        )

        # 7. Architecture plan.
        package.architecture_plan = self.planner.plan(package, template)
        package.milestones = package.architecture_plan.milestones
        package.risks = package.architecture_plan.risks
        package.testing_strategy = package.architecture_plan.testing_strategy
        package.recommended_tools = self._derive_tools(template, package)

        # 8. Render the engineered prompt (the main deliverable).
        package.engineered_prompt = self._render_prompt(package, template)

        # 9. Self-improvement: pull lessons from prior failures.
        if self.store is not None:
            try:
                lessons = await self.store.lessons_for_domain(domain, limit=3)
                if lessons:
                    package.engineered_prompt += "\n\n## Lessons From Prior Attempts\n"
                    for i, lesson in enumerate(lessons, 1):
                        package.engineered_prompt += f"{i}. {lesson}\n"
            except Exception as e:
                log.debug("Lessons retrieval failed (non-fatal): %s", e)

        # 10. Persist for self-improvement.
        if self.store is not None:
            try:
                prompt_id = await self.store.save_package(package)
                package.template_id = package.template_id or prompt_id
            except Exception as e:
                log.warning("PromptStore.save_package failed (non-fatal): %s", e)

        log.info(
            "PromptEngineeringNode: %s in %.2fs",
            package.summary(), time.time() - started_at,
        )

        # Emit prompt.engineered event for subscribers.
        await self._emit(EventTypes.PROMPT_ENGINEERED, {
            "domain": package.detected_domain.value,
            "project_type": package.project_type.value,
            "complexity": package.estimated_complexity.value,
            "inferred_count": len(package.inferred_requirements),
            "milestone_count": len(package.milestones),
            "risk_count": len(package.risks),
            "prompt_length": len(package.engineered_prompt),
            "original_length": len(package.original_request),
        })

        return package

    # ------------------------------------------------------------------ #
    # Prompt rendering
    # ------------------------------------------------------------------ #

    def _render_prompt(self, package: PromptPackage, template: DomainTemplate) -> str:
        """Render the structured engineered prompt as a markdown string."""
        lines: list[str] = []
        lines.append("# Engineered Engineering Prompt")
        lines.append("")

        lines.append("## Role")
        lines.append("Principal Software Engineer")
        lines.append("")

        lines.append("## Project")
        # Use the first 200 chars of the request as the project name.
        lines.append(package.original_request.strip()[:200])
        lines.append("")

        lines.append("## Domain")
        lines.append(template.name)
        lines.append("")

        lines.append("## Language")
        lines.append(package.recommended_language)
        lines.append("")

        if package.framework:
            lines.append("## Framework")
            lines.append(package.framework)
            lines.append("")

        lines.append("## Architecture")
        lines.append(package.architecture)
        lines.append("")

        if package.database:
            lines.append("## Database")
            lines.append(package.database)
            lines.append("")

        # Objectives
        lines.append("## Objectives")
        for obj in template.engineering_principles or [
            "scalable", "maintainable", "modular", "secure",
        ]:
            lines.append(f"* {obj}")
        lines.append("")

        # Required features (from inferred requirements).
        lines.append("## Required Features")
        for req in package.inferred_requirements:
            priority_tag = f"[{req.priority.upper()}]"
            lines.append(f"* {priority_tag} {req.category}: {req.description}")
        lines.append("")

        # Coding standards.
        lines.append("## Coding Standards")
        for std in template.coding_standards or [
            "SOLID", "DRY", "type hints", "modular design",
        ]:
            lines.append(f"* {std}")
        lines.append("")

        # Deliverables.
        lines.append("## Deliverables")
        for d in template.deliverables or [
            "source code", "tests", "README", "Docker Compose",
        ]:
            lines.append(f"* {d}")
        lines.append("")

        # Quality gates.
        if template.quality_gates:
            lines.append("## Quality Gates")
            for gate in template.quality_gates:
                lines.append(f"* {gate.name}: {gate.command}")
            lines.append("")

        # Architecture plan summary.
        plan = package.architecture_plan
        lines.append("## Architecture Plan")
        lines.append(plan.summary)
        lines.append("")
        if plan.execution_order:
            lines.append("### Execution Order")
            for i, phase in enumerate(plan.execution_order, 1):
                lines.append(f"{i}. {phase}")
            lines.append("")

        if plan.milestones:
            lines.append("### Milestones")
            for m in plan.milestones:
                lines.append(f"- **{m.name}**: {m.description}")
                if m.modules:
                    lines.append(f"  - modules: {', '.join(m.modules)}")
            lines.append("")

        # Risks.
        if package.risks:
            lines.append("## Risks")
            for risk in package.risks:
                lines.append(
                    f"- **[{risk.severity.upper()}]** {risk.description} "
                    f"— mitigation: {risk.mitigation}"
                )
            lines.append("")

        # Testing.
        lines.append("## Testing Strategy")
        ts = package.testing_strategy
        lines.append(f"* Unit tests: {ts.unit_tests}")
        lines.append(f"* Integration tests: {ts.integration_tests}")
        lines.append(f"* E2E tests: {ts.end_to_end_tests}")
        lines.append(f"* Coverage target: {int(ts.coverage_target * 100)}%")
        if ts.frameworks:
            lines.append(f"* Frameworks: {', '.join(ts.frameworks)}")
        lines.append("")

        # Security.
        if template.security_requirements:
            lines.append("## Security Requirements")
            for s in template.security_requirements:
                lines.append(f"* {s}")
            lines.append("")

        # Performance.
        if template.performance_recommendations:
            lines.append("## Performance Recommendations")
            for p in template.performance_recommendations:
                lines.append(f"* {p}")
            lines.append("")

        # Documentation.
        if template.documentation_standards:
            lines.append("## Documentation Standards")
            for d in template.documentation_standards:
                lines.append(f"* {d}")
            lines.append("")

        # Deployment.
        if template.deployment_expectations:
            lines.append("## Deployment Expectations")
            for d in template.deployment_expectations:
                lines.append(f"* {d}")
            lines.append("")

        return "\n".join(lines)

    # ------------------------------------------------------------------ #
    # Helpers
    # ------------------------------------------------------------------ #

    def _fallback_template(self, domain: SoftwareDomain) -> DomainTemplate:
        """Generic fallback when no plugin is registered for a domain."""
        return DomainTemplate(
            domain=domain,
            name=domain.value.replace("_", " ").title(),
            description="Generic software engineering template",
            recommended_language="python",
            recommended_framework="",
            architecture="layered",
            engineering_principles=["scalable", "maintainable", "modular", "secure"],
            required_features=["testing", "logging", "error_handling", "documentation"],
            coding_standards=["SOLID", "DRY", "type hints", "modular design"],
            deliverables=["source code", "tests", "README", "Dockerfile"],
            quality_gates=[],
            security_requirements=["input validation", "secret management"],
            documentation_standards=["README", "inline docstrings"],
            deployment_expectations=["container image"],
            detection_keywords=[],
        )

    def _infer_database(self, template: DomainTemplate, request: str) -> str:
        """Infer the database choice from the request or template defaults."""
        r = request.lower()
        if "postgres" in r or "postgresql" in r:
            return "PostgreSQL"
        if "mysql" in r:
            return "MySQL"
        if "sqlite" in r:
            return "SQLite"
        if "mongo" in r:
            return "MongoDB"
        if "redis" in r:
            return "Redis"
        if "dynamodb" in r:
            return "DynamoDB"
        # Domain defaults.
        if template.domain in (SoftwareDomain.BACKEND_API, SoftwareDomain.FULL_STACK):
            return "PostgreSQL"
        if template.domain == SoftwareDomain.CLI:
            return "SQLite"
        return ""

    def _derive_tools(self, template: DomainTemplate, package: PromptPackage) -> list[str]:
        """Recommended external tools/packages for the project."""
        tools: list[str] = []
        if package.recommended_language == "python":
            tools.extend(["ruff", "black", "mypy", "pytest"])
        elif package.recommended_language in ("typescript", "javascript"):
            tools.extend(["eslint", "prettier", "tsc", "vitest"])
        if package.detected_domain == SoftwareDomain.BACKEND_API:
            tools.extend(["FastAPI", "uvicorn", "alembic", "httpx"])
        elif package.detected_domain in (SoftwareDomain.FRONTEND, SoftwareDomain.WEB_DEVELOPMENT):
            tools.extend(["vite", "tailwindcss", "react-router"])
        elif package.detected_domain == SoftwareDomain.FULL_STACK:
            tools.extend(["next", "prisma", "trpc"])
        elif package.detected_domain == SoftwareDomain.AI_ML:
            tools.extend(["torch", "scikit-learn", "mlflow", "dvc"])
        elif package.detected_domain == SoftwareDomain.AUTONOMOUS_AGENTS:
            tools.extend(["langchain", "chromadb", "tiktoken"])
        elif package.detected_domain == SoftwareDomain.DEVOPS:
            tools.extend(["terraform", "tflint", "terragrunt"])
        # Dedup while preserving order.
        seen: set[str] = set()
        out: list[str] = []
        for t in tools:
            if t not in seen:
                seen.add(t)
                out.append(t)
        return out
