"""Cybersecurity template — offensive + defensive tooling."""
from __future__ import annotations

from adonai.prompt_engineering.models import (
    DomainTemplate,
    QualityGate,
    SoftwareDomain,
    TestingStrategy,
)
from adonai.prompt_engineering.templates.base import BaseDomainTemplate, register_template


@register_template
class CybersecurityTemplate(BaseDomainTemplate):
    domain = SoftwareDomain.CYBERSECURITY

    def build(self) -> DomainTemplate:
        return DomainTemplate(
            domain=self.domain,
            name="Cybersecurity",
            description="Security tooling (scanner, fuzzer, IDS, hardening)",
            recommended_language="python",
            recommended_framework="custom",
            alternative_frameworks=["Go + Cobra", "Rust"],
            architecture="Plugins + core engine + report generator",
            common_project_structure=[
                "src/core/", "src/plugins/", "src/scanners/",
                "src/reporters/", "src/utils/", "tests/",
                "rules/", "config/",
            ],
            engineering_principles=[
                "scoped", "auditable", "non-destructive",
                "explicit-consent", "minimal-footprint",
            ],
            required_features=[
                "scope_validation", "audit_log", "consent_check",
                "rate_limiting", "safe_mode", "testing",
                "report_generation", "evidence_capture",
            ],
            coding_standards=[
                "Type hints throughout",
                "No silent failures (log + escalate)",
                "Every action recorded in audit log",
                "Destructive operations require explicit --confirm",
                "All network calls have timeout + retries",
            ],
            deliverables=[
                "source code", "tests", "README", "scope-of-work template",
                "consent form template", "report template",
                "Docker image", "rules pack",
            ],
            quality_gates=[
                QualityGate(name="Ruff", command="ruff check ."),
                QualityGate(name="MyPy", command="mypy src/"),
                QualityGate(name="Bandit", command="bandit -r src/"),
                QualityGate(name="Pytest", command="pytest --cov=src --cov-fail-under=80"),
                QualityGate(name="pip-audit", command="pip-audit"),
            ],
            testing_expectations=TestingStrategy(
                unit_tests=True,
                integration_tests=True,
                security_tests=True,
                coverage_target=0.85,
                frameworks=["pytest", "pytest-asyncio", "bandit"],
                notes="Test scanners against intentionally vulnerable lab targets.",
            ),
            security_requirements=[
                "Explicit scope validation before every scan",
                "Written authorisation checked at startup",
                "No outbound traffic outside scope",
                "Encrypted storage for captured evidence",
                "Audit log tamper-evident (hash chain)",
                "Rate limiting to avoid DoS",
            ],
            performance_recommendations=[
                "Async I/O for concurrent scans",
                "Connection pooling for target lists",
                "Stream results to reporter (don't buffer)",
                "Profile slow scanners with cProfile",
            ],
            documentation_standards=[
                "README with scope + consent requirements",
                "Ruleset documentation per scanner",
                "Report template with sections: scope, findings, CVSS, remediation",
                "ADR for major design choices",
            ],
            deployment_expectations=[
                "Containerised with read-only root filesystem",
                "Run as non-root user",
                "Secrets via env / vault",
                "Isolated network segment for scanner host",
            ],
            detection_keywords=[
                "cybersecurity", "security", "pentest", "pen-test",
                "vulnerability", "scanner", "exploit", "ctf",
                "ids", "ips", "siem", "fuzzer", "fuzzing",
                "malware", "reverse engineering", "hardening",
                "soc", "incident response",
            ],
            detection_weight=1.0,
        )

    def customize(self, template: DomainTemplate, request: str, *, context: dict | None = None) -> DomainTemplate:
        r = request.lower()
        if "fuzzer" in r or "fuzzing" in r:
            template.alternative_frameworks = ["Atheris", "honggfuzz"]
        if "ids" in r or "siem" in r:
            template.recommended_framework = "Zeek / Suricata"
        return template
