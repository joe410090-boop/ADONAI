"""AI/ML template — PyTorch + MLflow + DVC."""
from __future__ import annotations

from adonai.prompt_engineering.models import (
    DomainTemplate,
    QualityGate,
    SoftwareDomain,
    TestingStrategy,
)
from adonai.prompt_engineering.templates.base import BaseDomainTemplate, register_template


@register_template
class AiMlTemplate(BaseDomainTemplate):
    domain = SoftwareDomain.AI_ML

    def build(self) -> DomainTemplate:
        return DomainTemplate(
            domain=self.domain,
            name="AI / Machine Learning",
            description="Model training + evaluation + experiment tracking",
            recommended_language="python",
            recommended_framework="PyTorch",
            alternative_frameworks=["TensorFlow", "JAX", "scikit-learn"],
            architecture="Notebooks (exploration) → src/ (production) → pipelines (training)",
            common_project_structure=[
                "src/data/", "src/models/", "src/training/",
                "src/evaluation/", "src/inference/", "configs/",
                "notebooks/", "tests/", "data/", "mlruns/",
            ],
            engineering_principles=[
                "reproducible", "experiment-driven", "modular",
                "versioned", "testable",
            ],
            required_features=[
                "experiment_tracking", "dataset_versioning", "model_registry",
                "hyperparameter_sweep", "ci_for_models", "reproducibility",
                "tensorboard", "logging", "testing", "model_card",
            ],
            coding_standards=[
                "Type hints + dataclasses for configs",
                "Hydra or OmegaConf for config management",
                "Deterministic seeds everywhere",
                "No business logic in notebooks (notebooks call src/)",
                "Docstrings with shapes annotated",
            ],
            deliverables=[
                "source code", "tests", "README", "model weights (or pointer)",
                "model card", "experiment tracking dashboard",
                "inference Docker image", "data sheet",
            ],
            quality_gates=[
                QualityGate(name="Ruff", command="ruff check ."),
                QualityGate(name="MyPy", command="mypy src/"),
                QualityGate(name="Pytest", command="pytest --cov=src"),
                QualityGate(name="Determinism", command="pytest -k determinism"),
            ],
            testing_expectations=TestingStrategy(
                unit_tests=True,
                integration_tests=True,
                property_tests=True,
                coverage_target=0.75,
                frameworks=["pytest", "pytest-cases", "torch-testing"],
                notes="Add determinism tests that assert same seed → same output.",
            ),
            security_requirements=[
                "Scan datasets for PII before training",
                "No model weights in repo (use LFS or registry)",
                "Inference input validation (no arbitrary pickle loading)",
                "Audit log for model deployments",
            ],
            performance_recommendations=[
                "Use mixed precision (AMP) by default",
                "Profile with torch.profiler before optimising",
                "Cache preprocessed data (HDF5 / webdataset)",
                "Use DataLoader workers + pin_memory",
                "Distributed training only after single-GPU correctness verified",
            ],
            documentation_standards=[
                "Model card for every published model",
                "Datasheet for every dataset",
                "README with quickstart + reproducibility instructions",
                "Notebooks exported to HTML for review",
            ],
            deployment_expectations=[
                "Inference server (FastAPI + ONNX/TorchScript)",
                "Model registry (MLflow registry)",
                "A/B test framework for new model versions",
                "Monitoring for drift + degradation",
            ],
            detection_keywords=[
                "ai", "ml", "machine learning", "deep learning", "neural",
                "pytorch", "tensorflow", "transformer", "llm", "rag",
                "model training", "inference", "classifier", "regression",
                "fine-tune", "fine tune", "embedding", "vector", "rag",
            ],
            detection_weight=1.0,
        )

    def customize(self, template: DomainTemplate, request: str, *, context: dict | None = None) -> DomainTemplate:
        r = request.lower()
        if "tensorflow" in r:
            template.recommended_framework = "TensorFlow"
        elif "jax" in r:
            template.recommended_framework = "JAX + Flax"
        elif "scikit" in r or "sklearn" in r:
            template.recommended_framework = "scikit-learn"
        if "llm" in r or "rag" in r or "transformer" in r:
            template.recommended_framework = "HuggingFace Transformers + LangChain"
        return template
