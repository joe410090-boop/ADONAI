"""Domain template plugins.

Every module in this package defines one or more
:class:`~adonai.prompt_engineering.templates.base.BaseDomainTemplate`
subclasses decorated with :func:`register_template`.  Importing this
package (via ``import adonai.prompt_engineering.templates``) registers
all built-in templates with the global
:class:`~adonai.prompt_engineering.templates.base.TemplateRegistry`.

To add a new domain:

1. Create ``adonai/prompt_engineering/templates/my_domain.py``.
2. Subclass :class:`BaseDomainTemplate`.
3. Set ``domain = SoftwareDomain.MY_DOMAIN``.
4. Implement ``build()`` to return a populated :class:`DomainTemplate`.
5. Decorate the class with ``@register_template``.

No changes to the core engine are needed — the registry auto-discovers
the new template when the package is imported.
"""
from __future__ import annotations

from adonai.prompt_engineering.templates.base import (  # noqa: F401
    BaseDomainTemplate,
    TemplateRegistry,
    get_global_registry,
    register_template,
)

# Importing the modules below triggers @register_template side-effects.
# Order doesn't matter; each module is self-contained.
from adonai.prompt_engineering.templates import (  # noqa: F401  # isort: skip
    backend,
    frontend,
    fullstack,
    mobile,
    cli,
    ai_ml,
    autonomous_agents,
    devops,
    databases,
    cybersecurity,
    game_dev,
    desktop,
)

__all__ = [
    "BaseDomainTemplate",
    "TemplateRegistry",
    "get_global_registry",
    "register_template",
]
