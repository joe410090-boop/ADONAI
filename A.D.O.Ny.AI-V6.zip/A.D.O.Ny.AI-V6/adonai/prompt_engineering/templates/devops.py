"""DevOps template — Terraform + Ansible + GitHub Actions."""
from __future__ import annotations

from adonai.prompt_engineering.models import (
    DomainTemplate,
    QualityGate,
    SoftwareDomain,
    TestingStrategy,
)
from adonai.prompt_engineering.templates.base import BaseDomainTemplate, register_template


@register_template
class DevOpsTemplate(BaseDomainTemplate):
    domain = SoftwareDomain.DEVOPS

    def build(self) -> DomainTemplate:
        return DomainTemplate(
            domain=self.domain,
            name="DevOps / Infrastructure",
            description="Infrastructure-as-code + CI/CD + observability",
            recommended_language="hcl",
            recommended_framework="Terraform",
            alternative_frameworks=["Pulumi", "CDK", "Crossplane", "Ansible"],
            architecture="Modules per service → environment stacks → pipelines",
            common_project_structure=[
                "infra/modules/", "infra/environments/",
                "infra/policies/", "ansible/playbooks/",
                "ansible/inventory/", ".github/workflows/",
                "scripts/", "docs/",
            ],
            engineering_principles=[
                "idempotent", "versioned", "auditable",
                "least-privilege", "tagged",
            ],
            required_features=[
                "remote_state", "state_locking", "plan_review",
                "linting", "policy_as_code", "secrets_management",
                "monitoring", "alerting", "logging", "backups",
            ],
            coding_standards=[
                "Every resource tagged with owner + cost-center + env",
                "No hardcoded secrets (use Vault / SSM / Key Vault)",
                "Modules versioned + pinned",
                "Provider versions pinned",
                "Terragrunt for DRY environment stacks",
            ],
            deliverables=[
                "source code", "tests", "README", "architecture diagram",
                "runbook", "cost estimate", "security review",
            ],
            quality_gates=[
                QualityGate(name="tflint", command="tflint --init && tflint"),
                QualityGate(name="tfsec", command="tfsec ."),
                QualityGate(name="terraform fmt", command="terraform fmt -check -recursive"),
                QualityGate(name="terraform validate", command="terraform validate"),
                QualityGate(name="checkov", command="checkov -d ."),
            ],
            testing_expectations=TestingStrategy(
                unit_tests=False,
                integration_tests=True,
                end_to_end_tests=False,
                coverage_target=0.7,
                frameworks=["terratest", "kitchen-terraform", "checkov"],
                notes="Terratest for integration; checkov for policy.",
            ),
            security_requirements=[
                "Principle of least privilege on every IAM role",
                "No 0.0.0.0/0 ingress on production",
                "Encryption at rest + in transit everywhere",
                "Secrets in Vault / SSM Parameter Store (never in code)",
                "Audit log enabled on every cloud account",
            ],
            performance_recommendations=[
                "Right-size resources (start small, scale on metrics)",
                "Use spot/preemptible for non-critical workloads",
                "Auto-scaling on every stateless service",
                "CDN for static assets",
                "Reserved instances for steady-state workloads",
            ],
            documentation_standards=[
                "Architecture diagram per environment",
                "Runbook for common operations",
                "Cost estimate + monthly burn",
                "ADR for major infra decisions",
            ],
            deployment_expectations=[
                "Plan → review → apply (with human approval)",
                "Blue/green or canary for stateful changes",
                "Rollback plan documented",
                "DR (disaster recovery) plan with RPO/RTO",
            ],
            detection_keywords=[
                "devops", "terraform", "ansible", "kubernetes",
                "infrastructure", "iac", "ci/cd", "ci cd",
                "pipeline", "deployment automation", "helm",
                "cloudformation", "pulumi",
            ],
            detection_weight=1.1,
        )

    def customize(self, template: DomainTemplate, request: str, *, context: dict | None = None) -> DomainTemplate:
        r = request.lower()
        if "pulumi" in r:
            template.recommended_framework = "Pulumi"
            template.recommended_language = "typescript"
        elif "cdk" in r:
            template.recommended_framework = "AWS CDK"
            template.recommended_language = "typescript"
        elif "crossplane" in r:
            template.recommended_framework = "Crossplane"
            template.recommended_language = "yaml"
        elif "ansible" in r and "terraform" not in r:
            template.recommended_framework = "Ansible"
            template.recommended_language = "yaml"
        return template
