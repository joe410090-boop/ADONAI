"""Backend API template — FastAPI + PostgreSQL + JWT."""
from __future__ import annotations

from adonai.prompt_engineering.models import (
    DomainTemplate,
    QualityGate,
    SoftwareDomain,
    TestingStrategy,
)
from adonai.prompt_engineering.templates.base import BaseDomainTemplate, register_template


@register_template
class BackendApiTemplate(BaseDomainTemplate):
    domain = SoftwareDomain.BACKEND_API

    def build(self) -> DomainTemplate:
        return DomainTemplate(
            domain=self.domain,
            name="Backend API",
            description="HTTP/gRPC service with auth, persistence, and observability",
            recommended_language="python",
            recommended_framework="FastAPI",
            alternative_frameworks=["Litestar", "Flask", "Django REST", "Express"],
            architecture="Clean Architecture (handlers → services → repositories)",
            common_project_structure=[
                "app/api/", "app/services/", "app/repositories/",
                "app/models/", "app/schemas/", "app/core/", "tests/",
                "alembic/versions/", "docker/", "docs/",
            ],
            engineering_principles=[
                "scalable", "maintainable", "modular", "secure",
                "stateless service layer", "dependency injection",
            ],
            required_features=[
                "authentication", "authorization", "crud", "validation",
                "logging", "monitoring", "configuration", "testing",
                "docker", "migrations", "rate_limiting", "health_checks",
            ],
            coding_standards=[
                "SOLID", "DRY", "type hints", "dependency injection",
                "modular design", "PEP 8", "docstrings on public APIs",
                "no business logic in route handlers",
            ],
            deliverables=[
                "source code", "tests", "README", "Docker Compose",
                "API documentation (OpenAPI)", "migration scripts",
                ".env.example", "Postman collection",
            ],
            quality_gates=[
                QualityGate(name="Ruff", command="ruff check .", description="Lint"),
                QualityGate(name="Black", command="black --check .", description="Format"),
                QualityGate(name="MyPy", command="mypy app/", description="Type check"),
                QualityGate(name="Pytest", command="pytest --cov=app --cov-fail-under=85", description="Tests + coverage"),
            ],
            testing_expectations=TestingStrategy(
                unit_tests=True,
                integration_tests=True,
                end_to_end_tests=True,
                coverage_target=0.85,
                frameworks=["pytest", "pytest-asyncio", "httpx"],
                notes="Test against a real Postgres in docker-compose for integration tests.",
            ),
            security_requirements=[
                "JWT auth with refresh tokens + revocation list",
                "RBAC with explicit role checks on every mutation endpoint",
                "Input validation via Pydantic schemas (no raw dict params)",
                "SQL injection prevention via ORM only (no raw SQL)",
                "Secrets in env vars / secret manager (never in code)",
                "CORS allowlist (never *)",
                "Rate limiting on auth + write endpoints",
            ],
            performance_recommendations=[
                "Async I/O throughout (asyncpg / SQLAlchemy 2.x async)",
                "Connection pooling (max pool size = 4 × CPU)",
                "Cache hot reads in Redis (5 min TTL default)",
                "Paginate every list endpoint (max page size 100)",
                "Use background tasks for slow side-effects (email, webhooks)",
            ],
            documentation_standards=[
                "OpenAPI auto-generated from route signatures",
                "Docstrings on every public service method",
                "README with quickstart + architecture diagram",
                "ADR (Architecture Decision Records) for major decisions",
            ],
            deployment_expectations=[
                "Multi-stage Dockerfile (slim base, non-root user)",
                "Health check endpoint /healthz (liveness) + /readyz (readiness)",
                "Graceful shutdown on SIGTERM (drain in-flight requests)",
                "12-factor config (env vars)",
                "CI/CD pipeline that runs lint → test → build → deploy",
            ],
            detection_keywords=[
                "api", "rest", "restful", "backend", "endpoint", "fastapi",
                "flask", "django", "graphql", "grpc", "microservice",
                "openapi", "swagger", "postgrest",
                # Common backend-style applications (data management backends).
                "crm", "erp", "inventory system", "booking system",
                "reservation system", "admin panel backend",
                "billing system", "order management",
            ],
            detection_weight=1.0,
        )

    def customize(self, template: DomainTemplate, request: str, *, context: dict | None = None) -> DomainTemplate:
        r = request.lower()
        if "graphql" in r:
            template.recommended_framework = "Strawberry GraphQL"
            template.alternative_frameworks = ["Ariadne", "Graphene"]
        elif "grpc" in r:
            template.recommended_framework = "grpc-python"
        elif "flask" in r:
            template.recommended_framework = "Flask"
        elif "django" in r:
            template.recommended_framework = "Django REST Framework"
        return template
