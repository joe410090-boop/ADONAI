"""CLI template — Typer/Click + layered config."""
from __future__ import annotations

from adonai.prompt_engineering.models import (
    DomainTemplate,
    QualityGate,
    SoftwareDomain,
    TestingStrategy,
)
from adonai.prompt_engineering.templates.base import BaseDomainTemplate, register_template


@register_template
class CliTemplate(BaseDomainTemplate):
    domain = SoftwareDomain.CLI

    def build(self) -> DomainTemplate:
        return DomainTemplate(
            domain=self.domain,
            name="CLI Application",
            description="Command-line tool with subcommands + layered config",
            recommended_language="python",
            recommended_framework="Typer",
            alternative_frameworks=["Click", "argparse", "Rich-cli"],
            architecture="Commands → services → core (no business logic in commands)",
            common_project_structure=[
                "src/cli/", "src/cli/commands/", "src/core/",
                "src/config/", "tests/", "docs/",
            ],
            engineering_principles=[
                "discoverable", "composable", "scriptable",
                "fast startup", "type-safe",
            ],
            required_features=[
                "help_text", "shell_completion", "config_layering",
                "logging", "dry_run", "version_flag", "testing",
                "man_page", "exit_codes",
            ],
            coding_standards=[
                "Type hints throughout",
                "No side-effects in module import",
                "Commands are thin wrappers over services",
                "Structured logging (not print)",
                "Standard exit codes (0 = success, 1 = error, 2 = usage)",
            ],
            deliverables=[
                "source code", "tests", "README", "man page",
                "completion scripts", "Homebrew formula / pipx publish",
            ],
            quality_gates=[
                QualityGate(name="Ruff", command="ruff check ."),
                QualityGate(name="MyPy", command="mypy src/"),
                QualityGate(name="Pytest", command="pytest --cov=src --cov-fail-under=85"),
                QualityGate(name="CLI Smoke", command="python -m cli --help"),
            ],
            testing_expectations=TestingStrategy(
                unit_tests=True,
                integration_tests=True,
                end_to_end_tests=False,
                coverage_target=0.85,
                frameworks=["pytest", "typer.testing.CliRunner", "pytest-cli"],
                notes="Use CliRunner for command-level tests.",
            ),
            security_requirements=[
                "No shell=True in subprocess calls",
                "Validate all user-provided paths",
                "Restrict file access to allowed directories",
                "Sanitise log output (no secrets)",
            ],
            performance_recommendations=[
                "Lazy-load expensive imports (defer until subcommand needs them)",
                "Cache network calls with TTL",
                "Async I/O for batch operations",
            ],
            documentation_standards=[
                "Auto-generated --help from docstrings",
                "Man page generated from --help",
                "README with examples + gifs",
                "Website with mkdocs",
            ],
            deployment_expectations=[
                "Published to PyPI (pipx install)",
                "Homebrew formula",
                "Docker image for CI use",
                "Single-binary via PyInstaller / Nuitka (optional)",
            ],
            detection_keywords=[
                "cli", "command-line", "command line", "terminal",
                "tool", "typer", "click", "argparse", "shell utility",
                "script", "console app",
            ],
            detection_weight=1.0,
        )

    def customize(self, template: DomainTemplate, request: str, *, context: dict | None = None) -> DomainTemplate:
        r = request.lower()
        if "go " in r or "golang" in r:
            template.recommended_language = "go"
            template.recommended_framework = "Cobra"
        elif "rust" in r:
            template.recommended_language = "rust"
            template.recommended_framework = "clap"
        elif "node" in r or "typescript cli" in r:
            template.recommended_language = "typescript"
            template.recommended_framework = "Commander.js + citty"
        return template
