"""Databases template — PostgreSQL/MySQL/Redis design + access patterns."""
from __future__ import annotations

from adonai.prompt_engineering.models import (
    DomainTemplate,
    QualityGate,
    SoftwareDomain,
    TestingStrategy,
)
from adonai.prompt_engineering.templates.base import BaseDomainTemplate, register_template


@register_template
class DatabasesTemplate(BaseDomainTemplate):
    domain = SoftwareDomain.DATABASES

    def build(self) -> DomainTemplate:
        return DomainTemplate(
            domain=self.domain,
            name="Databases",
            description="Database schema design + access patterns + operations",
            recommended_language="sql",
            recommended_framework="PostgreSQL",
            alternative_frameworks=["MySQL", "SQLite", "MongoDB", "CockroachDB"],
            architecture="Normalised schema + indices + access layer (repositories / DAOs)",
            common_project_structure=[
                "migrations/", "seeds/", "schemas/",
                "indexes/", "views/", "functions/",
                "tests/", "docs/",
            ],
            engineering_principles=[
                "consistent", "indexed", "migrated",
                "backed-up", "auditable",
            ],
            required_features=[
                "migrations", "indexing", "backups", "pitr",
                "replication", "monitoring", "slow_query_log",
                "connection_pooling", "testing",
            ],
            coding_standards=[
                "Forward-only migrations (never edit applied migrations)",
                "Every migration has a rollback script",
                "Naming conventions: snake_case tables, plural",
                "Foreign keys explicit + indexed",
                "No SELECT * in production queries",
                "Timestamps with timezone on every row",
            ],
            deliverables=[
                "schema files", "migrations", "seeds",
                "ER diagram", "index strategy doc",
                "backup + restore runbook", "tests",
            ],
            quality_gates=[
                QualityGate(name="squawk", command="squawk migrations/"),
                QualityGate(name="sqlfluff", command="sqlfluff lint migrations/"),
                QualityGate(name="pgtap", command="pg_prove tests/"),
            ],
            testing_expectations=TestingStrategy(
                unit_tests=True,
                integration_tests=True,
                coverage_target=0.8,
                frameworks=["pgTAP", "pytest-postgresql"],
                notes="Test migrations against a real Postgres container.",
            ),
            security_requirements=[
                "Least-privilege DB roles (app_user, migrator, admin)",
                "Row-level security where multi-tenant",
                "Encrypted at rest (TDE / volume encryption)",
                "TLS for client connections",
                "Audit log for DDL + privileged operations",
            ],
            performance_recommendations=[
                "Index every foreign key + every query WHERE clause",
                "Partition large tables (> 100M rows)",
                "VACUUM ANALYZE schedule tuned to write load",
                "Connection pooling (PgBouncer transaction mode)",
                "Materialised views for expensive aggregations",
            ],
            documentation_standards=[
                "ER diagram (dbdiagram.io or DBeaver)",
                "Data dictionary per table",
                "Index strategy document",
                "Runbook for backup + restore + failover",
            ],
            deployment_expectations=[
                "Managed service (RDS / Cloud SQL / Neon)",
                "Automated daily backups + PITR",
                "Read replicas for read-heavy workloads",
                "Failover tested quarterly",
            ],
            detection_keywords=[
                "database", "db", "sql", "postgres", "postgresql",
                "mysql", "sqlite", "mongodb", "mongo", "redis",
                "schema design", "migration", "data model", "dynamodb",
                "cockroach", "cassandra",
            ],
            detection_weight=1.0,
        )

    def customize(self, template: DomainTemplate, request: str, *, context: dict | None = None) -> DomainTemplate:
        r = request.lower()
        if "mysql" in r:
            template.recommended_framework = "MySQL"
        elif "sqlite" in r:
            template.recommended_framework = "SQLite"
        elif "mongo" in r:
            template.recommended_framework = "MongoDB"
            template.recommended_language = "javascript"
        elif "redis" in r:
            template.recommended_framework = "Redis"
            template.recommended_language = "yaml"
        elif "dynamodb" in r:
            template.recommended_framework = "DynamoDB"
            template.recommended_language = "yaml"
        return template
