"""Game development template — Unity or Godot."""
from __future__ import annotations

from adonai.prompt_engineering.models import (
    DomainTemplate,
    QualityGate,
    SoftwareDomain,
    TestingStrategy,
)
from adonai.prompt_engineering.templates.base import BaseDomainTemplate, register_template


@register_template
class GameDevTemplate(BaseDomainTemplate):
    domain = SoftwareDomain.GAME_DEVELOPMENT

    def build(self) -> DomainTemplate:
        return DomainTemplate(
            domain=self.domain,
            name="Game Development",
            description="2D/3D game with engine, assets, and game loop",
            recommended_language="c#",
            recommended_framework="Unity",
            alternative_frameworks=["Godot", "Unreal", "Bevy"],
            architecture="Entity-Component-System (ECS) or scene-graph",
            common_project_structure=[
                "Assets/Scenes/", "Assets/Scripts/",
                "Assets/Prefabs/", "Assets/Art/",
                "Assets/Audio/", "Assets/Animations/",
                "Tests/", "ProjectSettings/",
            ],
            engineering_principles=[
                "frame-rate-independent", "modular", "testable",
                "performant", "polished",
            ],
            required_features=[
                "game_loop", "input_system", "physics",
                "audio", "save_system", "settings_menu",
                "pause_menu", "testing", "build_pipeline",
            ],
            coding_standards=[
                "Use FixedUpdate for physics, Update for input",
                "Cache component references in Awake/Start",
                "Object pooling for frequently spawned objects",
                "State machine for game + character states",
                "ScriptableObjects for data-driven design",
                "No magic numbers (use constants)",
            ],
            deliverables=[
                "source code", "builds (Win/Mac/Linux)",
                "README", "design document",
                "asset manifest", "test plan",
            ],
            quality_gates=[
                QualityGate(name="Unit Tests", command="Unity Test Runner"),
                QualityGate(name="Lint", command="dotnet format"),
                QualityGate(name="Build", command="Unity -batchmode -buildTarget Win64"),
            ],
            testing_expectations=TestingStrategy(
                unit_tests=True,
                integration_tests=False,
                end_to_end_tests=True,
                coverage_target=0.6,
                frameworks=["Unity Test Framework", "Edit-mode + Play-mode tests"],
                notes="Play-mode tests for gameplay; edit-mode for pure logic.",
            ),
            security_requirements=[
                "No cheat-friendly client authority (server-authoritative for multiplayer)",
                "Save file integrity check (hash + signature)",
                "Encrypted player data",
                "Anti-tamper for release builds",
            ],
            performance_recommendations=[
                "Target 60fps on min-spec hardware",
                "Profile with Profiler + Frame Debugger",
                "Batch draw calls (Static + Dynamic batching)",
                "LOD groups for 3D models",
                "Audio: streaming for music, decompressed for SFX",
            ],
            documentation_standards=[
                "Game Design Document (GDD)",
                "Architecture overview",
                "Asset list + licensing",
                "Runbook for builds + releases",
            ],
            deployment_expectations=[
                "Steam / itch.io upload pipeline",
                "Versioned builds with semver",
                "Crash reporting (Sentry / Backtrace)",
                "Telemetry (opt-in)",
            ],
            detection_keywords=[
                "game", "unity", "godot", "unreal", "bevy",
                "2d game", "3d game", "platformer", "rpg", "shooter",
                "gameplay", "game dev", "game development",
            ],
            detection_weight=1.0,
        )

    def customize(self, template: DomainTemplate, request: str, *, context: dict | None = None) -> DomainTemplate:
        r = request.lower()
        if "godot" in r:
            template.recommended_framework = "Godot"
            template.recommended_language = "gdscript"
        elif "unreal" in r:
            template.recommended_framework = "Unreal Engine"
            template.recommended_language = "cpp"
        elif "bevy" in r:
            template.recommended_framework = "Bevy"
            template.recommended_language = "rust"
        return template
