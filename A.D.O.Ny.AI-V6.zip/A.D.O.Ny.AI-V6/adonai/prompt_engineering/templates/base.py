"""Base class for domain templates + plugin registry.

New domains can be added by:

1. Subclassing :class:`BaseDomainTemplate`.
2. Implementing :meth:`build` to return a :class:`DomainTemplate`.
3. Registering via ``@register_template`` decorator OR by calling
   ``TemplateRegistry.register(MyTemplate())`` at import time.

This keeps the core engine decoupled from the (growing) set of domains.
"""
from __future__ import annotations

import logging
from typing import Iterable

from adonai.prompt_engineering.models import DomainTemplate, SoftwareDomain

log = logging.getLogger(__name__)


class BaseDomainTemplate:
    """Abstract base for domain templates.

    Subclasses MUST set ``domain`` (a :class:`SoftwareDomain`) and
    implement :meth:`build` to produce a populated :class:`DomainTemplate`.
    """

    domain: SoftwareDomain = SoftwareDomain.UNKNOWN

    def build(self) -> DomainTemplate:  # pragma: no cover - abstract
        raise NotImplementedError

    # Optional LLM-driven customisation hook.  The node calls this with
    # the parsed user request so a template can adjust its defaults (e.g.
    # switch from Postgres to MySQL if the user mentioned MySQL).  The
    # default implementation is a no-op.
    def customize(self, template: DomainTemplate, request: str, *, context: dict | None = None) -> DomainTemplate:
        return template


# --------------------------------------------------------------------------- #
# Registry
# --------------------------------------------------------------------------- #

class TemplateRegistry:
    """Plugin registry for domain templates.

    The registry is a singleton-ish object keyed by
    :class:`SoftwareDomain`.  At startup the engine calls
    :meth:`register_all` to discover every template that has been
    ``@register_template``-decorated.
    """

    def __init__(self) -> None:
        self._templates: dict[SoftwareDomain, BaseDomainTemplate] = {}
        self._built_cache: dict[SoftwareDomain, DomainTemplate] = {}

    # ----- registration ----- #

    def register(self, template_cls: type[BaseDomainTemplate] | BaseDomainTemplate) -> None:
        """Register a template class or instance."""
        instance = template_cls() if isinstance(template_cls, type) else template_cls
        if instance.domain in self._templates:
            log.debug("TemplateRegistry: overriding existing template for %s", instance.domain)
        self._templates[instance.domain] = instance
        # Invalidate cache.
        self._built_cache.pop(instance.domain, None)

    def unregister(self, domain: SoftwareDomain) -> bool:
        if domain in self._templates:
            del self._templates[domain]
            self._built_cache.pop(domain, None)
            return True
        return False

    def register_all(self, templates: Iterable[type[BaseDomainTemplate] | BaseDomainTemplate]) -> None:
        for t in templates:
            self.register(t)

    # ----- lookup ----- #

    def has(self, domain: SoftwareDomain) -> bool:
        return domain in self._templates

    def domains(self) -> list[SoftwareDomain]:
        return sorted(self._templates.keys(), key=lambda d: d.value)

    def get(self, domain: SoftwareDomain) -> DomainTemplate | None:
        """Return the *built* (immutable) DomainTemplate for a domain.

        Built templates are cached; calling ``get`` twice returns the
        same object.
        """
        if domain not in self._templates:
            return None
        if domain not in self._built_cache:
            self._built_cache[domain] = self._templates[domain].build()
        return self._built_cache[domain]

    def get_plugin(self, domain: SoftwareDomain) -> BaseDomainTemplate | None:
        """Return the *plugin* (customisable) for a domain."""
        return self._templates.get(domain)

    def all_built(self) -> list[DomainTemplate]:
        """Return all built templates (for introspection / debugging)."""
        return [self.get(d) for d in self._templates]  # type: ignore[misc]


# --------------------------------------------------------------------------- #
# Decorator
# --------------------------------------------------------------------------- #

_GLOBAL_REGISTRY = TemplateRegistry()


def register_template(template_cls: type[BaseDomainTemplate]) -> type[BaseDomainTemplate]:
    """Class decorator that registers the template in the global registry."""
    _GLOBAL_REGISTRY.register(template_cls)
    return template_cls


def get_global_registry() -> TemplateRegistry:
    """Return the process-wide :class:`TemplateRegistry`.

    The PromptEngineeringNode uses this by default; tests can construct
    their own registry and inject it.
    """
    return _GLOBAL_REGISTRY
