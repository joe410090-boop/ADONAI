"""Autonomous agents template — LangChain + tools + memory + safety."""
from __future__ import annotations

from adonai.prompt_engineering.models import (
    DomainTemplate,
    QualityGate,
    SoftwareDomain,
    TestingStrategy,
)
from adonai.prompt_engineering.templates.base import BaseDomainTemplate, register_template


@register_template
class AutonomousAgentsTemplate(BaseDomainTemplate):
    domain = SoftwareDomain.AUTONOMOUS_AGENTS

    def build(self) -> DomainTemplate:
        return DomainTemplate(
            domain=self.domain,
            name="Autonomous Agents",
            description="LLM-driven agent with tools, memory, and safety guards",
            recommended_language="python",
            recommended_framework="LangChain / LangGraph",
            alternative_frameworks=["LlamaIndex", "CrewAI", "AutoGen", "custom"],
            architecture="Agent core → tools → memory → safety → planner → executor",
            common_project_structure=[
                "agent/", "agent/tools/", "agent/memory/",
                "agent/safety/", "agent/reasoning/", "agent/planning/",
                "agent/executors/", "tests/", "config/",
            ],
            engineering_principles=[
                "observable", "controllable", "idempotent",
                "recoverable", "bounded",
            ],
            required_features=[
                "memory", "tool_registry", "permission_policy",
                "safety_guard", "audit_log", "tracing",
                "checkpointing", "recovery", "streaming", "testing",
            ],
            coding_standards=[
                "Type hints throughout",
                "Async by default (no blocking I/O)",
                "Every tool declares JSON schema for params",
                "Every external call wrapped in try/except + retry",
                "Idempotent tool namespacing",
                "Token accounting on every LLM call",
            ],
            deliverables=[
                "source code", "tests", "README", "audit log viewer",
                "Docker Compose (agent + vector DB + Postgres)",
                "tool SDK", "deployment config",
            ],
            quality_gates=[
                QualityGate(name="Ruff", command="ruff check ."),
                QualityGate(name="MyPy", command="mypy agent/"),
                QualityGate(name="Pytest", command="pytest --cov=agent --cov-fail-under=80"),
                QualityGate(name="Safety", command="pytest tests/safety/"),
            ],
            testing_expectations=TestingStrategy(
                unit_tests=True,
                integration_tests=True,
                property_tests=True,
                coverage_target=0.85,
                frameworks=["pytest", "pytest-asyncio", "respx"],
                notes="Mock LLM in unit tests; real LLM in smoke tests only.",
            ),
            security_requirements=[
                "Permission policy on every tool (allow/deny/ask)",
                "Hard cap on tool calls per task (default 50)",
                "Approval gate for destructive tools",
                "Sandboxed code execution (no host access)",
                "Audit log of every action + LLM call",
                "Secret management via env / vault",
            ],
            performance_recommendations=[
                "Cache LLM responses (hash of messages)",
                "Batch tool calls when possible",
                "Stream tokens to user (perceived latency)",
                "Use cheaper model for routing, expensive for synthesis",
                "Prompt compression for long contexts",
            ],
            documentation_standards=[
                "Architecture diagram (agent loop + memory tiers)",
                "Tool catalogue with examples",
                "Runbook for common failure modes",
                "README with quickstart + safety notes",
            ],
            deployment_expectations=[
                "Containerised with health endpoints",
                "Horizontal scaling (stateless agent + shared memory store)",
                "Per-user token budget tracking",
                "Graceful degradation on LLM outage",
            ],
            detection_keywords=[
                "agent", "autonomous", "langchain", "llm agent",
                "tool use", "ai assistant", "chatbot", "assistant",
                "multi-agent", "agentic", "self-improving", "robot agent",
            ],
            detection_weight=1.2,  # Strong signal — agent projects are distinct.
        )

    def customize(self, template: DomainTemplate, request: str, *, context: dict | None = None) -> DomainTemplate:
        r = request.lower()
        if "llamaindex" in r:
            template.recommended_framework = "LlamaIndex"
        elif "crewai" in r or "crew ai" in r:
            template.recommended_framework = "CrewAI"
        elif "autogen" in r:
            template.recommended_framework = "AutoGen"
        return template
