"""Desktop application template — Electron or Tauri."""
from __future__ import annotations

from adonai.prompt_engineering.models import (
    DomainTemplate,
    QualityGate,
    SoftwareDomain,
    TestingStrategy,
)
from adonai.prompt_engineering.templates.base import BaseDomainTemplate, register_template


@register_template
class DesktopTemplate(BaseDomainTemplate):
    domain = SoftwareDomain.DESKTOP

    def build(self) -> DomainTemplate:
        return DomainTemplate(
            domain=self.domain,
            name="Desktop Application",
            description="Cross-platform desktop app (Win/Mac/Linux)",
            recommended_language="typescript",
            recommended_framework="Tauri",
            alternative_frameworks=["Electron", "Qt", "WPF", "Flutter Desktop"],
            architecture="Main process + renderer (webview) + IPC bridge",
            common_project_structure=[
                "src/main/", "src/renderer/", "src/preload/",
                "src/components/", "src/services/",
                "tests/", "resources/", "build/",
            ],
            engineering_principles=[
                "responsive", "native-feeling", "secure",
                "auto-updating", "offline-capable",
            ],
            required_features=[
                "auto_update", "native_menus", "system_tray",
                "file_dialogs", "deep_links", "notifications",
                "testing", "code_signing", "installer",
            ],
            coding_standards=[
                "TypeScript strict",
                "Context isolation enabled",
                "No Node APIs in renderer (use preload bridge)",
                "Sandbox renderer by default",
                "Validate all IPC payloads",
            ],
            deliverables=[
                "source code", "tests", "README",
                "installers (MSI/DMG/AppImage/DEB)",
                "auto-update server config", "code-signing cert",
            ],
            quality_gates=[
                QualityGate(name="ESLint", command="eslint . --max-warnings 0"),
                QualityGate(name="TypeScript", command="tsc --noEmit"),
                QualityGate(name="Vitest", command="vitest run --coverage"),
                QualityGate(name="Electron Forge / Tauri build", command="tauri build"),
            ],
            testing_expectations=TestingStrategy(
                unit_tests=True,
                integration_tests=True,
                end_to_end_tests=True,
                coverage_target=0.75,
                frameworks=["vitest", "playwright", "@tauri-apps/api/mocks"],
                notes="Playwright with _electron_ service for end-to-end.",
            ),
            security_requirements=[
                "Context isolation + sandbox enabled",
                "No nodeIntegration in renderer",
                "CSP with no unsafe-inline",
                "Code-sign every release build",
                "Auto-update channel over HTTPS with signature verification",
            ],
            performance_recommendations=[
                "Lazy-load renderer bundles",
                "Native module only when necessary (avoid native deps)",
                "Minimise IPC round-trips (batch)",
                "Binary size budget (Tauri < 10MB, Electron < 150MB)",
            ],
            documentation_standards=[
                "README with build instructions per OS",
                "Architecture diagram (main vs renderer vs preload)",
                "Auto-update flow documented",
                "Release notes per version",
            ],
            deployment_expectations=[
                "Code-signed builds for Win/Mac/Linux",
                "Auto-update server (Hazel / Tauri updater)",
                "Notarisation for macOS",
                "Chocolatey / Homebrew Cask distribution (optional)",
            ],
            detection_keywords=[
                "desktop", "electron", "tauri", "qt app",
                "wpf", "desktop app", "menubar app", "system tray app",
                "cross-platform desktop", "native app",
            ],
            detection_weight=1.0,
        )

    def customize(self, template: DomainTemplate, request: str, *, context: dict | None = None) -> DomainTemplate:
        r = request.lower()
        if "electron" in r:
            template.recommended_framework = "Electron + Forge"
        elif "qt" in r:
            template.recommended_framework = "Qt"
            template.recommended_language = "cpp"
        elif "wpf" in r:
            template.recommended_framework = "WPF"
            template.recommended_language = "csharp"
        elif "flutter desktop" in r:
            template.recommended_framework = "Flutter Desktop"
            template.recommended_language = "dart"
        return template
