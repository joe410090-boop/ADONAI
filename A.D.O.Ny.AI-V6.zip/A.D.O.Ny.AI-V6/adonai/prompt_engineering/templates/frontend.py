"""Frontend template — React + TypeScript + Tailwind + Vite."""
from __future__ import annotations

from adonai.prompt_engineering.models import (
    DomainTemplate,
    QualityGate,
    SoftwareDomain,
    TestingStrategy,
)
from adonai.prompt_engineering.templates.base import BaseDomainTemplate, register_template


@register_template
class FrontendTemplate(BaseDomainTemplate):
    domain = SoftwareDomain.FRONTEND

    def build(self) -> DomainTemplate:
        return DomainTemplate(
            domain=self.domain,
            name="Frontend",
            description="Single-page application with component-driven UI",
            recommended_language="typescript",
            recommended_framework="React + Vite",
            alternative_frameworks=["Next.js", "SvelteKit", "Vue 3", "SolidJS"],
            architecture="Feature-sliced (components / features / pages / app)",
            common_project_structure=[
                "src/components/", "src/features/", "src/pages/",
                "src/hooks/", "src/store/", "src/api/", "src/utils/",
                "src/styles/", "public/", "tests/",
            ],
            engineering_principles=[
                "accessible", "responsive", "performant",
                "type-safe", "component-driven", "design-system first",
            ],
            required_features=[
                "routing", "state_management", "forms", "validation",
                "testing", "linting", "theming", "i18n",
                "accessibility", "error_boundaries", "analytics",
            ],
            coding_standards=[
                "TypeScript strict mode",
                "functional components + hooks (no class components)",
                "no `any` types — use `unknown` + type guards",
                "co-locate component tests",
                "Barrel exports per feature",
                "CSS-in-JS or Tailwind only (no global CSS)",
            ],
            deliverables=[
                "source code", "tests", "README", "Storybook",
                "Dockerfile (nginx serving built assets)",
                "design tokens", "deployment config",
            ],
            quality_gates=[
                QualityGate(name="ESLint", command="eslint . --max-warnings 0"),
                QualityGate(name="Prettier", command="prettier --check ."),
                QualityGate(name="TypeScript", command="tsc --noEmit"),
                QualityGate(name="Vitest", command="vitest run --coverage"),
                QualityGate(name="Lighthouse CI", command="lhci autorun"),
            ],
            testing_expectations=TestingStrategy(
                unit_tests=True,
                integration_tests=True,
                end_to_end_tests=True,
                coverage_target=0.8,
                frameworks=["vitest", "react-testing-library", "playwright"],
                notes="Component tests with RTL; e2e with Playwright.",
            ),
            security_requirements=[
                "No `dangerouslySetInnerHTML` without sanitisation",
                "CSP headers (no inline scripts)",
                "XSS prevention via React's default escaping",
                "Auth tokens in httpOnly cookies (not localStorage)",
                "Subresource integrity for 3rd-party scripts",
            ],
            performance_recommendations=[
                "Code-split per route (React.lazy + Suspense)",
                "Image optimisation (WebP/AVIF, lazy load)",
                "Bundle size budget (≤ 200 KB gzipped initial)",
                "Memoise expensive renders (useMemo / React Compiler)",
                "Prefetch likely-next routes",
            ],
            documentation_standards=[
                "Storybook for every component",
                "TSDoc on every hook + utility",
                "README with quickstart + architecture diagram",
                "ADR for state-management choice",
            ],
            deployment_expectations=[
                "Static build served by CDN",
                "Cache headers (immutable for hashed assets)",
                "Preview deploy per PR",
                "Source maps uploaded to error tracker",
            ],
            detection_keywords=[
                "frontend", "ui", "react", "vue", "svelte", "angular",
                "next.js", "nextjs", "spa", "single-page", "component",
                "dashboard", "design system", "tailwind", "css",
            ],
            detection_weight=1.0,
        )

    def customize(self, template: DomainTemplate, request: str, *, context: dict | None = None) -> DomainTemplate:
        r = request.lower()
        if "next" in r or "nextjs" in r:
            template.recommended_framework = "Next.js"
        elif "svelte" in r:
            template.recommended_framework = "SvelteKit"
        elif "vue" in r:
            template.recommended_framework = "Vue 3 + Vite"
        elif "angular" in r:
            template.recommended_framework = "Angular"
            template.recommended_language = "typescript"
        return template
