"""Full-stack template — Next.js + Prisma + tRPC / Next.js App Router."""
from __future__ import annotations

from adonai.prompt_engineering.models import (
    DomainTemplate,
    QualityGate,
    SoftwareDomain,
    TestingStrategy,
)
from adonai.prompt_engineering.templates.base import BaseDomainTemplate, register_template


@register_template
class FullStackTemplate(BaseDomainTemplate):
    domain = SoftwareDomain.FULL_STACK

    def build(self) -> DomainTemplate:
        return DomainTemplate(
            domain=self.domain,
            name="Full Stack",
            description="End-to-end web application with frontend + API + database",
            recommended_language="typescript",
            recommended_framework="Next.js (App Router)",
            alternative_frameworks=["Remix", "SvelteKit", "Nuxt 3", "T3 Stack"],
            architecture="Monorepo (frontend + backend in one repo, separate packages)",
            common_project_structure=[
                "apps/web/", "apps/api/", "packages/db/", "packages/ui/",
                "packages/config/", "packages/types/", "tests/", "docker/",
            ],
            engineering_principles=[
                "scalable", "maintainable", "type-safe end-to-end",
                "modular", "secure", "shared types across stack",
            ],
            required_features=[
                "authentication", "authorization", "crud", "validation",
                "logging", "monitoring", "configuration", "testing",
                "docker", "migrations", "ssr", "api_routes",
                "background_jobs", "email", "file_uploads",
            ],
            coding_standards=[
                "TypeScript strict across the monorepo",
                "Shared types package imported by both apps",
                "tRPC or Zod schemas for end-to-end type safety",
                "DRY: business logic lives in packages, not apps",
                "SOLID + dependency injection",
                "Conventional commits + semantic versioning",
            ],
            deliverables=[
                "source code", "tests", "README", "Docker Compose",
                "API documentation", "design system", "deployment config",
                "seeds + fixtures",
            ],
            quality_gates=[
                QualityGate(name="ESLint", command="eslint . --max-warnings 0"),
                QualityGate(name="TypeScript", command="tsc -b"),
                QualityGate(name="Vitest", command="vitest run --coverage"),
                QualityGate(name="Playwright", command="playwright test"),
            ],
            testing_expectations=TestingStrategy(
                unit_tests=True,
                integration_tests=True,
                end_to_end_tests=True,
                coverage_target=0.8,
                frameworks=["vitest", "playwright", "msw"],
                notes="Mock API via MSW in component tests; real DB in integration tests.",
            ),
            security_requirements=[
                "Auth via httpOnly cookies (NextAuth / Lucia)",
                "CSRF protection on mutations",
                "RBAC enforced on both client + server",
                "Environment-based secrets (no .env in repo)",
                "Rate limiting on auth + write endpoints",
                "File upload validation (mime + size + virus scan)",
            ],
            performance_recommendations=[
                "SSR/ISR for public pages; CSR for authenticated",
                "Image optimisation via next/image",
                "DB connection pooling (Prisma pgbouncer mode)",
                "Edge caching for static assets",
                "Bundle size budget per route",
            ],
            documentation_standards=[
                "README per package",
                "OpenAPI / tRPC router types auto-exported",
                "Architecture diagram in root README",
                "ADR for major decisions",
            ],
            deployment_expectations=[
                "Frontend: Vercel / Cloudflare Pages",
                "Backend: containerised (Docker) on Fly.io / Railway / ECS",
                "Database: managed Postgres (RDS / Neon)",
                "CI/CD: GitHub Actions per package + monorepo root",
                "Preview deploy per PR",
            ],
            detection_keywords=[
                "full stack", "fullstack", "full-stack", "web app",
                "web application", "next.js", "nextjs", "remix",
                "t3 stack", "monorepo", "ssr app", "saas",
            ],
            detection_weight=1.2,  # Slightly higher because full-stack is a strong signal.
        )

    def customize(self, template: DomainTemplate, request: str, *, context: dict | None = None) -> DomainTemplate:
        r = request.lower()
        if "remix" in r:
            template.recommended_framework = "Remix"
        elif "t3" in r:
            template.recommended_framework = "T3 Stack (Next.js + tRPC + Prisma)"
        elif "nuxt" in r:
            template.recommended_framework = "Nuxt 3"
            template.recommended_language = "typescript"
        return template
