"""Mobile template — React Native or Flutter."""
from __future__ import annotations

from adonai.prompt_engineering.models import (
    DomainTemplate,
    QualityGate,
    SoftwareDomain,
    TestingStrategy,
)
from adonai.prompt_engineering.templates.base import BaseDomainTemplate, register_template


@register_template
class MobileTemplate(BaseDomainTemplate):
    domain = SoftwareDomain.MOBILE

    def build(self) -> DomainTemplate:
        return DomainTemplate(
            domain=self.domain,
            name="Mobile",
            description="Cross-platform mobile app (iOS + Android)",
            recommended_language="typescript",
            recommended_framework="React Native + Expo",
            alternative_frameworks=["Flutter", "Native (Swift/Kotlin)", "Ionic"],
            architecture="Feature-based with offline-first data layer",
            common_project_structure=[
                "src/features/", "src/components/", "src/navigation/",
                "src/api/", "src/store/", "src/hooks/", "src/theme/",
                "src/utils/", "assets/", "e2e/",
            ],
            engineering_principles=[
                "offline-first", "accessible", "performant",
                "type-safe", "platform-aware",
            ],
            required_features=[
                "navigation", "state_management", "offline_cache",
                "push_notifications", "analytics", "deep_linking",
                "biometric_auth", "testing", "theming",
            ],
            coding_standards=[
                "TypeScript strict",
                "Functional components + hooks",
                "Co-locate feature tests",
                "Platform-specific files via .ios/.android extensions",
                "No inline styles (use StyleSheet)",
            ],
            deliverables=[
                "source code", "tests", "README", "App Store screenshots",
                "Play Store listing", "CI/CD pipeline", "EAS build config",
            ],
            quality_gates=[
                QualityGate(name="ESLint", command="eslint . --max-warnings 0"),
                QualityGate(name="TypeScript", command="tsc --noEmit"),
                QualityGate(name="Jest", command="jest --coverage"),
                QualityGate(name="Detox", command="detox test --configuration ios.sim"),
            ],
            testing_expectations=TestingStrategy(
                unit_tests=True,
                integration_tests=True,
                end_to_end_tests=True,
                coverage_target=0.75,
                frameworks=["jest", "react-native-testing-library", "detox"],
                notes="Snapshot tests for components; Detox for e2e.",
            ),
            security_requirements=[
                "Secure storage for tokens (Keychain / Keystore)",
                "Certificate pinning for API calls",
                "No secrets in app bundle (use server-side proxy)",
                "Biometric auth for sensitive operations",
                "Code obfuscation in release builds",
            ],
            performance_recommendations=[
                "FlatList with recycled rows (never ScrollView for long lists)",
                "Image caching (FastImage)",
                "Memoise expensive renders",
                "Lazy-load feature bundles (Hermes)",
                "60fps target — profile with Flipper",
            ],
            documentation_standards=[
                "README with build + run instructions",
                "TSDoc on hooks + utilities",
                "Architecture decision records",
                "Runbook for releases",
            ],
            deployment_expectations=[
                "EAS Build for OTA updates + store builds",
                "Staged rollout (1% → 10% → 100%)",
                "Crash reporting (Sentry / Crashlytics)",
                "OTA updates for JS-only changes",
            ],
            detection_keywords=[
                "mobile", "ios", "android", "react native", "flutter",
                "expo", "app store", "play store", "swift", "kotlin",
                "mobile app", "tablet",
            ],
            detection_weight=1.0,
        )

    def customize(self, template: DomainTemplate, request: str, *, context: dict | None = None) -> DomainTemplate:
        r = request.lower()
        if "flutter" in r or "dart" in r:
            template.recommended_framework = "Flutter"
            template.recommended_language = "dart"
        elif "swift" in r or "native ios" in r:
            template.recommended_framework = "SwiftUI"
            template.recommended_language = "swift"
        elif "kotlin" in r or "native android" in r:
            template.recommended_framework = "Jetpack Compose"
            template.recommended_language = "kotlin"
        return template
