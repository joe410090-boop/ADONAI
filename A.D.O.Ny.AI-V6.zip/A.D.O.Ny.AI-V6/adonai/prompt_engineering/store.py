"""Prompt store — SQLite-backed persistence for self-improvement.

Stores every generated :class:`PromptPackage` and its
:class:`PromptOutcome`.  The Prompt Engineering Node queries the store
to retrieve similar past prompts + their outcomes, allowing it to:

* skip domains where prior prompts consistently failed
* surface lessons-learned as risks in new prompts
* rank templates by historical performance

The store is intentionally lightweight (one table for packages, one
for outcomes) and uses the project's existing data directory layout
(``data/adonai.db``).
"""
from __future__ import annotations

import json
import logging
import sqlite3
import time
from pathlib import Path
from typing import Any
from uuid import uuid4

from adonai.prompt_engineering.models import (
    Complexity,
    PromptOutcome,
    PromptPackage,
    SoftwareDomain,
)

log = logging.getLogger(__name__)


_SCHEMA = """
CREATE TABLE IF NOT EXISTS prompt_packages (
    id              TEXT PRIMARY KEY,
    created_at      REAL NOT NULL,
    original_request TEXT NOT NULL,
    detected_domain TEXT NOT NULL,
    project_type    TEXT NOT NULL,
    complexity      TEXT NOT NULL,
    language        TEXT,
    framework       TEXT,
    template_id     TEXT,
    engineered_prompt TEXT NOT NULL,
    package_json    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS prompt_outcomes (
    id              TEXT PRIMARY KEY,
    prompt_id       TEXT NOT NULL,
    recorded_at     REAL NOT NULL,
    build_success   INTEGER NOT NULL,
    bug_count       INTEGER NOT NULL DEFAULT 0,
    completion_time_s REAL NOT NULL DEFAULT 0,
    user_satisfaction REAL NOT NULL DEFAULT 0,
    code_quality_score REAL NOT NULL DEFAULT 0,
    notes           TEXT,
    FOREIGN KEY (prompt_id) REFERENCES prompt_packages(id)
);

CREATE INDEX IF NOT EXISTS idx_packages_domain ON prompt_packages(detected_domain);
CREATE INDEX IF NOT EXISTS idx_outcomes_prompt ON prompt_outcomes(prompt_id);
"""


class PromptStore:
    """SQLite-backed store for prompt packages + outcomes."""

    def __init__(self, db_path: str | Path) -> None:
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    # ------------------------------------------------------------------ #
    # Internal
    # ------------------------------------------------------------------ #

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _init_schema(self) -> None:
        try:
            with self._connect() as conn:
                conn.executescript(_SCHEMA)
                conn.commit()
        except Exception as e:
            log.error("PromptStore schema init failed: %s", e)
            raise

    # ------------------------------------------------------------------ #
    # Write
    # ------------------------------------------------------------------ #

    def save_package(self, package: PromptPackage) -> str:
        """Persist a PromptPackage; returns the assigned id."""
        prompt_id = f"prompt_{uuid4().hex[:12]}"
        package.template_id = package.template_id or prompt_id
        now = time.time()
        try:
            with self._connect() as conn:
                conn.execute(
                    """INSERT INTO prompt_packages
                       (id, created_at, original_request, detected_domain,
                        project_type, complexity, language, framework,
                        template_id, engineered_prompt, package_json)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        prompt_id, now, package.original_request,
                        package.detected_domain.value, package.project_type.value,
                        package.estimated_complexity.value,
                        package.recommended_language, package.framework,
                        package.template_id, package.engineered_prompt,
                        package.model_dump_json(),
                    ),
                )
                conn.commit()
        except Exception as e:
            log.error("PromptStore.save_package failed: %s", e)
            raise
        return prompt_id

    def record_outcome(self, outcome: PromptOutcome) -> None:
        """Record the outcome of using a prompt package."""
        outcome_id = f"outcome_{uuid4().hex[:12]}"
        now = time.time()
        try:
            with self._connect() as conn:
                conn.execute(
                    """INSERT INTO prompt_outcomes
                       (id, prompt_id, recorded_at, build_success, bug_count,
                        completion_time_s, user_satisfaction, code_quality_score,
                        notes)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        outcome_id, outcome.prompt_id, now,
                        int(outcome.build_success), outcome.bug_count,
                        outcome.completion_time_s, outcome.user_satisfaction,
                        outcome.code_quality_score, outcome.notes,
                    ),
                )
                conn.commit()
        except Exception as e:
            log.error("PromptStore.record_outcome failed: %s", e)
            raise

    # ------------------------------------------------------------------ #
    # Read
    # ------------------------------------------------------------------ #

    def get_package(self, prompt_id: str) -> PromptPackage | None:
        try:
            with self._connect() as conn:
                row = conn.execute(
                    "SELECT package_json FROM prompt_packages WHERE id = ?",
                    (prompt_id,),
                ).fetchone()
            if row is None:
                return None
            return PromptPackage.model_validate_json(row["package_json"])
        except Exception as e:
            log.warning("PromptStore.get_package failed: %s", e)
            return None

    def find_similar(
        self,
        request: str,
        domain: SoftwareDomain | None = None,
        limit: int = 5,
    ) -> list[dict[str, Any]]:
        """Find prior packages matching the request (by domain + keyword overlap).

        Returns a list of dicts: ``{prompt_id, request, domain, success_rate,
        avg_quality, avg_completion_time_s, engineered_prompt}``.
        """
        query = """
            SELECT p.id, p.original_request, p.detected_domain,
                   p.engineered_prompt,
                   AVG(o.build_success) AS success_rate,
                   AVG(o.code_quality_score) AS avg_quality,
                   AVG(o.completion_time_s) AS avg_completion_time_s,
                   COUNT(o.id) AS outcome_count
            FROM prompt_packages p
            LEFT JOIN prompt_outcomes o ON o.prompt_id = p.id
            WHERE 1=1
        """
        params: list[Any] = []
        if domain is not None:
            query += " AND p.detected_domain = ?"
            params.append(domain.value)
        query += " GROUP BY p.id ORDER BY p.created_at DESC LIMIT ?"
        params.append(limit)

        try:
            with self._connect() as conn:
                rows = conn.execute(query, params).fetchall()
        except Exception as e:
            log.warning("PromptStore.find_similar failed: %s", e)
            return []

        # Rank by simple keyword overlap with the request.
        request_lower = request.lower()
        request_words = set(request_lower.split())

        def _overlap(row: sqlite3.Row) -> int:
            prior = (row["original_request"] or "").lower()
            return len(request_words & set(prior.split()))

        ranked = sorted(rows, key=_overlap, reverse=True)
        return [
            {
                "prompt_id": r["id"],
                "request": r["original_request"],
                "domain": r["detected_domain"],
                "success_rate": float(r["success_rate"] or 0.0),
                "avg_quality": float(r["avg_quality"] or 0.0),
                "avg_completion_time_s": float(r["avg_completion_time_s"] or 0.0),
                "outcome_count": int(r["outcome_count"] or 0),
                "engineered_prompt": r["engineered_prompt"],
            }
            for r in ranked
        ]

    def domain_stats(self) -> dict[str, dict[str, float]]:
        """Per-domain success/quality/completion stats for self-improvement."""
        query = """
            SELECT p.detected_domain AS domain,
                   COUNT(DISTINCT p.id) AS package_count,
                   AVG(o.build_success) AS success_rate,
                   AVG(o.code_quality_score) AS avg_quality,
                   AVG(o.completion_time_s) AS avg_completion_time_s
            FROM prompt_packages p
            LEFT JOIN prompt_outcomes o ON o.prompt_id = p.id
            GROUP BY p.detected_domain
        """
        try:
            with self._connect() as conn:
                rows = conn.execute(query).fetchall()
        except Exception as e:
            log.warning("PromptStore.domain_stats failed: %s", e)
            return {}
        return {
            r["domain"]: {
                "package_count": float(r["package_count"] or 0),
                "success_rate": float(r["success_rate"] or 0.0),
                "avg_quality": float(r["avg_quality"] or 0.0),
                "avg_completion_time_s": float(r["avg_completion_time_s"] or 0.0),
            }
            for r in rows
        }

    def lessons_for_domain(self, domain: SoftwareDomain, limit: int = 5) -> list[str]:
        """Top-N lessons (notes from failed outcomes) for a domain."""
        query = """
            SELECT o.notes FROM prompt_outcomes o
            JOIN prompt_packages p ON p.id = o.prompt_id
            WHERE p.detected_domain = ? AND o.build_success = 0
                AND o.notes IS NOT NULL AND o.notes != ''
            ORDER BY o.recorded_at DESC LIMIT ?
        """
        try:
            with self._connect() as conn:
                rows = conn.execute(query, (domain.value, limit)).fetchall()
        except Exception as e:
            log.warning("PromptStore.lessons_for_domain failed: %s", e)
            return []
        return [r["notes"] for r in rows if r["notes"]]
