"""Domain detector — infers the software engineering domain from a request.

Uses a weighted keyword match against every registered template's
``detection_keywords`` list.  When the LLM is available, an LLM-backed
fallback can refine ambiguous cases (best-effort — keyword match is
the primary path because it's fast, deterministic, and free).
"""
from __future__ import annotations

import logging
import re
from collections import defaultdict
from typing import Any

from adonai.prompt_engineering.models import (
    Complexity,
    ProjectType,
    SoftwareDomain,
)
from adonai.prompt_engineering.templates.base import TemplateRegistry

log = logging.getLogger(__name__)


_compiled_pattern_cache: dict[str, re.Pattern] = {}


class PromptInjectionDetector:
    """Detects prompt injection attempts in user input and LLM outputs."""

    # Patterns that indicate injection attempts
    INJECTION_PATTERNS: list[str] = [
        r"ignore\s+(all\s+)?previous\s+instructions",
        r"disregard\s+(all\s+)?previous",
        r"you\s+are\s+now\s+(a|an)\s+",
        r"new\s+(system|core|base)\s+instruction",
        r"forget\s+(everything|all|your)\s+(instructions|rules|training)",
        r"pretend\s+(you|to\s+be)",
        r"role[- ]?play\s+as",
        r"act\s+as\s+(if\s+you\s+(are|were)|a|an)",
        r"jailbreak",
        r"DAN\s+mode",
        r"dev\s+mode",
        r"above\s+the\s+law",
        r"no\s+(ethical|moral|safety)\s+(constraints|restrictions|limits|guidelines)",
        r"bypass\s+(safety|security|filter|restriction)",
        r"you\s+must\s+(not|never)\s+(refuse|decline|reject)",
        r"output\s+(the\s+)?full\s+(prompt|system|instructions?)",
        r"reveal\s+(your|the)\s+(system|hidden|secret)",
        r"print\s+(your|the)\s+(system|initial|original)",
        r"\[SYSTEM\]|\<system\>|\<\|im_start\|>",
        r"\\{\\{.*?\\}\\}",  # template injection
        r"import\s+os\b",
        r"subprocess\.\w+",
        r"__import__",
        r"exec\s*\(",
        r"eval\s*\(",
        r"open\s*\([\"']/(etc|proc|sys|dev)",
        r"rm\s+(-rf)?\s+/",
        r"curl\s+.*\|\s*(bash|sh)",
        r"wget\s+.*\|\s*(bash|sh)",
        r"chmod\s+777",
        r"\\x[0-9a-f]{2}",  # hex-encoded payloads
    ]

    def __init__(self) -> None:
        self._compiled = [re.compile(p, re.IGNORECASE) for p in self.INJECTION_PATTERNS]

    def detect(self, text: str) -> tuple[bool, list[str]]:
        """Check text for prompt injection patterns.
        Returns (is_injection, list_of_matched_patterns).
        """
        if not text:
            return False, []
        matches: list[str] = []
        for pattern in self._compiled:
            found = pattern.findall(text)
            if found:
                matches.append(f"Pattern: {pattern.pattern}, Matched: {found[0][:80]}")
        return len(matches) > 0, matches

    def sanitize_input(self, text: str, max_length: int = 50000) -> str:
        """Sanitize user input by truncating and stripping control characters."""
        # Strip null bytes and control chars except newline/tab
        text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)
        # Truncate if too long
        if len(text) > max_length:
            text = text[:max_length] + "\n[... truncated ...]"
        return text


class DomainDetector:
    """Detect the :class:`SoftwareDomain` + :class:`ProjectType` of a request."""

    def __init__(self, registry: TemplateRegistry, llm: Any = None) -> None:
        self.registry = registry
        self.llm = llm

    # ------------------------------------------------------------------ #
    # Domain detection
    # ------------------------------------------------------------------ #

    def detect_domain(self, request: str) -> tuple[SoftwareDomain, float]:
        """Return (domain, confidence in 0..1).

        Confidence is the share of the winning domain's score relative to
        the total score across all matched domains.  If no domain
        matches, returns (UNKNOWN, 0.0).
        """
        request_lower = request.lower()
        scores: dict[SoftwareDomain, float] = defaultdict(float)

        for domain in self.registry.domains():
            template = self.registry.get(domain)
            if template is None:
                continue
            weight = template.detection_weight or 1.0
            for kw in template.detection_keywords:
                if not kw:
                    continue
                if self._keyword_matches(kw, request_lower):
                    # Longer keywords are stronger signals.
                    scores[domain] += weight * (1.0 + min(len(kw) / 30.0, 1.5))

        if not scores:
            return SoftwareDomain.UNKNOWN, 0.0

        winner = max(scores, key=scores.get)  # type: ignore[arg-type]
        total = sum(scores.values())
        confidence = scores[winner] / total if total > 0 else 0.0
        return winner, round(confidence, 4)

    @staticmethod
    def _keyword_matches(keyword: str, request_lower: str) -> bool:
        """Match a keyword against the request, respecting word boundaries
        for short keywords (≤ 4 chars) to avoid false positives like
        ``"ui"`` matching ``"build"`` or ``"ai"`` matching ``"chain"``.

        Longer keywords (multi-word phrases, framework names) use plain
        substring matching because they're already specific enough.
        """
        kw = keyword.lower().strip()
        if not kw:
            return False
        # Multi-word phrases: substring is fine (they're already specific).
        if " " in kw or "-" in kw or "." in kw or len(kw) > 4:
            return kw in request_lower
        # Short single-word keyword: require word-boundary match.
        # \b doesn't always work for technical terms (e.g. "c#"), so we
        # check the keyword is surrounded by non-alphanumeric chars or
        # string boundaries.
        pattern = r"(?:^|[^a-z0-9])" + re.escape(kw) + r"(?:$|[^a-z0-9])"
        return re.search(pattern, request_lower) is not None

    # ------------------------------------------------------------------ #
    # Project type detection
    # ------------------------------------------------------------------ #

    def detect_project_type(self, request: str, domain: SoftwareDomain) -> ProjectType:
        """Infer the high-level project shape."""
        r = request.lower()

        # Explicit keyword signals first.
        if any(k in r for k in ("terraform", "ansible", "kubernetes manifest", "helm chart")):
            return ProjectType.INFRASTRUCTURE
        if any(k in r for k in ("cli", "command-line", "command line", "terminal tool")):
            return ProjectType.TOOL
        if any(k in r for k in ("library", "sdk", "package for", "importable")):
            return ProjectType.LIBRARY
        if any(k in r for k in ("etl", "pipeline", "data pipeline", "streaming job")):
            return ProjectType.PIPELINE
        if any(k in r for k in ("experiment", "benchmark", "notebook", "research code")):
            return ProjectType.RESEARCH
        if any(k in r for k in ("firmware", "bare-metal", "microcontroller")):
            return ProjectType.EMBEDDED_FIRMWARE

        # Domain-driven defaults.
        domain_to_type = {
            SoftwareDomain.BACKEND_API: ProjectType.SERVICE,
            SoftwareDomain.WEB_DEVELOPMENT: ProjectType.APPLICATION,
            SoftwareDomain.FRONTEND: ProjectType.APPLICATION,
            SoftwareDomain.FULL_STACK: ProjectType.APPLICATION,
            SoftwareDomain.MOBILE: ProjectType.APPLICATION,
            SoftwareDomain.DESKTOP: ProjectType.APPLICATION,
            SoftwareDomain.CLI: ProjectType.TOOL,
            SoftwareDomain.AI_ML: ProjectType.RESEARCH,
            SoftwareDomain.AUTONOMOUS_AGENTS: ProjectType.APPLICATION,
            SoftwareDomain.ROBOTICS: ProjectType.EMBEDDED_FIRMWARE,
            SoftwareDomain.EMBEDDED: ProjectType.EMBEDDED_FIRMWARE,
            SoftwareDomain.OPERATING_SYSTEMS: ProjectType.LIBRARY,
            SoftwareDomain.NETWORKING: ProjectType.SERVICE,
            SoftwareDomain.CYBERSECURITY: ProjectType.TOOL,
            SoftwareDomain.DEVOPS: ProjectType.INFRASTRUCTURE,
            SoftwareDomain.CLOUD_INFRASTRUCTURE: ProjectType.INFRASTRUCTURE,
            SoftwareDomain.DATABASES: ProjectType.SERVICE,
            SoftwareDomain.BLOCKCHAIN: ProjectType.SERVICE,
            SoftwareDomain.GAME_DEVELOPMENT: ProjectType.APPLICATION,
            SoftwareDomain.BROWSER_DEVELOPMENT: ProjectType.APPLICATION,
            SoftwareDomain.COMPILERS: ProjectType.LIBRARY,
            SoftwareDomain.DISTRIBUTED_SYSTEMS: ProjectType.SERVICE,
            SoftwareDomain.DATA_ENGINEERING: ProjectType.PIPELINE,
            SoftwareDomain.SCIENTIFIC_COMPUTING: ProjectType.RESEARCH,
        }
        return domain_to_type.get(domain, ProjectType.OTHER)

    # ------------------------------------------------------------------ #
    # Complexity estimation
    # ------------------------------------------------------------------ #

    def estimate_complexity(self, request: str) -> Complexity:
        """Heuristic complexity estimate based on request length + signal words."""
        r = request.lower()
        word_count = len(r.split())

        # Very short / single-phrase requests are usually simple apps.
        if word_count < 5 and not any(k in r for k in ("system", "platform", "distributed")):
            return Complexity.SIMPLE

        complexity_signals = [
            "distributed", "real-time", "realtime", "scalable", "high-availability",
            "microservice", "multi-tenant", "federated", "consensus", "blockchain",
            "compiler", "operating system", "kernel", "embedded rtos",
        ]
        if sum(1 for s in complexity_signals if s in r) >= 2:
            return Complexity.VERY_COMPLEX
        if any(s in r for s in complexity_signals):
            return Complexity.COMPLEX
        if word_count > 30:
            return Complexity.COMPLEX
        if word_count > 15:
            return Complexity.MODERATE
        return Complexity.SIMPLE

    # ------------------------------------------------------------------ #
    # LLM refinement (best-effort)
    # ------------------------------------------------------------------ #

    async def refine_with_llm(
        self,
        request: str,
        domain: SoftwareDomain,
        confidence: float,
    ) -> tuple[SoftwareDomain, float]:
        """Use the LLM to disambiguate when keyword confidence is low.

        Only invoked when confidence < 0.5 AND the LLM is available.
        Returns the original (domain, confidence) on any error.
        """
        if self.llm is None or confidence >= 0.5:
            return domain, confidence
        try:
            import json
            from adonai.core.json_utils import extract_json
            domain_options = [d.value for d in self.registry.domains()]
            prompt = (
                "Classify the user's software engineering request into exactly "
                "one of these domains:\n"
                f"{domain_options}\n\n"
                f"Request: {request}\n\n"
                'Respond with JSON: {"domain": "<one of the above>", "confidence": 0.0-1.0}'
            )
            resp = await self.llm.complete(
                messages=[{"role": "user", "content": prompt}],
                temperature=0.0, max_tokens=80,
            )
            data = extract_json(resp.text or "")
            chosen = data.get("domain", domain.value)
            conf = float(data.get("confidence", confidence))
            try:
                new_domain = SoftwareDomain(chosen)
            except ValueError:
                return domain, confidence
            return new_domain, conf
        except Exception as e:
            log.debug("LLM domain refinement failed (non-fatal): %s", e)
            return domain, confidence
