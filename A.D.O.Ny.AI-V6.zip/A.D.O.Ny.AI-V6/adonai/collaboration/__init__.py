"""Multi-agent collaboration — blackboard + voting + consensus."""
from adonai.collaboration.blackboard import Blackboard
from adonai.collaboration.voting import VotingSystem
from adonai.collaboration.consensus import ConsensusBuilder

__all__ = ["Blackboard", "VotingSystem", "ConsensusBuilder"]
