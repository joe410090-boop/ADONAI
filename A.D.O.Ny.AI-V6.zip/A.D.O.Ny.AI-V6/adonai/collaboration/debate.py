"""Upgrade 6 — Multi-Agent Debate Framework.

Real multi-agent debate (not the single-LLM two-prompt trick from
``adonai.reasoning.debate``).  Spawns N distinct agents — Research,
Skeptic, Engineer — each with their own system prompt and (optionally)
their own LLM client.  Runs M rounds of argumentation, then a Judge
agent picks the strongest argument and returns a verdict.

Responsibilities of the Judge:

* Compare arguments across agents
* Evaluate evidence quality
* Select the strongest solution

The framework is pluggable: new participant roles can be added via
``DebateFramework.register_participant``.

Output: a :class:`~adonai.core.models.Debate` record with the full
transcript, the winning stance, the winning argument, and the judge's
verdict.
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from adonai.core.exceptions import DebateError
from adonai.core.events import EventPublisher, EventTypes
from adonai.core.interfaces import DebateFramework, LLMClient
from adonai.core.json_utils import JSONExtractionError, extract_json
from adonai.core.models import Debate, DebateStance, DebateTurn
from adonai.collaboration.voting import VotingSystem

log = logging.getLogger(__name__)


# ──────────────────────────────────────────────────────────────────────────────
# Participant system prompts
# ──────────────────────────────────────────────────────────────────────────────


_PARTICIPANT_PROMPTS: dict[DebateStance, str] = {
    DebateStance.RESEARCHER: (
        "You are the RESEARCHER in a structured debate.\n"
        "Your job is to gather and present EVIDENCE-BACKED arguments.\n"
        "Cite sources where possible.  Be precise, factual, and curious.\n"
        "Avoid speculation — if you don't know, say so and propose a test."
    ),
    DebateStance.SKEPTIC: (
        "You are the SKEPTIC in a structured debate.\n"
        "Your job is to find WEAKNESSES, unstated assumptions, and\n"
        "counter-examples in the other participants' arguments.\n"
        "Be respectful but relentless.  Don't concede unless the evidence\n"
        "is overwhelming."
    ),
    DebateStance.ENGINEER: (
        "You are the ENGINEER in a structured debate.\n"
        "Your job is to evaluate FEASIBILITY — implementation cost,\n"
        "technical risk, maintenance burden.  Propose concrete\n"
        "alternatives where the abstract plans won't survive contact\n"
        "with reality."
    ),
    DebateStance.PROPONENT: (
        "You are the PROPONENT in a structured debate.\n"
        "Your job is to make the STRONGEST possible case FOR the proposal.\n"
        "You don't have to believe it — but you must argue it well."
    ),
}

_JUDGE_PROMPT = (
    "You are the JUDGE of a structured debate.\n"
    "Your job is to:\n"
    "1. Compare arguments across all participants.\n"
    "2. Evaluate the quality of evidence each participant provided.\n"
    "3. Pick the WINNER — the stance whose argument best survives\n"
    "   cross-examination.\n"
    "4. Justify your verdict in 2-3 sentences.\n\n"
    "Output JSON:\n"
    "{\n"
    '  "winner": "researcher"|"skeptic"|"engineer"|"proponent",\n'
    '  "winning_argument": str,\n'
    '  "verdict": str,\n'
    '  "confidence": 0.0-1.0\n'
    "}\n\n"
    "Return ONLY the JSON.  No prose, no markdown fences."
)


# ──────────────────────────────────────────────────────────────────────────────
# DefaultDebateFramework
# ──────────────────────────────────────────────────────────────────────────────


class DefaultDebateFramework(DebateFramework, EventPublisher):
    """LLM-backed multi-agent debate framework.

    Each participant is a separate LLM call with a distinct system
    prompt.  The framework runs ``rounds`` rounds of argumentation:
    in each round, every participant presents its argument (in
    parallel), then sees the other participants' arguments and rebuts
    them in the next round.  After the final round, the Judge produces
    a verdict.
    """

    def __init__(
        self,
        llm: LLMClient | None = None,
        *,
        config: Any = None,
        participant_llms: dict[DebateStance, LLMClient] | None = None,
        voting_system: VotingSystem | None = None,
    ) -> None:
        self.llm = llm
        self.config = config
        # Allow per-stance LLM overrides (e.g. a stronger model for the
        # skeptic).  Falls back to self.llm otherwise.
        self.participant_llms = participant_llms or {}
        # Voting system — used by the judge to formally tally votes
        # across debate participants before rendering a verdict.
        self.voting_system = voting_system

    # ── DebateFramework interface ────────────────────────────────────────

    async def debate(
        self,
        question: str,
        *,
        rounds: int = 2,
        participants: list[str] | None = None,
        context: dict[str, Any] | None = None,
    ) -> Debate:
        """Run a debate; return the full transcript + verdict."""
        context = context or {}
        # Resolve participant stances.
        stances = self._resolve_participants(participants)
        if not stances:
            raise DebateError("debate requires at least one participant")

        cfg_rounds = (
            getattr(getattr(self.config, "debate", None), "default_rounds", 2)
            if self.config else 2
        )
        rounds = max(1, rounds or cfg_rounds)

        # Initialize the Debate record.
        debate = Debate(
            question=question,
            rounds=rounds,
            participants=stances,
            metadata={"context": context},
        )

        # Emit debate.started event.
        await self._emit(EventTypes.DEBATE_STARTED, {
            "debate_id": debate.id,
            "question": question[:200],
            "rounds": rounds,
            "participants": [s.value for s in stances],
        })

        # Run rounds.
        for round_idx in range(rounds):
            log.info(
                "Debate %s: round %d/%d (%d participants)",
                debate.id, round_idx + 1, rounds, len(stances),
            )
            # In each round, every participant speaks in parallel.
            coros = [
                self._participant_turn(
                    debate, stance, round_idx, context,
                )
                for stance in stances
            ]
            turns = await asyncio.gather(*coros, return_exceptions=True)
            for t in turns:
                if isinstance(t, DebateTurn):
                    debate.turns.append(t)
                    # Emit debate.turn event (lets clients stream).
                    await self._emit(EventTypes.DEBATE_TURN, {
                        "debate_id": debate.id,
                        "round": round_idx + 1,
                        "stance": t.stance.value,
                        "content_preview": t.content[:200],
                        "confidence": t.confidence,
                    })
                elif isinstance(t, Exception):
                    log.warning("Debate participant errored: %s", t)

        # Cast votes via the VotingSystem for each participant's stance.
        # This allows external consumers of the voting system to see
        # debate outcomes alongside any other proposals.
        if self.voting_system is not None:
            try:
                vote_proposal_id = f"debate_{debate.id}"
                for t in debate.turns:
                    # Each participant votes for its own stance.
                    self.voting_system.cast_vote(
                        proposal_id=vote_proposal_id,
                        agent=t.stance.value,
                        vote=t.stance.value,
                        weight=t.confidence,
                    )
            except Exception as e:
                log.debug("VotingSystem cast failed (non-fatal): %s", e)

        # Judge verdict.
        if self.llm is not None:
            try:
                await self._judge(debate, context)
            except Exception as e:
                log.warning("Debate judge failed: %s", e)
                debate.verdict = f"judge_failed: {e}"
                debate.confidence = 0.2
        else:
            # No LLM — fall back to longest-argument-wins heuristic.
            self._heuristic_judge(debate)

        # Tally the vote after the judge has spoken.
        if self.voting_system is not None:
            try:
                vote_proposal_id = f"debate_{debate.id}"
                # The judge's verdict is the authoritative vote.
                if debate.winner is not None:
                    self.voting_system.cast_vote(
                        proposal_id=vote_proposal_id,
                        agent="judge",
                        vote=debate.winner.value,
                        weight=debate.confidence * 2.0,  # judge's vote counts double
                    )
                tally = self.voting_system.tally(vote_proposal_id)
                debate.metadata["vote_tally"] = tally
            except Exception as e:
                log.debug("VotingSystem tally failed (non-fatal): %s", e)

        debate.completed_at = debate.completed_at or _now()

        # Emit debate.completed event.
        await self._emit(EventTypes.DEBATE_COMPLETED, {
            "debate_id": debate.id,
            "winner": debate.winner.value if debate.winner else None,
            "confidence": debate.confidence,
            "turn_count": len(debate.turns),
        })

        return debate

    # ── Internals ─────────────────────────────────────────────────────────

    def _resolve_participants(
        self, participants: list[str] | None,
    ) -> list[DebateStance]:
        if not participants:
            # Default to researcher + skeptic + engineer.
            return [DebateStance.RESEARCHER, DebateStance.SKEPTIC, DebateStance.ENGINEER]
        out: list[DebateStance] = []
        for p in participants:
            try:
                out.append(DebateStance(p))
            except ValueError:
                log.warning("Unknown debate stance: %s — skipping", p)
        return out

    async def _participant_turn(
        self,
        debate: Debate,
        stance: DebateStance,
        round_idx: int,
        context: dict[str, Any],
    ) -> DebateTurn:
        llm = self.participant_llms.get(stance) or self.llm
        if llm is None:
            return DebateTurn(
                agent=stance.value,
                stance=stance,
                content="(no LLM available — skipping)",
                confidence=0.0,
            )
        system_prompt = _PARTICIPANT_PROMPTS.get(stance, "You are a debate participant.")
        # Build the user prompt with the question + prior turns (if any).
        prior_turns_text = ""
        if debate.turns:
            prior_turns_text = "\n\nPrior arguments:\n" + "\n\n".join(
                f"[{t.stance.value}] {t.content}" for t in debate.turns[-6:]
            )
        user_prompt = (
            f"QUESTION: {debate.question}\n"
            f"ROUND: {round_idx + 1}/{debate.rounds}\n"
            f"YOUR STANCE: {stance.value}\n"
            f"{prior_turns_text}\n\n"
            f"Present your argument{' (or rebuttal, if round > 1)' if round_idx > 0 else ''}. "
            f"Be concise (max 200 words).  Cite evidence where possible."
        )
        resp = await llm.complete(
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            temperature=self._participant_temperature(),
            max_tokens=self._max_argument_tokens(),
        )
        # Extract citations (lines starting with [src] or http).
        content = (resp.text or "").strip()
        citations = self._extract_citations(content)
        return DebateTurn(
            agent=stance.value,
            stance=stance,
            content=content,
            citations=citations,
            confidence=0.6,  # participants don't grade themselves
        )

    async def _judge(
        self, debate: Debate, context: dict[str, Any],
    ) -> None:
        """Run the judge LLM and populate the verdict."""
        transcript = "\n\n".join(
            f"[{t.stance.value}] (confidence={t.confidence:.2f})\n{t.content}"
            for t in debate.turns
        )
        user_prompt = (
            f"QUESTION: {debate.question}\n\n"
            f"TRANSCRIPT:\n{transcript}\n\n"
            f"Pick the winner and justify your verdict as JSON."
        )
        resp = await self.llm.complete(
            messages=[
                {"role": "system", "content": _JUDGE_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
            temperature=self._judge_temperature(),
            max_tokens=512,
        )
        try:
            data = extract_json(resp.text or "")
        except JSONExtractionError as e:
            raise DebateError(f"judge returned unparseable JSON: {e}") from e
        if not isinstance(data, dict):
            raise DebateError("judge returned non-dict JSON")
        try:
            debate.winner = DebateStance(data.get("winner", "researcher"))
        except ValueError:
            debate.winner = None
        debate.winning_argument = str(data.get("winning_argument") or "")
        debate.verdict = str(data.get("verdict") or "")
        debate.confidence = float(data.get("confidence", 0.5))

    def _heuristic_judge(self, debate: Debate) -> None:
        """Cheap judge for when no LLM is available.

        Picks the stance with the longest total argument length across
        all rounds.  Confidence is 0.4 (low — heuristic).
        """
        if not debate.turns:
            debate.verdict = "no arguments presented"
            debate.confidence = 0.1
            return
        lengths: dict[DebateStance, int] = {}
        for t in debate.turns:
            lengths[t.stance] = lengths.get(t.stance, 0) + len(t.content)
        if not lengths:
            debate.verdict = "no arguments"
            debate.confidence = 0.1
            return
        winner = max(lengths, key=lengths.get)
        debate.winner = winner
        # Find the winning argument (the longest single turn from the winner).
        winning_turns = [t for t in debate.turns if t.stance == winner]
        if winning_turns:
            longest = max(winning_turns, key=lambda t: len(t.content))
            debate.winning_argument = longest.content
        debate.verdict = (
            f"Heuristic winner: {winner.value} (longest total argument length). "
            f"No LLM judge available."
        )
        debate.confidence = 0.4

    # ── Helpers ──────────────────────────────────────────────────────────

    @staticmethod
    def _extract_citations(text: str) -> list[str]:
        import re
        urls = re.findall(r"https?://[^\s)]+", text)
        bracketed = re.findall(r"\[([^\]]+)\]", text)
        return urls + bracketed

    def _participant_temperature(self) -> float:
        return (
            getattr(getattr(self.config, "debate", None),
                    "participant_temperature", 0.6)
            if self.config else 0.6
        )

    def _judge_temperature(self) -> float:
        return (
            getattr(getattr(self.config, "debate", None),
                    "judge_temperature", 0.1)
            if self.config else 0.1
        )

    def _max_argument_tokens(self) -> int:
        return (
            getattr(getattr(self.config, "debate", None),
                    "max_argument_tokens", 600)
            if self.config else 600
        )


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────


def _now():
    from datetime import datetime, timezone
    return datetime.now(timezone.utc)


__all__ = ["DefaultDebateFramework"]
