"""Consensus builder — synthesizes multiple agent outputs into a unified response."""
from __future__ import annotations

import logging
from typing import Any

log = logging.getLogger(__name__)


class ConsensusBuilder:
    """Use an LLM to synthesize multiple agent outputs into a single response."""

    def __init__(self, llm: Any) -> None:
        self.llm = llm

    async def build(
        self, question: str, outputs: list[str], agents: list[str] | None = None,
    ) -> str:
        """Synthesize multiple outputs into a single consensus response."""
        if not outputs:
            return ""
        if len(outputs) == 1:
            return outputs[0]
        agents = agents or [f"agent_{i}" for i in range(len(outputs))]
        joined = "\n\n".join(
            f"=== {agents[i]} ===\n{outputs[i]}"
            for i in range(min(len(outputs), len(agents)))
        )
        try:
            resp = await self.llm.complete(
                messages=[
                    {"role": "system", "content": (
                        "You are a consensus builder.  Multiple agents have "
                        "produced outputs for the same question.  Synthesize "
                        "them into a single, unified response that captures "
                        "the best insights from each.  Resolve contradictions "
                        "by preferring the majority view."
                    )},
                    {"role": "user", "content": (
                        f"Question: {question}\n\n"
                        f"Agent outputs:\n{joined}\n\n"
                        f"Synthesized consensus:"
                    )},
                ],
                temperature=0.3, max_tokens=1024,
            )
            return resp.text.strip()
        except Exception as e:
            log.warning("Consensus build failed: %s", e)
            # Fallback: return the longest output.
            return max(outputs, key=len)
