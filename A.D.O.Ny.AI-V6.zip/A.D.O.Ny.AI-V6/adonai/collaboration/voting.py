"""Voting system — agents vote on proposals; majority wins."""
from __future__ import annotations

import logging
from collections import Counter
from typing import Any

log = logging.getLogger(__name__)


class VotingSystem:
    """Simple majority voting across agents."""

    def __init__(self) -> None:
        self._votes: dict[str, list[tuple[str, Any, float]]] = {}

    def cast_vote(self, proposal_id: str, agent: str, vote: Any, weight: float = 1.0) -> None:
        """Cast a vote on *proposal_id*."""
        self._votes.setdefault(proposal_id, []).append((agent, vote, weight))

    def tally(self, proposal_id: str) -> dict[str, Any]:
        """Return the winning vote + breakdown."""
        votes = self._votes.get(proposal_id, [])
        if not votes:
            return {"winner": None, "votes": 0, "breakdown": {}}
        # Weighted majority on the string representation.
        counter: Counter[str] = Counter()
        breakdown: dict[str, list[str]] = {}
        for agent, vote, weight in votes:
            key = str(vote)
            counter[key] += weight
            breakdown.setdefault(key, []).append(agent)
        winner_key, weight = counter.most_common(1)[0]
        return {
            "winner": winner_key,
            "total_weight": sum(counter.values()),
            "winning_weight": weight,
            "breakdown": breakdown,
        }

    def clear(self, proposal_id: str | None = None) -> None:
        if proposal_id is None:
            self._votes.clear()
        else:
            self._votes.pop(proposal_id, None)
