"""Blackboard — shared memory bus for multi-agent collaboration.

Agents post observations/results to the blackboard; other agents read
them.  Decouples producers from consumers and enables emergent behavior.
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any

log = logging.getLogger(__name__)


class Blackboard:
    """Shared memory bus for multi-agent collaboration."""

    def __init__(self, max_entries: int = 1000) -> None:
        self._entries: list[dict[str, Any]] = []
        self._max = max_entries
        self._lock = asyncio.Lock()
        # Subscriptions: agent_name → callback
        self._subscribers: dict[str, list] = {}

    async def post(
        self, agent: str, key: str, value: Any, *, task_id: str | None = None,
    ) -> None:
        """Post an observation to the blackboard."""
        entry = {
            "agent": agent, "key": key, "value": value,
            "task_id": task_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        async with self._lock:
            self._entries.append(entry)
            if len(self._entries) > self._max:
                del self._entries[: len(self._entries) - self._max]
        # Notify subscribers.
        for callback in self._subscribers.get(key, []):
            try:
                await callback(entry)
            except Exception as e:
                log.warning("Blackboard subscriber raised: %s", e)

    async def read(
        self, key: str | None = None, task_id: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Read entries matching key and/or task_id."""
        async with self._lock:
            entries = list(self._entries)
        out = []
        for e in reversed(entries):
            if key and e["key"] != key:
                continue
            if task_id and e["task_id"] != task_id:
                continue
            out.append(e)
            if len(out) >= limit:
                break
        return out

    def subscribe(self, key: str, callback) -> None:
        """Subscribe to entries with a specific key."""
        self._subscribers.setdefault(key, []).append(callback)

    def clear(self, task_id: str | None = None) -> None:
        if task_id is None:
            self._entries.clear()
        else:
            self._entries = [e for e in self._entries if e["task_id"] != task_id]

    @property
    def size(self) -> int:
        return len(self._entries)
