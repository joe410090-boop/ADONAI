"""Unit tests for the architectural improvements (Batch 3)."""
from __future__ import annotations

import asyncio

import pytest


# ─── LLM retry policy ────────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_llm_retry_retries_transient_errors():
    from adonai.llm.retry import llm_retry
    calls = {"n": 0}

    @llm_retry(max_attempts=3, base_delay=0.01, max_delay=0.05, deadline=5.0)
    async def flaky():
        calls["n"] += 1
        if calls["n"] < 3:
            raise ConnectionError("transient")
        return "ok"

    r = await flaky()
    assert r == "ok"
    assert calls["n"] == 3


@pytest.mark.asyncio
async def test_llm_retry_does_not_retry_permanent_errors():
    from adonai.llm.retry import llm_retry
    calls = {"n": 0}

    @llm_retry(max_attempts=3, base_delay=0.01, deadline=5.0)
    async def permanent():
        calls["n"] += 1
        raise ValueError("invalid api key")

    with pytest.raises(ValueError):
        await permanent()
    assert calls["n"] == 1, "permanent error should not retry"


@pytest.mark.asyncio
async def test_llm_retry_respects_deadline():
    from adonai.llm.retry import llm_retry
    calls = {"n": 0}

    @llm_retry(max_attempts=10, base_delay=0.5, max_delay=1.0, deadline=0.3)
    async def slow_fail():
        calls["n"] += 1
        raise ConnectionError("transient")

    with pytest.raises(ConnectionError):
        await slow_fail()
    # Should have stopped early due to deadline — max 3 attempts (1 + up to 2 retries
    # before the 0.3s deadline elapses given 0.5s base delay with jitter).
    assert calls["n"] <= 3, f"deadline should have stopped retries, got {calls['n']}"


@pytest.mark.asyncio
async def test_llm_retry_does_not_swallow_cancellation():
    from adonai.llm.retry import llm_retry

    @llm_retry(max_attempts=3, base_delay=0.01, deadline=5.0)
    async def cancellable():
        raise asyncio.CancelledError()

    with pytest.raises(asyncio.CancelledError):
        await cancellable()


# ─── Dependency cycle detection ──────────────────────────────────────────────

def test_dependency_graph_detects_cycle():
    from adonai.planning.graph import DependencyGraph
    from adonai.core.models import Plan, PlanStep
    s1 = PlanStep(id="s1", description="a", tool=None); s1.dependencies = ["s3"]
    s2 = PlanStep(id="s2", description="b", tool=None); s2.dependencies = ["s1"]
    s3 = PlanStep(id="s3", description="c", tool=None); s3.dependencies = ["s2"]
    plan = Plan(task_id="t", goal="g", steps=[s1, s2, s3])
    g = DependencyGraph(plan)
    assert g.has_cycle()
    cycle = g.find_cycle()
    assert cycle is not None and len(cycle) >= 2


def test_dependency_graph_acyclic_returns_none():
    from adonai.planning.graph import DependencyGraph
    from adonai.core.models import Plan, PlanStep
    s1 = PlanStep(id="s1", description="a", tool=None)
    s2 = PlanStep(id="s2", description="b", tool=None); s2.dependencies = ["s1"]
    plan = Plan(task_id="t", goal="g", steps=[s1, s2])
    g = DependencyGraph(plan)
    assert not g.has_cycle()
    assert g.find_cycle() is None


def test_dependency_graph_topological_order():
    from adonai.planning.graph import DependencyGraph
    from adonai.core.models import Plan, PlanStep
    s1 = PlanStep(id="s1", description="a", tool=None)
    s2 = PlanStep(id="s2", description="b", tool=None); s2.dependencies = ["s1"]
    s3 = PlanStep(id="s3", description="c", tool=None); s3.dependencies = ["s2", "s1"]
    plan = Plan(task_id="t", goal="g", steps=[s3, s2, s1])  # intentionally out of order
    g = DependencyGraph(plan)
    order = g.topological_order()
    assert order.index("s1") < order.index("s2")
    assert order.index("s2") < order.index("s3")


def test_dependency_graph_topological_order_raises_on_cycle():
    from adonai.planning.graph import DependencyGraph
    from adonai.core.models import Plan, PlanStep
    s1 = PlanStep(id="s1", description="a", tool=None); s1.dependencies = ["s2"]
    s2 = PlanStep(id="s2", description="b", tool=None); s2.dependencies = ["s1"]
    plan = Plan(task_id="t", goal="g", steps=[s1, s2])
    g = DependencyGraph(plan)
    with pytest.raises(ValueError, match="cycle"):
        g.topological_order()


def test_planner_breaks_cycles_in_generated_plans():
    """The planner should detect and break cycles in LLM-generated plans."""
    import inspect
    from adonai.planning.planner import HierarchicalPlanner
    src = inspect.getsource(HierarchicalPlanner.plan)
    assert "find_cycle" in src or "DependencyGraph" in src


# ─── Verification as a gate ──────────────────────────────────────────────────

def test_reasoning_engine_zeros_confidence_on_verification_failure():
    """When verification fails, confidence must be zeroed and needs_review set."""
    import inspect
    from adonai.reasoning.engine import ReasoningEngine
    src = inspect.getsource(ReasoningEngine.reason)
    assert "needs_review" in src
    # Look for the confidence-zeroing line.
    assert 'result["confidence"] = 0.0' in src or "confidence'] = 0.0" in src


# ─── replan() uses alternative_branches ──────────────────────────────────────

def test_replan_uses_alternative_branches():
    import inspect
    from adonai.planning.planner import HierarchicalPlanner
    src = inspect.getsource(HierarchicalPlanner.replan)
    assert "alternative_branches" in src


# ─── Executive autonomy layer ────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_executive_controller_lifecycle():
    """The executive controller should start/stop cleanly."""
    from adonai.agents.executive_controller import ExecutiveController, GoalTier, GoalStatus

    class FakeRuntime:
        llm = None
        tools = None
        memory = None
        async def run(self, goal):
            from adonai.core.models import TaskResult, TaskStatus
            return TaskResult(task_id="t", status=TaskStatus.COMPLETED, output=f"did {goal}")

    ctrl = ExecutiveController(FakeRuntime(), tick_interval_s=0.05)
    await ctrl.start()
    gid = await ctrl.submit_goal("test goal", tier=GoalTier.TASK)
    assert gid in ctrl.world.goals
    # Let it tick once.
    await asyncio.sleep(0.2)
    await ctrl.stop(timeout=2.0)
    # The goal should have been processed (status changed from PENDING).
    g = ctrl.world.goals[gid]
    assert g.status != GoalStatus.PENDING or g.tier == GoalTier.TASK


def test_world_model_unblocked_pending():
    """WorldModel.unblocked_pending should respect dependencies."""
    from adonai.agents.executive_controller import WorldModel, Goal, GoalTier, GoalStatus
    wm = WorldModel()
    g1 = Goal(id="g1", title="a", tier=GoalTier.TASK)
    g2 = Goal(id="g2", title="b", tier=GoalTier.TASK, dependencies=["g1"])
    wm.add_goal(g1)
    wm.add_goal(g2)
    # g2 is blocked by g1 (which is PENDING).
    unblocked = wm.unblocked_pending()
    assert g1 in unblocked
    assert g2 not in unblocked
    # Complete g1; now g2 is unblocked.
    g1.status = GoalStatus.COMPLETED
    unblocked = wm.unblocked_pending()
    assert g2 in unblocked


# ─── Observability ───────────────────────────────────────────────────────────

def test_structured_logger_emits_json():
    import json, logging
    from adonai.observability import StructuredLogger
    slog = StructuredLogger("test.logger")
    # Capture log output.
    records: list[str] = []
    handler = logging.Handler()
    handler.emit = lambda record: records.append(record.getMessage())
    slog._logger.addHandler(handler)
    slog._logger.setLevel(logging.INFO)
    slog.info("test_event", key="value", num=42)
    assert len(records) == 1
    parsed = json.loads(records[0])
    assert parsed["event"] == "test_event"
    assert parsed["key"] == "value"
    assert parsed["num"] == 42
    assert parsed["level"] == "INFO"


def test_metrics_registry_counter():
    from adonai.observability import MetricsRegistry
    reg = MetricsRegistry()
    c = reg.counter("tasks_total", labels={"agent": "executive"})
    c.inc()
    c.inc(2)
    assert c.value == 3
    snap = reg.snapshot()
    assert any(c["name"] == "tasks_total" and c["value"] == 3 for c in snap["counters"])


def test_metrics_registry_histogram():
    from adonai.observability import MetricsRegistry
    reg = MetricsRegistry()
    h = reg.histogram("task_duration_s")
    h.observe(0.1)
    h.observe(1.5)
    h.observe(5.0)
    assert h.count == 3
    assert abs(h.sum - 6.6) < 0.001


def test_execution_tracer_records_spans():
    from adonai.observability import ExecutionTracer
    tracer = ExecutionTracer()
    span_id = tracer.start_span("test_span", root_id="root1", attr1="val1")
    tracer.add_event(span_id, "mid_event", detail="halfway")
    tracer.end_span(span_id, result="ok")
    trace = tracer.get_trace("root1")
    assert len(trace) == 1
    assert trace[0]["name"] == "test_span"
    assert trace[0]["attributes"]["attr1"] == "val1"
    assert trace[0]["end_ts"] is not None
    assert len(trace[0]["events"]) == 1
