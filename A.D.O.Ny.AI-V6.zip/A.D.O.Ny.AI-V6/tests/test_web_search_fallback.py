import asyncio
import httpx

from adonai.tools.builtin.web import WebSearchTool


class _FakeResponse:
    def __init__(self, *, text: str, status_code: int = 200):
        self.text = text
        self.status_code = status_code
        self.headers = {}

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            raise httpx.HTTPStatusError("boom", request=None, response=None)


class _FakeAsyncClient:
    def __init__(self, *args, **kwargs):
        self._responses = []

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    async def get(self, url, params=None, headers=None):
        return self._responses.pop(0)


def test_web_search_falls_back_when_duckduckgo_returns_bot_challenge(monkeypatch):
    ddg_challenge = """
    <!DOCTYPE html>
    <html><body>
    <div class="anomaly-modal__title">Unfortunately, bots use DuckDuckGo too.</div>
    <div class="anomaly-modal__description">Please complete the following challenge</div>
    </body></html>
    """
    bing_results = """
    <li class="b_algo">
      <h2><a href="https://example.com/ai-news">Example AI News</a></h2>
      <div>Latest AI breakthroughs and launches.</div>
    </li>
    <li class="b_algo">
      <h2><a href="https://example.org/ai">Another AI update</a></h2>
      <div>Second example result.</div>
    </li>
    """

    client = _FakeAsyncClient()
    client._responses = [_FakeResponse(text=ddg_challenge, status_code=202), _FakeResponse(text=bing_results, status_code=200)]

    class _Factory:
        def __init__(self, *args, **kwargs):
            self._client = client
        async def __aenter__(self):
            return self._client
        async def __aexit__(self, exc_type, exc, tb):
            return False

    monkeypatch.setattr("adonai.tools.builtin.web.httpx.AsyncClient", lambda *args, **kwargs: client)

    async def _run():
        result = await WebSearchTool().execute(query="latest AI news 2026", max_results=5)
        assert result.success is True
        assert result.output["count"] >= 1
        assert result.output["results"][0]["url"] == "https://example.com/ai-news"

    asyncio.run(_run())
