"""Integration tests for v6 OpenHuman-inspired subsystems.

Each test exercises one subsystem in isolation.  No LLM is required —
the tests use stub LLMs where needed.
"""
from __future__ import annotations

import asyncio
import os
import sys
import tempfile
from pathlib import Path

import pytest

# Ensure the project root is on sys.path.
_PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))

from adonai.config.settings import (
    AgentEconomyConfig,
    BatteriesConfig,
    GoalsTodosConfig,
    GraphHarnessConfig,
    MemoryTreeConfig,
    MeetingAgentsConfig,
    SplitBrainConfig,
    SubconsciousConfig,
    SuperContextConfig,
    TokenJuiceConfig,
    WorkflowsConfig,
)
from adonai.openhuman.memory_tree import (
    Chunk, MemoryTreeService, MemoryTreeStore, TreeNode,
)
from adonai.openhuman.subconscious import (
    ActivityEntry, SubconsciousEngine, SubconsciousTask,
)
from adonai.openhuman.goals_todos import GoalsTodosService
from adonai.openhuman.tokenjuice import TokenJuice
from adonai.openhuman.workflows import WorkflowEngine
from adonai.openhuman.graph_harness import GraphHarness
from adonai.openhuman.split_brain import SplitBrain
from adonai.openhuman.agent_economy import AgentEconomy
from adonai.openhuman.super_context import SuperContext
from adonai.openhuman.batteries import Batteries, PrivacyMode
from adonai.openhuman.meeting_agents import MeetingAgentsService, Meeting
from adonai.openhuman.subconscious_bridge import SubconsciousExecutiveBridge


# ──────────────────────────────────────────────────────────────────────────────
# Stub LLM
# ──────────────────────────────────────────────────────────────────────────────


class StubLLM:
    """A stub LLM that returns canned responses."""

    def __init__(self, response: str = "OK") -> None:
        self.response = response
        self.calls: list[str] = []

    async def complete(self, prompt: str, **kw):
        self.calls.append(prompt)
        # Return an object with a .text attribute, like the real LLM.
        class _Resp:
            text = self.response
        return _Resp()

    async def close(self) -> None:
        pass


# ──────────────────────────────────────────────────────────────────────────────
# Helpers
# ──────────────────────────────────────────────────────────────────────────────


def _tmp_path(name: str) -> Path:
    """Return a path under the system temp dir, ensuring the parent exists."""
    p = Path(tempfile.gettempdir()) / "adonai_v6_tests" / name
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


# ──────────────────────────────────────────────────────────────────────────────
# Feature 1: Memory Tree
# ──────────────────────────────────────────────────────────────────────────────


class TestMemoryTree:
    def _config(self, tmp_path: Path) -> MemoryTreeConfig:
        return MemoryTreeConfig(
            enabled=True,
            db_path=tmp_path / "mt.db",
            vault_path=tmp_path / "vault",
            mirror_interval_s=9999,  # disable background mirror
        )

    def test_ingest_and_search(self, tmp_path: Path) -> None:
        cfg = self._config(tmp_path)
        store = MemoryTreeStore(cfg)
        store.ingest(Chunk(
            id="c1", source_kind="chat", source_id="s1",
            source_authority=0.9, content="The user asked about Q3 revenue.",
            created_at=1700000000000,
        ))
        store.ingest(Chunk(
            id="c2", source_kind="email", source_id="e1",
            source_authority=0.8, content="Q3 revenue was $2.4M, up 18% YoY.",
            created_at=1700000001000,
        ))
        n = store.build_tree()
        assert n == 2, f"Expected 2 nodes, got {n}"
        hits = store.search("revenue", k=5)
        assert len(hits) >= 1
        assert any("revenue" in h.summary.lower() for h in hits)
        store.close()

    def test_mirror_to_vault(self, tmp_path: Path) -> None:
        cfg = self._config(tmp_path)
        store = MemoryTreeStore(cfg)
        store.ingest(Chunk(
            id="c1", source_kind="chat", source_id="s1",
            source_authority=0.9, content="Test content for vault mirroring.",
            created_at=1700000000000,
        ))
        store.build_tree()
        n = store.mirror_to_vault()
        assert n == 1
        files = list(cfg.vault_path.glob("*.md"))
        assert len(files) == 1
        text = files[0].read_text()
        assert "Test content" in text
        assert "score:" in text  # YAML frontmatter
        store.close()

    def test_top_entities(self, tmp_path: Path) -> None:
        cfg = self._config(tmp_path)
        store = MemoryTreeStore(cfg)
        store.ingest(Chunk(
            id="c1", source_kind="chat", source_id="s1",
            source_authority=0.9,
            content="Alice met Bob at the Eiffel Tower in Paris.",
            created_at=1700000000000,
        ))
        entities = store.top_entities(5)
        names = [e for e, _ in entities]
        assert "Alice" in names or "Bob" in names
        store.close()


# ──────────────────────────────────────────────────────────────────────────────
# Feature 2: Subconscious
# ──────────────────────────────────────────────────────────────────────────────


class TestSubconscious:
    def test_engine_starts_and_stops(self) -> None:
        cfg = SubconsciousConfig(enabled=True, tick_interval_s=9999)
        engine = SubconsciousEngine(cfg, llm=StubLLM())
        asyncio.run(engine.start())
        assert engine._running
        asyncio.run(engine.stop())
        assert not engine._running

    def test_evaluate_skip(self) -> None:
        cfg = SubconsciousConfig(enabled=True, tick_interval_s=9999)
        engine = SubconsciousEngine(cfg, llm=StubLLM("skip\nnothing new"))
        task = SubconsciousTask(id="t1", title="Test task", intent="read")
        decision, result = asyncio.run(engine._evaluate(task, "(no changes)"))
        assert decision == "skip"

    def test_evaluate_act(self) -> None:
        cfg = SubconsciousConfig(enabled=True, tick_interval_s=9999)
        engine = SubconsciousEngine(cfg, llm=StubLLM("act\nsomething changed"))
        task = SubconsciousTask(id="t1", title="Test task", intent="read")
        decision, result = asyncio.run(engine._evaluate(task, "new email arrived"))
        assert decision == "act"


# ──────────────────────────────────────────────────────────────────────────────
# Feature 3: Goals & Todos
# ──────────────────────────────────────────────────────────────────────────────


class TestGoalsTodos:
    def test_add_long_term_goal(self, tmp_path: Path) -> None:
        cfg = GoalsTodosConfig(enabled=True, db_path=tmp_path / "gt.db")
        svc = GoalsTodosService(cfg)
        g = svc.add_long_term("Ship v6 release")
        assert g.id
        assert g.scope == "long_term"
        assert g.title == "Ship v6 release"
        goals = svc.list_long_term()
        assert len(goals) == 1
        svc.close()

    def test_kanban_board(self, tmp_path: Path) -> None:
        cfg = GoalsTodosConfig(enabled=True, db_path=tmp_path / "gt.db")
        svc = GoalsTodosService(cfg)
        svc.add_kanban_card("session-1", "Task A", status="backlog")
        svc.add_kanban_card("session-1", "Task B", status="doing")
        svc.add_kanban_card("session-1", "Task C", status="done")
        board = svc.kanban_board("session-1")
        assert len(board["backlog"]) == 1
        assert len(board["doing"]) == 1
        assert len(board["done"]) == 1
        svc.close()

    def test_per_thread_promotion(self, tmp_path: Path) -> None:
        cfg = GoalsTodosConfig(
            enabled=True, db_path=tmp_path / "gt.db",
            promote_to_long_term_after_turns=2,
        )
        svc = GoalsTodosService(cfg)
        svc.add_per_thread("sess-1", "Investigate bug")
        svc.bump_turn("sess-1")
        promoted = svc.bump_turn("sess-1")
        assert len(promoted) == 1
        assert promoted[0].scope == "long_term"
        svc.close()


# ──────────────────────────────────────────────────────────────────────────────
# Feature 4: TokenJuice
# ──────────────────────────────────────────────────────────────────────────────


class TestTokenJuice:
    def test_passthrough_for_short_inputs(self) -> None:
        cfg = TokenJuiceConfig(enabled=True, min_tokens_to_compress=256)
        tj = TokenJuice(cfg)
        short = "Hello, world."
        assert tj.compress(short) == short

    def test_extractive_compression(self) -> None:
        cfg = TokenJuiceConfig(
            enabled=True, strategy="extractive",
            min_tokens_to_compress=10, target_ratio=0.3,
            max_output_tokens=500, cache_enabled=False,
        )
        tj = TokenJuice(cfg)
        long_text = (
            "The quick brown fox jumps over the lazy dog. "
            "This is a long sentence about foxes and dogs. "
            "Another sentence about weather patterns. "
            "Yet another about machine learning models. "
            "And one more about distributed systems."
        ) * 10
        compressed = tj.compress(long_text)
        assert len(compressed) < len(long_text)
        stats = tj.stats_snapshot()
        assert stats["total_inputs"] >= 1

    def test_cache_hit(self) -> None:
        cfg = TokenJuiceConfig(
            enabled=True, strategy="extractive",
            min_tokens_to_compress=10, target_ratio=0.3,
            cache_enabled=True,
        )
        tj = TokenJuice(cfg)
        long_text = "Sentence one. Sentence two. " * 50
        out1 = tj.compress(long_text)
        out2 = tj.compress(long_text)
        assert out1 == out2
        stats = tj.stats_snapshot()
        assert stats["total_cache_hits"] >= 1


# ──────────────────────────────────────────────────────────────────────────────
# Feature 5: Workflows
# ──────────────────────────────────────────────────────────────────────────────


class TestWorkflows:
    def test_propose_validates_graph(self, tmp_path: Path) -> None:
        cfg = WorkflowsConfig(enabled=True, db_path=tmp_path / "wf.db")
        engine = WorkflowEngine(cfg)
        # Invalid: no trigger.
        proposal = engine.propose_workflow(
            "test", "desc",
            {"nodes": {"n1": {"id": "n1", "kind": "agent", "next": []}}},
        )
        assert not proposal["valid"]
        # Valid: one trigger.
        proposal = engine.propose_workflow(
            "test", "desc",
            {"nodes": {
                "t": {"id": "t", "kind": "trigger", "next": ["n1"]},
                "n1": {"id": "n1", "kind": "agent", "next": []},
            }},
        )
        assert proposal["valid"]
        # Clean up the store (stop() is async; we only need to close the DB).
        engine.store.close()

    def test_save_and_list(self, tmp_path: Path) -> None:
        cfg = WorkflowsConfig(enabled=True, db_path=tmp_path / "wf.db")
        engine = WorkflowEngine(cfg)
        wf = engine.save_workflow(
            "My Flow", "A test flow",
            {"nodes": {
                "t": {"id": "t", "kind": "trigger", "next": ["n1"]},
                "n1": {"id": "n1", "kind": "agent", "next": []},
            }},
            enabled=True,
        )
        assert wf.id
        flows = engine.store.list_workflows()
        assert len(flows) == 1
        assert flows[0].name == "My Flow"
        engine.store.close()


# ──────────────────────────────────────────────────────────────────────────────
# Feature 6: Graph Harness
# ──────────────────────────────────────────────────────────────────────────────


class TestGraphHarness:
    def test_build_default_graph(self) -> None:
        cfg = GraphHarnessConfig(enabled=True)
        harness = GraphHarness(cfg)
        graph = harness.build_default_graph("test goal")
        assert "plan" in graph
        assert "execute" in graph
        assert "review" in graph
        assert "finalize" in graph
        harness.close()

    def test_run_with_no_runtime(self) -> None:
        cfg = GraphHarnessConfig(enabled=True)
        harness = GraphHarness(cfg, runtime=None)
        run = asyncio.run(harness.run("test goal", max_steps=2))
        assert run.status in ("completed", "failed", "incomplete")
        assert len(run.steps) > 0
        harness.close()

    def test_journal_persists(self, tmp_path: Path) -> None:
        cfg = GraphHarnessConfig(
            enabled=True,
            cost_db_path=tmp_path / "costs.db",
        )
        harness = GraphHarness(cfg)
        run = asyncio.run(harness.run("test goal", max_steps=1))
        replay = harness.replay(run.id)
        assert replay is not None
        assert replay["run"]["id"] == run.id
        harness.close()


# ──────────────────────────────────────────────────────────────────────────────
# Feature 7: Split Brain
# ──────────────────────────────────────────────────────────────────────────────


class TestSplitBrain:
    def test_triage_no_llm_hands_to_deep(self) -> None:
        cfg = SplitBrainConfig(enabled=True)
        sb = SplitBrain(cfg, reflex_llm=None, deep_llm=None, deep_runtime=None)
        result = asyncio.run(sb.triage("complex question"))
        assert result.verdict == "hand_to_deep"

    def test_history_compressor(self) -> None:
        from adonai.openhuman.split_brain import HistoryCompressor
        hc = HistoryCompressor(ratio=2)
        for i in range(10):
            hc.add({"role": "user", "content": f"message {i}"})
        ctx = hc.get_context(max_tokens=4096)
        assert "message" in ctx

    def test_steering_directive(self) -> None:
        cfg = SplitBrainConfig(enabled=True)
        sb = SplitBrain(cfg, reflex_llm=None, deep_llm=None)
        sb.set_directive("Focus on security review")
        assert sb._directive is not None
        assert "security" in sb._directive.text


# ──────────────────────────────────────────────────────────────────────────────
# Feature 8: Agent Economy
# ──────────────────────────────────────────────────────────────────────────────


class TestAgentEconomy:
    def test_start_stop(self) -> None:
        cfg = AgentEconomyConfig(enabled=True, handle="adonai@tiny.place")
        ae = AgentEconomy(cfg)
        asyncio.run(ae.start())
        assert ae.handle is not None
        assert ae.handle.handle == "adonai@tiny.place"
        asyncio.run(ae.stop())
        assert ae.handle is None

    def test_pairing_fails_closed_without_consent(self) -> None:
        cfg = AgentEconomyConfig(enabled=True, handle="a@tiny.place",
                                 require_pairing_consent=True)
        ae = AgentEconomy(cfg)
        asyncio.run(ae.start())
        # No approval callback → pairing should be rejected (fails closed).
        pairing = asyncio.run(ae.request_pairing("peer@tiny.place"))
        assert pairing.state == "unpaired"
        asyncio.run(ae.stop())

    def test_pairing_with_consent(self) -> None:
        cfg = AgentEconomyConfig(enabled=True, handle="a@tiny.place",
                                 require_pairing_consent=True)
        ae = AgentEconomy(cfg)
        ae._approval_callback = lambda action, ctx: True
        asyncio.run(ae.start())
        pairing = asyncio.run(ae.request_pairing("peer@tiny.place"))
        assert pairing.state == "paired"
        asyncio.run(ae.stop())


# ──────────────────────────────────────────────────────────────────────────────
# Feature 9: SuperContext
# ──────────────────────────────────────────────────────────────────────────────


class TestSuperContext:
    def test_sweep_no_deps(self) -> None:
        cfg = SuperContextConfig(enabled=True, max_sweep_s=1.0)
        sc = SuperContext(cfg, memory_tree=None, workspace_root=None)
        pack = asyncio.run(sc.sweep("hello world"))
        assert pack.elapsed_ms < 2000
        assert isinstance(pack.to_prompt(), str)

    def test_inject(self) -> None:
        cfg = SuperContextConfig(enabled=True)
        sc = SuperContext(cfg)
        pack = asyncio.run(sc.sweep("test"))
        result = sc.inject("user message", pack)
        assert "user message" in result


# ──────────────────────────────────────────────────────────────────────────────
# Feature 10: Batteries
# ──────────────────────────────────────────────────────────────────────────────


class TestBatteries:
    def test_privacy_mode_default_off(self) -> None:
        cfg = BatteriesConfig()
        b = Batteries(cfg)
        assert not b.privacy_mode.enabled

    def test_privacy_mode_enable(self) -> None:
        cfg = BatteriesConfig()
        b = Batteries(cfg)
        b.privacy_mode.enable()
        assert b.privacy_mode.enabled
        assert b.privacy_mode.check_backend("ollama")
        assert not b.privacy_mode.check_backend("openai")

    def test_model_router_extensions(self) -> None:
        cfg = BatteriesConfig()
        b = Batteries(cfg)
        assert b.router_ext.route("chat") == "small"
        assert b.router_ext.route("reasoning") == "large"


# ──────────────────────────────────────────────────────────────────────────────
# Feature 11: Meeting Agents
# ──────────────────────────────────────────────────────────────────────────────


class TestMeetingAgents:
    def test_schedule_and_list(self) -> None:
        cfg = MeetingAgentsConfig(enabled=True)
        svc = MeetingAgentsService(cfg, llm=None)
        m = Meeting(
            id="m1", platform="meet", url="https://meet.google.com/abc",
            title="Standup", start_at=1700000000000,
        )
        svc.schedule_meeting(m)
        meetings = svc.list_meetings()
        assert len(meetings) == 1
        assert meetings[0].title == "Standup"

    def test_status(self) -> None:
        cfg = MeetingAgentsConfig(enabled=True)
        svc = MeetingAgentsService(cfg, llm=None)
        status = svc.status()
        assert status["enabled"]
        assert status["scheduled"] == 0


# ──────────────────────────────────────────────────────────────────────────────
# Feature 12: Subconscious → Executive Bridge
# ──────────────────────────────────────────────────────────────────────────────


class TestSubconsciousBridge:
    def test_journal_roundtrip(self, tmp_path: Path) -> None:
        from adonai.openhuman.subconscious_bridge import BridgeJournal, BridgeEntry
        j = BridgeJournal(str(tmp_path / "bridge.db"))
        entry = BridgeEntry(
            id="b1", goal="test goal", tainted=False,
            submitted_at=1700000000000,
        )
        j.add(entry)
        j.update("b1", task_id="t1", status="running")
        recent = j.recent()
        assert len(recent) == 1
        assert recent[0]["task_id"] == "t1"
        j.close()

    def test_bridge_submission_no_runtime(self, tmp_path: Path) -> None:
        cfg = SubconsciousConfig(enabled=True, bridge_to_executive=True)
        bridge = SubconsciousExecutiveBridge(cfg, runtime=None)
        # Override the journal to use a tmp path so the test is isolated.
        bridge.journal.close()
        from adonai.openhuman.subconscious_bridge import BridgeJournal
        bridge.journal = BridgeJournal(str(tmp_path / "bridge.db"))
        # Should fail gracefully and record the error.
        result = asyncio.run(bridge("test goal", {"tainted": False}))
        assert result  # returns the entry id even on failure
        recent = bridge.recent()
        assert len(recent) == 1
        assert recent[0]["status"] == "failed"
        bridge.close()
