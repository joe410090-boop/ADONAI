"""Unit tests for the CRITICAL bug fixes (Batch 1).

Each test corresponds to a CRITICAL finding from the Phase 1 audit.
"""
from __future__ import annotations

import asyncio
import inspect
import uuid

import pytest

from adonai.core.models import TaskResult, TaskStatus


# ─── CRITICAL-02: TaskResult.tool_calls defaults to None ─────────────────────

def test_task_result_tool_calls_defaults_to_empty_list():
    """CRITICAL-02: tool_calls must be [] not None, so iteration doesn't crash."""
    tr = TaskResult(task_id=str(uuid.uuid4()), status=TaskStatus.COMPLETED, output="x")
    assert tr.tool_calls == [], f"expected [], got {tr.tool_calls!r}"
    # The original bug: `for tc in result.tool_calls` crashed with TypeError.
    assert hasattr(tr.tool_calls, "__iter__")
    assert list(tr.tool_calls) == []


def test_task_result_tool_calls_is_per_instance():
    """Each TaskResult gets its own list (no shared mutable default)."""
    a = TaskResult(task_id="a", status=TaskStatus.COMPLETED, output="x")
    b = TaskResult(task_id="b", status=TaskStatus.COMPLETED, output="y")
    a.tool_calls.append.__self__  # just check it's a real list
    assert a.tool_calls is not b.tool_calls


# Note: test_enhanced_planner_uses_correct_arg_count removed in v5 —
# EnhancedPlanner was dead code (never imported by runtime, duplicated
# by TreeOfThoughtPlanner) and has been deleted.


# ─── CRITICAL-04: Chroma indexing ────────────────────────────────────────────

def test_chroma_to_memory_handles_flat_and_nested_shapes():
    """CRITICAL-04: _chroma_to_memory was using [0][idx] indexing which
    broke on ChromaDB's flat-list shape from .get()."""
    import time as _time
    from adonai.memory.chroma_store import _chroma_to_memory
    ts = _time.time()
    # Flat shape (from .get())
    flat = {
        "ids": ["m1", "m2"],
        "metadatas": [{"type": "semantic", "metadata_json": "{}", "created_at": ts},
                       {"type": "episodic", "metadata_json": "{}", "created_at": ts}],
        "documents": ["hello", "world"],
        "embeddings": [[0.1, 0.2], [0.3, 0.4]],
    }
    m1 = _chroma_to_memory("m1", flat)
    assert m1.id == "m1"
    assert m1.content == "hello"
    assert m1.embedding == [0.1, 0.2]
    m2 = _chroma_to_memory("m2", flat)
    assert m2.id == "m2"
    assert m2.content == "world"
    assert m2.embedding == [0.3, 0.4]


# ─── CRITICAL-03: search("*") wildcard bug ───────────────────────────────────

@pytest.mark.asyncio
async def test_sqlite_search_wildcard_returns_all(tmp_path):
    """CRITICAL-03: search('*') was compiling to LIKE '%*%' and matching
    only memories containing a literal asterisk. Now it returns all."""
    from adonai.memory.sqlite_store import SQLiteMemoryStore
    from adonai.core.models import Memory, MemoryType
    store = SQLiteMemoryStore(db_path=tmp_path / "mem.db", table_name="episodic")
    # Add three memories, none containing '*'
    for i, content in enumerate(["alpha", "beta", "gamma"]):
        await store.add(Memory(
            id=f"m{i}", type=MemoryType.EPISODIC, content=content,
            importance=0.5,
        ))
    # search("*") should return all 3, not 0.
    results = await store.search("*", top_k=100)
    assert len(results) == 3, f"expected 3, got {len(results)}"
    # search_all should also work.
    results2 = await store.search_all(top_k=100)
    assert len(results2) == 3


# ─── CRITICAL-06: VerificationGate workspace ─────────────────────────────────

def test_executor_passes_workspace_to_verify():
    """CRITICAL-06: executor was calling verify() without workspace=,
    so FILE_EXISTS checks always used CWD instead of the sandbox."""
    from adonai.executors.executor import TaskExecutor
    src = inspect.getsource(TaskExecutor.execute)
    assert "workspace=self.workspace" in src, \
        "executor should pass workspace=self.workspace to verify()"


def test_config_has_workspace_field():
    """CRITICAL-06: Config had no workspace attribute; now it does."""
    from adonai.config.settings import Config
    c = Config()
    assert hasattr(c, "workspace")
    assert isinstance(c.workspace, str)


# ─── CRITICAL-21: runtime.shutdown() calls container.shutdown() ──────────────

def test_runtime_shutdown_calls_container_shutdown():
    """CRITICAL-21: shutdown() was leaking 10+ subsystems."""
    from adonai.runtime import ADONAI
    src = inspect.getsource(ADONAI.shutdown)
    assert "container.shutdown" in src, "should call container.shutdown()"


# ─── CRITICAL-22: runtime.start() is concurrency-safe ────────────────────────

def test_runtime_start_uses_lock():
    """CRITICAL-22: start() was not idempotent across concurrent calls."""
    from adonai.runtime import ADONAI
    src = inspect.getsource(ADONAI.start)
    assert "_start_lock" in src, "should use _start_lock"


# ─── CRITICAL-09: executor no longer auto-fills terminal.command from goal ───

def test_executor_does_not_autofill_terminal_command():
    """CRITICAL-09: executor was running task.goal as a shell command."""
    from adonai.executors.executor import TaskExecutor
    src = inspect.getsource(TaskExecutor._execute_step)
    assert 'params["command"] = task.goal' not in src, \
        "should NOT auto-fill terminal.command from task.goal"
    assert "refuses auto-fill" in src or "auto-fill" in src, \
        "should document the safety refusal"


# ─── Mutable class defaults (HIGH) ───────────────────────────────────────────

def test_tool_subclasses_isolate_mutable_defaults():
    """Tool.parameters and Tool.tags should not be shared across subclasses."""
    from adonai.core.interfaces import Tool
    from adonai.core.models import ToolResult

    class ToolA(Tool):
        name = "a"
        parameters = {"x": 1}
        tags = ["t1"]
        async def execute(self, **params):
            return ToolResult(call_id="c", tool="a", success=True)

    class ToolB(Tool):
        name = "b"
        parameters = {"y": 2}
        tags = ["t2"]
        async def execute(self, **params):
            return ToolResult(call_id="c", tool="b", success=True)

    # Modifying ToolA's parameters shouldn't affect ToolB.
    ToolA.parameters["x"] = 999
    assert ToolB.parameters == {"y": 2}, f"ToolB polluted: {ToolB.parameters}"
