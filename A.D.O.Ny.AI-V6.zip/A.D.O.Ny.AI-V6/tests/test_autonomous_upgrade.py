"""Tests for the autonomous-agent upgrade (Batch 6).

Covers all the new features added in the production-upgrade pass:
  * GoalStore (Section 5) — goal persistence + recovery
  * Procedural memory (Section 3) — MemoryType.PROCEDURAL + skill→memory wiring
  * Rate limiting middleware (Section 8) — enforce rate_limit_per_minute
  * Human approval gates (Section 8) — PermissionPolicy.check_async + /approvals
  * Graph of Thought (Section 2) — non-linear reasoning
  * Reasoning cache (Section 2) — memoise reasoning results
  * Prompt optimizer (Section 4) — auto-tune system prompts
  * Benchmark runner (Section 4) — track performance over time
  * Prometheus metrics endpoint (Section 11) — /metrics/prometheus
  * Batched embeddings (Section 12) — concurrent embed calls
  * Watchdog timer (Section 7) — detect + cancel hung tasks
"""
from __future__ import annotations

import asyncio
import inspect
import os
import sqlite3
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest


# ─── Section 5: GoalStore — goal persistence ────────────────────────────────

def test_goal_store_persists_and_loads_goals(tmp_path):
    """GoalStore must save + load Goal objects round-trip."""
    from adonai.agents.executive_controller import (
        GoalStore, Goal, GoalTier, GoalStatus,
    )
    store = GoalStore(tmp_path / "goals.db")
    g = Goal(
        id="g_test1", title="Test Goal", description="A test",
        tier=GoalTier.GOAL, status=GoalStatus.PENDING, priority=3,
        confidence=0.7, deadline=1234567890.0,
        lessons=["lesson1", "lesson2"],
        metadata={"key": "value"},
    )
    store.save(g)
    # Load all — should include our goal.
    loaded = store.load_all()
    assert len(loaded) == 1
    assert loaded[0].id == "g_test1"
    assert loaded[0].title == "Test Goal"
    assert loaded[0].tier == GoalTier.GOAL
    assert loaded[0].status == GoalStatus.PENDING
    assert loaded[0].priority == 3
    assert loaded[0].confidence == 0.7
    assert loaded[0].deadline == 1234567890.0
    assert loaded[0].lessons == ["lesson1", "lesson2"]
    assert loaded[0].metadata == {"key": "value"}
    store.close()


def test_goal_store_upserts_on_save(tmp_path):
    """Saving the same goal ID twice should update, not duplicate."""
    from adonai.agents.executive_controller import (
        GoalStore, Goal, GoalTier, GoalStatus,
    )
    store = GoalStore(tmp_path / "goals.db")
    g = Goal(id="g_test2", title="Original", tier=GoalTier.GOAL)
    store.save(g)
    g.title = "Updated"
    g.status = GoalStatus.COMPLETED
    store.save(g)
    loaded = store.load_all()
    assert len(loaded) == 1
    assert loaded[0].title == "Updated"
    assert loaded[0].status == GoalStatus.COMPLETED
    store.close()


def test_goal_store_delete(tmp_path):
    from adonai.agents.executive_controller import GoalStore, Goal, GoalTier
    store = GoalStore(tmp_path / "goals.db")
    g = Goal(id="g_del", title="To Delete", tier=GoalTier.GOAL)
    store.save(g)
    assert store.delete("g_del") is True
    assert store.load_all() == []
    # Deleting non-existent returns False.
    assert store.delete("g_del") is False
    store.close()


def test_executive_controller_accepts_goal_store(tmp_path):
    """ExecutiveController must accept goal_store= kwarg."""
    from adonai.agents.executive_controller import (
        ExecutiveController, GoalStore,
    )
    store = GoalStore(tmp_path / "goals.db")
    ctrl = ExecutiveController(
        runtime=MagicMock(), goal_store=store,
    )
    assert ctrl._store is store
    store.close()


@pytest.mark.asyncio
async def test_executive_controller_loads_goals_on_start(tmp_path):
    """start() must load persisted goals from the store."""
    from adonai.agents.executive_controller import (
        ExecutiveController, GoalStore, Goal, GoalTier,
    )
    store = GoalStore(tmp_path / "goals.db")
    # Pre-populate with a goal.
    store.save(Goal(id="g_pre", title="Pre-existing", tier=GoalTier.TASK))
    ctrl = ExecutiveController(
        runtime=MagicMock(), goal_store=store, tick_interval_s=100,
    )
    # Mock the runtime's tools attribute (start() calls list_tools).
    ctrl.runtime.tools = MagicMock()
    ctrl.runtime.tools.list_tools = AsyncMock(return_value=[])
    await ctrl.start()
    try:
        assert "g_pre" in ctrl.world.goals
        assert ctrl.world.goals["g_pre"].title == "Pre-existing"
    finally:
        await ctrl.stop()
        store.close()


# ─── Section 3: Procedural memory ───────────────────────────────────────────

def test_memory_type_procedural_exists():
    from adonai.core.models import MemoryType
    assert hasattr(MemoryType, "PROCEDURAL")
    assert MemoryType.PROCEDURAL.value == "procedural"


def test_memory_manager_routes_procedural_to_procedural_store(tmp_path):
    """MemoryManager._route must send PROCEDURAL memories to the procedural store."""
    from adonai.memory.manager import MemoryManager
    from adonai.config.settings import Config
    from adonai.core.models import MemoryType
    config = Config()
    config.memory.sqlite_path = tmp_path / "mem.db"
    mgr = MemoryManager(config=config, llm=MagicMock())
    # Set up a mock procedural store.
    mock_procedural = MagicMock()
    mgr.procedural = mock_procedural
    assert mgr._route(MemoryType.PROCEDURAL) is mock_procedural


def test_build_memory_manager_creates_procedural_store(tmp_path):
    from adonai.memory.manager import build_memory_manager
    from adonai.config.settings import Config
    config = Config()
    config.memory.sqlite_path = tmp_path / "mem.db"
    config.memory.chroma_path = tmp_path / "chroma"
    config.memory.use_chroma = False
    config.memory.use_knowledge_graph = False
    mgr = build_memory_manager(config, MagicMock())
    assert mgr.procedural is not None
    assert mgr.procedural.table_name == "memories_procedural"


def test_skill_evolver_accepts_memory_manager():
    """DefaultSkillEvolver must accept memory_manager= kwarg."""
    from adonai.skills.evolution import DefaultSkillEvolver
    sig = inspect.signature(DefaultSkillEvolver.__init__)
    assert "memory_manager" in sig.parameters


@pytest.mark.asyncio
async def test_skill_evolver_writes_procedural_memory_on_promote(tmp_path):
    """promote_to_tool() must write a PROCEDURAL memory entry."""
    from adonai.skills.evolution import DefaultSkillEvolver
    from adonai.core.models import Skill, PlanStep
    from adonai.tools.registry import ToolRegistry
    from adonai.tools.permissions import PermissionPolicy
    from adonai.config.settings import Config

    config = Config()
    # Set up a real tool registry.
    policy = PermissionPolicy(config.safety)
    tools = ToolRegistry(permission_policy=policy)
    # Mock memory manager.
    mock_memory = MagicMock()
    mock_memory.add = AsyncMock()
    # Mock skill manager.
    mock_skills = MagicMock()
    mock_skills.store = MagicMock()
    mock_skills.store.save = AsyncMock()
    evolver = DefaultSkillEvolver(
        llm=MagicMock(), skill_manager=mock_skills,
        tool_registry=tools, config=config, memory_manager=mock_memory,
    )
    # Create a skill with a procedure (uses PlanStep, not SkillStep).
    skill = Skill(
        id="s_test", name="test_procedure",
        description="A test procedure",
        trigger_patterns=["test"],
        procedure=[PlanStep(id="ps1", description="search", tool="web_search")],
    )
    tool_name = await evolver.promote_to_tool(skill)
    assert tool_name.startswith("skill.")
    # Verify the procedural memory was written.
    mock_memory.add.assert_called_once()
    args = mock_memory.add.call_args[0]
    mem = args[0]
    assert mem.type.value == "procedural"
    assert "test_procedure" in mem.content
    assert mem.importance == 0.9


# ─── Section 8: Rate limiting ───────────────────────────────────────────────

def test_rate_limit_middleware_is_registered():
    """server.py must register a rate-limit middleware."""
    from adonai.api.server import create_app
    from adonai.config.settings import load_config
    config = load_config()
    config.analytics.enabled = False
    config.mcp.enabled = False
    app = create_app(config=config)
    # The middleware should be present.
    src = inspect.getsource(create_app)
    assert "_rate_limit_middleware" in src


@pytest.mark.asyncio
async def test_rate_limit_returns_429_when_exceeded():
    """When rate_limit_per_minute is 1, the 2nd request should 429."""
    from fastapi.testclient import TestClient
    from adonai.api.server import create_app
    from adonai.config.settings import load_config
    config = load_config()
    config.api.rate_limit_per_minute = 1  # very low limit
    config.analytics.enabled = False
    config.mcp.enabled = False
    app = create_app(config=config)
    with TestClient(app) as client:
        # First request should succeed (200).
        r1 = client.get("/introspect")
        assert r1.status_code == 200
        # Second request from same IP should be rate-limited (429).
        r2 = client.get("/introspect")
        assert r2.status_code == 429
        assert "rate limit" in r2.json().get("detail", "").lower()


# ─── Section 8: Human approval gates ────────────────────────────────────────

def test_permission_policy_has_check_async():
    from adonai.tools.permissions import PermissionPolicy
    assert hasattr(PermissionPolicy, "check_async")


def test_permission_policy_has_set_approval_callback():
    from adonai.tools.permissions import PermissionPolicy
    assert hasattr(PermissionPolicy, "set_approval_callback")


@pytest.mark.asyncio
async def test_approval_callback_invoked_for_high_risk_tools():
    """When require_approval=True and a callback is registered, high-risk
    tools must trigger the callback."""
    from adonai.tools.permissions import PermissionPolicy
    from adonai.config.settings import SafetyConfig
    from adonai.core.interfaces import Tool
    config = SafetyConfig(require_approval=True)
    policy = PermissionPolicy(config)
    # Register a callback.
    callback_invoked = []
    async def cb(name, params):
        callback_invoked.append((name, params))
        return True, "approved"
    policy.set_approval_callback(cb)
    # Mock high-risk tool.
    mock_tool = MagicMock(spec=Tool)
    mock_tool.risk_level = "high"
    allowed, reason = await policy.check_async("terminal", mock_tool, {"command": "ls"})
    assert allowed is True
    assert len(callback_invoked) == 1
    assert callback_invoked[0][0] == "terminal"


@pytest.mark.asyncio
async def test_approval_callback_fail_closed_when_no_callback():
    """When require_approval=True but no callback is registered, high-risk
    tools must be REJECTED (fail-closed)."""
    from adonai.tools.permissions import PermissionPolicy
    from adonai.config.settings import SafetyConfig
    from adonai.core.interfaces import Tool
    config = SafetyConfig(require_approval=True)
    policy = PermissionPolicy(config)
    mock_tool = MagicMock(spec=Tool)
    mock_tool.risk_level = "high"
    allowed, reason = await policy.check_async("terminal", mock_tool, {})
    assert allowed is False
    assert "fail-closed" in reason or "no approval" in reason.lower()


def test_approvals_endpoints_registered():
    from adonai.api.server import create_app
    from adonai.config.settings import load_config
    config = load_config()
    config.analytics.enabled = False
    config.mcp.enabled = False
    app = create_app(config=config)
    routes = {r.path for r in app.routes}
    assert "/approvals" in routes
    assert "/approvals/{approval_id}/decision" in routes


# ─── Section 2: Graph of Thought ────────────────────────────────────────────

def test_graph_of_thought_importable():
    from adonai.reasoning.graph_of_thought import (
        GraphOfThoughtReasoner, ThoughtGraph, Thought,
    )
    assert GraphOfThoughtReasoner.name == "graph_of_thought"


def test_thought_graph_best_path():
    from adonai.reasoning.graph_of_thought import ThoughtGraph, Thought
    g = ThoughtGraph()
    g.add(Thought(id="a", content="root", score=0.5, generation=0))
    g.add(Thought(id="b", content="child1", parents=["a"], score=0.8, generation=1))
    g.add(Thought(id="c", content="child2", parents=["a"], score=0.6, generation=1))
    path = g.best_path()
    assert len(path) == 2
    assert path[0].id == "a"
    assert path[1].id == "b"  # higher score


def test_thought_graph_merge_supports_multiple_parents():
    from adonai.reasoning.graph_of_thought import ThoughtGraph, Thought
    g = ThoughtGraph()
    g.add(Thought(id="a", content="root1", score=0.5))
    g.add(Thought(id="b", content="root2", score=0.6))
    # A child with TWO parents (merge).
    g.add(Thought(id="c", content="merged", parents=["a", "b"], score=0.9))
    c = g.get("c")
    assert set(c.parents) == {"a", "b"}
    assert "c" in g.get("a").children
    assert "c" in g.get("b").children


def test_reasoning_engine_registers_got_strategy():
    from adonai.reasoning.engine import ReasoningEngine
    src = inspect.getsource(ReasoningEngine.__init__)
    assert "graph_of_thought" in src
    assert "GraphOfThoughtReasoner" in src


# ─── Section 2: Reasoning cache ─────────────────────────────────────────────

def test_reasoning_cache_get_miss_returns_none():
    from adonai.reasoning.cache import ReasoningCache
    cache = ReasoningCache()
    assert cache.get("unique question", "cot") is None


def test_reasoning_cache_put_then_get():
    from adonai.reasoning.cache import ReasoningCache
    cache = ReasoningCache()
    result = {"conclusion": "42", "confidence": 0.9}
    cache.put("What is 6*7?", "cot", result)
    got = cache.get("What is 6*7?", "cot")
    assert got is not None
    assert got["conclusion"] == "42"


def test_reasoning_cache_near_duplicate_detection():
    """Near-duplicate queries should hit the cache via Jaccard similarity."""
    from adonai.reasoning.cache import ReasoningCache
    cache = ReasoningCache(similarity_threshold=0.6)
    cache.put("latest AI news 2026", "cot", {"conclusion": "test"})
    # Paraphrase — should hit.
    got = cache.get("recent AI news 2026", "cot")
    assert got is not None
    assert got["conclusion"] == "test"


def test_reasoning_cache_lru_eviction():
    """Cache must evict oldest entries when full."""
    from adonai.reasoning.cache import ReasoningCache
    cache = ReasoningCache(max_entries=3)
    for i in range(5):
        cache.put(f"question {i}", "cot", {"i": i})
    # Only the last 3 should be cached.
    assert cache.get("question 0", "cot") is None
    assert cache.get("question 1", "cot") is None
    assert cache.get("question 4", "cot") is not None


def test_reasoning_engine_has_cache():
    from adonai.reasoning.engine import ReasoningEngine
    src = inspect.getsource(ReasoningEngine.__init__)
    assert "ReasoningCache" in src
    assert "self.cache" in src


# ─── Section 4: Prompt optimizer ────────────────────────────────────────────

def test_prompt_optimizer_importable():
    from adonai.learning.prompt_optimizer import (
        PromptOptimizer, PromptVariant,
    )
    assert PromptVariant is not None


def test_prompt_optimizer_current_prompt_starts_none():
    from adonai.learning.prompt_optimizer import PromptOptimizer
    opt = PromptOptimizer(llm=MagicMock())
    assert opt.current_prompt is None


def test_prompt_optimizer_record_outcome_updates_score():
    from adonai.learning.prompt_optimizer import PromptOptimizer, PromptVariant
    opt = PromptOptimizer(llm=MagicMock())
    v = PromptVariant(id="v1", prompt="test")
    opt.record_outcome(v, success=True, confidence=0.9)
    assert v.sample_count == 1
    assert v.success_count == 1
    assert v.mean_confidence == 0.9
    assert v.score == 0.9  # 1.0 success_rate * 0.9 confidence


def test_prompt_optimizer_maybe_promote_first_variant():
    from adonai.learning.prompt_optimizer import PromptOptimizer, PromptVariant
    opt = PromptOptimizer(llm=MagicMock())
    v = PromptVariant(id="v1", prompt="test", score=0.5)
    assert opt.maybe_promote(v) is True
    assert opt.current_prompt == "test"


def test_prompt_optimizer_does_not_promote_without_margin():
    from adonai.learning.prompt_optimizer import PromptOptimizer, PromptVariant
    opt = PromptOptimizer(
        llm=MagicMock(), promotion_margin=0.1,
    )
    current = PromptVariant(id="v1", prompt="old", score=0.8)
    opt.maybe_promote(current)
    # Candidate scores only 0.85 — needs 0.8 + 0.1 = 0.9 to promote.
    candidate = PromptVariant(id="v2", prompt="new", score=0.85)
    assert opt.maybe_promote(candidate) is False
    assert opt.current_prompt == "old"


# ─── Section 4: Benchmark runner ────────────────────────────────────────────

def test_benchmark_runner_importable():
    from adonai.learning.benchmark import (
        BenchmarkRunner, BenchmarkTask, BenchmarkResult, DEFAULT_BENCHMARKS,
    )
    assert len(DEFAULT_BENCHMARKS) >= 4


def test_benchmark_runner_summary_empty(tmp_path):
    from adonai.learning.benchmark import BenchmarkRunner
    runner = BenchmarkRunner(db_path=tmp_path / "bench.db")
    s = runner.summary()
    assert s["total_runs"] == 0


@pytest.mark.asyncio
async def test_benchmark_runner_run_one(tmp_path):
    from adonai.learning.benchmark import BenchmarkRunner, BenchmarkTask
    runner = BenchmarkRunner(db_path=tmp_path / "bench.db")
    bench = BenchmarkTask(
        id="test", goal="hello",
        expected_keywords=["hello"], timeout_s=5.0,
    )
    # Mock runtime.
    mock_runtime = MagicMock()
    mock_runtime.chat = AsyncMock(return_value="hello world")
    result = await runner.run_one(bench, mock_runtime)
    assert result.success is True
    assert result.keyword_coverage == 1.0


# ─── Section 11: Prometheus metrics ─────────────────────────────────────────

def test_prometheus_endpoint_registered():
    from adonai.api.server import create_app
    from adonai.config.settings import load_config
    config = load_config()
    config.analytics.enabled = False
    config.mcp.enabled = False
    app = create_app(config=config)
    routes = {r.path for r in app.routes}
    assert "/metrics/prometheus" in routes


def test_prometheus_endpoint_returns_text():
    from fastapi.testclient import TestClient
    from adonai.api.server import create_app
    from adonai.config.settings import load_config
    config = load_config()
    config.analytics.enabled = False
    config.mcp.enabled = False
    app = create_app(config=config)
    with TestClient(app) as client:
        r = client.get("/metrics/prometheus")
        assert r.status_code == 200
        # Should be text/plain, not JSON.
        assert "text/plain" in r.headers.get("content-type", "")
        body = r.text
        # Either disabled comment or actual metrics.
        assert isinstance(body, str)


# ─── Section 12: Batched embeddings ─────────────────────────────────────────

def test_ollama_embed_uses_asyncio_gather():
    """embed() must use asyncio.gather for concurrent embedding."""
    from adonai.llm.ollama import OllamaLLMClient
    src = inspect.getsource(OllamaLLMClient.embed)
    assert "asyncio.gather" in src or "_aio.gather" in src
    # Must NOT be a sequential for-loop calling await.
    assert "for t in texts:" not in src or "gather" in src


# ─── Section 7: Watchdog timer ──────────────────────────────────────────────

def test_watchdog_importable():
    from adonai.safety.watchdog import Watchdog
    assert Watchdog is not None


@pytest.mark.asyncio
async def test_watchdog_cancels_hung_task():
    """A task that exceeds the timeout must be cancelled."""
    from adonai.safety.watchdog import Watchdog

    async def _slow_task():
        await asyncio.sleep(10.0)
        return "should never get here"

    wd = Watchdog(default_timeout_s=0.1)
    mock_task = MagicMock()
    mock_task.id = "t_test"
    result = await wd.run_with_timeout(mock_task, _slow_task)
    # Should return a TaskResult with FAILED status.
    from adonai.core.models import TaskStatus
    assert hasattr(result, "status")
    assert result.status == TaskStatus.FAILED
    assert "timeout" in (result.error or "").lower()


@pytest.mark.asyncio
async def test_watchdog_allows_fast_task():
    """A task that completes within the timeout must return its result."""
    from adonai.safety.watchdog import Watchdog

    async def _fast_task():
        return "done"

    wd = Watchdog(default_timeout_s=5.0)
    mock_task = MagicMock()
    mock_task.id = "t_fast"
    result = await wd.run_with_timeout(mock_task, _fast_task)
    assert result == "done"


def test_runtime_has_watchdog_slot():
    from adonai.runtime import ADONAI
    ai = ADONAI()
    assert hasattr(ai, "watchdog")


def test_runtime_wraps_executor_in_watchdog():
    from adonai.runtime import ADONAI
    src = inspect.getsource(ADONAI._run_task)
    assert "watchdog" in src
    assert "run_with_timeout" in src


# ─── Integration: runtime constructs all new subsystems ─────────────────────

def test_runtime_has_all_upgrade_attributes():
    """The runtime must expose all the new upgrade attributes."""
    from adonai.runtime import ADONAI
    ai = ADONAI()
    attrs = [
        "metrics", "health_monitor", "tracer",  # observability
        "executive_controller",  # executive autonomy
        "watchdog",  # watchdog timer
        "consensus",  # consensus builder
        # v4 subsystems (populated in start())
        "critic", "model_router", "reflection_engine",
        "skill_evolver", "debate_framework", "hypothesis_generator",
        "experiment_loop", "safety_guard", "self_improvement",
        "simulators", "strategic_reasoner", "prompt_engineer",
        "tool_calling_agent",
    ]
    for attr in attrs:
        assert hasattr(ai, attr), f"ADONAI missing attribute: {attr}"
