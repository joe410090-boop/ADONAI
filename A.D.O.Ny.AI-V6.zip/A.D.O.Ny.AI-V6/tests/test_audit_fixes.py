"""Tests for the audit-driven fixes (Batch 5).

Covers the 10 high-priority findings from the architecture audit:
  * MetricsRegistry schema migration (no-column-named-type bug)
  * ToolCallingAgent duplicate-tool-call loop detection
  * recall_lessons() call signature fix
  * observe_bottlenecks() ToolRegistry wiring + field name fix
  * PatternExtractor.analyze() sync/await fix
  * SQLiteMemoryStore connection pooling + embedding-based search
  * Executor memory.recall() wiring
  * Regrounding pass conditionalisation (only for hallucination-prone tools)
  * EventBus parallel subscriber dispatch
  * HTTP/web SSRF-via-redirect defense
  * TerminalTool workspace_root wiring
  * Prompt-injection rejection (not log-and-continue)
  * recall_similar() episodic memory wiring
"""
from __future__ import annotations

import asyncio
import inspect
import os
import sqlite3
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest


# ─── Fix 1: MetricsRegistry schema migration ─────────────────────────────────

def test_metrics_registry_migrates_old_schema_without_type_column(tmp_path):
    """The original metrics table had no `type` column.  The registry must
    ALTER TABLE ADD COLUMN on init rather than crashing on every flush."""
    db = tmp_path / "metrics.db"
    # Create an old-schema table without `type` or `labels`.
    with sqlite3.connect(str(db)) as c:
        c.execute("CREATE TABLE metrics (name TEXT, value REAL, ts REAL)")
        c.execute("INSERT INTO metrics VALUES ('old', 1.0, 0)")
        c.commit()
    # Now construct the registry — it must migrate, not crash.
    from adonai.observability import MetricsRegistry
    reg = MetricsRegistry(db_path=db)
    # Verify all expected columns now exist.
    with sqlite3.connect(str(db)) as c:
        cols = [r[1] for r in c.execute("PRAGMA table_info(metrics)").fetchall()]
    assert "type" in cols, f"type column missing after migration: {cols}"
    assert "labels" in cols
    assert "value" in cols
    assert "ts" in cols
    # A flush must succeed (no "no column named type" error).
    reg.counter("test_counter").inc()
    reg._flush()
    with sqlite3.connect(str(db)) as c:
        rows = c.execute(
            "SELECT name, type, value FROM metrics WHERE name = ?",
            ("test_counter",),
        ).fetchall()
    assert rows == [("test_counter", "counter", 1.0)]


# ─── Fix 2: ToolCallingAgent duplicate-tool-call loop detection ──────────────

def test_tool_call_signature_helper_dedupes_identical_calls():
    from adonai.agents.tool_calling_agent import _tool_call_signature
    from adonai.core.models import ToolCall
    tc1 = [ToolCall(tool="github_search", parameters={"q": "AI 2026"})]
    tc2 = [ToolCall(tool="github_search", parameters={"q": "AI 2026"})]
    tc3 = [ToolCall(tool="github_search", parameters={"q": "different"})]
    assert _tool_call_signature(tc1) == _tool_call_signature(tc2)
    assert _tool_call_signature(tc1) != _tool_call_signature(tc3)


def test_tool_call_signature_handles_param_ordering():
    """{a:1,b:2} and {b:2,a:1} should produce the same signature."""
    from adonai.agents.tool_calling_agent import _tool_call_signature
    from adonai.core.models import ToolCall
    tc1 = [ToolCall(tool="t", parameters={"a": 1, "b": 2})]
    tc2 = [ToolCall(tool="t", parameters={"b": 2, "a": 1})]
    assert _tool_call_signature(tc1) == _tool_call_signature(tc2)


def test_tool_calling_agent_has_loop_stuck_detection_attribute():
    from adonai.agents.tool_calling_agent import ToolCallingAgent
    src = inspect.getsource(ToolCallingAgent.__init__)
    assert "max_duplicate_tool_calls" in src
    assert "_tool_call_signature" in inspect.getsource(
        ToolCallingAgent.run_with_transcript
    )


# ─── Fix 3: recall_lessons() call signature ──────────────────────────────────

def test_recall_lessons_call_uses_keyword_arg():
    """planner.py must call recall_lessons(domain=..., top_k=...) — NOT
    pass task.goal positionally into the keyword-only `domain` parameter."""
    from adonai.planning import planner as planner_mod
    src = inspect.getsource(planner_mod.HierarchicalPlanner._build_user_prompt)
    # The fixed call uses domain= explicitly.
    assert "recall_lessons(" in src
    assert "domain=" in src, "must use domain= keyword arg"
    # The old broken call (positional) must be gone.
    assert "recall_lessons(task.goal, top_k=3)" not in src


def test_recall_lessons_handles_lesson_objects_and_dicts():
    """The fix normalises both Pydantic Lesson objects and plain dicts
    so the f-string formatting doesn't crash."""
    from adonai.planning import planner as planner_mod
    src = inspect.getsource(planner_mod.HierarchicalPlanner._build_user_prompt)
    assert "hasattr(l, \"lesson\")" in src or "hasattr(l, 'lesson')" in src


# ─── Fix 4: observe_bottlenecks() ToolRegistry wiring ────────────────────────

@pytest.mark.asyncio
async def test_observe_bottlenecks_uses_tool_registry_stats():
    """observe_bottlenecks must accept tool_registry= and read all_stats()."""
    from adonai.safety.self_improvement import SelfImprovementEngine
    from adonai.config.settings import Config

    config = Config()
    engine = SelfImprovementEngine(
        llm=MagicMock(), config=config, safety_guard=MagicMock(),
    )
    # Mock tool registry with failing tools.
    fake_registry = MagicMock()
    fake_registry.all_stats.return_value = {
        "web_search": {"calls": 10, "success": 5, "fail": 5, "total_s": 12.0},
        "file.read": {"calls": 20, "success": 20, "fail": 0, "total_s": 2.0},
    }
    bottlenecks = await engine.observe_bottlenecks(
        analytics=None, tool_registry=fake_registry,
    )
    # web_search has 50% fail rate (>0.3 threshold) → should be flagged.
    assert any(b["tool"] == "web_search" and b["kind"] == "tool_failure" for b in bottlenecks)
    # file.read has 0% fail rate → should NOT be flagged.
    assert not any(b["tool"] == "file.read" for b in bottlenecks)


def test_observe_bottlenecks_accepts_tool_registry_keyword():
    from adonai.safety.self_improvement import SelfImprovementEngine
    sig = inspect.signature(SelfImprovementEngine.observe_bottlenecks)
    assert "tool_registry" in sig.parameters


# ─── Fix 5: PatternExtractor.analyze() sync/await ────────────────────────────

def test_learning_loop_calls_analyze_without_await():
    """The loop must call self.patterns.analyze() (sync) and only await
    if it returns a coroutine — NOT unconditionally await a sync method."""
    from adonai.learning.loop import LearningLoop
    src = inspect.getsource(LearningLoop._process)
    # The fix uses asyncio.iscoroutine() to detect async returns.
    assert "iscoroutine" in src
    # The old buggy `await self.patterns.analyze()` (without the
    # iscoroutine guard) must be gone.
    assert "await self.patterns.analyze()\n" not in src


# ─── Fix 6: SQLiteMemoryStore connection pooling + embedding search ──────────

def test_sqlite_store_uses_pooled_connection(tmp_path):
    """The store must reuse one connection, not open a fresh one per call."""
    from adonai.memory.sqlite_store import SQLiteMemoryStore
    store = SQLiteMemoryStore(tmp_path / "mem.db")
    # The pool is the _conn attribute (a single sqlite3.Connection).
    assert hasattr(store, "_conn")
    assert isinstance(store._conn, sqlite3.Connection)
    # Calling _conn_ctx() returns the SAME connection (not a new one).
    assert store._conn_ctx() is store._conn
    store.close()


@pytest.mark.asyncio
async def test_sqlite_store_falls_back_to_like_when_no_llm(tmp_path):
    """When no LLM is configured, search() must fall back to LIKE — not
    crash trying to embed."""
    from adonai.memory.sqlite_store import SQLiteMemoryStore
    from adonai.core.models import Memory, MemoryType
    store = SQLiteMemoryStore(tmp_path / "mem.db")  # no llm
    await store.add(Memory(
        id="m1", type=MemoryType.SEMANTIC, content="hello world",
        importance=0.5, source="test",
    ))
    results = await store.search("hello", top_k=5)
    assert len(results) == 1
    assert results[0].content == "hello world"
    store.close()


@pytest.mark.asyncio
async def test_sqlite_store_uses_embedding_search_when_llm_available(tmp_path):
    """When an LLM is configured, search() must embed the query and do
    cosine search — not fall back to LIKE."""
    from adonai.memory.sqlite_store import SQLiteMemoryStore
    from adonai.core.models import Memory, MemoryType

    # Mock LLM that returns a fixed embedding for any input.
    fake_llm = MagicMock()
    fake_llm.embed = AsyncMock(return_value=[[0.1, 0.2, 0.3]])

    store = SQLiteMemoryStore(tmp_path / "mem.db", llm=fake_llm)
    # Add a memory with a known embedding.
    m = Memory(
        id="m1", type=MemoryType.SEMANTIC, content="some content",
        importance=0.5, source="test",
    )
    m.embedding = [0.1, 0.2, 0.3]  # exact match with query embedding
    await store.add(m)
    # Search — should call llm.embed() and find the memory via cosine.
    results = await store.search("anything", top_k=5)
    fake_llm.embed.assert_called_once_with("anything")
    assert len(results) >= 1
    store.close()


# ─── Fix 7: Executor memory.recall() wiring ──────────────────────────────────

def test_executor_calls_memory_recall_in_execute():
    """The executor's execute() method must call memory.recall() to
    inject long-term context into the system prompt."""
    from adonai.executors.executor import TaskExecutor
    src = inspect.getsource(TaskExecutor.execute)
    assert "memory.recall" in src or "self.memory.recall" in src
    assert "Recalled context from long-term memory" in src


# ─── Fix 8: Regrounding pass conditionalisation ──────────────────────────────

def test_should_reground_returns_true_for_web_search():
    from adonai.agents.tool_calling_agent import _should_reground
    transcript = [{"tool": "web_search", "parameters": {"q": "AI news"}}]
    assert _should_reground(transcript) is True


def test_should_reground_returns_false_for_file_read():
    from adonai.agents.tool_calling_agent import _should_reground
    transcript = [{"tool": "file.read", "parameters": {"path": "/tmp/x"}}]
    assert _should_reground(transcript) is False


def test_should_reground_returns_true_for_github_search():
    from adonai.agents.tool_calling_agent import _should_reground
    transcript = [{"tool": "github_search", "parameters": {"q": "AI"}}]
    assert _should_reground(transcript) is True


def test_should_reground_returns_false_for_empty_transcript():
    from adonai.agents.tool_calling_agent import _should_reground
    assert _should_reground([]) is False
    assert _should_reground(None) is False


def test_regrounding_pass_uses_conditional_check():
    """The chat loop must call _should_reground() before invoking
    _reground_answer — not reground on every tool-using turn."""
    from adonai.agents.tool_calling_agent import ToolCallingAgent
    src = inspect.getsource(ToolCallingAgent.run_with_transcript)
    assert "_should_reground(transcript)" in src


# ─── Fix 9: EventBus parallel subscriber dispatch ────────────────────────────

@pytest.mark.asyncio
async def test_eventbus_dispatches_subscribers_concurrently():
    """A slow subscriber must NOT block other subscribers."""
    from adonai.core.events import EventBus, Event
    bus = EventBus()
    received: list[str] = []
    import asyncio as _a

    async def _fast(_event):
        received.append("fast")

    async def _slow(_event):
        await _a.sleep(0.1)  # 100ms delay
        received.append("slow")

    bus.subscribe("test", _slow)
    bus.subscribe("test", _fast)
    # Publish — _fast should receive the event BEFORE _slow finishes,
    # because they're dispatched concurrently via asyncio.gather.
    import time as _time
    start = _time.monotonic()
    await bus.publish(Event(type="test"))
    elapsed = _time.monotonic() - start
    # Both should have run.
    assert "fast" in received
    assert "slow" in received
    # And total time should be ~0.1s (concurrent), not ~0.2s (sequential).
    # Allow generous headroom for CI.
    assert elapsed < 0.18, f"dispatch was sequential (elapsed={elapsed:.3f}s)"


# ─── Fix 10: SSRF-via-redirect defense ───────────────────────────────────────

def test_http_tool_does_not_use_follow_redirects_true():
    """http.py must NOT pass follow_redirects=True to httpx — that
    would bypass URL safety validation on redirect targets."""
    from adonai.tools.builtin import http as http_mod
    src = inspect.getsource(http_mod.HTTPRequestTool.execute)
    # Strip comment lines so docstring/comments mentioning the old
    # behaviour don't trigger a false positive.
    code_lines = [
        line for line in src.splitlines()
        if line.strip() and not line.strip().startswith("#")
    ]
    code = "\n".join(code_lines)
    assert "follow_redirects=True" not in code, (
        "http.py must not use follow_redirects=True in executable code"
    )
    assert "follow_redirects=False" in code


def test_web_fetch_tool_does_not_use_follow_redirects_true():
    """WebFetchTool (which takes user-supplied URLs) must not blindly
    follow redirects.  WebSearchTool is exempt because it calls a
    fixed trusted endpoint (DuckDuckGo)."""
    from adonai.tools.builtin import web as web_mod
    src = inspect.getsource(web_mod.WebFetchTool)
    # Look at code lines only (no comments).
    lines = [
        line for line in src.splitlines()
        if "follow_redirects=True" in line
        and not line.strip().startswith("#")
    ]
    assert not lines, f"WebFetchTool still uses follow_redirects=True: {lines}"


# ─── Fix 11: TerminalTool workspace_root wiring ──────────────────────────────

def test_all_builtin_tools_accepts_workspace_root():
    """all_builtin_tools() must accept a workspace_root kwarg and pass
    it to TerminalTool so the cwd sandbox activates."""
    from adonai.tools.builtin import all_builtin_tools, TerminalTool
    import inspect
    sig = inspect.signature(all_builtin_tools)
    assert "workspace_root" in sig.parameters


def test_all_builtin_tools_passes_workspace_to_terminal(tmp_path):
    from adonai.tools.builtin import all_builtin_tools, TerminalTool
    tools = all_builtin_tools(workspace_root=str(tmp_path))
    terminal = next(t for t in tools if isinstance(t, TerminalTool))
    assert terminal._workspace_root == tmp_path.resolve()


# ─── Fix 12: Prompt-injection rejection ──────────────────────────────────────

def test_runtime_run_rejects_prompt_injection():
    """run() must return a FAILED TaskResult when injection is detected,
    NOT pass the injected text to the LLM."""
    from adonai.runtime import ADONAI
    src = inspect.getsource(ADONAI.run)
    assert "REJECTING" in src or "rejected" in src.lower()
    assert "TaskStatus.FAILED" in src


def test_runtime_chat_rejects_prompt_injection():
    """chat() must return an error string when injection is detected,
    NOT pass the injected text to the LLM."""
    from adonai.runtime import ADONAI
    src = inspect.getsource(ADONAI.chat)
    assert "prompt-injection" in src or "REJECTING" in src


# ─── Fix 13: recall_similar() episodic memory wiring ─────────────────────────

def test_learning_loop_writes_episodic_memory_with_experience_metadata():
    """The loop must write a Memory entry with metadata['experience']
    so recall_similar() can find it."""
    from adonai.learning.loop import LearningLoop
    src = inspect.getsource(LearningLoop._process)
    assert "memory_manager" in src
    assert "EPISODIC" in src
    assert '"experience"' in src or "'experience'" in src


def test_learning_loop_constructor_accepts_memory_manager():
    from adonai.learning.loop import LearningLoop
    sig = inspect.signature(LearningLoop.__init__)
    assert "memory_manager" in sig.parameters


# ─── Integration: runtime wires all the new dependencies ─────────────────────

def test_runtime_passes_memory_manager_to_learning_loop():
    """runtime.py must pass self.memory as memory_manager= to LearningLoop."""
    from adonai.runtime import ADONAI
    src = inspect.getsource(ADONAI._start_impl)
    assert "memory_manager=self.memory" in src


def test_runtime_passes_tool_registry_to_observe_bottlenecks():
    """runtime.py must pass tool_registry=self.tools to observe_bottlenecks."""
    from adonai.runtime import ADONAI
    src = inspect.getsource(ADONAI.self_improve)
    assert "tool_registry=self.tools" in src


def test_runtime_wires_reflection_engine_into_planner():
    """runtime.py must set planner.reflection_engine after v4 subsystems start."""
    from adonai.runtime import ADONAI
    src = inspect.getsource(ADONAI._start_v4_subsystems)
    assert "planner.reflection_engine" in src


def test_runtime_passes_workspace_to_builtin_tools():
    """runtime.py must pass config.workspace to all_builtin_tools()."""
    from adonai.runtime import ADONAI
    src = inspect.getsource(ADONAI._start_impl)
    assert "workspace_root=" in src
    assert "all_builtin_tools(workspace_root=" in src
