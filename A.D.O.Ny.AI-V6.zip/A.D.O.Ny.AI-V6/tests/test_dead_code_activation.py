"""Tests for the dead-code + bug-fix pass (Batch 4).

Covers:
  * Ollama /api/generate fallback path (chat-template parser failure)
  * Inline tool-call parser for the fallback path
  * CachedLLMClient.check_vision_capable() delegation
  * EventBus subscriber __name__ safety on bound methods
  * ConsensusBuilder is reachable from runtime (no longer dead)
  * Observability singletons are constructed (no longer dead)
  * ExecutiveController is constructable (no longer dead)
  * CORS config accepts explicit allowlist without warning
"""
from __future__ import annotations

import asyncio
import inspect
from typing import Any

import pytest


# ─── Ollama /api/generate fallback: inline tool-call parser ──────────────────

def test_parse_inline_tool_call_extracts_tool_call_json():
    from adonai.llm.ollama import _parse_inline_tool_call
    text = (
        'I will now search the web.\n'
        '{"tool": "web_search", "parameters": {"query": "latest AI news"}}\n'
        'Let me know what you find.'
    )
    calls = _parse_inline_tool_call(text)
    assert calls is not None
    assert len(calls) == 1
    assert calls[0].tool == "web_search"
    assert calls[0].parameters == {"query": "latest AI news"}


def test_parse_inline_tool_call_handles_alt_shape():
    """OpenAI-style {"name": ..., "arguments": ...} should also parse."""
    from adonai.llm.ollama import _parse_inline_tool_call
    text = '{"name": "file.read", "arguments": {"path": "/tmp/x"}}'
    calls = _parse_inline_tool_call(text)
    assert calls is not None and len(calls) == 1
    assert calls[0].tool == "file.read"
    assert calls[0].parameters == {"path": "/tmp/x"}


def test_parse_inline_tool_call_returns_none_when_no_tool():
    from adonai.llm.ollama import _parse_inline_tool_call
    assert _parse_inline_tool_call("just a plain answer") is None
    assert _parse_inline_tool_call("") is None
    assert _parse_inline_tool_call('{"unrelated": "json"}') is None


def test_parse_inline_tool_call_recovers_from_invalid_args_json():
    """If the arguments JSON is malformed we still return a ToolCall
    with the raw string preserved as `_raw` — instead of crashing."""
    from adonai.llm.ollama import _parse_inline_tool_call
    text = '{"tool": "broken_tool", "parameters": {not valid json}}'
    calls = _parse_inline_tool_call(text)
    assert calls is not None
    assert calls[0].tool == "broken_tool"
    assert "_raw" in calls[0].parameters


# ─── Ollama fallback path triggers on parser-failure bodies ──────────────────

def test_ollama_400_body_contains_parser_failure_markers():
    """The HTTP 400 error body returned by Ollama for a Qwen3 chat-template
    parser failure must include the marker substrings we look for."""
    from adonai.llm import ollama as ollama_mod
    src = inspect.getsource(ollama_mod)
    # Verify the fallback markers exist in the source.
    assert "unable to generate parser" in src
    assert "raise_exception" in src
    assert "automatic parser generation failed" in src
    assert "no user query found in messages" in src
    # Verify the fallback method exists.
    assert hasattr(ollama_mod.OllamaLLMClient, "_generate_fallback")


# ─── CachedLLMClient.check_vision_capable delegation ─────────────────────────

def test_cached_llm_client_forwards_check_vision_capable():
    """CachedLLMClient must forward check_vision_capable() to its inner
    client so the FileAnalysisAgent's vision detection works through
    the cache layer."""
    from adonai.llm.cache import CachedLLMClient

    class _FakeInner:
        async def complete(self, **kw): ...  # pragma: no cover
        async def stream(self, **kw): ...    # pragma: no cover
        async def embed(self, text): ...     # pragma: no cover
        async def close(self): ...           # pragma: no cover
        async def check_vision_capable(self):
            return True

    from adonai.llm.cache import ResponseCache
    client = CachedLLMClient(_FakeInner(), ResponseCache())
    assert hasattr(client, "check_vision_capable")


def test_cached_llm_client_check_vision_returns_none_when_inner_lacks_it():
    from adonai.llm.cache import CachedLLMClient, ResponseCache

    class _BareInner:
        async def complete(self, **kw): ...  # pragma: no cover
        async def stream(self, **kw): ...    # pragma: no cover
        async def embed(self, text): ...     # pragma: no cover
        async def close(self): ...           # pragma: no cover
        # NOTE: no check_vision_capable — OpenAI-compat client doesn't
        # have one.

    client = CachedLLMClient(_BareInner(), ResponseCache())

    async def _go():
        return await client.check_vision_capable()

    assert asyncio.run(_go()) is None


# ─── EventBus subscriber __name__ safety ─────────────────────────────────────

@pytest.mark.asyncio
async def test_eventbus_does_not_crash_on_bound_method_subscriber():
    """Bound methods, lambdas, and callable instances don't expose
    __name__ directly — the bus used to crash with AttributeError
    when one of them raised."""
    from adonai.core.events import EventBus, Event

    bus = EventBus()
    received: list[Event] = []

    class _Subscriber:
        async def __call__(self, event: Event):
            received.append(event)
            raise RuntimeError("intentional")

    sub = _Subscriber()
    bus.subscribe("test.event", sub)  # bound callable instance
    # Must not raise even though the subscriber raises.
    await bus.publish(Event(type="test.event", payload={"hi": 1}))
    assert len(received) == 1


@pytest.mark.asyncio
async def test_eventbus_does_not_crash_on_lambda_subscriber():
    from adonai.core.events import EventBus, Event
    bus = EventBus()
    raised: list[bool] = []

    async def _boom(_event):
        raised.append(True)
        raise ValueError("lambda boom")

    bus.subscribe("lambda.event", _boom)
    await bus.publish(Event(type="lambda.event"))
    assert raised == [True]


# ─── ConsensusBuilder is reachable from the runtime (no longer dead) ─────────

def test_runtime_exposes_consensus_builder():
    """ADONAI.consensus must be set after construction (not left as None
    forever).  The actual .build() call requires an LLM so we just verify
    the attribute is wired."""
    from adonai.runtime import ADONAI
    ai = ADONAI()
    assert hasattr(ai, "consensus")
    # The constructor sets it to None; _start_impl populates it.  Just
    # verify the slot exists and the method exists on the class.
    assert hasattr(ADONAI, "_run_multi_agent")


# ─── Observability singletons are constructed (no longer dead) ───────────────

def test_runtime_has_observability_slots():
    """ADONAI must expose metrics/health_monitor/tracer slots so
    /metrics, /health-check, and /traces endpoints have somewhere to
    read from."""
    from adonai.runtime import ADONAI
    ai = ADONAI()
    assert hasattr(ai, "metrics")
    assert hasattr(ai, "health_monitor")
    assert hasattr(ai, "tracer")


def test_observability_module_endpoints_are_registered():
    """The /metrics, /health-check, and /traces endpoints must be
    registered on the FastAPI app — verifying the previously-dead
    observability module is now wired into the API surface."""
    from adonai.api.server import create_app
    from adonai.config.settings import load_config
    config = load_config()
    config.analytics.enabled = False  # avoid needing a writable DB
    app = create_app(config=config)
    routes = {r.path for r in app.routes}
    assert "/metrics" in routes
    assert "/health-check" in routes
    assert "/traces" in routes


# ─── ExecutiveController is constructable (no longer dead) ───────────────────

def test_runtime_has_executive_controller_slot():
    """ADONAI must expose the executive_controller slot so the
    /executive endpoints can read its state."""
    from adonai.runtime import ADONAI
    ai = ADONAI()
    assert hasattr(ai, "executive_controller")


def test_executive_controller_endpoints_registered():
    """The /executive, /executive/goals endpoints must exist on the app."""
    from adonai.api.server import create_app
    from adonai.config.settings import load_config
    config = load_config()
    config.analytics.enabled = False
    app = create_app(config=config)
    routes = {r.path for r in app.routes}
    assert "/executive" in routes
    assert "/executive/goals" in routes


def test_executive_controller_is_constructable():
    """ExecutiveController must be importable + constructable in
    isolation — proves the class isn't dead."""
    from adonai.agents.executive_controller import (
        ExecutiveController, Goal, GoalTier, WorldModel,
    )
    # Just construct it with a stub runtime — no real LLM needed.
    ctrl = ExecutiveController(runtime=object())
    assert ctrl.world is not None
    assert isinstance(ctrl.world, WorldModel)
    # And the dataclasses work.
    g = Goal(id="g1", title="test")
    ctrl.world.add_goal(g)
    assert ctrl.world.pending_goals() == [g]


# ─── CORS config: explicit allowlist doesn't trigger warning ─────────────────

def test_default_config_cors_origins_is_explicit_allowlist():
    """The bundled config/default.yaml must not ship cors_origins: ['*']
    — it should be an explicit localhost allowlist."""
    from adonai.config.settings import load_config
    config = load_config()
    assert "*" not in config.api.cors_origins, (
        "default cors_origins must not contain wildcard '*'"
    )
    assert len(config.api.cors_origins) >= 1


def test_cors_middleware_accepts_wildcard_in_dev_without_disabling_credentials():
    """In development mode, a wildcard cors_origins should auto-expand
    to a localhost allowlist rather than disabling credentials."""
    from adonai.config.settings import load_config
    from adonai.api.server import create_app
    config = load_config()
    config.environment = "development"
    config.api.cors_origins = ["*"]
    config.analytics.enabled = False
    # Must not raise.
    app = create_app(config=config)
    # Find the CORS middleware and verify allow_origins was expanded.
    cors = None
    for m in app.user_middleware:
        if "CORSMiddleware" in str(m.cls):
            cors = m
            break
    assert cors is not None, "CORS middleware must be installed"
    # allow_origins should NOT contain "*" anymore.
    origins = cors.kwargs.get("allow_origins", [])
    assert "*" not in origins
    assert len(origins) >= 1


# ─── Multi-agent consensus path is reachable (no longer dead) ────────────────

@pytest.mark.asyncio
async def test_multi_agent_consensus_path_returns_failure_when_all_agents_fail():
    """When all eligible agents raise, _run_multi_agent must return a
    TaskResult with status=FAILED — not crash."""
    from adonai.runtime import ADONAI
    from adonai.core.models import Task

    ai = ADONAI()

    class _BrokenAgent:
        name = "broken"
        async def run(self, task):
            raise RuntimeError("intentional failure")

    task = Task(goal="test")
    result = await ai._run_multi_agent(task, [(0.9, _BrokenAgent()), (0.8, _BrokenAgent())])
    assert result.status.value == "failed"
    assert "all multi-agent runs failed" in (result.error or "")


@pytest.mark.asyncio
async def test_multi_agent_consensus_path_skips_synthesis_for_single_success():
    """When only one agent succeeds, _run_multi_agent must skip consensus
    and return that agent's output directly."""
    from adonai.runtime import ADONAI
    from adonai.core.models import Task, TaskResult, TaskStatus

    ai = ADONAI()

    class _GoodAgent:
        name = "good"
        async def run(self, task):
            return TaskResult(
                task_id=task.id, status=TaskStatus.COMPLETED,
                output="good answer", confidence=0.9,
            )

    class _BadAgent:
        name = "bad"
        async def run(self, task):
            raise RuntimeError("oops")

    task = Task(goal="test")
    result = await ai._run_multi_agent(
        task, [(0.9, _GoodAgent()), (0.8, _BadAgent())],
    )
    assert result.status.value == "completed"
    assert result.output == "good answer"


# ─── Parallel executor still calls (now-no-op) meta question method ─────────

def test_handle_meta_question_is_documented_noop():
    """The _handle_meta_question method must continue to be a no-op
    (it was a hard-coded interception before; now it lets the LLM
    answer naturally).  Verifies the stub isn't accidentally revived."""
    from adonai.executors.executor import TaskExecutor
    src = inspect.getsource(TaskExecutor._handle_meta_question)
    assert "return None" in src
