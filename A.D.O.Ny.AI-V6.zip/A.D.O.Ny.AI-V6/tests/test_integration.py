"""Integration tests — verify subsystems work together end-to-end.

These tests exercise the full pipeline: planner → executor → tools → memory,
without requiring an actual LLM (uses a mock).
"""
from __future__ import annotations

import asyncio
import json
import uuid
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock

import pytest

from adonai.core.models import (
    Memory, MemoryType, Plan, PlanStep, Task, TaskResult, TaskStatus,
    ToolCall, ToolResult,
)
from adonai.llm.base import LLMResponse


class MockLLM:
    """A mock LLM that returns canned responses for testing."""

    def __init__(self, responses: list[str] | None = None) -> None:
        self._responses = responses or []
        self._idx = 0
        self.calls: list[dict] = []

    async def complete(self, messages, tools=None, temperature=0.7, max_tokens=2048, **kwargs):
        self.calls.append({"messages": messages, "tools": tools})
        text = self._responses[self._idx] if self._idx < len(self._responses) else '{"steps":[]}'
        self._idx += 1
        return LLMResponse(text=text, tool_calls=None, tokens_in=10, tokens_out=20)

    async def embed(self, text):
        if isinstance(text, str):
            text = [text]
        return [[0.1] * 8 for _ in text]

    async def close(self):
        pass


# ─── Memory subsystem integration ────────────────────────────────────────────

@pytest.mark.asyncio
async def test_memory_manager_roundtrip(tmp_path):
    """Memory add → search → recall roundtrip with the SQLite backend."""
    from adonai.memory.sqlite_store import SQLiteMemoryStore
    store = SQLiteMemoryStore(db_path=tmp_path / "mem.db", table_name="episodic")
    # Add three memories.
    for i, content in enumerate(["hello world", "world peace", "goodbye moon"]):
        await store.add(Memory(
            id=f"m{i}", type=MemoryType.EPISODIC, content=content,
            importance=0.5 + i * 0.1,
        ))
    # Search by keyword.
    results = await store.search("world", top_k=10)
    contents = [r.content for r in results]
    assert "hello world" in contents
    assert "world peace" in contents
    assert "goodbye moon" not in contents


@pytest.mark.asyncio
async def test_memory_consolidation_no_longer_silently_broken(tmp_path):
    """CRITICAL-03 regression: consolidation must actually find memories."""
    from adonai.memory.sqlite_store import SQLiteMemoryStore
    from adonai.core.models import Memory, MemoryType

    store = SQLiteMemoryStore(db_path=tmp_path / "mem.db", table_name="episodic")
    for i in range(20):
        await store.add(Memory(
            id=f"m{i}", type=MemoryType.EPISODIC, content=f"memory number {i}",
            importance=0.1,  # low importance so it's a candidate for pruning
        ))
    # The decay pass should find all 20 memories (not 0 like before the fix).
    results = await store.search("*", top_k=100)
    assert len(results) == 20, f"expected 20, got {len(results)} (search('*') bug?)"


# ─── Planner integration ─────────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_planner_produces_acyclic_plan(tmp_path):
    """The planner should never produce a plan with a dependency cycle."""
    from adonai.planning.planner import HierarchicalPlanner
    from adonai.planning.graph import DependencyGraph

    plan_json = json.dumps({
        "steps": [
            {"id": "s1", "description": "step 1", "tool": None, "dependencies": ["s3"]},
            {"id": "s2", "description": "step 2", "tool": None, "dependencies": ["s1"]},
            {"id": "s3", "description": "step 3", "tool": None, "dependencies": ["s2"]},
        ],
        "confidence": 0.7,
    })
    llm = MockLLM(responses=[plan_json])
    planner = HierarchicalPlanner(llm=llm)
    task = Task(goal="test cyclic plan")
    plan = await planner.plan(task)
    # The planner should have broken the cycle.
    g = DependencyGraph(plan)
    assert not g.has_cycle(), "planner should produce acyclic plans"


# ─── Terminal tool integration ───────────────────────────────────────────────

@pytest.mark.asyncio
async def test_terminal_tool_e2e(tmp_path):
    """Terminal tool: echo → read output → verify success."""
    from adonai.tools.builtin.terminal import TerminalTool
    t = TerminalTool(workspace_root=str(tmp_path))
    r = await t.execute(command="echo integration_test")
    assert r.success
    assert "integration_test" in r.output["stdout"]


@pytest.mark.asyncio
async def test_terminal_tool_workspace_isolation(tmp_path):
    """Commands run inside the workspace sandbox."""
    from adonai.tools.builtin.terminal import TerminalTool
    t = TerminalTool(workspace_root=str(tmp_path))
    # Create a file in the workspace.
    r = await t.execute(command="touch created.txt")
    assert r.success
    assert (tmp_path / "created.txt").exists()


# ─── Python exec integration ─────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_python_exec_e2e(tmp_path):
    """Python exec: safe code runs, output captured."""
    from adonai.tools.builtin.python_exec import PythonExecTool
    p = PythonExecTool(workspace_root=str(tmp_path))
    r = await p.execute(code="print('hello from python_exec'); import math; print(math.sqrt(16))")
    assert r.success
    assert "hello from python_exec" in r.output["stdout"]
    assert "4.0" in r.output["stdout"]


# ─── Filesystem tool integration ─────────────────────────────────────────────

@pytest.mark.asyncio
async def test_filesystem_read_write_e2e(tmp_path):
    """Filesystem: write → read → verify content matches."""
    # Create a workspace dir and put a file in it.
    ws = tmp_path / "workspace"
    ws.mkdir()
    (ws / "existing.txt").write_text("existing content")

    from adonai.tools.builtin.filesystem import FileReadTool, FileWriteTool
    # Write a new file.
    writer = FileWriteTool()
    r = await writer.execute(path="new.txt", content="new content")
    assert r.success
    # Read it back.
    reader = FileReadTool()
    r2 = await reader.execute(path="new.txt")
    assert r2.success
    assert "new content" in r2.output["content"]


# ─── URL safety integration ──────────────────────────────────────────────────

@pytest.mark.asyncio
async def test_web_fetch_blocks_ssf(tmp_path):
    """WebFetchTool must block SSRF attempts."""
    from adonai.tools.builtin.web import WebFetchTool
    w = WebFetchTool()
    r = await w.execute(url="http://169.254.169.254/latest/meta-data/")
    assert not r.success
    assert "safety" in (r.error or "").lower()


# ─── Recovery manager integration ────────────────────────────────────────────

@pytest.mark.asyncio
async def test_recovery_manager_tracks_tasks(tmp_path):
    """RecoveryManager should keep strong refs to recovery tasks."""
    from adonai.executors.recovery import RecoveryManager
    from adonai.executors.checkpoint import CheckpointManager
    from adonai.config.settings import Config
    from adonai.core.models import Task, TaskResult, TaskStatus

    cfg = Config()
    cfg.memory.sqlite_path = tmp_path / "checkpoints.db"
    cm = CheckpointManager(cfg)
    # Schema is auto-created in __init__; just ensure the table exists.
    cm._ensure_schema()

    # Track a fake agent that just records calls.
    calls: list[Task] = []

    async def fake_agent(task: Task) -> TaskResult:
        calls.append(task)
        await asyncio.sleep(0.05)  # simulate work
        return TaskResult(task_id=task.id, status=TaskStatus.COMPLETED, output="ok")

    rm = RecoveryManager(cm, fake_agent, max_concurrent=2)

    # Insert a fake resumable task into the checkpoint DB.
    import sqlite3, time
    with sqlite3.connect(str(cfg.memory.sqlite_path)) as conn:
        conn.execute("""
            INSERT INTO tasks (id, goal, status, session_id, created_at, updated_at, plan)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, ("recovered-1", "test recovery goal", "running", "s1",
              time.time(), time.time(), "{}"))
        conn.commit()

    recovered = await rm.recover_all()
    assert "recovered-1" in recovered
    # The task should still be running (fake_agent sleeps 50ms).
    assert len(rm._recovery_tasks) > 0
    # Wait for it to finish.
    await rm.wait_for_recovery(timeout=2.0)
    assert len(calls) == 1
    assert calls[0].id == "recovered-1"
    await rm.shutdown()


# ─── Verification gate integration ───────────────────────────────────────────

@pytest.mark.asyncio
async def test_verification_gate_file_exists(tmp_path):
    """FILE_EXISTS verification should check the workspace, not CWD."""
    from adonai.executors.plugins.verification_gate import VerificationGate, VerificationType
    from adonai.core.models import PlanStep

    # Create a file in the workspace.
    (tmp_path / "target.txt").write_text("content")

    gate = VerificationGate(llm=None, workspace=str(tmp_path))
    step = PlanStep(
        id="s1", description="create file", tool="file.write",
        verification_type=VerificationType.FILE_EXISTS,
        verification_detail="target.txt",
    )
    result = await gate.verify(step, "wrote target.txt", workspace=str(tmp_path))
    assert result.passed, f"FILE_EXISTS should pass: {result.message}"


@pytest.mark.asyncio
async def test_verification_gate_file_exists_fails_when_missing(tmp_path):
    """FILE_EXISTS verification should fail when the file is absent."""
    from adonai.executors.plugins.verification_gate import VerificationGate, VerificationType
    from adonai.core.models import PlanStep

    gate = VerificationGate(llm=None, workspace=str(tmp_path))
    step = PlanStep(
        id="s1", description="create file", tool="file.write",
        verification_type=VerificationType.FILE_EXISTS,
        verification_detail="nonexistent.txt",
    )
    result = await gate.verify(step, "wrote it", workspace=str(tmp_path))
    assert not result.passed


# ─── LLM retry integration with mock ─────────────────────────────────────────

@pytest.mark.asyncio
async def test_llm_complete_retries_on_transient_failure():
    """OllamaLLMClient.complete should retry on transient errors."""
    from adonai.llm.ollama import OllamaLLMClient
    from adonai.config.settings import LLMConfig

    # We can't easily mock httpx without monkeypatching; instead verify the
    # retry wrapper is applied at the source level.
    import inspect
    src = inspect.getsource(OllamaLLMClient.complete)
    assert "standard_llm_retry" in src or "llm_retry" in src
