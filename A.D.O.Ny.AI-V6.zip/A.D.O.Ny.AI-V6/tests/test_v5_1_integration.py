"""v5.1 integration tests — verifies KG, PromptOptimizer, BenchmarkRunner,
and executive_loop/self_improvement config integration.
"""
from __future__ import annotations

import asyncio
import inspect
import pytest


# ──────────────────────────────────────────────────────────────────────────────
# Config: self_improvement + executive_loop enabled by default
# ──────────────────────────────────────────────────────────────────────────────

def test_self_improvement_enabled_by_default():
    """v5.1: SelfImprovementConfig.enabled must default to True."""
    from adonai.config.settings import SelfImprovementConfig
    assert SelfImprovementConfig().enabled is True


def test_executive_loop_enabled_by_default():
    """v5.1: AgentConfig.executive_loop must default to True."""
    from adonai.config.settings import AgentConfig
    assert AgentConfig().executive_loop is True


def test_prompt_optimizer_config_exists():
    """v5.1: PromptOptimizerConfig must exist and default to enabled."""
    from adonai.config.settings import PromptOptimizerConfig, Config
    c = Config()
    assert c.prompt_optimizer.enabled is True
    assert c.prompt_optimizer.optimization_interval_tasks == 50
    assert c.prompt_optimizer.promotion_margin == 0.05


def test_benchmark_config_exists():
    """v5.1: BenchmarkConfig must exist and default to enabled."""
    from adonai.config.settings import BenchmarkConfig, Config
    c = Config()
    assert c.benchmark.enabled is True
    assert c.benchmark.interval_tasks == 100


# ──────────────────────────────────────────────────────────────────────────────
# Knowledge Graph wired into HierarchicalPlanner
# ──────────────────────────────────────────────────────────────────────────────

def test_planner_has_kg_integration():
    """v5.1: HierarchicalPlanner._build_user_prompt must query the KG."""
    from adonai.planning.planner import HierarchicalPlanner
    src = inspect.getsource(HierarchicalPlanner._build_user_prompt)
    assert "kg_block" in src, "planner must build a kg_block"
    assert "context_for" in src, "planner must call kg.context_for()"
    assert "knowledge_graph" in src, "planner must check self.knowledge_graph"


def test_planner_prompt_includes_kg_block():
    """v5.1: the final prompt string must include kg_block."""
    from adonai.planning.planner import HierarchicalPlanner
    src = inspect.getsource(HierarchicalPlanner._build_user_prompt)
    # The return f-string must reference {kg_block}
    assert "{kg_block}" in src, "final prompt must include {kg_block}"


def test_runtime_wires_kg_into_planner():
    """v5.1: runtime._start_v4_subsystems must wire KG into planner."""
    from adonai.runtime import ADONAI
    src = inspect.getsource(ADONAI._start_v4_subsystems)
    assert "knowledge_graph" in src
    assert "planner.knowledge_graph" in src


# ──────────────────────────────────────────────────────────────────────────────
# PromptOptimizer wired into LearningLoop
# ──────────────────────────────────────────────────────────────────────────────

def test_learning_loop_accepts_prompt_optimizer():
    """v5.1: LearningLoop must accept prompt_optimizer parameter."""
    from adonai.learning.loop import LearningLoop
    sig = inspect.signature(LearningLoop.__init__)
    assert "prompt_optimizer" in sig.parameters


def test_learning_loop_records_prompt_outcomes():
    """v5.1: LearningLoop._process must call prompt_optimizer.record_outcome."""
    from adonai.learning.loop import LearningLoop
    src = inspect.getsource(LearningLoop._process)
    assert "prompt_optimizer" in src
    assert "record_outcome" in src


def test_learning_loop_generates_variants_periodically():
    """v5.1: LearningLoop._process must call generate_variants every N tasks."""
    from adonai.learning.loop import LearningLoop
    src = inspect.getsource(LearningLoop._process)
    assert "generate_variants" in src
    assert "optimization_interval_tasks" in src


def test_runtime_constructs_prompt_optimizer():
    """v5.1: runtime must construct PromptOptimizer and wire into LearningLoop."""
    from adonai.runtime import ADONAI
    src = inspect.getsource(ADONAI._start_v4_subsystems)
    assert "PromptOptimizer" in src
    assert "prompt_optimizer" in src


# ──────────────────────────────────────────────────────────────────────────────
# BenchmarkRunner wired into LearningLoop
# ──────────────────────────────────────────────────────────────────────────────

def test_learning_loop_accepts_benchmark_runner():
    """v5.1: LearningLoop must accept benchmark_runner parameter."""
    from adonai.learning.loop import LearningLoop
    sig = inspect.signature(LearningLoop.__init__)
    assert "benchmark_runner" in sig.parameters


def test_learning_loop_runs_benchmarks_periodically():
    """v5.1: LearningLoop._process must call benchmark_runner.run_all every N tasks."""
    from adonai.learning.loop import LearningLoop
    src = inspect.getsource(LearningLoop._process)
    assert "benchmark_runner" in src
    assert "run_all" in src


def test_runtime_constructs_benchmark_runner():
    """v5.1: runtime must construct BenchmarkRunner and wire into LearningLoop."""
    from adonai.runtime import ADONAI
    src = inspect.getsource(ADONAI._start_v4_subsystems)
    assert "BenchmarkRunner" in src
    assert "benchmark_runner" in src


def test_learning_loop_accepts_runtime_param():
    """v5.1: LearningLoop must accept runtime parameter for benchmark execution."""
    from adonai.learning.loop import LearningLoop
    sig = inspect.signature(LearningLoop.__init__)
    assert "runtime" in sig.parameters


# ──────────────────────────────────────────────────────────────────────────────
# API endpoints for benchmark + prompt-optimizer
# ──────────────────────────────────────────────────────────────────────────────

def test_benchmark_endpoint_exists():
    """v5.1: POST /benchmark endpoint must exist."""
    from adonai.api import server
    src = inspect.getsource(server)
    assert '"/benchmark"' in src


def test_benchmark_history_endpoint_exists():
    """v5.1: GET /benchmark/history endpoint must exist."""
    from adonai.api import server
    src = inspect.getsource(server)
    assert "/benchmark/history" in src


def test_prompt_optimizer_stats_endpoint_exists():
    """v5.1: GET /prompt-optimizer/stats endpoint must exist."""
    from adonai.api import server
    src = inspect.getsource(server)
    assert "/prompt-optimizer/stats" in src


# ──────────────────────────────────────────────────────────────────────────────
# Functional: PromptOptimizer + BenchmarkRunner work
# ──────────────────────────────────────────────────────────────────────────────

def test_prompt_optimizer_functional():
    """v5.1: PromptOptimizer can record outcomes and compute scores."""
    from adonai.learning.prompt_optimizer import PromptOptimizer, PromptVariant
    import tempfile, os
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name
    try:
        # Mock LLM
        class MockLLM:
            async def complete(self, messages, **kw):
                return type("R", (), {"text": '{"variants": ["v1", "v2"]}'})()
        opt = PromptOptimizer(MockLLM(), db_path=db_path)
        # Create a variant and record outcomes
        v = PromptVariant(id="pv_test", prompt="test prompt")
        opt.record_outcome(v, success=True, confidence=0.8)
        assert v.sample_count == 1
        assert v.success_count == 1
        assert v.mean_confidence == 0.8
        assert v.score == 0.8  # success_rate(1.0) * mean_confidence(0.8)
        stats = opt.stats()
        assert stats["has_current"] is False  # not promoted yet
    finally:
        os.unlink(db_path)


def test_benchmark_runner_functional():
    """v5.1: BenchmarkRunner can run benchmarks against a mock runtime."""
    from adonai.learning.benchmark import BenchmarkRunner, BenchmarkTask
    import tempfile, os
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name
    try:
        runner = BenchmarkRunner(db_path=db_path)
        # Mock runtime with a chat() method
        class MockRuntime:
            async def chat(self, goal):
                return f"Response to: {goal}"
        bench = BenchmarkTask(
            id="test_bench", goal="Say hello",
            expected_keywords=["hello", "response"],
            timeout_s=5.0,
        )
        result = asyncio.run(runner.run_one(bench, MockRuntime()))
        assert result.task_id == "test_bench"
        # "hello" appears in "Response to: Say hello" -> coverage >= 0.5
        assert result.keyword_coverage >= 0.5
        # History should be empty (run_one doesn't persist; run_all does)
        assert runner.history() == []
    finally:
        os.unlink(db_path)


def test_benchmark_runner_persists_results():
    """v5.1: BenchmarkRunner.run_all must persist results to SQLite."""
    from adonai.learning.benchmark import BenchmarkRunner, BenchmarkTask
    import tempfile, os
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name
    try:
        runner = BenchmarkRunner(
            db_path=db_path,
            benchmarks=[BenchmarkTask(id="t1", goal="hi", expected_keywords=["hi"])],
        )
        class MockRuntime:
            async def chat(self, goal):
                return "hi there"
        results = asyncio.run(runner.run_all(MockRuntime()))
        assert len(results) == 1
        # History should now have 1 entry
        history = runner.history()
        assert len(history) == 1
        summary = runner.summary()
        assert summary["total_runs"] == 1
    finally:
        os.unlink(db_path)


# ──────────────────────────────────────────────────────────────────────────────
# Config YAML has all v5 sections
# ──────────────────────────────────────────────────────────────────────────────

def test_default_yaml_has_v5_sections():
    """v5.1: config/default.yaml must contain all v5 config sections."""
    with open("config/default.yaml") as f:
        content = f.read()
    assert "self_improvement:" in content
    assert "executive_loop: true" in content
    assert "prompt_optimizer:" in content
    assert "benchmark:" in content
    assert "reflection:" in content
    assert "critic:" in content
    assert "knowledge_graph:" in content
    assert "model_router:" in content
    assert "skill_evolution:" in content
    assert "tot:" in content
    assert "strategy:" in content
    assert "simulation:" in content
