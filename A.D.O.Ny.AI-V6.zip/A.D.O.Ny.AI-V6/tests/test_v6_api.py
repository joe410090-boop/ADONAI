"""API integration tests for the v6 OpenHuman-inspired subsystem routes.

Exercises the /v6/* endpoints through FastAPI's TestClient.  No LLM is
required — the tests verify route registration, request/response shape,
and graceful 503 when a subsystem is disabled.
"""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

_PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(_PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(_PROJECT_ROOT))


@pytest.fixture
def v6_client(tmp_path):
    """A TestClient with v6 subsystems enabled, isolated to tmp_path.

    Bypasses the FastAPI lifespan (which would try to start the full
    ADONAI runtime + LLM warmup) and instead constructs the v6
    subsystems directly on the captured runtime instance.  This lets
    the tests exercise the v6 routes without needing a running LLM.
    """
    from fastapi.testclient import TestClient
    from adonai.api.server import create_app
    from adonai.config.settings import load_config
    from adonai.runtime import ADONAI

    config = load_config()
    # Point all v6 DBs at tmp_path so tests are isolated.
    config.memory_tree.db_path = tmp_path / "mt.db"
    config.memory_tree.vault_path = tmp_path / "vault"
    config.memory_tree.mirror_interval_s = 9999  # disable background loop
    config.goals_todos.db_path = tmp_path / "gt.db"
    config.workflows.db_path = tmp_path / "wf.db"
    config.graph_harness.cost_db_path = tmp_path / "costs.db"
    # Disable the subconscious tick loop so it doesn't fire during tests.
    config.subconscious.tick_interval_s = 9999
    # Disable the executive loop (it would try to call the LLM).
    config.agent.executive_loop = False
    # Disable analytics + MCP to keep startup fast.
    config.analytics.enabled = False
    config.mcp.enabled = False

    # Build the app (this constructs ai = ADONAI(config) inside create_app).
    app = create_app(config=config)

    # Extract the ADONAI instance from the route handlers' closures.
    # All the v6 route handlers close over `ai`, so we can find it by
    # scanning their __closure__ cells.
    ai = None
    for route in app.routes:
        if hasattr(route, "endpoint"):
            closure = getattr(route.endpoint, "__closure__", None) or ()
            for cell in closure:
                try:
                    if isinstance(cell.cell_contents, ADONAI):
                        ai = cell.cell_contents
                        break
                except (ValueError, AttributeError):
                    continue
        if ai is not None:
            break

    if ai is not None:
        # Manually construct the v6 subsystems (bypassing _start_impl
        # which needs the LLM).  This makes the routes return real data
        # instead of 503.
        import asyncio
        from adonai.openhuman.memory_tree import MemoryTreeService
        from adonai.openhuman.goals_todos import GoalsTodosService
        from adonai.openhuman.tokenjuice import TokenJuice
        from adonai.openhuman.workflows import WorkflowEngine
        from adonai.openhuman.graph_harness import GraphHarness
        from adonai.openhuman.split_brain import SplitBrain
        from adonai.openhuman.agent_economy import AgentEconomy
        from adonai.openhuman.super_context import SuperContext
        from adonai.openhuman.batteries import Batteries
        from adonai.openhuman.meeting_agents import MeetingAgentsService

        loop = asyncio.new_event_loop()
        try:
            ai.memory_tree = MemoryTreeService(config.memory_tree)
            ai.goals_todos = GoalsTodosService(config.goals_todos)
            ai.tokenjuice = TokenJuice(config.tokenjuice, llm=None)
            ai.graph_harness = GraphHarness(config.graph_harness, runtime=ai)
            ai.workflow_engine = WorkflowEngine(config.workflows, runtime=ai)
            ai.super_context = SuperContext(
                config.super_context,
                memory_tree=ai.memory_tree,
                workspace_root=None,
            )
            ai.batteries = Batteries(config.batteries)
            ai.split_brain = SplitBrain(
                config.split_brain, reflex_llm=None,
                deep_llm=None, deep_runtime=ai,
            )
            ai.agent_economy = AgentEconomy(config.agent_economy)
            loop.run_until_complete(ai.agent_economy.start())
            ai.meeting_agents = MeetingAgentsService(
                config.meeting_agents, llm=None,
                memory_tree=ai.memory_tree,
            )
            # Subconscious + bridge (need the LLM=None — evaluate will
            # return "skip" gracefully when no LLM is configured).
            from adonai.openhuman.subconscious import SubconsciousEngine
            from adonai.openhuman.subconscious_bridge import SubconsciousExecutiveBridge
            ai.subconscious_bridge = SubconsciousExecutiveBridge(
                config.subconscious, runtime=ai, http_endpoint=None,
            )
            ai.subconscious = SubconsciousEngine(
                config.subconscious, llm=None,
                memory_tree=ai.memory_tree, goals=ai.goals_todos,
                bridge=ai.subconscious_bridge,
            )
        finally:
            loop.close()

    # Use the client WITHOUT entering the context manager — this skips
    # the lifespan startup (which would hang on LLM warmup).  The routes
    # are all registered; they just need `ai` to have non-None v6 attrs,
    # which we set above.
    client = TestClient(app, raise_server_exceptions=False)
    try:
        yield client
    finally:
        # Clean up the v6 subsystems we constructed.
        if ai is not None:
            for attr_name in ("memory_tree", "goals_todos", "graph_harness",
                              "workflow_engine", "agent_economy",
                              "subconscious_bridge"):
                attr = getattr(ai, attr_name, None)
                if attr is not None:
                    try:
                        close = getattr(attr, "close", None) or getattr(attr, "stop", None)
                        if close is not None:
                            result = close()
                            if asyncio.iscoroutine(result):
                                loop = asyncio.new_event_loop()
                                try:
                                    loop.run_until_complete(result)
                                finally:
                                    loop.close()
                    except Exception:
                        pass
                    setattr(ai, attr_name, None)


# ──────────────────────────────────────────────────────────────────────────────
# Memory Tree
# ──────────────────────────────────────────────────────────────────────────────


class TestMemoryTreeRoutes:
    def test_ingest_search_sources(self, v6_client):
        # Ingest a chunk.
        r = v6_client.post("/v6/memory_tree/ingest", json={
            "source_kind": "chat",
            "source_id": "s1",
            "content": "The user asked about Q3 revenue.",
            "source_authority": 0.9,
        })
        assert r.status_code == 200, r.text
        assert r.json()["status"] == "ingested"
        # Rebuild the tree so search has nodes.
        r = v6_client.post("/v6/memory_tree/rebuild")
        assert r.status_code == 200
        assert r.json()["nodes_created"] >= 1
        # Search.
        r = v6_client.get("/v6/memory_tree/search", params={"q": "revenue", "k": 5})
        assert r.status_code == 200
        data = r.json()
        assert data["query"] == "revenue"
        assert len(data["hits"]) >= 1
        # Sources.
        r = v6_client.get("/v6/memory_tree/sources")
        assert r.status_code == 200
        assert len(r.json()["sources"]) >= 1
        # Entities.
        r = v6_client.get("/v6/memory_tree/entities", params={"k": 5})
        assert r.status_code == 200
        # Mirror.
        r = v6_client.post("/v6/memory_tree/mirror")
        assert r.status_code == 200
        assert r.json()["files_written"] >= 1

    def test_recall(self, v6_client):
        v6_client.post("/v6/memory_tree/ingest", json={
            "source_kind": "email", "source_id": "e1",
            "content": "Q3 revenue was $2.4M.", "source_authority": 0.8,
        })
        v6_client.post("/v6/memory_tree/rebuild")
        r = v6_client.get("/v6/memory_tree/recall", params={"q": "revenue", "k": 3})
        assert r.status_code == 200
        assert len(r.json()["hits"]) >= 1


# ──────────────────────────────────────────────────────────────────────────────
# Goals & Todos
# ──────────────────────────────────────────────────────────────────────────────


class TestGoalsRoutes:
    def test_create_list_update_delete(self, v6_client):
        # Create a long-term goal.
        r = v6_client.post("/v6/goals", json={"title": "Ship v6", "scope": "long_term"})
        assert r.status_code == 200, r.text
        gid = r.json()["id"]
        # List long-term goals.
        r = v6_client.get("/v6/goals", params={"scope": "long_term"})
        assert r.status_code == 200
        assert any(g["id"] == gid for g in r.json()["goals"])
        # Update status.
        r = v6_client.patch(f"/v6/goals/{gid}", json={"status": "doing"})
        assert r.status_code == 200
        # Delete.
        r = v6_client.delete(f"/v6/goals/{gid}")
        assert r.status_code == 200

    def test_kanban_board(self, v6_client):
        # Create two kanban cards.
        v6_client.post("/v6/goals", json={
            "title": "Task A", "scope": "kanban",
            "session_id": "sess-1", "status": "backlog",
        })
        v6_client.post("/v6/goals", json={
            "title": "Task B", "scope": "kanban",
            "session_id": "sess-1", "status": "doing",
        })
        r = v6_client.get("/v6/goals", params={"scope": "kanban", "session_id": "sess-1"})
        assert r.status_code == 200
        board = r.json()["board"]
        assert len(board["backlog"]) == 1
        assert len(board["doing"]) == 1


# ──────────────────────────────────────────────────────────────────────────────
# Workflows
# ──────────────────────────────────────────────────────────────────────────────


class TestWorkflowRoutes:
    GRAPH = {
        "nodes": {
            "t": {"id": "t", "kind": "trigger", "next": ["n1"]},
            "n1": {"id": "n1", "kind": "agent", "next": []},
        },
    }

    def test_propose_validate_create_list(self, v6_client):
        # Propose (validate only).
        r = v6_client.post("/v6/workflows/propose", json={
            "name": "My Flow", "description": "test", "graph": self.GRAPH,
        })
        assert r.status_code == 200, r.text
        assert r.json()["valid"] is True
        # Create.
        r = v6_client.post("/v6/workflows", json={
            "name": "My Flow", "description": "test", "graph": self.GRAPH,
            "enabled": True, "require_approval": True,
        })
        assert r.status_code == 200
        wf_id = r.json()["id"]
        # List.
        r = v6_client.get("/v6/workflows")
        assert r.status_code == 200
        assert any(w["id"] == wf_id for w in r.json()["workflows"])
        # Get.
        r = v6_client.get(f"/v6/workflows/{wf_id}")
        assert r.status_code == 200
        assert "nodes" in r.json()
        # Delete.
        r = v6_client.delete(f"/v6/workflows/{wf_id}")
        assert r.status_code == 200

    def test_propose_rejects_invalid_graph(self, v6_client):
        r = v6_client.post("/v6/workflows/propose", json={
            "name": "Bad", "description": "", "graph": {"nodes": {
                "n1": {"id": "n1", "kind": "agent", "next": []},
            }},
        })
        assert r.status_code == 200
        assert r.json()["valid"] is False


# ──────────────────────────────────────────────────────────────────────────────
# Subconscious
# ──────────────────────────────────────────────────────────────────────────────


class TestSubconsciousRoutes:
    def test_status_tasks_activity(self, v6_client):
        r = v6_client.get("/v6/subconscious/status")
        assert r.status_code == 200
        assert "running" in r.json()
        # Tasks — should have the 4 default system tasks.
        r = v6_client.get("/v6/subconscious/tasks")
        assert r.status_code == 200
        assert len(r.json()["tasks"]) >= 4
        # Activity log.
        r = v6_client.get("/v6/subconscious/activity")
        assert r.status_code == 200
        assert "activity" in r.json()

    def test_add_delete_task(self, v6_client):
        r = v6_client.post("/v6/subconscious/tasks", json={
            "id": "test_task", "title": "Test task", "intent": "read",
        })
        assert r.status_code == 200
        # Delete.
        r = v6_client.delete("/v6/subconscious/tasks/test_task")
        assert r.status_code == 200


# ──────────────────────────────────────────────────────────────────────────────
# Briefing
# ──────────────────────────────────────────────────────────────────────────────


class TestBriefingRoute:
    def test_briefing_returns_string(self, v6_client):
        r = v6_client.get("/v6/briefing")
        assert r.status_code == 200
        assert "briefing" in r.json()


# ──────────────────────────────────────────────────────────────────────────────
# Split Brain
# ──────────────────────────────────────────────────────────────────────────────


class TestSplitBrainRoutes:
    def test_triage(self, v6_client):
        r = v6_client.post("/v6/split_brain/triage", json={"message": "hello"})
        assert r.status_code == 200, r.text
        assert r.json()["verdict"] in ("reply_now", "hand_to_deep", "drop")

    def test_set_directive(self, v6_client):
        r = v6_client.post("/v6/split_brain/directive", json={"text": "Focus on security"})
        assert r.status_code == 200
        assert r.json()["status"] == "set"


# ──────────────────────────────────────────────────────────────────────────────
# SuperContext
# ──────────────────────────────────────────────────────────────────────────────


class TestSuperContextRoute:
    def test_sweep(self, v6_client):
        r = v6_client.post("/v6/super_context/sweep", json={"message": "test query"})
        assert r.status_code == 200, r.text
        data = r.json()
        assert "prompt" in data
        assert "tokens_estimated" in data
        assert "elapsed_ms" in data


# ──────────────────────────────────────────────────────────────────────────────
# TokenJuice
# ──────────────────────────────────────────────────────────────────────────────


class TestTokenJuiceRoutes:
    def test_compress_and_stats(self, v6_client):
        long_text = "The quick brown fox. Lazy dog. " * 50
        r = v6_client.post("/v6/tokenjuice/compress", json={
            "text": long_text, "strategy": "extractive",
        })
        assert r.status_code == 200, r.text
        assert "compressed" in r.json()
        assert len(r.json()["compressed"]) < len(long_text)
        # Stats.
        r = v6_client.get("/v6/tokenjuice/stats")
        assert r.status_code == 200
        assert r.json()["total_inputs"] >= 1


# ──────────────────────────────────────────────────────────────────────────────
# Agent Economy
# ──────────────────────────────────────────────────────────────────────────────


class TestAgentEconomyRoutes:
    def test_status(self, v6_client):
        r = v6_client.get("/v6/agent_economy/status")
        assert r.status_code == 200, r.text
        data = r.json()
        assert data["enabled"] is True
        assert data["handle"] == "adonai@tiny.place"

    def test_pairings_list(self, v6_client):
        r = v6_client.get("/v6/agent_economy/pairings")
        assert r.status_code == 200
        assert "pairings" in r.json()

    def test_bounties_list(self, v6_client):
        r = v6_client.get("/v6/agent_economy/bounties")
        assert r.status_code == 200
        assert "bounties" in r.json()


# ──────────────────────────────────────────────────────────────────────────────
# Meeting Agents
# ──────────────────────────────────────────────────────────────────────────────


class TestMeetingRoutes:
    def test_schedule_list_status(self, v6_client):
        r = v6_client.post("/v6/meetings", json={
            "id": "m1", "platform": "meet", "url": "https://meet.google.com/abc",
            "title": "Standup", "start_at": 1700000000000,
        })
        assert r.status_code == 200, r.text
        # List.
        r = v6_client.get("/v6/meetings")
        assert r.status_code == 200
        assert any(m["id"] == "m1" for m in r.json()["meetings"])
        # Status.
        r = v6_client.get("/v6/meetings/status")
        assert r.status_code == 200


# ──────────────────────────────────────────────────────────────────────────────
# Batteries
# ──────────────────────────────────────────────────────────────────────────────


class TestBatteriesRoutes:
    def test_status(self, v6_client):
        r = v6_client.get("/v6/batteries/status")
        assert r.status_code == 200, r.text
        data = r.json()
        assert "privacy_mode" in data
        assert "whisper_available" in data

    def test_privacy_mode_toggle(self, v6_client):
        r = v6_client.post("/v6/batteries/privacy_mode", json={"enabled": True})
        assert r.status_code == 200
        assert r.json()["privacy_mode"] is True
        r = v6_client.post("/v6/batteries/privacy_mode", json={"enabled": False})
        assert r.status_code == 200
        assert r.json()["privacy_mode"] is False


# ──────────────────────────────────────────────────────────────────────────────
# Bridge
# ──────────────────────────────────────────────────────────────────────────────


class TestBridgeRoute:
    def test_recent(self, v6_client):
        r = v6_client.get("/v6/bridge/recent")
        assert r.status_code == 200, r.text
        assert "entries" in r.json()


# ──────────────────────────────────────────────────────────────────────────────
# Graph Harness
# ──────────────────────────────────────────────────────────────────────────────


class TestGraphHarnessRoutes:
    def test_run_and_replay(self, v6_client):
        r = v6_client.post("/v6/graph/run", json={"goal": "test", "max_steps": 1})
        assert r.status_code == 200, r.text
        run_id = r.json()["run_id"]
        # Replay.
        r = v6_client.get(f"/v6/graph/runs/{run_id}")
        assert r.status_code == 200
        assert r.json()["run"]["id"] == run_id

    def test_list_runs(self, v6_client):
        r = v6_client.get("/v6/graph/runs")
        assert r.status_code == 200
        assert "runs" in r.json()
