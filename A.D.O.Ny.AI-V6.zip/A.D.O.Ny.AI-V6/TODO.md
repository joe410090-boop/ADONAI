# Potential Issues Fixes — Progress

## Issue 1: Config workspace directory not created in `ensure_dirs()`
- [x] `adonai/config/settings.py` — Add workspace dir to `ensure_dirs()`

## Issue 2: `ModelRouterConfig.tiers` formatting cleanup
- [x] `adonai/config/settings.py` — Clean up extra whitespace in tiers field

## Issue 3: LearningLoop `_task_count` not incremented for simple tasks
- [x] `adonai/learning/loop.py` — Add `self._task_count += 1` before early return in `_process()`

## Issue 4: Unbounded rate limit bucket growth in API server
- [x] `adonai/api/server.py` — Add cleanup mechanism for stale rate-limit entries

## Issue 5: `type` column name is SQL reserved word — ensure proper escaping
- [x] `adonai/memory/sqlite_store.py` — Ensure column name `type` is properly escaped throughout

## Issue 6: Inconsistent DB connection patterns in ConversationStore
- [x] `adonai/executors/conversation_store.py` — Add connection pooling

## Issue 7: Rate limiting middleware initialization inside function scope
- [x] `adonai/api/server.py` — Move `_rate_buckets` and `_time_mod` to proper scope

## Issue 8: Verify workspace config path
- [x] `config/default.yaml` — Ensure workspace path is correct

## Issue 9: Move inline imports to module level
- [x] Various files — Move imports to module level where appropriate

## Issue 10: EventPublisher class-level vs instance-level _event_bus shadowing
- [x] `adonai/core/events.py` — Simplify the property override logic
